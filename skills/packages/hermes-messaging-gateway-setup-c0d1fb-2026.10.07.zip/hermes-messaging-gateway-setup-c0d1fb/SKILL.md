---
name: hermes-messaging-gateway-setup
description: "Connect Hermes to a messaging platform (WeChat, QQ, Telegram)."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, gateway, messaging, wechat, weixin, qq, qqbot, telegram, setup, qr]
---

# Hermes Messaging Gateway Platform Setup

Connect Hermes to a messaging platform through the interactive gateway setup. This skill captures the reusable mechanics of driving the wizard and handling scan-to-login (QR) flows — the parts that are platform-agnostic.

> The `hermes-agent` bundled skill is the authoritative feature reference. This skill fills the gap the bundled hub skill does not cover well: actually *driving* the interactive setup over a background PTY and handling QR-rendering fallbacks.

## When to use
- User says "connect my WeChat/Telegram/WhatsApp/..." to Hermes.
- Any task that runs `hermes gateway setup` and requires driving an interactive menu.
- Any scan-to-login (QR) platform (Weixin/WeChat personal, WeCom, Telegram via code, etc.).

## Prereqs & health check (before driving the wizard)
1. `hermes gateway status` — confirm gateway state. "not running" is fine; it must not be half-configured.
2. **Platform adapter present** — confirm the adapter file exists in the source tree (e.g. `gateway/platforms/weixin.py`) rather than assuming.
3. **Python deps installed** for that adapter. Weixin/WeChat needs `aiohttp` + `cryptography`. Check with the project's python (not system python): `cd hermes-agent && ./venv/Scripts/python -c "import aiohttp, cryptography"` (Unix: `./venv/bin/python`). If missing, install into the venv with the project's package manager (`uv pip install -e ".[messaging]"` from inside the venv, or `uv pip install aiohttp cryptography`).
4. **QR renderer is Python `qrcode`** — if it's missing the wizard prints a fallback URL (see below). You do NOT need to install it to proceed.

## Driving the interactive wizard
`hermes gateway setup` is a curses menu, so it must run in a pty. Run it in the background with a real terminal:

```bash
terminal(command="hermes gateway setup", background=true, pty=true)
```

Then drive it with `process(action=submit, data=...)` — always **submit** (appends Enter, the only reliable line terminator on a Windows PTY), never `write` with a bare `\n`. Read progress with `process(action=wait)` / `process(action=log)`, not a blind sleep.

> **Gotcha — never pipe the wizard through `| head` / `| tail`.** The pty command must run bare (`background=true, pty=true`, no pipe). Piping makes `head` wait for EOF forever while the curses wizard never exits, so the process hangs open — it looks like "nothing happened". Kill it and re-run bare; the bare run renders the menu fine. (`hermes gateway setup 2>&1 | head -80` → hung; killing the session and re-running without the pipe works.) Also: the Chinese characters in this menu are NOT mojibake in this build — they render correctly.

### Install a platform's adapter deps into the venv (uv, not pip)
Before driving the wizard, install the platform's extra into the project venv. The wizard checks for the adapter's SDK/QR deps. Use uv with the **Windows native path** — an MSYS path (`/e/...`) is rejected with "No virtual environment found":
```bash
cd /e/软件/Hermes/hermes-agent \
  && uv pip install --python "E:\\软件\\Hermes\\hermes-agent\\venv\\Scripts\\python.exe" <dep>...
```
The venv often has **no pip** (`venv/Scripts/python -m pip` → "No module named pip"), so uv is the only way in. (Weixin needs `aiohttp`+`cryptography`; Feishu needs `lark-oapi`+`qrcode` — see the platform section below.)

Menu navigation pattern (loop of read-wait → submit):
1. `wait` for the menu to render, note the **platform's number** in the list (e.g. Weixin settled at `3` in one build; do NOT hard-code — read the rendered label like "💬 Weixin / WeChat").
2. `submit` the number, then the confirmation prompt (e.g. "Start QR login now? [Y/n]:") → `submit` `Y`.
3. `wait` for the QR payload or a success/error line.

> **Gotcha — the rendered menu is often paged/truncated.** The first `wait` frequently shows only a clipped slice (e.g. items 7–28 with "28. Done" at the end). A platform's number can sit **above that crop**: QQ was item `5`, below the half-screen cutoff and invisible until you capture the menu *start*. Before choosing, re-poll (`process wait`/`log`) or read the whole menu so the number comes from the actual top — never assume the target is the last visibly-numbered row.

> **Gotcha — the wizard chains its own multi-Y restart prompt list.** After a platform is configured, `hermes gateway setup` asks, in sequence: "Restart the gateway to pick up changes? [Y/n]:" → (if not installed) "Install it now so the gateway starts on login? [Y/n]:" → "Start the gateway now after install? [Y/n]:" → "Start the gateway automatically on Windows login with a Scheduled Task? [Y/n]:" → "Open the UAC prompt now? [y/N]:". Each is a `submit Y`; only the final one (UAC) needs the user to click the Windows admin prompt. If the scheduled-task branch fails on a non-admin/non-ASCII home, it silently falls back — see the auto-start section before trusting the "installed" line.

## QR login flows — and the `qrcode` fallback
When a platform requests scan-to-login (Weixin/WeChat personal is the common case):
- The wizard calls the platform's QR endpoint (e.g. Tencent iLink) and renders it via the Python `qrcode` module.
- **If `qrcode` is missing** the wizard prints a line like:
  `（终端二维码渲染失败: No module named 'qrcode'，请直接打开上面的二维码链接）` and prints the raw login URL (e.g. `https://liteapp.weixin.qq.com/q/<id>?qrcode=<token>&bot_type=3`).
- **Reliable path when terminal rendering fails:** open that raw URL in the desktop preview pane (`desktop_preview action=open url=...`) so the user can scan it with their phone's camera/"扫一扫". Or hand the URL to the user to open in the platform's mobile app.
- Do **not** spend turns installing `qrcode`. The URL is the correct, sufficient fallback. (If you do want to install it: use the venv's package manager — bare `uv pip install qrcode` failed in this workspace because it couldn't resolve the venv, and `venv/Scripts/python -m pip` had no pip. The URL path sidesteps all of it.)

After scan + confirm on the phone, the wizard stores credentials automatically. Poll `wait` until you see a success line (Weixin: "微信连接成功，account_id=..." type message) and the process exits or returns to the menu.

## Credentials stored (where to look)
- Scan/login creds go to the adapter's own dir (Weixin: `~/.hermes/weixin/accounts/`), and the `account_id`/`token` are written to `~/.hermes/.env` as e.g. `WEIXIN_ACCOUNT_ID=...`, `WEIXIN_TOKEN=...`.
- Access-control env vars set *after* login (Weixin: `WEIXIN_DM_POLICY=open`, `WEIXIN_ALLOWED_USERS=...`). Set them only after the account is configured.

## After setup
- Start the gateway: `hermes gateway run` (foreground) or `hermes gateway install` (Windows Scheduled Task / auto-start on login). Then verify with `hermes gateway status`.
- Start a **new session** so the platform's system-prompt block and tools take effect; gateway sessions don't inherit the currently-running chat.

## "All platforms suddenly unreachable" — the gateway PROCESS is down (distinct from platform disconnect)

When the user says "飞书/QQ/微信链接稳吗" / "都连不上了", the FIRST thing to check is not per-platform config — it's whether the **gateway process itself is running**. A dead gateway makes every platform look unreachable.

1. `hermes gateway list` — if EVERY profile shows `not running` (default included), the gateway process is DOWN. This is the root cause, not a platform flake.
2. Confirm the process is really gone: `Get-Process -Id <pid>` returns nothing, and `hermes gateway status` shows no running process.
3. Fix: `hermes gateway start` → returns `✓ Gateway started via direct spawn (PID …)`. Then `hermes gateway status` shows the process running.
4. **Verify liveness by actually sending, not by log-grepping (this is the fast path).** `hermes send --list` shows every configured target as `platform:chat_id` (feishu:oc_…, qqbot:B44…, weixin:o9…@im.wechat). Then send a test to each: `hermes send --to "weixin:o9…@im.wechat" "【链路测试】..."`. Each returns `sent` = that platform is live. All three `sent` = fully restored. (`hermes send --list` rendering a target means the creds are registered; a `sent` response proves the live path.)
5. Confirm auto-start is still registered: `Get-ScheduledTask -TaskName Hermes_Gateway` → `Ready` (so it comes back on boot, not just this session). A gateway that silently dies is the recurring "链接不稳" cause — if it happens again, re-run `hermes gateway start` and consider why it stopped.

Note: `hermes send --list` shows ALL targets even when the gateway was down (it reads config, not liveness) — so seeing targets in `--list` does NOT mean the platforms are live. Only a `sent` response after a test send proves the platform is connected. Distinguish "config present" from "actually delivering."

## "Is it actually connected?" — boot-time discovery + the `send --list` trap

Users frequently say "我接好了，链接成功了吗?" after configuring a platform. Config being writable is NOT the same as the platform being live. Three facts to check before you answer:

1. **Platforms are discovered ONCE at gateway startup, never hot-loaded.** The gateway reads `.env` and builds its platform list when the process boots. Adding a platform's creds to `.env` while the gateway is running does NOT load it — the running gateway never sees the new platform until it restarts. So a platform you just configured via `hermes gateway setup` will have no connection log line at all until you restart the gateway.
2. **`hermes send --list` is a CONFIG listing, not a LIVE check.** It enumerates platforms from `.env` (`load_gateway_config().get_connected_platforms()`), and shows "no channels discovered yet" for any platform that is configured but has no channel entry. It does NOT prove the running gateway loaded or connected that platform. Seeing `Qqbot:` in the list only tells you the env vars are present.
3. **To verify a platform is actually LIVE, read the gateway log**, not `send --list`.

### How to verify a platform actually connected
- Find the gateway log: `logs/gateway.log` under `$HERMES_HOME` (e.g. `E:\软件\Hermes\logs\gateway.log`).
- Grep for the platform's connect marker + the boot summary:
  - **QQ** (`QQ开放平台 qBOT`): `[QQBot:<app_id>] WebSocket connected to wss://api.sgroup.qq.com/websocket` → `[QQBot:<app_id>] Connected` → `[QQBot:<app_id>] Ready, session_id=…`. Also `✓ qqbot connected` and `Gateway running with 2 platform(s)`.
  - **Weixin**: `[Weixin] Connected account=<term>`.
  - **Feishu/Lark**: `✓ feishu connected`, `[Feishu] Connected in websocket mode (feishu)`, plus the Lark SDK's own `connected to wss://msg-frontier.feishu.cn/ws/v2?...` line. All three in `logs/gateway.log` = live.
  - The boot summary `Gateway running with N platform(s)` tells you how many loaded.
- If a platform's app_id/name appears in `.env` but there is NO corresponding `Connected` line in the log, the gateway did not load it — restart the gateway.

### Restarting so a newly-configured platform takes effect
`hermes gateway restart` is the normal path. On a manually-spawned gateway (not a registered service) `hermes gateway status` may report "not running" and `restart` walks you into the interactive install prompt (Scheduled Task → UAC → Startup-folder VBS fallback). The direct spawn path (`✓ Gateway started via direct spawn …`) works even on the non-ASCII path. After restart, re-run the log grep above to confirm the new platform reached `Connected` / `Ready`, and confirm Weixin also reconnected (its `[Weixin] Connected account=…` marker reappears).

## QQ (QQ开放平台 qBOT) — platform specifics
- Adapter: `gateway/platforms/qqbot/` (adapter.py, plus onboard.py for the QR scan-to-configure flow).
- Credentials in `.env`: `QQ_APP_ID`, `QQ_CLIENT_SECRET`, `QQ_ALLOWED_USERS` (allowlist), `QQ_ALLOW_ALL_USERS`, `QQBOT_HOME_CHANNEL`.
- Transport: gets an access token from `QQ_APP_ID`+`QQ_CLIENT_SECRET`, then holds a long-lived WebSocket to `wss://api.sgroup.qq.com/websocket`. On connect it logs `Access token refreshed` → `Gateway URL: wss://api.sgroup.qq.com/websocket` → `WebSocket connected` → `Identify sent` → `Ready, session_id=…`.
- **qBOT is session/channel-based**: the channel directory stays empty ("no channels discovered yet") until someone actually messages the bot. A live WebSocket + `Ready` is the correct success signal; an empty channel list is NORMAL and does NOT mean it failed.
- Onboarding flow: `qr_register()` hits `q.qq.com` create-bind-task / poll-bind-result; on scan you get the scanner's `user_openid`, which is the value written to `QQ_ALLOWED_USERS` and `QQBOT_HOME_CHANNEL`.
- See [references/qqbot-setup-verification.md](references/qqbot-setup-verification.md) for the real transcript and exact config keys.

### Chinese voice transcription (STT) on QQ
Voice messages auto-transcribe via the `stt` config. A message arriving as `[Voice] <text>` = working; bare `[Voice]` (no transcript) = STT not wired. The common Chinese miss is the top-level `stt.language` defaulting to `en` — pin it to `zh`. Full fix (faster-whisper dep, `hermes config set` keys, verification): see [references/qq-voice-stt.md](references/qq-voice-stt.md).

### Group-chat support (answer @-mentions in a QQ group)
The qBOT adapter also handles group messages. It triggers only when someone **@-mentions** the bot (`GROUP_AT_MESSAGE_CREATE` → `_handle_group_message`), and replies go to `/v2/groups/{group_openid}/messages`. Access is gated by `platforms.qq.extra.group_policy` (`open|allowlist|disabled|pairing`, default `pairing`) plus `group_allow_from`. To enable: enable the bot's group capability + add it to the group (QQ开放平台 side), set `group_policy` via `hermes config set`, then **restart the gateway** to load the ACL. Full detail: [references/qqbot-group-support.md](references/qqbot-group-support.md).

## Feishu / Lark — platform specifics
- Adapter: `gateway/platforms/feishu*`; officially supported and **full-featured** (Voice / Images / Files / Threads / Reactions / Typing / Streaming all ✅).
- Deps (pyproject extra `feishu`): `lark-oapi==1.6.8` + `qrcode==7.4.2`. `lark-oapi` = Feishu SDK (WebSocket client); `qrcode` renders the on-device QR. **Install into the venv with uv + Windows native path** (see wizard-driving section) before running the wizard.
- Credentials in `.env`: `FEISHU_APP_ID`, `FEISHU_APP_SECRET`, `FEISHU_DOMAIN=feishu` (feishu=China / lark=international), `FEISHU_CONNECTION_MODE=websocket` (recommended, no public webhook needed), optional `FEISHU_ALLOWED_USERS=ou_xxx,...`, `FEISHU_HOME_CHANNEL=oc_xxx`.
- **Wizard submenu**: after selecting "🪽 Feishu / Lark", it asks `How would you like to set up Feishu / Lark?` — option `1. Scan QR code to create a new bot automatically (recommended)` is the default (just Enter); `2. Enter existing App ID and App Secret manually` is the manual path.
- **Scan with the Feishu/Lark mobile app** (not WeChat), then approve the on-phone "create app" prompt. The wizard prints a real scannable QR **and** a one-time launcher URL `https://open.feishu.cn/page/launcher?user_code=…&from=hermes&tp=hermes` — use the URL as the desktop-preview fallback if the terminal QR is hard to scan. The link is time-limited; the user must scan promptly.
- **Post-scan question chain (drive it, don't stall).** After the user scans and approves on-phone, the wizard does NOT exit on its own — it asks (defaults are the safe pick, just Enter): (1) `How should direct messages be authorized?` → `1. Use DM pairing approval (recommended)`; (2) `How should group chats be handled?` → `1. Respond only when @mentioned in groups (recommended)`; then (3) returns to the platform menu and prompts `Restart the gateway to pick up changes? [Y/n]:` → `Y`. **DM pairing means the first real DM from the user needs `hermes pairing approve` before the bot answers.** Concrete approve + verify workflow (applies to ANY DM-pairing platform — Feishu, QQ, etc.):
  1. Have the user send a real message to the bot from their phone/desktop first — a pending request only exists after an actual inbound DM (the bot DMs a pairing code). Then run `hermes pairing list`; a pending row shows `Platform | Request ID | User ID | Name | Age`.
  2. Approve with `hermes pairing approve <platform> <request-id>` (e.g. `hermes pairing approve feishu 58c3...`). Output: `Approved! User ou_... on feishu can now use the bot~`.
  3. **Verify, don't trust the line.** Re-run `hermes pairing list`: it should show `No pending pairing requests.` and the approved user under `Approved Users (1)`. Then re-confirm the gateway is still alive (`hermes gateway status`) and the platform still connected (grep `logs/gateway.log` for the connect marker). Only report success when all three hold.
  Trap: `hermes pairing approve` with no pending request fails — the request is created by the user's first real DM, so if `pairing list` shows nothing, the user hasn't messaged the bot yet, or the platform never delivered the DM. Don't approve-and-assume.
- **The post-scan stall is a trap, not a failure.** After scanning, the wizard can sit on `Fetching configuration results.....` for 2–5 minutes while it secretly already completed and advanced. Do NOT poll-and-conclude "stuck" early — run `process(action=log)` (full output), not just `poll`, and look DOWN the output: if you see `✓ Bot created: Hermes` and the DM-authorization question, it worked and is waiting for your input.
- **The menu still shows `(not configured)` after success — ignore it.** After a successful Feishu bind, the platform list keeps rendering `12. 🪽 Feishu / Lark (not configured)` even though creds landed. The list is a stale refresh, not a status. Verify success by grepping `.env` for `FEISHU_APP_ID`/`FEISHU_APP_SECRET` AND the gateway log (below) — never by the list display.
- Group behavior: responds to @-mentions in group chats (bot must be mentioned); per-user session isolation by default (`group_sessions_per_user: true`).
- See [references/feishu-setup-walkthrough.md](references/feishu-setup-walkthrough.md) for the exact menu numbers, submit sequence, QR URL format, and expected `.env` keys.

## Windows auto-start: the non-ASCII-HERMES_HOME trap (read before relying on it)
`hermes gateway install` on Windows registers a Scheduled Task (`schtasks` ONLOGON), but **only if it can elevate**. On a non-admin account it is blocked by UAC ("Open the UAC prompt now? [y/N]" → skipped) and silently **falls back to the Startup-folder VBS**. That VBS/BAT path **breaks when `HERMES_HOME` contains non-ASCII characters** (e.g. `E:\软件\Hermes`): CMD and WScript decode the path as GBK/ANSI, so every launcher fails with `系统找不到指定的文件` / `'xxx' is not recognized`, and the gateway never comes up at login — while `hermes gateway status` still shows the login item as "installed". Do not trust the "installed" line; trigger the launcher from a stopped gateway to prove it works.

**Root causes confirmed** (not guesses): a) `cmd /c "中文路径.exe 加参数"` → "not recognized as an internal or external command" (quote+arg misparse); b) VBS `sh.Run` with a quoted Chinese path + args misparses the dir; c) PowerShell 5.1 reads a **no-BOM** `.ps1` as ANSI/GBK, so `$HERMES_HOME="E:\软件\Hermes"` becomes null — a `.ps1` must be saved **UTF-8 with BOM** (`utf-8-sig`); (the **reverse** holds for `.bat`: a `.bat` containing Chinese must be **GBK/ANSI 936** + `chcp 936` + CRLF — a UTF-8-encoded `.bat` renders every Chinese line as 乱码 on Chinese Windows CMD); d) `schtasks /Create` from a non-admin shell returns `ERROR: Access is denied.` — no elevation, no scheduled task, no way around it from here.

**The reliable fix that needs no admin and survives the Chinese path — registry Run key + Python launcher:**
1. Write a pure-stdlib Python launcher (no 3rd-party deps) that shells out to the venv `hermes.exe`:
   `subprocess.Popen([hermes_exe, "gateway", "start"], cwd=HERMES_HOME, stdin=DEVNULL, stdout=DEVNULL, stderr=DEVNULL, creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))`.
   Python handles the Unicode path natively — no shell parsing involved.
2. Register it under `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` via `winreg.SetValueEx(key,"HermesGateway",0,winreg.REG_SZ, value)` where `value = '"<venv>\pythonw.exe" "<script>.py"'`. The Run key stores a Unicode string and Windows launches it with `CreateProcess` (not via cmd/VBS), so the Chinese path is never mangled.
3. Set launcher env: `HERMES_HOME`, `HERMES_GATEWAY_DETACHED=1`, `PYTHONIOENCODING=utf-8`, `HERMES_ACCEPT_HOOKS=1` (in the launcher `os.environ`).
4. **Verify from a stopped gateway**: `hermes gateway stop` → run the launcher (via python) → `hermes gateway status` shows running. Delete the deprecated Startup VBS so it can't confuse `gateway status`.

If you can register a real scheduled task (admin session), prefer it; otherwise the Run-key + Python launcher is the fallback that actually works. On a fully non-admin, non-ASCII install it is the correct end state.

Harmless Windows noise to ignore: a `start_unix_server` / `shutdown_watchdog` `AttributeError: module 'asyncio' has no attribute 'start_unix_server'` traceback at startup — Windows has no Unix-domain sockets, so the liveness watchdog just can't run; it does not stop the gateway from accepting/delivering messages.

## 让主机重启一次，并确认 agent 会自己回来（2026-09-23 实操）

十一 会直接说「重启一下电脑」，然后真正关心的是两件事：**重启后你还在吗 / 你会不会自己回来**。按这个顺序做：

1. **先证明自启链路真的在，别口头保证。** 本机实测存在**三重自启**（任何一个生效就够，三个都在 = 更稳）：
   - 启动文件夹 `…\Startup\Hermes_Gateway.vbs`
   - 注册表 Run 键 `HermesGateway` → `hermes_gateway_autostart.py`（Python 启动器，见上文非 ASCII 路径那一节）
   - 计划任务 `\Hermes_Gateway`（`Get-ScheduledTask -TaskName Hermes_Gateway` → `Ready`）
   回答「重启后你还在吗」时**把这三条列出来**（各自位置 + 哪条是这台机器上真正在起作用的），比一句「会回的」有用得多。
2. **重启前扫一遍「用户会丢什么」并点名提醒。** 至少两项：
   - **Excel 锁文件**：`glob('**/~$*.xlsx')` —— 扫到就是有表格正开着，提醒他先保存（本会话真扫到一个）。
   - 会断的东西：所有 Chrome 窗口被关（正在跑的浏览器自动化中断）、桌面分身窗口需重开、未保存文件丢失。
   - 定时任务（cron）**不受影响**，重启后照常触发 —— 这句要主动说，否则他会担心漏采。
3. **挂一个「重启后报信」的一次性任务，让恢复可见。** 光说「我会回来」不算交付：
   `cronjob(create, name='重启后报信', schedule='in 5m', repeat=1, no_agent=True, deliver=<用户所在平台>, script='reboot_ping.py')`
   脚本内容 = 往用户的 QQ/微信发一条「✅ 电脑已重启完成，我回来了」。**它到点没发出来 = 自启失败**，
   用户不用来问你就能判断；你也因此有了一个**可证伪**的验证点（而不是事后靠猜）。
4. ⚠️ **`shutdown.exe` 由 agent 发起时可能被系统授权确认弹窗拦下（= 未执行）。** 别在这上面耗轮次 ——
   直接把一行命令交给用户：`Win+R` → `shutdown /r /t 60`（反悔 `shutdown /a`）。他执行一次，你继续干别的。
5. **重启后回到会话时**，按上文「How to verify a platform actually connected」grep `logs/gateway.log` 的
   `Connected` / `Ready` 标记 + `hermes gateway status`，确认三个平台都回来了再汇报（别只报「我在了」）。

## Pushing computer→phone notifications (after a platform is connected)
Once a platform is configured, you can proactively message the user from the
computer/agent side without an LLM round-trip, via `hermes send`:
- `hermes send --list` → shows every configured target as `platform:chat_id`
  (e.g. `weixin:o9cq...@im.wechat`); greedy the platform's DM chat_id from here.
- Send: `hermes send --to "weixin:<chat_id>" "message"` (or `echo ... | hermes send ...`,
  or `--file /tmp/msg.md` for a body, or `MEDIA:/path` for an attachment).
- Feedback: only specify `--to` as a bare platform when a home channel is set;
  otherwise pass the full `platform:chat_id`. Errors like "No home channel set for
  weixin" mean target it explicitly.
- Exit codes: 0 ok / 1 delivery-error / 2 usage-error. `sent` printed = delivered.
- Reuses the gateway's stored creds; no running gateway or LLM needed for
  bot-token platforms. Use for "tell me on my phone when X needs me", "电脑端要
  指令时发我微信" type standing requests — pair with a hook/cron trigger if the
  user wants it automatic at specific events.

### ─ 推给用户的报表被“吃”了一半？先查这三条排版陷阱
Outbound text is run through `format_message` (`_normalize_markdown_blocks` + `_wrap_copy_friendly_lines_for_weixin`) and treated as markdown-ish, so a few shapes silently destroy a pushed report (踩过的坑，2026-09-17):
- **纯连字符分隔线 `--------` 会命中表格分隔行正则** `^\s*:?-{3,}:?\s*$` (`agent/markdown_tables.py` `_DIVIDER_CELL_RE`) → 整条消息被当表格重解析，**用户只看到前一两行，后面全没了**。用带空格的 `- - - - - - - -`（不匹配）。
- **`1. ` 编号被当 markdown 有序列表**重排/加缩进 → 用 `1)`。
- **宽字符连用**（`━` U+2501、`▇` 连十几个）在手机上撑爆折行 → 条形图字符每行控制 2~8 个。

验证方式：用 `cronjob action='run'` 真推一条，**或读 cron output 文件看原文**；不要只凭 `sent` 就以为用户看到的是你写的样子。另外：cron `no_agent` 的 stdout 是逐字投递（空 stdout = 静默，非零退出 = 错误告警），所以脚本自己排好版就够了，不需要 agent 润色。

**推完以后，用户那句短反馈怎么接（同样踩过）**
- 排版/口径**每次改动都要真推一条再交付**。本地脚本打印得好 ≠ 微信里长这样——上面三条陷阱只在真投递时暴露。
- 「**很乱**」→ 排版问题（宽字符 / markdown 误判）→ 往窄字符 + 安全分隔线改。
- 「**不是这个数据**」→ 有两种解读，**直接给 2 个选项让他选**（①板块加错了 → 删掉 ②数字/口径不对 → 问哪个店哪个数），**别猜**。猜错要返工一整轮。
- 他**把自己的改稿贴回来**（例：把"本月"改成"本月当前"、删掉日期范围）→ 那**就是定稿文案，照抄**，不要自作主张加回自己认为更好的写法。
- 他贴回一整段推送文本时，**先 diff 他的版本 vs 当前输出**，只改差异处，不要整段重写。

## Platform identity pitfalls (read before promising the user anything)
- **Weixin: it is an iLink bot identity, not your personal account as a scriptable bot.** QR login binds an `xxx@im.bot` facade. Consequences: DMs to that bot work reliably; but ordinary WeChat **group** delivery and `@`-mentions typically do NOT reach the gateway (iLink-side limitation, not a Hermes bug). `WEIXIN_GROUP_POLICY` only matters if iLink actually returns group events. Most deployments only get DMs reliably.
- **Weixin (personal WeChat) ≠ WeCom (Enterprise WeChat).** Different adapter entirely. If the user means their corporate/customer-service WeChat, point at the WeCom adapter instead.
- Keep expectations honest: say "personal chats reliable, ordinary groups may not deliver" *before* the user scans, not after.
- **主动推送（`hermes send` / cron 投递）受「互动窗口」限制。** 窗口过期时 iLink 返回 **`ret=-2 prepare failed`** —— 这不是限流，是会话上下文过期；**用户给机器人随便发一条消息即恢复**。所以"推送没到"要先分清：①互动窗口过期（让用户先发一条）②同一波多条短时高频被限流（逐条之间隔 ~4 秒）。被动回复（用户先说话）不受此限 —— 这就解释了他常说的"你能回我，但主动推给我会漏"。诊断顺序：先 `hermes send --to <target> "..."` 实测看是否 `sent`（通 = 通道正常，问题在窗口/节奏），再看 cron output 文件里有无投递错误，别先急着改脚本。

## Session-specific detail
- [references/weixin-setup-walkthrough.md](references/weixin-setup-walkthrough.md) — the concrete end-to-end WeChat connect from 2026-08 (menu label, exact submit sequence, the `qrcode`-fallback URL, saved `.env` keys).
- [references/windows-autostart-nonascii-path.md](references/windows-autostart-nonascii-path.md) — exact launcher code, registry values, and the diagnosis transcript for the non-ASCII-path auto-start failure + Run-key fix.
- [references/qqbot-setup-verification.md](references/qqbot-setup-verification.md) — QQ (qBOT) connect: exact `.env` keys, WebSocket connect log markers, and the boot-time-discovery verification transcript.
- [references/qq-voice-stt.md](references/qq-voice-stt.md) — QQ voice messages → Chinese text: `stt.language` pin to `zh` (default `en` breaks Chinese transcripts), faster-whisper dep, config keys, verification.
- [references/qqbot-group-support.md](references/qqbot-group-support.md) — QQ group chat: `@`-mention trigger (`GROUP_AT_MESSAGE_CREATE`), send path `/v2/groups/{group_openid}/messages`, `group_policy`/`group_allow_from` ACL keys, enable + verify steps.
- [references/feishu-setup-walkthrough.md](references/feishu-setup-walkthrough.md) — Feishu/Lark connect: dep install (uv + Windows native path), menu numbers, submit sequence, QR/launcher-URL fallback, expected `.env` keys.
