# Feishu / Lark setup walkthrough (completed 2026-08-31)

Connecting the Feishu/Lark bot via `hermes gateway setup` scan-to-create. Platform is officially supported and full-featured: Voice / Images / Files / Threads / Reactions / Typing / Streaming all ✅.

## Deps (install BEFORE running the wizard)
Extras declared in `hermes-agent/pyproject.toml`:
```toml
feishu = ["lark-oapi==1.6.8", "qrcode==7.4.2"]
```
`lark-oapi` is the Feishu SDK (WebSocket client); `qrcode` renders the on-device QR in the terminal. `websockets` was already present at 15.0.1.

**Install into the project venv with uv — use the WINDOWS native path, NOT an MSYS path** (uv rejects `/e/...` with "No virtual environment found"):
```bash
cd /e/软件/Hermes/hermes-agent \
  && uv pip install --python "E:\\软件\\Hermes\\hermes-agent\\venv\\Scripts\\python.exe" \
     "lark-oapi==1.6.8" "qrcode==7.4.2"
```
The venv has NO pip (`venv/Scripts/python -m pip` → "No module named pip"), so uv is the way in.

## Driving the wizard
```bash
terminal(command="hermes gateway setup", background=true, pty=true)
```
Drive with `process(submit)` — submit appends Enter. Never `write` a bare `\n`.

**Do NOT pipe the wizard through `| head` / `| tail`.** The pty command must run bare (background+pty, no pipe). Piping makes `head` wait for EOF forever while the curses wizard never exits → the process hangs open. Make the exact mistake to avoid: `hermes gateway setup 2>&1 | head -80` hung; killing the session and re-running bare fixed it.

Observed menu (this build, Chinese output, numbered platform list):
- Platform list is numbered; **Feishu / Lark = item 12**, `28. Done` at the end. Read the rendered label ("🪽 Feishu / Lark") + number from the actual menu — the top rows can be cropped on first `wait`, so re-poll and read the menu *start* before choosing.
- After selecting the platform, the wizard asks `How would you like to set up Feishu / Lark?` with:
  - `(●) 1. Scan QR code to create a new bot automatically (recommended)` — default
  - `(○) 2. Enter existing App ID and App Secret manually`

Submit sequence observed: select `12` → confirm default `1` (scan-to-create, just Enter) → QR appears → user scans with Feishu mobile app + approves on-phone "create app" prompt.

## The post-scan flow (the part you must drive to completion)
After the user scans + approves, the wizard does NOT exit on its own. It advances through a question chain — the defaults are the safe pick, so just Enter each:
1. `✓ Bot created: Hermes` (bot name follows the profile/app name) — confirms the app bound.
2. `How should direct messages be authorized?` → `(●) 1. Use DM pairing approval (recommended)` (Enter) → `✓ DM pairing enabled. Unknown users can request access; approve with 'hermes pairing approve'.` **This means the first real DM from the user needs `hermes pairing approve` before the bot answers.**
3. `How should group chats be handled?` → `(●) 1. Respond only when @mentioned in groups (recommended)` (Enter).
4. Returns to the platform menu → `Restart the gateway to pick up changes? [Y/n]:` → `Y`. The wizard itself stops + starts the gateway (`✓ Gateway stopped (drained cleanly)` → `✓ Gateway started via direct spawn (PID xxx)`).
5. The pty then sits idle; send Ctrl+C (a raw `\x03`) or just kill the session — it is done.

## Two traps you will hit
1. **"Fetching configuration results....." stall is NOT a failure.** After scanning, the wizard can sit on this line for 2–5 min while it secretly advanced. Do NOT early-conclude "stuck" — run `process(action=log)` (full output), not just `poll` (which only shows the tail/head-crop). Reading DOWN the log is what reveals it already reached `✓ Bot created: Hermes` + the DM-authorization question.
2. **The menu still shows `(not configured)` after success.** After a successful bind, the platform list keeps rendering `12. 🪽 Feishu / Lark (not configured)` even though creds landed. The list is a stale refresh, not a status. Verify success by grepping `.env` for `FEISHU_APP_ID` + `FEISHU_APP_SECRET` AND the gateway log markers below — never by the list display.

## Credentials the wizard writes
Observed `.env` keys (from `$HERMES_HOME/.env`, e.g. `E:\软件\Hermes\.env`):
- `FEISHU_APP_ID=cli_xxx`
- `FEISHU_APP_SECRET=secret_xxx`
- `FEISHU_DOMAIN=feishu` (feishu=China, lark=international)
- `FEISHU_CONNECTION_MODE=websocket` (recommended; no public webhook needed)
- `FEISHU_GROUP_POLICY` (set by the group-handling question)
- optional: `FEISHU_ALLOWED_USERS=ou_xxx,...`, `FEISHU_HOME_CHANNEL=oc_xxx`

## Verification — CONFIRMED success markers (this session)
Grep `$HERMES_HOME/logs/gateway.log` (also `logs/agent.log` mirrors it). For Feishu, ALL of these present = live:
- `INFO gateway.run: Connecting to feishu...`
- `INFO gateway.run: ✓ feishu connected`
- `INFO hermes_plugins.feishu_platform.adapter: [Feishu] Connected in websocket mode (feishu)`
- `INFO Lark: connected to wss://msg-frontier.feishu.cn/ws/v2?...` (the SDK's own long-lived WSS line)

`hermes gateway status` showing `✓ Gateway process running` is necessary but NOT sufficient — the log markers above are the real proof. `hermes send --list` is a config listing, not a live check. Confirm delivery with an actual DM (after `hermes pairing approve`).
