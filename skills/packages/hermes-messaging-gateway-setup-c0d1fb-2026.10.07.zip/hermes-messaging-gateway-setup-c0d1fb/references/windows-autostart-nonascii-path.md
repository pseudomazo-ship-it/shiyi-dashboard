# Windows gateway auto-start on a non-ASCII HERMES_HOME path

Session proof that `hermes gateway install` auto-start **silently fails** when
`HERMES_HOME` is on a path with non-ASCII characters (here `E:\软件\Hermes`), and
the working fix. Captured 2026-08.

## Symptom
- `hermes gateway status` reports the login item as installed
  (`✓ Windows login item installed: ...\Startup\Hermes_Gateway.vbs`) and the
  gateway runs *right now* — but after a real login/reboot it does **not** come back.
- Triggering the launcher from a cleanly-stopped gateway fails silently. Logs show
  the gateway never accepts inbound messages after a cold start.

## Why it fails (confirmed, not guessed)
1. `hermes gateway install` → wants a Scheduled Task (`schtasks` ONLOGON). On a
   **non-admin** account it is blocked at the UAC prompt ("Open the UAC prompt now? [y/N]")
   and **falls back to the Startup-folder VBS**.
2. That VBS (and the `gateway-service\Hermes_Gateway.cmd` it calls) breaks on a
   non-ASCII `HERMES_HOME`:
   - `cmd /c "E:\软件\Hermes\...\hermes.exe gateway start"` →
     `'...' is not recognized as an internal or external command` (the quoted
     Chinese path + args is parsed as a single command token).
   - VBS `sh.Run "<quoted chinese path>" args` → `系统找不到指定的文件` (WScript
     decodes the path as GBK/ANSI).
   - PowerShell 5.1 reads a **without-BOM** `.ps1` as ANSI/GBK, so
     `$HERMES_HOME = "E:\软件\Hermes"` evaluates to null →
     `Start-Process -WorkingDirectory $null` throws. The `.ps1` **must** be saved
     as UTF-8 **with BOM** (`utf-8-sig`).
   - `schtasks /Create /SC ONLOGON ...` from a non-admin shell →
     `ERROR: Access is denied.` — no elevation, no scheduled task, no way around it.
   - `GetShortPathNameW` returned the long path unchanged, so there is **no 8.3
     short path** to fall back to on this volume either.

## The working fix: registry Run key + Python launcher (no admin, no shell parsing)
The Run key stores a Unicode string and Windows launches it with `CreateProcess`
directly — not through cmd/VBS — so Unicode paths are never mangled.

### 1. Python launcher (pure stdlib, no extra pip deps)
`gateway-service/hermes_gateway_autostart.py`:
```python
import os, subprocess, sys
HERMES_HOME = r"E:\软件\Hermes"
HERMES_EXE  = r"E:\软件\Hermes\hermes-agent\venv\Scripts\hermes.exe"
def main():
    os.environ["HERMES_HOME"] = HERMES_HOME
    os.environ.setdefault("HERMES_GATEWAY_DETACHED", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    os.environ.setdefault("HERMES_ACCEPT_HOOKS", "1")
    cmd = [HERMES_EXE, "gateway", "start"]
    try:
        subprocess.Popen(cmd, cwd=HERMES_HOME,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        try:
            with open(os.path.join(HERMES_HOME, "logs", "gateway-autostart.log"), "a", encoding="utf-8") as f:
                f.write("autostart launcher error: %r\n" % (e,))
        except Exception:
            pass
        sys.exit(1)
if __name__ == "__main__":
    main()
```
Key point: `subprocess.Popen([exe, "gateway", "start"], ...)` passes args as an
argv list — no shell string parsing, Unicode handled natively.

### 2. Register the Run key (Python, via winreg)
```python
import winreg
PYW      = r"E:\软件\Hermes\hermes-agent\venv\Scripts\pythonw.exe"
LAUNCHER = r"E:\软件\Hermes\gateway-service\hermes_gateway_autostart.py"
value    = f'"{PYW}" "{LAUNCHER}"'
key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
winreg.SetValueEx(key, "HermesGateway", 0, winreg.REG_SZ, value)
winreg.CloseKey(key)
# readback: winreg.QueryValueEx(key, "HermesGateway")  -> value, REG_SZ
```

### 3. Verify from a stopped gateway (the only real proof)
```python
import subprocess, time
hermes_exe = r"E:\软件\Hermes\hermes-agent\venv\Scripts\hermes.exe"
subprocess.run([hermes_exe, "gateway", "stop"], env=dict(os.environ)); time.sleep(3)
# simulate the Run-key launch exactly:
subprocess.run([PYW, LAUNCHER], env=dict(os.environ))
time.sleep(10)
subprocess.run([hermes_exe, "gateway", "status"], env=dict(os.environ))  # -> running PID
```
If that shows a running PID, cold-start auto-start works. Clean up the broken
Startup-folder VBS (`...\Startup\Hermes_Gateway.vbs`) so `gateway status` isn't
misled.

## Harmless Windows noise to ignore
At startup the gateway logged:
```
AttributeError: module 'asyncio' has no attribute 'start_unix_server'
```
in `gateway/shutdown_watchdog.py` (loop-tick unix socket). Windows has no
Unix-domain sockets, so the liveness watchdog can't bind — it merely degrades.
It does **not** stop the gateway from accepting/delivering messages. Log it as a
warning; don't treat it as a config failure.

## Generalization
This isn't specific to Weixin. Any platform on a non-ASCII `HERMES_HOME` hits
the same auto-start trap. When in doubt: run the launcher (registry/key or the
`gateway start` path) from a **stopped** gateway and confirm a PID comes up.
