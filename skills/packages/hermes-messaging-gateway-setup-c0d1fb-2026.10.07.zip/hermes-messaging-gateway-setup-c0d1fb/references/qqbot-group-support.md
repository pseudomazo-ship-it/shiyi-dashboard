# QQ (qBOT) group-chat support

The QQ qBOT adapter handles group messages in addition to DMs and guild/channel messages. This is how to get the bot answering `@`-ments inside a QQ group.

## Event types the adapter routes (from `gateway/platforms/qqbot/adapter.py` `_on_event`)
- `C2C_MESSAGE_CREATE` — private 1:1 DM
- `GROUP_AT_MESSAGE_CREATE` — **group chat; triggered by `@`-mention** → `_handle_group_message`
- `GUILD_MESSAGE_CREATE` / `GUILD_AT_MESSAGE_CREATE` — guild/channel messages
- `DIRECT_MESSAGE_CREATE` — guild DM

Group replies are sent to `POST /v2/groups/{group_openid}/messages`.

## The `@`-mention rule (hard constraint — tell the user up front)
QQ group bots answer only when someone **`@`-mentions** the bot — the event is literally `GROUP_AT_*`. The bot does NOT see/respond to every group message. In a group, it's `@机器人 内容` that triggers a reply. Tell the user this before they add the bot, so they don't expect it to lurk on every message.

## Config keys (`config.yaml` → `platforms.qq.extra`)
```yaml
platforms:
  qq:
    enabled: true
    extra:
      app_id: "..."
      client_secret: "..."
      group_policy: "open"            # open | allowlist | disabled | pairing (default: pairing)
      group_allow_from: ["group_openid_1"]   # required when group_policy=allowlist
      dm_policy: "pairing"            # open | allowlist | disabled | pairing (DMs)
      allow_from: ["openid_1"]
      markdown_support: true
```
`group_policy`/`dm_policy` are the access gates (read from `extra` via `_group_policy`/`_dm_policy`; **default `pairing`**). A new group with `pairing` needs its first `@`-mention paired before replies flow; `open` lets any group in; `allowlist` restricts to the openids in `group_allow_from`; `disabled` turns it off. Credentials in the live deployment stay in `.env` (`QQ_APP_ID`, `QQ_CLIENT_SECRET`, `QQ_ALLOW_ALL_USERS`, `QQ_ALLOWED_USERS`, `QQBOT_HOME_CHANNEL`); the group ACL is `platforms.qq.extra`, not env.

## Enable group chat end-to-end
1. **QQ开放平台 side (user)**: the bot's app must have group (群聊) message capability enabled, and the group must add the bot (group owner/admin, or `@`-mention to invite).
2. **Hermes side (agent)**: set `platforms.qq.extra.group_policy` to `open` (or `allowlist` + the group's `group_openid` in `group_allow_from`) via `hermes config set` — never hand-edit config.yaml.
3. **Restart the gateway**: `hermes gateway restart` — ACL is read at boot; a running gateway won't pick up a new group policy.
4. **Verify**: `@`bot in the group and confirm it answers; check `logs/gateway.log` for `GROUP_AT_MESSAGE_CREATE` handling.

## Getting the `group_openid`
Inbound group events carry `group_openid` (adapter reads `event.group_openid`). If the bot handled one `@`-mention, the openid shows in the log / channel directory; otherwise it's on the QQ开放平台 side.
