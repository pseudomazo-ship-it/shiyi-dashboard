# QQ (QQ开放平台 qBOT) — setup & verification walkthrough

Concrete end-to-end QQ connect for a Hermes gateway (from 2026-08). Complements the Weixin walkthrough; the class-level mechanics are in the SKILL.md body (`"Is it actually connected?"` and `QQ (QQ开放平台 qBOT)` sections).

## What QQ is here
QQBot is the QQ 开放平台 (open platform) bot, accessed via `q.qq.com` developer APIs — NOT a personal QQ account bot. It binds a bot app identity and talks to QQ's websocket gateway. Adapter code lives at `gateway/platforms/qqbot/`.

## Config written to `.env`
```
QQ_APP_ID=1905531064
QQ_CLIENT_SECRET=<secret>
QQ_ALLOW_ALL_USERS=false
QQ_ALLOWED_USERS=<scanner_openid>      # e.g. B442F9FE60F6270750FBB0E59D838EFF
QQBOT_HOME_CHANNEL=<scanner_openid>     # same value as allowed user, after QR bind
```
The allowlist value is the `user_openid` returned by the QR bind (`qr_register()`), i.e. the person who scanned. `QQBOT_HOME_CHANNEL` points at them as home.

## Boot sequence (what "connected" looks like in `logs/gateway.log`)
On a successful connect the log shows, in order:
```
gateway.run: Connecting to qqbot...
gateway.platforms.qqbot.adapter: [QQBot:1905531064] Access token refreshed, expires in 6723s
gateway.platforms.qqbot.adapter: [QQBot:1905531064] Gateway URL: wss://api.sgroup.qq.com/websocket
gateway.platforms.qqbot.adapter: [QQBot:1905531064] WebSocket connected to wss://api.sgroup.qq.com/websocket
gateway.platforms.qqbot.adapter: [QQBot:1905531064] Connected
gateway.platforms.qqbot.adapter: [QQBot:1905531064] Identify sent
gateway.run: ✓ qqbot connected
gateway.run: Gateway running with 2 platform(s)
gateway.platforms.qqbot.adapter: [QQBot:1905531064] Ready, session_id=<uuid>
```

## Verification decision tree
- `hermes send --list` shows `Qqbot:` → only proves `.env` has the keys. (Config, not live.)
- `grep -aE "\[QQBot:.*?Connected|Ready" logs/gateway.log` finds a match → QQ is LIVE.
- No `[QQBot:` line at all in the log → the running gateway was started before the QQ keys were added and never loaded the adapter → **restart the gateway**, then re-grep.
- `send --list` still says "no channels discovered yet" after a live `Ready` → normal; qBOT populates channels only when someone messages the bot. Have the owner DM the bot from QQ; the channel will then appear.

## Wizard submit sequence (2026-08, this build)
Menu positions shift across Hermes builds — read the rendered labels and confirm each prompt before submitting. The chain that completed an 8-30-26 connect was:

1. `hermes gateway status` → gateway half-configured is fine. Confirm deps: `venv/Scripts/python -c "import aiohttp, httpx"`.
2. `hermes gateway setup` in a **pty** (background) → wait for menu → note `5. 🐧 QQ Bot` (read the rendered label) → submit `5`.
3. `How would you like to set up QQ Bot?` → submit `1` (Scan QR code... recommended).
4. Wizard prints the onboard URL `https://q.qq.com/qqbot/openclaw/connect.html?task_id=<uuid>&_wv=2&source=hermes` (gives URL only when `qrcode` module is absent). Open it in `desktop_preview` so the owner scans with phone QQ, or hand the URL to them.
5. Phone confirms → wizard shows `QR scan complete! (App ID: <id>)` and `Scanner's OpenID: <openid>`.
6. `How should direct messages be authorized?` → submit `1` (Use DM pairing approval).
7. `Add yourself (<openid>) to the allow list? [Y/n]:` → `Y` (writes `QQ_ALLOWED_USERS`).
8. `Use your QQ user ID (<openid>) as the home channel? [Y/n]:` → `Y` (writes `QQBOT_HOME_CHANNEL`).
9. Back at the main menu → `Done` → submit its number (`28` in this build).
10. `Restart the gateway to pick up changes? [Y/n]:` → `Y` → `✓ Gateway stopped (drained cleanly)`.
11. `Install it now so the gateway starts on login? [Y/n]:` → `Y`.
12. `Start the gateway now after install? [Y/n]:` → `Y`.
13. `Start the gateway automatically on Windows login with a Scheduled Task? [Y/n]:` → `Y`.
14. `Open the UAC prompt now? [y/N]:` → `Y` → the owner clicks 「是」 on the Windows UAC prompt → `✓ Gateway started via direct spawn (...)` and `✓ Scheduled Task registered: Hermes_Gateway`.

Resulting `.env` keys: `QQ_APP_ID=1905531064`, `QQ_ALLOWED_USERS=B442F9FE60F6270750FBB0E59D838EFF`, `QQBOT_HOME_CHANNEL=B442F9FE60F6270750FBB0E59D838EFF` (allowlist/home value = the scanner's `user_openid`). Confirmation the round trip is live: after the owner DMs the bot, `logs/gateway.log` shows `inbound message: platform=qqbot user=<openid> ...` then `Sending response ... to <openid>`. Weixin coexists (`Weixin connected` line reappears after restart).

## Pitfalls
- Boot-time discovery: the gateway builds its platform list ONCE at startup. Creds written to `.env` while it runs are ignored until restart. Diagnosing an unconnected platform is almost always "restart the gateway" rather than a config bug.
- `hermes gateway restart` on a manually-spawned gateway can drop into the interactive install/Scheduled-Task wizard when `status` says "not running"; the direct spawn fallback (`✓ Gateway started via direct spawn …`) works and does not need the admin Scheduled Task. Weixin reconnects after the restart (its `[Weixin] Connected account=…` marker reappears).
- Don't conflate "home channel set" with "connected": `QQBOT_HOME_CHANNEL` / `QQ_ALLOWED_USERS` being present is config; the WebSocket `Ready` log line is the live signal.
