# QQ voice messages → text (Chinese STT)

Hermes auto-transcribes voice messages from messaging platforms via the `stt` config. For a QQ bot speaking **Chinese**, the one thing that bites is the default `stt.language: en` — English-pinned segmentation yields poor/empty transcripts on Chinese audio, and it looks like "receives a voice message but can't read it."

## Diagnosis — placeholder vs transcript
- A voice message coming through as `[Voice] 能听到的文字...` (readable Chinese after the marker) = STT is working.
- A voice message coming through as just `[Voice]` with nothing after = STT did NOT transcribe (disabled, no provider, or language-mismatched). Not a platform bug — it's the STT config.

## Enable / fix (never hand-edit config.yaml — use `hermes config set`)
```bash
hermes config set stt.enabled true
hermes config set stt.provider local          # local = faster-whisper, free
hermes config set stt.language zh             # <- the critical one; top-level default is ``en``
hermes config set stt.local.language zh       # pin the local faster-whisper model to Chinese
hermes config set stt.local.model base        # tiny|base|small|medium|large-v3; base is a good cpu default
```
Verify with `hermes config get stt` — the `language:` rows should show `zh` (top-level + the `local:` block).

## Dependency
- Local provider needs `faster-whisper` (pip). Check with the **project venv** python, not system python:
  `venv/Scripts/python -c "import faster_whisper; print(faster_whisper.__version__)"` (Unix: `venv/bin/python`).
- If missing: `uv pip install faster-whisper` from inside the venv.
- Auto-detect priority if `provider` is not set: local faster-whisper → Groq → OpenAI → Mistral.

## Verify
Have the user send a fresh voice message. If it lands as `[Voice] <Chinese text>` it works. If it still shows bare `[Voice]`, the running gateway may need a restart to reload config (`hermes gateway restart`), then re-test.

## Note
`local.language` empty means auto-detect (works but less deterministic); pin `zh` when the channel is Chinese-only. Cloud providers (`groq`/`openai`/`else`) also honor `stt.language`, so set the top level to `zh` too for consistency.
