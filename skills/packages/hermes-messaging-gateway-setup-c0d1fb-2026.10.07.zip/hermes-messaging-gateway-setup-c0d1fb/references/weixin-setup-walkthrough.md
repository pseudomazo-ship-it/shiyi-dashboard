# Weixin / WeChat connectivity walkthrough (2026-08)

Concrete, verified end-to-end sequence for connecting Hermes to a personal WeChat account via the Weixin (iLink Bot) adapter. Environment: Windows, Hermes installed at `E:\软件\Hermes`, venv at `hermes-agent/venv/`.

## What we did
1. `hermes gateway status` → "✗ Gateway is not running" (fine, not half-configured).
2. Confirmed adapter exists: `gateway/platforms/weixin.py`.
3. Confirmed deps with **project** python (not system): `cd hermes-agent && python -c "import aiohttp, cryptography"` → OK (aiohttp 3.14.3, cryptography 50.0.0). Note: system `python` was fine here because the venv's interpreter is what `python` resolved to; the reliable check is `./venv/Scripts/python -c "import ..."`.
4. Launched the wizard: `terminal(command="hermes gateway setup", background=true, pty=true)`.
5. Drove it with `process(action=submit, data=...)` — never `write` with a bare `\n` on Windows PTY.

## Exact submit sequence
| Prompt rendered | submit data | Result |
|---|---|---|
| `Choice [default 28]:` (menu) | `3` | Entered Weixin setup (label "💬 Weixin / WeChat").
| `Start QR login now? [Y/n]:` | `Y` | QR request fired.

> The menu item was **number 3** in this build. Always read the rendered number next to the "Weixin / WeChat" label instead of hard-coding — menu order can shift between versions.

## The `qrcode`-missing fallback
After choosing Weixin + Y, the wizard printed:
```
请使用微信扫描以下二维码：
https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=1d52e72fb102e024ca60bd6a2400963a&bot_type=3
（终端二维码渲染失败: No module named 'qrcode'，请直接打开上面的二维码链接）
```
Terminal QR render failed because Python module `qrcode` isn't installed. Rather than fight the install, open the raw URL.

**Best delivery:** `desktop_preview action=open url=<the raw login url>` — the user scans it with their phone "扫一扫". The preview pane's `read` returned `text: "请使用「微信」扫码打开"`, confirming the page renders the QR for scanning.

Installing qrcode was NOT needed. Two dead ends worth knowing (do NOT treat as the answer):
- `uv pip install qrcode` → "No virtual environment found"; the venv is `hermes-agent/venv/` but uv didn't resolve it.
- `./venv/Scripts/python -m pip install qrcode` → "No module named pip" (this venv is minimal).

The URL + preview-pane fallback sidesteps both.

## After a successful scan
The wizard stores: account creds under `~/.hermes/weixin/accounts/`, and an `account_id`/`token` set in `~/.hermes/.env` as `WEIXIN_ACCOUNT_ID`, `WEIXIN_TOKEN` (auto-saved, no manual config).

Optional access control set *after* login:
```
WEIXIN_DM_POLICY=open
WEIXIN_ALLOWED_USERS=<user-id>
```
`WEIXIN_GROUP_POLICY` only affects group delivery when iLink actually returns group events — most bot-type accounts never do, so expect DMs to work and ordinary groups not to.

## Honest expectation to state before scanning
The logged-in identity is an **iLink bot** (`xxx@im.bot`), not your personal WeChat acting as a scriptable bot. Personal-chat (DM) messaging works reliably; ordinary WeChat group delivery and `@`-mentions generally do NOT reach the gateway. This is an iLink-side limitation, not a Hermes bug. Say this to the user *before* they scan, not after.
