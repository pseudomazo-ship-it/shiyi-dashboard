#!/usr/bin/env node
// 拼多多商家后台 CDP 驱动助手（复用脚本，避免每次手写 WS/回调样板）
// 用法: node cdp-helper.mjs <subcommand> [...args]
//   list  [port=9335]                     列所有 page target:  id | 标题 | url
//   eval  <wsUrl> <expression>            Runtime.evaluate (awaitPromise+returnByValue) 打印 JSON
//   nav   <wsUrl> <url>                   Page.navigate
//   setfiles <wsUrl> <selector> <file>    DOM.querySelector + DOM.setFileInputFiles(传图)
//   findurl <port> <substr>               列出 url 含 substr 的 page 的 id + webSocketDebuggerUrl
//
// Node 22+（自带全局 WebSocket）。
// 常见坑: 启动 electron 时用 --remote-debugging-port 且必须 `unset ELECTRON_RUN_AS_NODE`（export "" 也触发 Node 模式）。

const [cmd, ...rest] = process.argv.slice(2);

function connect(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let nextId = 1; const pending = new Map();
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = nextId++; pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params }));
  });
  ws.onmessage = (ev) => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { const { resolve, reject } = pending.get(m.id); pending.delete(m.id); m.error ? reject(new Error(JSON.stringify(m.error))) : resolve(m.result); }
  };
  return new Promise((resolve, reject) => {
    ws.onopen = () => resolve({ ws, send });
    ws.onerror = (e) => reject(new Error('WS_ERROR ' + (e.message || e)));
  });
}

async function json(port) {
  const res = await fetch(`http://127.0.0.1:${port}/json`);
  return res.json();
}

async function main() {
  if (cmd === 'list') {
    const port = rest[0] || '9335';
    const pages = await json(port);
    pages.filter(t => t.type === 'page').forEach(t => console.log(`${t.id} | ${(t.title || '').slice(0, 30)} | ${t.url || ''}`));
    return;
  }
  if (cmd === 'findurl') {
    const [port, substr] = rest;
    const pages = await json(port);
    const hit = pages.filter(t => t.type === 'page' && (t.url || '').includes(substr));
    hit.forEach(t => console.log(`ID=${t.id}\nWS=${t.webSocketDebuggerUrl}\nTITLE=${t.title}\nURL=${t.url}`));
    console.log('found=' + hit.length);
    return;
  }

  const wsUrl = rest[0];
  const { ws, send } = await connect(wsUrl);

  if (cmd === 'eval') {
    const expression = rest.slice(1).join(' ');
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
    console.log(JSON.stringify(r.result, null, 2));
  } else if (cmd === 'nav') {
    await send('Page.enable');
    const r = await send('Page.navigate', { url: rest[1] });
    console.log(JSON.stringify(r));
  } else if (cmd === 'setfiles') {
    const [_, selector, file] = rest; // wsUrl, selector, file
    await send('DOM.enable');
    const doc = await send('DOM.getDocument', { depth: -1, pierce: true });
    const q = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector });
    if (!q.nodeId) { console.error('NO_NODE'); process.exit(1); }
    await send('DOM.setFileInputFiles', { nodeId: q.nodeId, files: [file] });
    console.log('UPLOADED ' + file);
  } else {
    console.error('unknown cmd: ' + cmd);
  }
  ws.close();
  setTimeout(() => process.exit(0), 200);
}

main().catch(e => { console.error('ERR', e.message); process.exit(1); });
