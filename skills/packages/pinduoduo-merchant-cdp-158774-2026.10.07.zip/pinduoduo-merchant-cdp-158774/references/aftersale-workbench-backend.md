# 售后处理工作台 后端 API 架构（2026-09-02 搭建，真实数据链路）

> 定位：把「售后退款处理工作台」前端（`aftersale_workbench.html`）接到**真实拼多多后台数据**的后端。
> 先说结论：**读列表（订单号/类型/原因/金额/倒计时）稳定；买家诉求 + 物流明细在详情页，经本会话 2026-09-02 末新增「批量采集详情脚本」能成批抓到（见 aftersale-detail-collection.md 的收集脚本节），存 `order_details.json` 缓存，前端经 `/api/details` 读取补全卡片（不再只是"读不到留空"）**。

## 一、核心文件与角色

- `workbench_api.py`（工作区 `E:\软件\Hermes\cache\`）——本地 HTTP 服务（默认 `http://127.0.0.1:8088`），**同时**：
  1. **托管前端页面**（`GET /` 返回 HTML，同源避免 file:// 跨域）；
  2. **提供 /api/orders**（读当前店铺列表页真实订单）；
  3. **提供 /api/detail?id=<售后编码>**（URL 直航读单条详情，读后 auto close tab）。

- 前端 `售后处理工作台.html`——`fetch('/api/orders')` 拉数据渲染。改前端 JS 后**必过 `node --check`**（见 aftersale-workbench-ui.md 第十四节）。

## 二、为什么必须用「后端托管页面」而不是 file:// 直开

- 本地 HTML 用 `file://` 打开时，前端 `fetch('http://127.0.0.1:8088/api/orders')` 是**跨域**（`file://` 的 origin 是 `null`），浏览器会拦——哪怕后端设了 `Access-Control-Allow-Origin: *`，`file://` 页面仍可能被拦/读不到。
- **正解**：后端用 `http.server` 在 `GET /` 返回 HTML 文件内容（`Content-Type: text/html; charset=utf-8`），前端去访问 `http://127.0.0.1:8088/`（同源）。这样 fetch 干干净净。
- 注意：`BaseHTTPRequestHandler` 默认不支持 `HEAD`（返回 501），只有 `GET` 可用——`curl -I` 会 501 但 `curl` 取内容正常，别误判。

## 三、/api/orders 读列表（稳定，能采）

- 连接 9555 端口的 aftersale_list tab，`Runtime.evaluate("document.body.innerText")` 拿整页文本。
- 按 `订单号：` 切块，每块正则抓：订单号 / 申请时间 / 超时倒计时（`（\d+天\d+时\d+分\d+秒未处理`）/ 实收 / 退款 / 售后类型 / 申请原因（词表匹配）。
- 订单号用 `\d{6}-\d{12,15}` 匹配（列表里订单号可能是 12~15 位）。
- 店铺名从页面文本读（蒙倩美发官方旗舰店），**不要把自己当店铺**——子账号（十一美发旗舰店）只在账号下拉里，见 aftersale-workbench-ui.md。

## 四、/api/detail 读详情（按 [SKILL.md 详情读取硬坑] 采）

- 入参 `id=<售后编码>`（**必须带 id**，只带 orderSn 是半加载空壳）。
- 用浏览器级 WS `Target.createTarget({url})` 新开 tab → 等 3s → 读该 target 的 innerText → 正则抓：售后编码/订单号/售后类型/申请原因/退款金额/**问题描述为：…（买家诉求）**/发货物流公司/发货快递单号/退货快递单号 → `Target.closeTarget` 关闭。
- ⚠️ 有时 `createTarget` 到该 URL 会被重定向回 `setup?tab=3`（detail tab 没开成）——检测 tab URL 不是 detail 即失败，需重试或手动。

## 五、/api/details 读详情缓存（2026-09-02 末新增，给卡片补全买家诉求+物流）

- 批量采集脚本（`collect_all_details_v2.py`）把每单详情（desc 买家诉求 / ship 发货物流公司+单号 / ret_no 退货单号 / code 售后编码）落到 `软件雏形\order_details.json`（按售后编码为 key）。
- `/api/details` 直接读该 json 文件返回 `{ok:true, details:{...}}`；前端 `loadOrders` 里 `Promise.all([fetch('/api/orders'), fetch('/api/details')])` 并行拉，按**订单号**匹配（`details[k].sn === o.sn`）把 desc 填到卡片「买家诉求」、ship 经 `buildLogi(rtype,det)` 构造成物流明细（仅退款 1 条收货快递；退货退款=发货快递+退货快递 2 条）。
- desc 为空 = 该单确实没填描述，卡片留空即可，不是采集失败。

## 五B、/api/process 一键处理（驳回→协商→提交，2026-09-02 尾段实测走通）

- 前端点「处理」按钮 → `fetch('/api/process?sn=<订单号>')` → 后端在已登录浏览器里自动执行「驳回→协商→提交」。返回 `{ok, steps:[…], result}`。
- **核心函数 `process_order(sn)`**（复用本技能已验证的弹窗链路，见 aftersale-reject-wizard.md 与 SKILL.md「重大突破」节）：
  1. 找到打开的 detail tab（`aftersales-ssr/detail`），无则返回「请先打开详情」；
  2. `click_txt('驳回退款')`（**必须 CDP 真实鼠标点击，js click 无效**）；
  3. 若出现「平台提示」确认层（货物与描述不符类单）→ `click_txt('坚持驳回')`；
  4. `click_txt('协商其他方案')`（radio）→ `click_txt('协商退款金额')` → 「填金额5」（`Input.insertText`）→ `click_txt('退货后退全款')` → `click_txt('提交协商方案')` → `click_txt('确认，发给消费者')`；
  5. 读结果：`'第一轮协商'`（含「第一轮售后协商」）/ `'商家驳回'`（含「商家驳回」）/ `'已提交'`。
- **封装 `find_center(ws, txt, exact)`**：`[...querySelectorAll('button,a,label,span,div')].filter(文本===txt 或 includes(txt) && 可见 && width in (0,300))` 取第一个的 `getBoundingClientRect()` 中心。`click_at` 封装 mouseMoved→pressed(buttons:1)→sleep(0.15)→released(buttons:0)。
- **⚠️ 按钮用 `includes` 匹配会命中大容器导致点偏**：卡在自绘 checkbox 时优先用 AX 树 `Accessibility.getFullAXTree`（role=checkbox/radio + backendDOMNodeId）定位，或直接用 `textContent.trim()===目标` 精确匹配 + `elementFromPoint` 命中校验。若命中返回非目标元素（浮层/容器），不要死点——先处理遮挡（关闭浮层/换元素）。

## 五C、整合版 workbench_app.py（单文件，前端+后端+处理合一，2026-09-02 尾段）

- 本会话把 `workbench_api.py` 整合为 `workbench_app.py`（工作区外 `E:\软件\Hermes\cache\`）：一个文件同时托管前端 HTML + `/api/orders` + `/api/details` + `/api/process` + `/api/health`。**这是可打包成 exe 的单文件雏形**（方案B分发版的最小形态）。
- 启动：`uv run --with websockets python workbench_app.py` → 浏览器访问 `http://127.0.0.1:8088` 即完整工作台。
- 前端「一键处理」队列 `stepProcess` 改调 `callProcess(sn)`（后端 `/api/process`），不再只是模拟；每单间隔 `setTimeout(stepProcess, 2500)`（后端处理较慢）。
- 处理范围逻辑：有筛选/搜索 → 只处理当前 `filtered()`；全选 → 按店铺权重排序（`, `weightedOrder()`：权重=店铺处理时长倒数+单数加成+紧急性，剩余<6小时强制置顶）。

## 六、后端启动方式

```bash
cd /e/软件/Hermes/cache
uv run --with websockets python workbench_api.py   # 默认 8088；WB_PORT=xxxx 可改
```

- 依赖 `websockets`（CDP 通信）→ 用 `uv run --with websockets`。
- 前置：**9555 端口必须有已登录拼多多后台的 Chrome**（`--remote-debugging-port=9555 --user-data-dir=<独立profile>`，账号密码登录）。后端连不上就直接返回「读不到页面」。

## 六、Python http.server 注意事项

- `do_GET` 里按 `self.path` 前缀路由；给 JSON 响应加 `Access-Control-Allow-Origin: *` + `Content-Type: application/json; charset=utf-8`。
- 托管 HTML 时 `self.wfile.write(html.encode('utf-8'))`，长度 `Content-Length` = bytes 长度。
- 每次读页面都新建 CDP WS 连接（asyncio.run 单独调用），避免会话串扰。

## 七、环境事实（本机）

- Python 3.11（`uv run --with websockets` 提供依赖，本机无独立 pip/venv）。
- 前端文件在工作区 `软件：自动处理退款工作台/软件雏形/售后处理工作台.html`；后端在工作区外 `E:\软件\Hermes\cache\workbench_api.py`（`uv run` 目录）。
