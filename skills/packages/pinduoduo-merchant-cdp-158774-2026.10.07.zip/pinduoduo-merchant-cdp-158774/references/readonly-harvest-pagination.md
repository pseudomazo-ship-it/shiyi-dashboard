# 拼多多商家后台 · 只读批量采集（分页器 / 多标签 / 点火轮询）

2026-09-16 实测于 `mms.pinduoduo.com/goods/goods_list`，一次跑了 8 家店共 460 个商品。

## 0. 背景：为什么不用列表接口

`POST /vodka/v2/mms/query/display/mall/goodsList` 带 `Anti-Content` 签名头。用 hook 抓到的页面自身请求头：

```
POST /vodka/v2/mms/query/display/mall/goodsList
{ "content-type":"application/json", "Anti-Content":"0asAfx5E-wCEgqYOXySt_..." }   # 逐请求变化
```

页面内手搓 `fetch` / `XHR` 调它一律返回：

```json
{"error_code":54001,"error_msg":"操作太过频繁，请稍后再试！","result":{"verifyAuthToken":"..."}}
```

**等多久都没用**（实测等 60s 仍是 54001）——不是限频，是缺签名。
**不要去逆向签名。** 改用 DOM 翻页。

对比：属性接口 `POST /draco-ms/mms/query-goods-property` 不带该头，可正常调用（8 条/批 + 600ms 间隔，99 条 0 失败）。

## 1. 按 mallId 找目标标签（多标签问题的解）

```python
def attach_by_mall(mall):
    for t in cdp('Target.getTargets').get('targetInfos', []):
        if t.get('type') == 'page' and 'goods_list' in (t.get('url') or ''):
            a = cdp('Target.attachToTarget', targetId=t['targetId'], flatten=True)
            s = a['sessionId']
            v = cdp('Runtime.evaluate', returnByValue=True, session_id=s,
                    expression="(document.documentElement.innerHTML.match(/\"mallId\":(\\d+)/)||[])[1]||''")
            if (v.get('result') or {}).get('value') == mall:
                return t['targetId'], s
            cdp('Target.detachFromTarget', sessionId=s)
    return None, None

def ev(expr, sid, await_promise=True):
    r = cdp('Runtime.evaluate', expression=expr, returnByValue=True,
            awaitPromise=await_promise, session_id=sid)
    return (r.get('result') or {}).get('value')
```

`session_id` 不跨 browser_exec 调用持久 —— **每次调用重新 attach**。

排查用：把每个 `goods_list` 标签的店名 + mallId 都读出来，一眼看出十一切到了哪家：

```js
(()=>{const out=[];
document.querySelectorAll('*').forEach(function(e){const r=e.getBoundingClientRect();
 if(r.width>0&&r.top<80&&r.left>1500&&(e.innerText||'').trim()&&e.children.length===0) out.push((e.innerText||'').trim());});
const mid=(document.documentElement.innerHTML.match(/"mallId":(\d+)/)||[])[1]||'?';
const tot=(document.body.innerText.match(/共有\s*(\d+)\s*条/)||[])[1]||'?';
return [...new Set(out)].slice(0,2).join(' / ')+' | mallId='+mid+' | 共有='+tot;})()
```

## 2. DOM 翻页拿 goods_id

选择器（实测）：

| 部件 | 选择器 |
|---|---|
| 分页器容器 | `ul[class*=PGT_outerWrapper]` |
| 页码 | `li[class*=PGT_pagerItem]` |
| 当前页 | `li[class*=PGT_pagerItemActive]` |
| 下一页 | `li[class*=PGT_next]`（到底时 className 含 `disabled`） |
| 每页条数 | `div[class*=PGT_sizeSelect]` |

点击（**唯一奏效的方式**）：

```js
(sel)=>{const n=document.querySelector(sel); if(!n) return 'no';
 if(String(n.className).indexOf('disabled')>=0) return 'disabled';
 ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(t){
   n.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,buttons:1}))});
 return 'ok';}
```

读取（每页 10 条；`ID:` 的**上一行就是商品标题**）：

```js
(()=>{
 const lines=document.body.innerText.split('\n').map(function(s){return s.trim()});
 const out=[]; const seen={};
 for(var i=0;i<lines.length;i++){
   var m=lines[i].match(/^ID:\s*(\d+)/);
   if(m && !seen[m[1]]){ seen[m[1]]=1; out.push({id:m[1], name:(lines[i-1]||'').slice(0,80)}); }
 }
 const a=document.querySelector('li[class*=PGT_pagerItemActive]');
 const tot=(document.body.innerText.match(/共有\s*(\d+)\s*条/)||[])[1];
 return JSON.stringify({page:a?a.innerText.trim():'?', total:tot, items:out});})()
```

循环：回第 1 页 → 读 → 点 next → 读 …… 直到 `next` 返回 `disabled`。每步间隔 ~3s，上限给 20~25 轮（别写死小店页数）。按 goods_id 去重兜底。

## 3. 计数以「共有 N 条」为准（标签页数字会串店）

**切店后「在售中(N)」标签会保留上一家店的缓存值**，实测两次：

| 店铺 | 标签页显示 | 分页器「共有」 | 实际抓到 |
|---|---|---|---|
| 蒙倩染发旗舰店 | 在售中(99) ← 上一家的数 | **58** | 58（6页=5×10+8） |
| 植粹草本染发坊 | 在售中(58) ← 上一家的数 | **58** | 58 |

→ **每次都用「共有 N 条」+ 实际抓到条数 + 标签页三者交叉核对**；不一致时以「共有」为准，并在汇报里说明。刚切店时刷新一次页面（`Page.reload`）可减少缓存。

## 4. 点火即返回 + 轮询（js() 约 5s 上限）

```python
# 点火（立刻返回）
js("""(()=>{ window.__props=[]; window.__prog=0; window.__done=false; window.__err=null;
 void (async()=>{
   const ids=%s;
   for(let i=0;i<ids.length;i+=8){
     const rs=await Promise.all(ids.slice(i,i+8).map(async function(gid){
       try{
         const r=await fetch('/draco-ms/mms/query-goods-property',{method:'POST',credentials:'include',
           headers:{'Content-Type':'application/json'},body:JSON.stringify({goods_id:Number(gid)})});
         const t=await r.text(); let j={}; try{j=JSON.parse(t)}catch(e){ return {goods_id:gid, err:'parse'}; }
         if(j.error_code===54001) return {goods_id:gid, err:'54001'};
         const props={};
         ((j.result||{}).goods_properties||[]).forEach(function(p){
           props[p.name]=(p.values||[]).map(function(v){return v.value}).join('、'); });
         return {goods_id:gid, props:props};
       }catch(e){ return {goods_id:gid, err:String(e).slice(0,60)}; }
     }));
     window.__props.push.apply(window.__props,rs);
     window.__prog=window.__props.length;
     await new Promise(function(z){setTimeout(z,600)});
   }
   window.__done=true;
 })().catch(function(e){ window.__err=String(e); window.__done=true; });
 return 'started';
})()""" % json.dumps([int(x) for x in ids]).replace(' ', ''))

# 轮询
d = json.loads(js("JSON.stringify({p:window.__prog||0,done:!!window.__done,err:window.__err||null})"))

# 完成后分批取回（每批 ~12 条，太长会被截断）
allp = []
for a in range(0, n, 12):
    allp.extend(json.loads(js("JSON.stringify((window.__props||[]).slice(%d,%d))" % (a, a+12))))
```

> 坑：`const ids=[...]` 若声明在 async IIFE 内，外层箭头函数里读 `ids.length` 会 `ReferenceError` —— 条数在 Python 侧算好传进去。

## 5. 采集完成后

- 只关**自己开的**标签：遍历 page target，用 `typeof window.__props === 'object'` 认领（自己注入过 `__props` 的那个就是自己的），再 `Target.closeTarget`。**别按 URL 猜**——用户可能开着同名页。
- 只读采集，不写不提交。
