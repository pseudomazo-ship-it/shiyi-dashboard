# 用软件工作台自己的成熟自动化方法填属性/传图（本类任务最值钱经验）

## 核心原则（用户 2026-08-31 点醒，一定要记住）
拼多多属性下拉/图片上传组件对**从零硬写的自动化极不配合**（点开→搜选→选中，就像它其它控件一样"刁"）。**别再自己跟 UI 死磕**——上架工具软件工作台的 `src/main.js` 里**已经有验证流畅的填属性和传图逻辑**（`fillProductAttributes` + `setFilesOnPlatformInput`），直接**参考/移植这套逻辑**。用户原话：「其他图片上传方式你可以参考软件工作台内的商品数据上传模式，商品属性也一样参考，之前上传都是很流畅的」。

## 属性填充（fillProductAttributes，移植后真机 10/11 项成功）
`src/main.js` 的 `fillProductAttributes(webContents, attributes)`（约 L523-620）。逐项处理：

1. **找 label**：`[...document.querySelectorAll('body *')]` 里 `innerText === 属性名`（或包含+长度<=name+100）取最短最短children的。⚠️ `是否特殊用途化妆品` 页面**实际标签是「是否为特殊用途化妆品」**（带"为"），且该属性可能**页面根本没有**（彩染染发膏是特殊用途化妆品→品类自动设为"是"，不暴露该标签）——找不到别报错卡住。
2. **找控件**：从 label 向上逐级 `parentElement`，取第一个非 hidden 的 `input,textarea,[role="combobox"]`。
3. **判类型**（决定怎么填，`combined` 判定）：
   - `生产日期` → **日期选择器**（点击→面板→`beast-core-datePicker-dropdown-contentRoot`，年/月输入框 + 月份切换按钮 `RPR_iconPrevNext_` + `[role="date-cell"]` 点目标日）。日期格式 `YYYY-MM-DD`。
   - 下拉类（是否为特殊用途化妆品/功能/功效成分/产品类型/规格类型/包装方式/适用人群）→ `field.click()` 打开，再点匹配 `[role="option"]`/`li`/空叶子节点（文本完全相等）的选项。
   - 文本类（保质期/化妆品批准文号）→ 用 **原生 value setter**（`Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set`）+ `InputEvent('input',{insertText})` + `change` + `blur`（React 受控输入，只赋 `.value` 无效）。保质期去非数字。
   - `功能`（、"分隔多选）→ split 逐项 `pickOption`，串成「、」。
4. 每项 `await sleep` 间隔（~900ms 开盘 + 180ms 选完）。

### 实测属性名 → 值（紫盒染发膏，真机已验证）
| 属性 | 值 |
|---|---|
| 生产日期 | 2026-01-02（日期选择器） |
| 保质期 | 1095天（→`1095`） |
| 功能 | 染发、染色、固色（多选，点选3项） |
| 功效成分 | 草豆蔻（ALPINIA KATSUMADAI）提取物 |
| 产品类型 | 半永久（下拉点选） |
| 规格类型 | 常规单品（下拉点选） |
| 包装方式 | 普通盒装（下拉点选） |
| 适用人群 | 普通人群（下拉点选） |
| 化妆品批准文号 | 国妆特字20248508（文本） |
| 品牌 | 蒙倩（模板已带） |

### 移植到外挂 Chrome 的方法
用 CDP `Runtime.evaluate`（`userGesture:true,awaitPromise:true,returnByValue:true`）跑上面同一段 JS，`DOM.setFileInputFiles` 只在传图用。js 用**模板字符串注入 `属性名/值`**（避免 shell 转义，`.mjs` 文件而非 `node -e`）。移植脚本样例见项目 `fill-attrs.mjs`（fillOne：找label→找控件→判类型→设值/点选；datePick：日期选择器；pickOption：点选项；都可复用）。

## 图片上传（setFilesOnPlatformInput 的上下文评分法）
`src/main.js` 的 `setFilesOnPlatformInput(files, target)`（约 L129-163）。**核心不是按 DOM 顺序设文件框，而是按"上下文评分"识别目标输入框**：

1. 对所有 `input[type="file"]`，向上最多 16 层拼 `innerText`，按 target 加权评分：
   - `main`（主图/轮播图）：`el.closest('#picture')`+40，near 含 商品主图/商品轮播图/主轮播图 +10，是第1个 image input +8；
   - `white`（白底图）：`#materialPic`+40，含 商品辅助图/白底图 +14；
   - `label`（标签图）：`#pack_label_image`+40，含 包装标签图 +14；
   - `detail`（详情图）：`#detail_pic`+40，含 商品详情/快捷编辑 +10，是最后一个 image input +8；
   - `multiple`+2，accept 含 jpeg/png +2。
2. 取评分最高的，`setAttribute('data-codex-upload-target', target)`，然后 `DOM.querySelector` 该属性 + `DOM.setFileInputFiles`。
3. 验证：读 `已上传 N/M 张` 文本确认。

### ⚠️ 外挂 Chrome 上的诚实结论（2026-08-31，勿当已验证稳定）
用同一评分+`DOM.setFileInputFiles` 在**外部 Chrome**：单次设多文件 → 只传上**第1张**；**对同一输入框循环逐张设文件 → 计数不递增**（仍是 1，主图缩略图不在 `#picture`）。**外部 Chrome 的主图/详情图多张上传尚未跑通**（与软件内嵌浏览器行为不同）。不要把它写成"可靠做法"。**可复用结论**：软件内嵌浏览器环境里 setFilesOnPlatformInput 验证过流畅；外部 Chrome 需另行破解（可能要点「上传图片」按钮走原生文件对话框），属未解问题。属性填充（上面的 fillProductAttributes）在被识别为下拉的属性上已验证稳定。

## 迁移提示
属性/图片现在用**外部 Chrome（端口 9444）**驱动。软件内嵌浏览器（`--remote-debugging-port=9334/9335`）不稳定，但**它的 main.js 逻辑（fillProductAttributes / setFilesOnPlatformInput）仍是"该怎么填"的权威参考**——JS 片段可直接迁到外部 Chrome 的 CDP `Runtime.evaluate`。
