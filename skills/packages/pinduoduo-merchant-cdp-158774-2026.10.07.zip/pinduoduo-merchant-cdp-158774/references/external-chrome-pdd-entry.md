# 外部稳定 Chrome 直连 PDD 入口（2026-08-31 实测验证）

## 为什么用它
内嵌(WebContentsView)窗口对 PDD「商品列表→点发布新商品→选类目→进带类目编辑器」**全线不稳定**：坐标偏移(靠 `setZoomFactor(0.55)` 时 getBoundingClientRect 与物理点击不同步)、崩溃/掉线、重启丢登录。**换独立外部 Chrome 直连可稳定走通整个入口**，且登录一次长用、坐标准确。

## 启动（登录一次长用）
```
chrome.exe --user-data-dir=<持久目录> --remote-debugging-port=9444 \
  --no-first-run --no-default-browser-check --window-size=1600,1000 \
  https://mms.pinduoduo.com/goods/goods_list
```
- `<持久目录>` 换成机器上真实路径（如项目下 `pdd-browser-profile`）。登录态存这里，重启不丢。
- 找到本机 Chrome：`C:/Program Files/Google/Chrome/Application/chrome.exe`（Win 常见；Edge 同理在 Program Files/.../msedge.exe）。
- 驱动用 CDP `http://127.0.0.1:9444/json` 列标签 / 页面 WebSocket 发 Runtime.evaluate + Input.dispatchMouseEvent（与内嵌窗口同一套 CDP 脚本，只是端口换成外部浏览器）。

## 关键：点「发布新商品」→ 选类目 → 进正确编辑器（已实测）
1. 确认在 `goods_list`（登录后正常应自动落在商品列表）。
2. **用"视口内"过滤找工具栏「发布新商品」BUTTON**：`0<=getBoundingClientRect().left<=innerWidth && top>=0 && width>0 && height>0`（排除左侧边栏导航里那个被定位到屏幕外的同名项，内嵌窗口里它实测 `left=-150, top=-2999`）。外部 Chrome 里真按钮坐标 **@(244,462)**，坐标准确。
3. CDP `Input.dispatchMouseEvent` 点击 → **稳定进 `goods/category?id=..`**（带分类树的正确页，非无 id 空白页）。
4. 逐级原生点击选类目（用精确文本匹配取最小子节点 → 点其中心），实测坐标：
   - 美发护发/假发 **@(125,299)**
   - 染发烫发 **@(499,374)**
   - 彩染染发膏 **@(847,274)**
   - 确认发布该类商品 **@(792,872)**
5. **进正确编辑器 `goods_add/index?type=add`，顶部商品分类=美发护护/假发>染发烫发>彩染染发膏**。

> 页面 ID 每次导航/刷新会变，每次先 `curl /json` 重查目标页 ID，别用旧 ID。

## 该编辑器的规格 UI（与内嵌窗口不同，注意）
- 顶部**单个「规格类型」下拉**（placeholder=**规格类型1**）+ 默认 1 个 SKU 行（库存/拼单价/单买价/规格编码）。
- 点开「规格类型1」下拉 → 选项有 **容量/包装方式/属性/重量/套餐**（**没有"颜色"**——颜色需走标准"颜色"属性或另加为规格）。
- 下拉打开：点输入框触发；选选项：**用小节点 `dispatchEvent(new MouseEvent('click'))`**（原生坐标点击对下拉选项不一定生效）。
- 选中「**套餐**」→ 出现「**自定义套餐**」值输入框（实测 @398,189）+ 下方 SKU 行输入框。

## ⏳ 未解决（勿当已验证自动流）
给「自定义套餐」填 一盒装/两盒装/三盒装：
- 设 `input.value` + dispatch input/change → **不注册**；
- 原生 value setter + 键盘 Enter 事件 → **不注册**；
- CDP `Input.insertText` + `Input.dispatchKeyEvent`(Enter) → **不注册**。
**已验证（2026-08-31 尾段）**：CDP **逐字符真实键击**（`Input.dispatchKeyEvent` 每个字符发 `rawKeyDown`+`char`+`keyUp`）**能真正往「自定义套餐」里打入文字**——输入框确实出现了值（如“三盒装一盒装一两盒装盒装”）。`Input.insertText` 单发不认、`.value`+事件不认；真实逐键对受控组件有效。**但**拼多多该输入是**受控组件**，程序化输入不买账；**`char:'\r'` 会把回车当字符插入**（要用纯 `rawKeyDown` Enter，去掉 char 事件）。填颜色值、逐行填 库存/拼单价/单买价/规格编码、提交并上架 尚未跑通。

**最新精确卡点（2026-08-31 尾段实测）**：逐键**能打入文字**，但**回车没把每个值"提交成独立标签(tag/pill)"**——一盒装/两盒装/三盒装堆在一个输入框（`tags=0`）。即"打进去"已解决、"提交成标签"是剩的小触发，需搞清正确触发（可能是输入框外的"添加"按钮 / 失焦 blur / 特定 keydown 的 keyCode），再 填颜色值→逐行填SKU→提交。

## 结论
- **入口用外部 Chrome 可稳定跑通**（避开内嵌窗口坐标/崩溃/登录问题）——这是本项目从"内嵌窗口自动化"转向"外部稳定驱动"的可行路线。
- 入口之后（受控输入/SKU 逐行/提交）仍需真实 keystroke 与更多真机调试。
