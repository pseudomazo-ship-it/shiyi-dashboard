# 上架直操 · Playwright 版（CDP 9337）— 2026-09-25 实测 28/28 跑通

> 这是**上架这条线现在的主力**（与本文档别处那套「Electron 上架工具 + 9444」是两套东西，别混用）。
> 把 `F:\解析链接文件汇总\店铺解析\<商品ID>.txt`（自家商品快照）逐个上架到拼多多店铺，**默认只存草稿**。

## 一、项目与浏览器

- **项目**：`D:\Agent.GongZuoQu\Hermes.GZQ\项目--上架控制台Playwright版`
  - 界面层（一般用不到）：Electron 控制台 `启动控制台.bat` / `npm start`
  - **实操层（真正干活的）**：`_direct\*.js` 直接连独立 Chrome 的 CDP 跑；
    `src\worker\publisher.js` = 8 步上架流程；`src\domain\*` = TXT → 紫盒模型
- **独立 Chrome**：CDP **9337**，配置源 `D:\Agent.GongZuoQu\Hermes.GZQ\上架直操-<日期>\state.json`
  拉起 = `node _direct/01-open-login.js`（spawn `chrome.exe --remote-debugging-port=9337 --user-data-dir=%APPDATA%\listing-console-pw\profiles\store-<ts>`）
- ⚠️ 该脚本**只打开登录页，绝不填账号密码** —— 登录由十一**人工扫码/短信验证**（不破解验证码是硬边界）

## 二、开工前两件事（顺序不能反）

### 1) 探活 + 登录态
```bash
curl -s -m 5 http://127.0.0.1:9337/json/version   # 有 Chrome 版本号 = 浏览器活着
```
连上去读页面：URL 含 `/login` 或正文有「扫码登录 / 请输入短信验证码 / 忘记密码」= **要十一重新登录**
→ 亮黄提醒 + **停手等人工**，不要自己尝试登录。
**登录态约 2 天就过期**（本次 9/23 跑完 → 9/25 已过期）。

### 2) 确认店铺（最容易出事的一步）
- 读右上角店铺名（截图 + vision 最省事）
- ⚠️ **账号名 ≠ 店铺名**（账号「十一护肤美妆官方」可以管多家店；本次登录到的店铺是「蒙倩护肤美妆官方旗舰店」）
- ⚠️ **一个账号可切多家店** → 上错店 = 几十个草稿全进别人家
- 判据：`goods_list` 页签条数（如「在售中(2) / 草稿箱(0)」）+ 右上角店铺名，两个一起看

## 三、跑批

```bash
cd /d/Agent.GongZuoQu/Hermes.GZQ/项目--上架控制台Playwright版
node _direct/20-run-all.js                      # 跑 TXT 目录里全部
node _direct/20-run-all.js --only=111,222          # 只跑指定 ID（补跑用）
node _direct/20-run-all.js submit                # ⚠️ 真提交上架！十一说「存草稿」时不要加
```

- 脚本顶部有 **`DONE = ['<id>']` 硬编码跳过名单** → 草稿箱已清空/要全量重跑时**先清空它**，否则静默漏跑那几个 ID（本次漏了 `180382281996`）
- 节奏 ~4 分钟/个；28 个 ≈ **2 小时** → `background=true` + `notify=true`，别前台等
- 日志：`上架直操-<日期>\log-<商品ID>.txt`（一个商品一份，8 步标记 ①…⑩）
  成功标志 = `⑩ ✅ 保存草稿：提交成功：暂无错误内容`；末尾汇总 `✅ <id>  SKU n / 详情图 m`
- ⚠️ **日志里的时钟是 UTC**（比本地文件时间早 8 小时）→ 别以为日志没在更新

## 四、验证（必做，别信脚本自报的 ok）

- `node _direct/31-list-drafts.js` —— 列草稿箱前 16 条（ID + 标题）
- `node _direct/32-match-drafts.js` —— 把 TXT 标题逐个与草稿箱匹配
- ⚠️⚠️ **匹配 0 命中时先查店铺对不对**，不要以为脚本坏了 —— 本次 0/29 的真因就是**登录的是另一家店**
- ⚠️ **草稿箱页签的数字不是实时的**：刚存完可能还显示 `草稿箱(0)`，**重新进一次 `goods_list` 才刷新**（本次实测：先读到 (0)，重进后是 (27) ✓）。计数以页签为准
- 点页签要**真人节奏**（0 延迟会被平台拒，且**不报错、只是没反应**）：
  ```js
  const box = await tab.boundingBox();
  await p.mouse.move(box.x + box.width/2, box.y + box.height/2);
  await p.waitForTimeout(250);
  await p.mouse.down(); await p.waitForTimeout(160); await p.mouse.up();
  ```

## 五、踩过的坑

| 坑 | 真相 / 处理 |
|---|---|
| `page.goto: net::ERR_PROXY_CONNECTION_FAILED` | 本机**系统代理**（`127.0.0.1:7897`）**偶发掐断**（netstat 里一堆 `FIN_WAIT_2`；代理本身 `curl -x` 通）→ **直接重试即可**（本次 3 个商品中招，重试全过）。别怀疑脚本、别改代码 |
| 脚本报 ok、草稿箱却是 0 | 见上「数字不实时」→ 等 10 秒并重新 goto `goods_list` 再读 |
| 每单都报「白底图 0 张 / 包装标签图 0 张」 | 源 TXT 里**本来就没有**这两类图（不是脚本漏传）→ 平台必填，所以**只能存草稿、提交会被拦**。要提交上架必须先补图 |
| 长跑中途想并行查草稿 | **别在同一个 9337 上跑第二个脚本**（抢页面会互相打断）→ 先停批再查 |
| `--only` 里含 `DONE` 名单的 ID | 会被静默过滤掉 → 先清 `DONE` |
| 十一说「停止」 | 立刻停手 + 确认没有 `20-run-all`/`runner.js` 进程（`wmic process where "name='node.exe'" get commandline`）；**专用浏览器留着别关**（保登录态） |

## 六、交付

- 报：成功/失败数 + 每个 ID 的 SKU 数/详情图数 + **草稿箱实读条数**（两个数字必须闭环，本次 26+1=27 ✓）
- 失败的**逐个重试**（本次失败全是代理抖动，重试即通），重试后更新汇总
- 别忘了同时说明：**这一批全是草稿、一个都没提交上架**
