# 复议（消费者负向体验补偿 → 复议）真实流程选择器（2026-08-30 实测）

> 给 `pinduoduo-merchant-cdp` 的 SKILL.md 配套。产出工具：`订单申诉复议自动处理工具`（data/cdp-run-review.js）。

## 与申诉的差异（一句话）

申诉入口 = `customer_complain_appeal?from=list`，表单是**详情页内「发起申诉」模态框**。
复议入口 = **另一个** `orders/appeals/negativeExperienceReconsider`，提交按钮是「**提交复议**」，原因选项**实测含「其他」**（早期 dump 漏抓、误判为无；实际可选中「其他」并展开表单）。

## 真实入口链路（实测）

```
/orders/appeals                     # 订单申诉页
→ 消费者负向体验申诉卡片下的「去复议」   # 不是「全部可复议申诉」！那是复议页内部的一个 tab
→ 打开新标签：/orders/appeals/negativeExperienceReconsider?reconsiderSecondaryTabKey=negativeExperience
→ 列表「以下申诉可发起复议」（近30天复议成功 N 单，返还金额 M 元）
    表头：订单编号 | 商品信息 | 问题类型 | 处理金额(元) | 处罚时间 | 复议倒计时 | 操作
→ 操作列：「发起复议」+「查看详情」
→ 点「发起复议」→ 弹复议表单
```

## 复议表单字段（实测 dump）

- 复议原因：自定义下拉，input placeholder「**请选择**」。真实选项（**含「其他」**，用同容器去重选中；其余具体项）：
  - 商品无问题，消费者误解
  - 商品有问题，但已与消费者达成一致其他售后方案
  - 商品有问题，但消费者主动表示无需处理
  - 消费者未表达商品问题（含售后详情内未描述问题等）
- 复议说明：textarea，**选完原因才展开**（原因没选时 `textareas:0`）。
- 凭证：上传区，选完原因后出现（`input[type=file]`，`uploadFiles(-1, evidence)`）。
- 提交按钮：「**提交复议**」+「取消」；成功判据 = 页面出现「提交复议成功，平台将在3至7个工作日内给出复议结果」且该订单从「可复议」列表消失（用 /受理|已提交/ 判会误判）。
- 凭证硬校验：**必须与首次申诉不同**（否则「请补充与首次申诉不同的有效凭证」拦截、表单不关、订单仍在可复议）。
- **「发起复议」按钮只能用 JS `el.click()` 触发**：CDP 坐标点击（clickByText/clickByExpr）返回 ok 但页面毫无反应；用 `[...document.querySelectorAll('button,a,span,div')].filter(文本==='发起复议'&&offsetWidth>0).sort(按 children 数取最少).click()`，再 `waitText(['提交复议','复议原因'])` 确认，建议 3 次重试。页面多个「其他」同名，取与「商品无问题」同容器的候选去重。
- 选完原因才展开 textarea/上传区（未选时 `textareas:[] fileInputs:[]`）；填说明/传凭证前保证表单已展开，各加等待+重试（~1.8s × 3）。
- 列表中无行 =「暂无可复议订单」（正常，无故障）。

## 用诊断脚本先摸清真实 DOM（必做，别凭假设写选择器）

内联 `node -e "..."` 会被 shell 转义破坏（`${v}` 被插值），一律写独立 `data/diag-*.js`：

1. `http://127.0.0.1:9333/json` → 确认 9333 在线 + 列 page 标签。
2. 判登录：读任意 `mms.pinduoduo.com` 页 `document.body.innerText`，有真实数据（可申诉订单 99+ 等）= 已登录；`扫码登录|账号登录` = 未登录。
3. `Page.navigate` 到入口 URL → `sleep(9000)` → eval body.innerText dump 全文 + `grep` 可点文本（`复议|可复议|发起复议|提交复议|去复议`）。
4. 逐个点真元素（`clickByText` 或坐标点击），看**跳转 URL / 新开标签**；展开下拉 dump 真实选项。

## 验证守卫（亮黄 + 等人工 + 自动续）实现要点

- 关键词：`/验证码|安全验证|拖动滑块|拖动下方滑块|请完成验证|人机验证|安全校验|风险确认|滑块|图形验证|请输入验证码|完成验证/`。
- 命中 → `log('【需人工介入】⚠️ 检测到验证/安全校验——请到专用 Chrome 完成验证，工具在此等待，处理完会自动继续')`。`【需人工介入】` 是界面亮黄横幅的信号（renderer 的 onLog 里 `/需人工介入/.test(msg) → showHumanAlert()`，`#humanAlert` 黄底白边闪烁 + 「知道了」按钮）。
- `while` 每 `sleep(3000)` 轮询；验证文本消失 → `log('✅ 人工已处理验证，继续运行')` → 返回 true，**当前笔继续，随后进下一笔**。
- `maxWaitMs=300000`（5 分钟）未处理 → `log('【需人工介入】等待人工处理超时，本轮跳过')` → 返回 false，跳过本轮。
- 检查点：表单/弹窗出现后、提交前，各一次。

## 暂停（真·可继续）实现要点

外部 spawned 子进程无 IPC，用**标志文件**：主进程写/删 `data/pause.flag`，脚本每笔之间 `waitIfPaused()` 轮询（存在→等，删除→续），stop 时清 flag。暂停落在**笔与笔之间**（安全边界），不断进行中的一步。

## 配置隔离（申诉 / 复议各自独立）

不要复用 `appeal-config:*` IPC 存复议配置。应为复议开独立 `review-config:load/save/pick-evidence/remove-evidence`，独立 `data/<flow>-config/{config.json, evidence/}` 目录。共用会导致：复议保存覆盖申诉话术/原因/凭证，切页时互相污染。

## 少触发（降风控 / 验证拦截）

随机人类节奏 `sleep = base + rand(spread)`（连表单 3000+1000、查询 3500+1200、首笔详情 5000+1500、每笔间 3500+2000）。提交前先跑验证守卫。真实批量前必须 `--dry` 干跑（填表不提交）验证选择器全绿。
