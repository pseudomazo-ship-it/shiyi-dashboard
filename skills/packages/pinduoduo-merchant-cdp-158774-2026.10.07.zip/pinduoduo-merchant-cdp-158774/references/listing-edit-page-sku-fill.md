# 拼多多「相似品 / 机会商品」编辑页 —— 补价格·库存·规格编码·标签图

> 实测 2026-09-29，**2026-09-30 大幅更正 + 补全**（规格编码规则、虚拟列表读写法）。
> 页面：`https://mms.pinduoduo.com/goods/goods_add/index?type=add&from=chance&id=<机会商品ID>&goods_id=<商品ID>&chance_tab=search&sourcePage=goodsListTopButton_CHANCE`
>
> **和 `listing-direct-playwright-9337.md`（从 TXT 全流程上架）不是一回事** ✗ ——
> 这是**平台已经生成好的相似品草稿**（主图/SKU图/详情图都由平台预填 ✓），只补几项再提交。
> 走同一条线：CDP **9337** 独立 Chrome + `playwright-core` `connectOverCDP('http://127.0.0.1:9337')`，脚本放 `_direct/*.js`。

---

## 0. ⚠️ 两条最重要更正（2026-09-30 用户纠正 + 实测，先读这段）

**① 规格编码 ≠ `B编号#颜色`，也 ≠ `色号#颜色#档位`** ✗（本文件旧版建议的 `色号#颜色#档位` 是错的 ✗）

| 字段 | 写什么 |
|---|---|
| **颜色**（商品规格的规格值） | `B165#自然黑`（**编号 + # + 颜色名**，保留原后缀如【免漂发色】居家快染）|
| **规格编码** | **色号表编码 + 盒数**，例 `Y C677黑茶色【紫盒】2盒`、`W 775焦糖栗棕【紫盒】3盒` |

- 来源：项目 `src/domain/purple-box-rules.js` → `buildSpecCode(rawCode, _fixedColor, quantity) { return `${rawCode}${Math.max(1,quantity)}盒` }` ✓（= 「A 老规矩」）
- **盒数确认不了 → 默认 2 盒**（用户 2026-09-29 定；价格、编码都要对应同一档）
- 旧例：`W C623冷咖棕【紫盒】2盒`、`W 775摩卡色【紫盒】3盒`
- 色号表 = 312 条紫盒色号（全表见工作区 `文档--紫盒规格编码规则\紫盒规格编码规则与色号总表_2026.09.2x.md`，也已传 IMA「公司：各事项/第三方」）

**② 填 SKU 表别在「全屏编辑」上耗时间** ✗（本页点不开）

2026-09-30 实测：`goods_add` 编辑页的「全屏编辑」蓝字链接在 **y≈1061（窗口高 1060）**，**落在视口外** —— 按 `getBoundingClientRect` 取的坐标直接 `mouse.move` 会**点到别的东西** ✗；改用 Playwright 自动滚动的 `locator.click()` **也没打开弹窗** ✗。折腾 3 轮无果 ✗。
（注：**另一个页面**——发布新商品 add 编辑器的「全屏编辑」是能用的 ✓，见 `pdd-sku-fullscreen-edit.md`。两个页面的行为不一样，别把结论互套。）

**➡️ 本页填 SKU 表的正确解法 = 直接操作它的滚动容器（第三节）✓**

---

## 一、页面结构（先看清再动手）

**规格与库存区列名**（`th` 原文）：
```
净含量 ｜ 颜色 ｜ *库存 ｜ *拼单价(元) ｜ *单买价(元) ｜ *预览图 ｜ 规格编码 ｜ 状态
```
底部两个按钮：**`提交并上架`** / **`保存草稿`**

**图片区（页面原文要求）**：
| 区 | 要求 |
|---|---|
| 商品轮播图 | 宽高比例 **1:1 或 3:4**、宽高均 **>480px**、**3M 内** |
| 白底图 / 长图 | 同上 |
| **包装标签图** | **1:1 或 3:4、>480px、3M 内** |
| 商品详情 | 已上传 N/100 |

⚠️ 十一给的标签图是**实拍**（常见 3:1 / 4:3）✗ —— **先试传**，被拦**立刻报给他**（别自己裁 ✗ 别静默跳过 ✗）。实测平台对 3:1 和 4:3 **没报尺寸问题** ✓（本次 2/10 张成功）。

## 二、读 SKU 表（坑都实测踩过）

### 坑1：表头表和表体表是**两张 `<table>`**
`[...document.querySelectorAll('table')].find(t => /拼单价/.test(t.innerText))` 找到的是**表头那张** ✗，它的 `tbody tr` = **0** ✗（跟视觉上明明有 28 行矛盾，极易误判成"没渲染"）。

**两种可用的读法**（都验过）：
```js
// A. 取 tbody tr 最多的那张表
let best=null; document.querySelectorAll('table').forEach(tb=>{
  const n=tb.querySelectorAll('tbody tr').length;
  if(n>(best?best.querySelectorAll('tbody tr').length:0)) best=tb; });

// B. ★更稳：全局拿所有「有 ≥3 个 text 输入框的行」，不看是哪个 table
const trs=[...document.querySelectorAll('tr')].filter(tr=>tr.querySelectorAll('input[type=text]').length>=3);
```
→ 本页经验：**A 有时仍会挑到没行的表**（表头表也可能带 tbody 度量行 ✗）；**B 一次就能拿到 15/33 行，最省事** ✓。

### 坑2：行是**懒渲染**的
刚进页面 `tbody tr` = **0** ✗。必须先滚过去再等：
```js
await p.evaluate(()=>{ const el=[...document.querySelectorAll('*')].find(e=>(e.innerText||'').trim()==='规格与库存'); if(el) el.scrollIntoView({block:'start'}); });
await p.waitForTimeout(6000);      // 之后行才出现
```

### 坑3：`td.innerText` **不含 `<input>` 的 value**
读出来库存/价格/编码看着全空 ✗，其实值都在 input 里 ✓。要读真实值：直接读 `input.value` ✓（比截图+vision 快），或截图 + vision 复核 ✓。

### 坑4：**虚拟列表**只渲染一屏（本页约 15 行）
33 行的表，任何时候 DOM 里只有 ~15 行 ✗。
**➡️ 想"看到"后半部分，唯一的路 = 滚它的滚动容器**（第三节）。

## 三、★虚拟列表读写法（2026-09-30 跑通 33/33 的那套）

### 3.1 找滚动容器：**从任意一行往上走**
```js
const row = [...document.querySelectorAll('tr')].find(tr=>tr.querySelectorAll('input').length>=3);
let n=row, sc=null;
for(let k=0;k<12&&n;k++){ n=n.parentElement; if(!n)break;
  if(n.scrollHeight>n.clientHeight+20 && n.clientHeight>200){ sc=n; break; } }
window.__sc = sc; sc.scrollTop = 0;      // 或 += 600 逐屏滚
```
- ✗ **滚页面（`window.scrollBy` / `mouse.wheel` 在表格外）动不了它** —— 表格有自己的滚动容器，本次在 x≈1109、窗口只有 1060 高，鼠标放 (900,600) 滚的是整页 ✗
- ✗ 别用「表格 boundingBox 中心」当鼠标落点（本次表头那截只有 45px 高，落点全偏 ✗）
- ✅ **先探测状态**：本次容器 `scrollHeight 2309 / clientHeight 756 / scrollTop 1553` = **已经在底部** → 那 5 个"找不到"的颜色**其实就在页面上** ✓（读一下填上就完事 ✓）

### 3.2 边滚边读、去重核对（**收尾必做**）
```js
const seen = new Map();
for (let i=0;i<14;i++){
  const snap = await p.evaluate(()=>{
    const trs=[...document.querySelectorAll('tr')].filter(tr=>tr.querySelectorAll('input[type=text]').length>=3);
    let last=''; const out=[];
    trs.forEach(tr=>{
      const tds=[...tr.querySelectorAll('td')].map(td=>(td.innerText||'').replace(/\s+/g,' ').trim());
      const cc=tds.find(x=>/【/.test(x)); if(cc) last=cc;            // 颜色是合并单元格 → 只在本组第一行 → 向下继承
      const ins=[...tr.querySelectorAll('input[type=text]')];
      if(ins[3]) out.push((last||'').split('【')[0].replace(/^B\d+#/,'').trim()+'||'+(ins[3].value||'(空)'));
    });
    const b=window.__sc.scrollTop; window.__sc.scrollTop=b+600; return {out, moved: window.__sc.scrollTop>b};
  });
  snap.out.forEach(k=>seen.set(k,1)); if(!snap.moved) break; await p.waitForTimeout(800);
}
// 期望行数 = 颜色数 × 档位数（本次 11×3 = 33）；空值数必须为 0
```
→ 本次结果：**扫到 33 行 / 有值 33 / 空着 0 / 涉及 11 个颜色** ✓ —— **这就是"跑通"的验收方式**：不看单屏、不看脚本自己的 ok，**全表去重扫一遍数行** ✓。

## 四、规格编码规则（**以第 0 节为准**）

- **规格编码 = 色号表编码 + N盒** ✓（`Y C677黑茶色【紫盒】2盒`）
- **`B编号#颜色` 写在「颜色」规格值里** ✓（不是编码列 ✗——这是 9/30 用户明确纠正的）
- **编号跨链接不重复、按顺序续接** ✓（用户 2026-09-29 原话「后续所有链接所有颜色不要有重复，按照顺序以后每个链接内的颜色都要有」）；**按页面颜色从上到下排** ✓
  - 快照（会过期）：`1011009223371` = B165–B178；`1011043433228` = B163–B176；截至 2026-09-30 用到 **B178 → 下一链接从 B179 起** ✓
- **色号表有重复/脏数据** ⚠️：同一颜色名可能有 2–3 条候选（冷茶棕 = `W C623冷茶棕色【紫盒】` / `W 623…` / `W  C623…` 双空格；荔枝粉棕 = `W C6/5…` / `W C645…`；摩卡棕 = `W C647…` / `W 775…`；还有 栗棕色 / 树莓红 / 粉棕色 各有 2 条）→ **取候选第一条（与前面链接取法一致）并在交付里点명这是有歧义的颜色** ✓，别静默选一个 ✗
- 「**是不是几盒**」在型号/套餐列文本里可读（如 `2盒420ml齐胸发选择这个哦`）→ **能读出盒数就用读到的**，读不出才默认 2 盒 ✓

## 五、填充技术要点（Playwright，逐条踩过）

1. **写输入框用 Playwright `locator.fill()`** ✓ —— `Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set` + 派发 `input/change` 在本页**不生效** ✗（React 受控）
2. **`page.evaluate(fn, arg)` 只传一个参数** ✗ —— 传第二个（如一个映射表）会被静默丢掉 → **映射表写进函数体内部** ✓
3. **视口外的元素，坐标点击必然点错** ✗ —— `getBoundingClientRect()` + `mouse.move` 仅对**当前视口内**的元素可靠；视口外要用 **Playwright `locator.click({delay:150})`**（自动滚动）✓，且**元素是否在视口内先自查** ✗
4. **本编辑页会「自动保存草稿」** ⚠️ —— 一次超时/误操作就会**把坏状态写进草稿**（本次把「净含量」规格值弄没了 ✗）；**别做没回读的多步危险编辑** ✓，改错立刻回读 + 报给十一 ✓
5. **只填被要求的字段** ✓ —— 用户说「你只需要填写一下规格编码，其他不需要你操作」就**只动编码列** ✓；**别调 `fillSkus`** ✗（它会连库存/拼单价/单买价一起写 ✗）。项目 `src/worker/publisher.js` 可复用的导出：`ensureSpecType` / `fillSpecValues` / `fillSkuRow` / `tagVisibleSkuRows` / `scrollSkuTableByScreen` ✓（但用之前先确认它改的字段是不是你要改的）
6. **点不动的按钮按顺序试**：①`locator.click({delay:150})` → ②派发原生事件序列（`pointerdown/mousedown/pointerup/mouseup/click`）→ ③CDP 真实鼠标（按住 150ms）——别死磕一种 ✓

## 六、🚦 开工前必须停下来的两类情况（提交不可逆）

1. **页面结构与十一的描述不符**（维度数量/颜色个数/色号位次/价格档数 任一对不上）→ **列证据 + 一次问完再动** ✓（9/29 那次就是这么办的：5 个问题一次问清）
2. **要点的是不可逆按钮**（`提交并上架`）→ 即使他说过"直接提交" ✓，也**先回读逐格核对 → 截图给他看 → 他点头再点** ✓

## 七、可复用的动作顺序

```
① connectOverCDP(9337)（setDefaultTimeout(8000)，别让一步卡死 7 分钟 ✗）→ 找 /goods_add/ 那个 page
② 滚到「规格与库存」+ 等 6s
③ 从任意一行往上找滚动容器 → 探测 scrollTop/scrollHeight（可能已在底部 ✓）
④ 边滚边读全表（颜色继承 + input.value）→ 数行数、对期望值（颜色数 × 档位数）
⑤ 只填被要求的字段（本次只填规格编码）→ Playwright .fill()
⑥ 再扫一遍全表去重核对：有值数 = 期望行数、空值 = 0 ✓
⑦ 报结果（含歧义项、未提交状态）；不可逆动作等十一点头
```

> **十一的沟通底线（2026-09-30）**：「**你只需要填写 X，其他不需要你操作**」= 只做 X，别顺手美化/补全/重构 ✗；「**自己跑通**」= **不要把半成品丢回给他让你手动收尾** ✗ —— 卡住了换方法接着做（本次换了 4 种才跑通），最后给「全表核对后的完整结果」✓。
