# Electron 上架工具打包（国内网络）— 类级可复用

把「上架工具」这类 Electron 桌面工具（主进程 `src/main.js` + `renderer/`）打包成 Windows 安装版 / 免装版。
下次要「优化打包跑通」直接照此做，别从零试。

## 1. 依赖安装
```bash
npm install --save-dev electron electron-builder   # electron 44 / electron-builder 26
```
- 装完 `node_modules/electron` 的 npm 包装在，但**二进制没下**（真正报错在跑 `electron`/`npm run start` 时：
  `TypeError: fetch failed … Downloading Electron binary … Electron failed to install correctly`）。

## 2. 🔑 国内网络修法（最大坑）
Electron 默认从 GitHub `github.com/electron/electron` 拉二进制 → 被墙直接失败。
```bash
export ELECTRON_MIRROR="https://npmmirror.com/mirrors/electron/"
cd node_modules/electron && node install.js          # 用镜像重新下载二进制
ls dist/electron.exe                                  # 存在=成功
```

## 3. electron-builder 配置（package.json 加 build 段 + script）
```json
"scripts": { "dist:win": "electron-builder --win" },
"build": {
  "appId": "com.mengqian.product-console",
  "productName": "链接差异化批量上架控制台",
  "asar": true,
  "files": ["src/**/*", "renderer/**/*", "package.json", "data/**/*"],
  "directories": { "output": "release" },
  "win": { "target": [{ "target": "nsis", "arch": ["x64"] }] }
}
```
- `files` 必须显式列 src/renderer/package.json/data；`data/` 放模板/词库/色号表。
- 无自定义图标 → electron-builder 用默认图标（仅提示，可忽略）。

## 4. 打包命令（镜像 + 缓存）
```bash
export ELECTRON_MIRROR="https://npmmirror.com/mirrors/electron/"
export ELECTRON_BUILDER_BINARIES_MIRROR="https://npmmirror.com/mirrors/electron-builder-binaries/"
export ELECTRON_BUILDER_CACHE="E:/软件/Hermes/cache/electron-builder"   # 复用缓存
npm run dist:win
```
- 产物：`release/链接差异化批量上架控制台 Setup <ver>.exe`（NSIS 安装版）
  ＋ `release/win-unpacked/<产品名>.exe`（免装版，体积更大）。
- 后台跑（`background=true` + `notify=true`），下载 nsis/winCodeSign/7zip 用上面的镜像。

## 4b. ⚠️ 正在跑打包版时重复打包 → EPERM 锁文件
上次打包出的 `release/win-unpacked/<产品名>.exe` **正在运行**时，再次 `npm run dist:win` 会报
`EPERM: operation not permitted, unlink 'release\win-unpacked\d3dcompiler_47.dll'`（打包器要清 win-unpacked，但程序锁着 DLL）。
- **不要杀正在运行的程序**（十一正在操作）——**打到另一个目录**：
  `npx electron-builder --win -c.directories.output=release2`（输出 `release2/win-unpacked/`，与旧版并存、互不锁）。
- 产物在 `release2/链接差异化批量上架控制台 Setup <ver>.exe` + `release2/win-unpacked/<产品名>.exe`。
- 若确实要覆盖 `release/`，先 `Stop-Process` 关掉运行中的旧版再重打。

## 5. 验证打包版能跑
```bash
"./release/win-unpacked/<产品名>.exe" --smoke-test
```
- 期望 `SMOKE_RESULT={"ready":true,"panels":…}`、退出码 0。`--smoke-test` 是工具自带的启动自检（渲染出标题+面板即可）。

## 6. 本次 session 修的 bug（打包前的 `npm run smoke` 暴露）
`switchBrowserShop`（src/main.js）在 `browserView` 为 null 时 `.setVisible` 崩溃：
`Error occurred in handler for 'browser:switch-shop': Cannot read properties of null (reading 'setVisible')`。
- 场景：smoke-test / 未初始化内嵌浏览器时切店铺 → `attachBrowserView` 没建出 view。
- 修法：`attachBrowserView(shopId)` 后加 `if (!browserView) return {ok:false, shopId, message:'无法创建店铺浏览器视图'};` 再 `.setBounds/.setVisible`。

## 7. 流程顺序（本工具，勿乱序）
smoke 验证加载 → 修崩溃 → 单测（`node --test tests/*.test.js`，18/18）→ `dist:win` 打包 → 跑打包版 `--smoke-test`。
