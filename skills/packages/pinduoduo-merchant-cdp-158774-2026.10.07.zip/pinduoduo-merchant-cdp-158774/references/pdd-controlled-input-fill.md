# PDD 受控输入框填充（真实键盘逐字符法）— 2026-08-31 实测验证

## 结论一句话
拼多多发布新商品编辑器的「自定义套餐」「选择或输入主色」等输入框是 **React 受控组件**，**程序化 `.value` 赋值 / `Input.insertText` 单次注入 / dispatchEvent 全部无效**。**唯一可靠解法 = CDP `Input.dispatchKeyEvent` 逐字符真实键击**：`rawKeyDown` + `char` + `keyUp`（每字符一次），配合先点击聚焦。

## 逐字符真实键击（已验证的 fill 内核）
```js
await send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
for (const ch of text) {
  await send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: ch, code: 'KeyX', text: ch, unmodifiedText: ch, windowsVirtualKeyCode: 0, nativeVirtualKeyCode: 0 });
  await send('Input.dispatchKeyEvent', { type: 'char', text: ch, key: ch, code: 'KeyX', unmodifiedText: ch, windowsVirtualKeyCode: 0, nativeVirtualKeyCode: 0 });
  await send('Input.dispatchKeyEvent', { type: 'keyUp', key: ch, code: 'KeyX', text: ch, windowsVirtualKeyCode: 0, nativeVirtualKeyCode: 0 });
  await sleep(50);
}
```
- CDP 连接用 **Node 内置 `WebSocket`**（Node 22+），不要 `import ws`（从临时目录/非项目目录跑会 `ERR_MODULE_NOT_FOUND`）。`Runtime.evaluate` 必带 `userGesture: true`（否则部分 PDD 弹层不响应）。
- 中文/复杂字串可直接逐字符 char 打（PDD 按字符接受，无需 IME）。

## 「套餐」值：横向多个「自定义套餐」输入框逐个填
用户口述：**第 1 个框填一盒装、第 2 个（横向）框填两盒装、第 3 个三盒装……**，**不是回车生成标签**。
- 点「添加规格类型」→ 下拉点「套餐」→ 出现「自定义套餐」输入框 + SKU 行。「添加定制规格」(≈493,245) 可加值。
- 填法：**按索引**找 `input[placeholder*='自定义套餐']`（按 `getBoundingClientRect().left` 升序），**第 n 个框清空 → 逐字符打值**；**每填一个自动出下一个空框**（无需回车）。
- 实测：填第 1 个后 `['一盒装','两盒装','三盒装','']`，`fill-nth.mjs` 按索引填即可。

## 「颜色 / 主色」输入框：**必须连点两次**
「选择或输入主色」输入框：**第一次点击显示标准色选择器；再点一次（第二次）才进入文本输入模式**，然后逐字符打字即提交，并自动出下一个颜色框。
- 实测：连点两次后打「亚麻棕」→ `主色值 ['亚麻棕','']`（新空框自动出现）；批量 `fill-colors.mjs` 连点两次+逐字符。
- 只点一次 + 直接打字 → 值进不去（选择器挡着）；`getBoundingClientRect` 坐标可点击（把坐标换算到元素中心，点击坐标在页面未缩放时=CSS坐标，准确）。

## 外挂编辑器规格结构（发布新商品 add 页，类目=彩染染发膏）
- 顶上单个「**规格类型1**」下拉（placeholder=`规格类型1`，选项=容量/包装方式/属性/重量/**套餐**，**无颜色**）；下方默认 1 个 SKU 行；价格及库存区列=**库存|拼单价(元)|单买价(元)|规格编码|商品编码|状态**。
- 「颜色」是**独立的标准色属性**（选择或输入主色 + 备注（偏深/浅等）），**不在**规格类型下拉里。
- 填完颜色值 + 套餐值后，**SKU 矩阵确实会生成**（颜色×套餐 交叉表，行=亚麻棕×一盒装/两盒装/三盒装 等，规格编码如 `W 011【紫盒】1盒`）。**排错注意**：用「库存」标签（`innerText==='库存'`）计数**会误判成 1 行**——矩阵是表格，库存/套餐是**列头**，不是每行一个标签；正确看「价格及库存」表格区实际行数。

## 「颜色×套餐」SKU 逐行填表：库存/拼单价/单买价（2026-08-31 实测）

矩阵生成后逐行填 **库存 / 拼单价(元) / 单买价(元)**，关键坐标与价格规则（已验证，填了 12 行价格全对）：
- 每行 3 个 `input`（placeholder=`请输入`）列位置：**库存 @x≈661、拼单价 @x≈792、单买价 @x≈1006**；行距 ≈69px（y 从 ~204 递增，滚动后重取）。
- **价格规则**（参考用户填法）：**一盒装=库存500/拼20/单30，两盒装=500/40/60，三盒装=500/60/90**；每色循环 一盒→两盒→三盒。
- 填法：对每个 `[y, 套餐]` 依次 点击+Ctrl+A+Delete 清空+逐字符真实键击 到 (661,y),(792,y),(1006,y)。脚本 `fill-sku-rows2.mjs`（按 `[[y,"一盒装"],...]` 用 PRICE 循环填）。
- ⚠️ **虚拟列表/滚动敏感**：滚动后行 y 与行检测会变（`scrollingElement.scrollTop` 改、行检测可能归零）；填后续行须先滚到目标行所在视口再重取 y。且 (y 附近的)「满2件 9.5折」「单买价 系统自动计算」等**不是 SKU 行**，点它们无效果，勿当空 SKU 行。
- **颜色×套餐是否有行要先数对**：用「库存」标签计数会误判为 1 行（库存是列头）；直接**在「价格及库存」表格区数 库存@661 列的输入行**。

## ⚠️ 连点两次必须慢速 + 每次验证颜色是否进值（2026-08-31 尾段实测修正）
"连点两次"**不是快速双击**，而是**两次独立的慢速点击**：第1次点击(显示选择器)→**停~500ms**→第2次点击(进文本输入)→停~500ms→再逐字符打字。用 350ms 间隔的快速"双击"→ 颜色值**进不去**（主色值全空）；用 500ms 慢速 + 每色填后验证 → 值能提交。所以颜色批量脚本要**慢速连点两次 + 填后验证(失败重试≤3次)**。

## 🔑 SKU 表是虚拟列表：填的值"滚走就清零"（关键，别误以为填了）
逐行填 SKU（库存/拼/单/编码）后**滚到别处再滚回来，值会被页面重置清空**（实测：滚到顶部后，18 行只剩 6 行保留值；脚本报的"填了 34 行"是跨滚动重复统计+重置）。所以**逐行程序填整张大的 SKU 表不可靠**——虚拟列表只渲染+保存当前视口行的值。**规避方向 = 用编辑器的「Excel批量编辑规格 / 全屏编辑」按钮**（该编辑器有此功能；PDD 官方支持用 Excel 一次填整张 SKU 表的 库存/价格/编码/预览图），一次填全绕过虚拟列表——这可能是正确的正路，待验。

## 检测受控输入的坑：值可能被提交成"标签"，不在 input.value 里
判定某值是否填进受控输入框，用 `input.value`/`v.includes(c)` 可能**假失败**——值被提交成标签(chip)后 input.value 为空。判断"是否真的成了值"要看页面文本/标签，不只信 input.value。

## SKU 矩阵列坐标"每状态都变"，务必每次重测
库存/拼/单/编码的 x 坐标在不同页面状态不同（一次 661/792/1006，另一次 614/721/896/1159）；填表前先 dump 一次真实列 x，别硬编码上一次的坐标。

## 相关已验证（本分类其他文件）
- 外部稳定 Chrome 直连入口、坐标、启动：`references/external-chrome-pdd-entry.md`
- 发布新商品→选类目逐段路径：`references/goods-publish-category-flow.md`
- SKU 虚拟列表行定位 + fillSkuData 列式行检测：`references/pdd-sku-virtual-list-fill.md`
- 临时脚本样板（CDP take/点/填）：`scripts/cdp-helper.mjs`
