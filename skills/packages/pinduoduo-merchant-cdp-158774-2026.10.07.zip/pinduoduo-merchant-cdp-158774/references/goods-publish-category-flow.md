# 拼多多「发布新商品 → 选类目 → 编辑器」CDP 流（2026-08-31 真机验证）

目标：让工作台从商家后台自动走到「发布新商品」(type=add) 编辑器，且**类目取自商品数据**（例：美发护发/假发 > 染发烫发 > 彩染染发膏）。用在 `publishMode='add'` 流程的 open 步骤（替代"只到第1级"的旧缺口）。

> ⚠️ 本流走通的是**人工/CDP 逐段驱动**路径，尚未整段写进工具自动化。坐标会随页面滚动/窗口变化变化，**每步先 `getBoundingClientRect()` 重测元素中心再点**，不要硬编码死坐标。

## 已跑通的正确路径（逐段）

```
商家后台(首页) → 商品列表 goods/goods_list
→ 点「发布新商品」主按钮(页面正文的大按钮，~x=293,y=473；侧边栏 nav 里的同名项也命中，取页面正文那个)
→ 进入「发布新商品 / 选择分类」页
→ 类目树(4 列级联)：点第1级「美发护发/假发」→ 第2级「染发烫发」→ 第3级「彩染染发膏」
→ 点底部「确认发布该类商品」(~x=855,y=1359；三级全选后才可点)
→ 跳转 goods_add/index?type=add&from=category → 进入"发布新商品"编辑器(顶部"商品分类：美发护发/假发 > 染发烫发 > 彩染染发膏")
```

真机实测坐标（当次页面、未滚动，仅参考，必须重测）：发布新商品(293,473) → 美发护发/假发(281,386) → 染发烫发(552,461) → 彩染染发膏(937,361) → 确认发布该类商品(855,1359)。

## 每步的标准动作（CDP，in-app WebContentsView）

1. `Page.navigate` 或 `location.href` 到 goods/goods_list；`eval('document.body.innerText')` 判已登录。
2. 找可点元素：`[...document.querySelectorAll('button,[role=button],div,span,a')].filter(el => el.getBoundingClientRect().width>0 && /^发布新商品$/.test(el.innerText.trim()))`，取**页面正文那个大按钮**（tag=BUTTON、尺寸大），用其中心坐标。
3. **真机鼠标点击** `Input.dispatchMouseEvent mousePressed+mouseReleased`（比合成 `dispatchEvent('click')`、也比 Electron 的 `webContents.sendInputEvent` 更能触发 PDD 的 React/导航；合成 click 与 sendInputEvent 对部分 PDD 控件都不响应）。**in-app 自动化里封装成 `nativeClick(webContents,x,y)` 助手**：`webContents.debugger.attach('1.3')`（未附时）+ `sendCommand('Input.dispatchMouseEvent',{type:'mousePressed'/'mouseReleased'})`，异常回退 `sendInputEvent`。**凭实测：手动 CDP(独立WS)点按钮能跳转，但同页从主进程发的 sendInputEvent/debugger CDP 有时仍不触发导航**——属未解决的开项。
4. 每一步后 `Page.captureScreenshot` 存 png → `vision_analyze` 看结果 → 再点下一步（"驱动靠眼睛"循环）。
5. 类目项定位：精确文本(`el.innerText.trim()==='染发烫发'`) + `children.length<=1` + 可见；**同名项按所属列 x 范围/最小高度筛选**。

## 坑（高频踩）

- **同名类目项在「左侧边栏」也有**：`美发护发/假发` 在左侧导航(x≈98)和类目树(x≈281)各出现一次。自动化按 `querySelectorAll` 取第一个(children数最小)会**点中边栏项 → 不选中**（诊断标志：`已选分类` 为空、第2列不出现「染发烫发」）。**必须取 `getBoundingClientRect().left>=180` 的树内项**再点（或按所属列 x 范围筛选）。
- **open(发布新商品)入口自动化的"点发布新商品→跳选类目页"尚未解决**：进商品列表 OK、也能定位到「发布新商品」BUTTON(x≥200)，但点它后**页面不跳转**到 goods/category；试过合成click、sendInputEvent、debugger CDP 三种都无效，唯独手动独立WS的 CDP 点击能跳。**勿当可用自动流**——现阶段选类目仍靠人工/CDP逐段驱动，或把"点发布新商品"留成手动一步。
- **「最近使用的分类」快捷路径(美发护护/假发>染发烫发>彩染染发膏)是纯显示历史，点击不会选中类目**——别指望一键选。要走类目树逐级点。
- **类目搜索框**(请输入类目词搜索分类)输入+回车**不会出结果**（下拉列表已开但搜索不过滤）——**别用搜索，走树**。
- 点完第1级「美发护发/假发」后，第2列可能显示**别的类目**(洗发/沐浴露/面部护肤…)而非「染发烫发」——高亮有误导，**直接按 DOM 精确文本点「染发烫发」**即可（它其实在 DOM 里，`cats` 查询能查到）。
- 第3列(三级)要等第2级点完才出现。
- 点叶子「彩染染发膏」后 URL 变 `goods/category?id=<categoryId>&goods_id=...`（类目确认页），**「确认发布该类商品」按钮仍在**，再点它才进编辑器。
- 每次导航/点某些控件后，**CDP WebSocket 可能断、端口可能掉**（应用崩溃/跳转）→ **重跑 `/json` 重新拿页面 id**，再用新 id 连接；登录态在分区持久，无需重扫码。
- 坐标随滚动变：**点之前必须重测**。
