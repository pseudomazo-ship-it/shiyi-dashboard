# 评价管理页「只读数量」采集（1-5星 × 全店/商品ID）

> 2026-09-21 在「蒙倩护发造型官方旗舰店」实测跑通，已固化成每日 14:00 的 cron 采集。
> 适用场景：**只要数量，不要明细** —— 各星级有多少条、某个商品有多少条、近90天趋势。

## 为什么这条路最好走

平台对评价明细有「**仅展示2000条**」上限，翻页采全量做不到。但**统计数字不受这个限制**：
筛好条件 → 页面直接显示「共查询到 X 条数据」→ 读一个字符串就完事。

- 一次采集 = （1 个全店 + N 个商品ID）× 5 个星级 = `5×(N+1)` 次查询
- 实测：全店 + 5 个商品 = **30 次查询，约 2.5 分钟**（含每次 1.5~3.8s 随机停顿）
- 这个频率对风控很轻（不是翻页狂刷）

## 页面元素（class 带哈希，用 `[class*=xxx]` 模糊匹配，别写死）

| 用途 | 定位 |
|---|---|
| 时间窗 | 文本 `近30天` / `近90天` / `近180天` / `自定义`，class 含 `search_btn`；选中态 class 含 `checked` |
| 星级 | 文本 `1星`…`5星`，同一套 `search_btn` class |
| 商品ID | 筛选区第 **2** 个 `input[placeholder="请输入"]`（3 个依次是 订单编号/商品ID/关键词） |
| 查询按钮 | `BUTTON.BTN_primary`，文本 `查询` |
| **统计文案** | **`[class*=numberInfo]`** → `共查询到9条数据（未包含默认评价）` |
| 分页总数 | `[class*=PGT_totalText]` → `共有 9 条`（同一个数的另一种写法） |

判断「页面可用」= `!!document.querySelector('[class*=numberInfo]')`；若 URL 含 `/login` 就是掉登录了。

## 四条必守的机制（每条都踩过）

### 1. 星级是**多选复选框**，不是单选
点「2星」是**加选**。实测：当前 1星=9，点一下 2星 → 变成 11（= 1星+2星 合计），
而 `[class*=search_btn_checked]` 返回 `["近90天","1星","2星"]`。

**正确做法（两步 + 校验）**：
```js
// 第一步：取消除目标星外的所有已勾选
(() => { const bs=[...document.querySelectorAll('*')].filter(e=>/^[1-5]星$/.test((e.textContent||'').trim()) && e.children.length===0);
  const tg=bs.find(e=>e.textContent.trim()==='2星');
  bs.forEach(b=>{ if(b!==tg && /checked/.test(String(b.className))) { const el=b; ['mousedown','mouseup','click'].forEach(t=>el.dispatchEvent(new MouseEvent(t,{bubbles:true}))); } }); return 1; })()
// sleep 1.5~2.1s
// 第二步：若目标星未勾选，勾上
(() => { const b=[...document.querySelectorAll('*')].find(e=>/^2星$/.test((e.textContent||'').trim()) && e.children.length===0);
  if(!/checked/.test(String(b.className))) { const el=b; ['mousedown','mouseup','click'].forEach(t=>el.dispatchEvent(new MouseEvent(t,{bubbles:true}))); } return 1; })()
// sleep 1.8~2.4s
```
**每轮都要读回 `search_btn_checked` 校验：星级项只有 1 个且是目标星**。本会话 30 轮全部校验通过。

### 2. 切星级**自动刷新**，不用点「查询」
省一半操作。点完等 1.8~2.4s 再读数字即可。

### 3. 商品ID 筛选**必须点「查询」**
```js
// 填值（React 受控，用原生 setter + input 事件）
(() => { const ins=[...document.querySelectorAll('input')].filter(i=>i.placeholder==='请输入');
  const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;
  ins.forEach(el=>{ s.call(el,'996720881635'); el.dispatchEvent(new Event('input',{bubbles:true})); }); return 1; })()
// sleep 0.6s → 点查询 → sleep 3.0~3.8s
```
清空商品ID（传 `''`）+ 点查询 → 干净回到全店。**这是可逆的**，实测清空后全店1星回到 9（起始值）。

### 4. 收尾必须复位
采完 → 清空商品ID → 点查询 → 切回 1星。否则用户手动打开页面时看到的是你留下的筛选态。

## ⚠️ 口径：「未包含默认评价」—— 这是我这次最容易误用的一条

那个数字**不是评价总量**。原文就是「共查询到 9 条数据（**未包含默认评价**）」。

实测对比（同一个店）：近90天「未包含默认评价」全店只有 **364 条**，
而店铺同期（含默认评价）的总评价量在万级 —— 差两个数量级。

**所以：**
- 不能用它当「店铺评价总量」
- 用它算出来的均分**不能和平台 DSR 对比**（口径不同）
- 交付/看板里必须把「未包含默认评价」写进口径栏

## ⚠️ 验证码检测：别用泛化关键词

第一版检测用 `/captcha|verify|slider|nc_|drag|geetest|验证码|滑块/i` 匹配所有元素的 class/id →
**误报 3 个**，全部是 `react-draggable` / `new_message_box_drag_area`（**消息盒子、官方客服的可拖动悬浮窗**），
采集被自己的守卫拦死。

**正确写法**（限定具体组件 + 可见文案）：
```js
(() => {
  const txt=[...document.querySelectorAll('*')].some(e=>e.offsetParent &&
    /滑动验证|请完成验证|拖动滑块|安全验证|请按顺序点击|请输入验证码/.test((e.textContent||'').trim().slice(0,40)));
  const box=document.querySelector('.nc_container,.nc_wrapper,.nc_scale,[class*=geetest],[class*=yidun],[id*=captcha],[class*=slide-verify]');
  const ifr=[...document.querySelectorAll('iframe')].some(f=>/captcha|verify|geetest|yidun|nc_/i.test(f.src||''));
  return (txt||!!box||ifr) ? 1 : 0; })()
```
**教训通用**：凡是「命中就中止任务」的守卫，正则必须收窄到**目标组件类名 + 可见文案**；
用 `drag`/`verify` 这种通用词会命中一堆无害的 UI 库，把任务自己拦死。

## 怎么把它变成每日定时（脚本层）

见 `cdp-browser-automation` 的「用 browser-use CLI 从脚本驱动浏览器」一节：
**不要自己写 raw CDP websocket** —— 直接 `printf '<python代码>' | browser-use.EXE`，
走同一个 daemon，`js()` / `cdp()` 在脚本里都能用（本机实测可行）。
定时任务的 `script` 参数**只接受 `~/.hermes/scripts/` 下的文件名（绝对路径会被拒）**，
所以在那里放一个转发入口，真正的脚本留在工作区项目目录。

### ⚠️ 无人值守的两个致命前提（本会话都真实踩到过）

**1. 页面不在就得自己开 —— 别依赖「人工留着那个标签页」**

第一版脚本假设「评价管理页已经开着」，找不到就报 `NO_PAGE` 退出。
实测：用户随手关掉标签 → 采集当场失败。**每天定时跑的任务不能有这个假设。**

```python
if page is None:
    new_tab('https://mms.pinduoduo.com/goods/evaluation/index')   # harness 预置助手
    time.sleep(10)
    page = 重新在 cdp('Target.getTargets') 里找
if page is None:
    bail('NO_PAGE', '开不了页面，检查浏览器是否正常')
```

`new_tab` / `goto_url` 是 browser-use harness 的预置助手，脚本里直接能用，不用自己开标签。
改完**必须实测一次「先把页面关掉再跑」**才算真正验证。

**2. 转发入口里硬编码的工作区路径，会在工作区迁移后静默失效**

入口脚本写死了 `D:\...\项目：XXX\脚本\run_daily.py`；工作区一迁，入口就指向废路径，
**cron 到点才炸**（不跑根本发现不了）。改法：入口开头做**存在性检查**，
报错里点明「主脚本不见了，工作区是不是又迁移了？」，别让它默默失败。

改完要**手动跑一次入口脚本**验证链路通（本会话正是这么发现路径没跟上的）。

**通用教训（本会话被十一连问两次「为什么不在工作区」）**：
接到新任务要新建文件夹前，**先 `ls` 一次工作区根目录**，确认没有新迁移/新结构/新建的同类区。
照旧路径直接写 = 落到作废地址，或落到别的 Agent 的工区里。

### 把浏览器结果带回脚本：`__RESULT__` 标记行 + 按 URL 锁定标签

脚本读不到浏览器的变量，而 payload 里 `print()` 的 stdout 又混着 harness 自己的日志。
**实测可行的约定**：payload 最后只打印一行 `__RESULT__{json}`，脚本按前缀扫 stdout 提取。

```python
# collect 脚本侧
out = (p.stdout or '') + '\n' + (p.stderr or '')
for line in out.splitlines():
    if line.startswith('__RESULT__'):
        return json.loads(line[len('__RESULT__'):])
# 拿不到就把尾部输出带上 —— 否则排障完全靠猜
return {'ok': False, 'error': 'NO_RESULT: 尾部=%s' % ' / '.join(out.splitlines()[-3:])[:300]}
```

payload 侧：**失败也走同一条路**（`bail('NOT_LOGGED_IN', '…')` 先 `print('__RESULT__' + json.dumps({...}))` 再 `SystemExit`），
不要靠抛异常让外层猜——外层只认那一行。这一条让「掉登录 / 页面没就绪 / 验证码」在脚本侧
都能拿到**结构化原因**，而不是一句“采集失败”。

**别依赖「当前标签」**：payload 里一律
`cdp('Target.getTargets')` → 找 URL 含关键字的 page target →
`cdp('Target.attachToTarget', targetId=…, flatten=True)` 拿 `sessionId` →
之后所有 `Runtime.evaluate` 都带 `session_id=sid`。
（靠“哪个标签在前台”会随用户操作漂移，是间歇性失败最常见的来源。）

`subprocess.run(..., timeout=900)`，超时当一次失败处理（别无限等）；
结束后把 `__pycache__` 删掉再交付（工作区迁移脚本会显式排除它）。

## 下游：采集 → 看板 → 推送（十一 2026-09-21 定的形态）

需求原话：「不需要登记在飞书了，就登记在网页看板内，这样方便看」+「每天把关键数字微信推你手机」。

```
collect_stars.py → data\daily.json（追加，同日重跑覆盖）
                 → build_view.py → index.html（离线单文件看板）
                 → run_daily.py 调 hermes send 分条推微信
```

### cron 接线（Hermes 侧两个硬约束）
- `script` 只接受 `~/.hermes/scripts/` 下的**文件名** —— 传绝对路径会被直接拒。
  解法：`scripts/` 下放一个**转发入口**（`subprocess.run([sys.executable, 工作区主脚本])`），
  真脚本仍留在工作区项目目录（工程性和 11 的文件归位规则都保住）。
- 形态 = **`no_agent=True` + `deliver='local'`**，由**脚本自己** `hermes send` 分条发。
  理由：微信 iLink 不渲染换行，一条 stdout 塞多行在手机上会糊成一坨。
  入口：`hermes.exe send --to <platform>:<chat_id> "文本"`（`--help` 看 target 格式）。

### 推送要分条 + 要降级
- 微信分 4 条短消息：①标题 ②全店 1-5星+合计+均分 ③环比 ④各商品明细。每条 <100 字，一条一行。
- **微信主动推送有互动窗口期**（久没互动会 prepare failed）→ 发失败**自动降级到 QQ**。
  两个通道的 chat_id 在 `channel_directory.json`（platforms.weixin / platforms.qqbot）里查。
- **采集失败也要推**：带原因 + 建议（「看一眼 Chrome 是不是还登录着」），别静默失败。

### 看板配色：这个要浅色，别套财务看板的深色
- 十一原话「整体色调偏浅色系」→ 底 `#f4f6f9`、白卡片 + 淡阴影、蓝主色 `#2563eb`。
- ⚠️ **不要直接复用财务/运营看板的深色 `#0f1117`** —— 看板配色按项目问/按项目定，别当成全局偏好。
- **DSR（均分）是主角**：顶部大数字 + 单序列折线大图；再一张**多序列对比图**（全店 + 各商品ID 同一张图、
  图例带最新值）；每个商品卡里再嵌一条 mini sparkline。**必须有 Y 轴刻度 + 网格线**
  （第一版漏了，被指出后补上：没刻度只能看走势，没法读数）。
- 十一明确**不要「1-2星占比」这类衍生列** —— 明细表给到「合计 + DSR」就够，别自作主张加列。

### 三个渲染坑（都实测踩过）
1. **窄窗/预览窗里宽表会把整页撑破** —— `table` 默认不收缩，导致整页横向溢出、
   标题和左侧卡片被挤出视野（看上去像"渲染坏了"）。修法：表格外套 `.tablewrap{overflow-x:auto}`，
   让表自己横向滚，页面宽度不被撑。
2. **Python 拼 HTML 时，CSS 里的 `%` 必须写 `%%`** —— `width:100%`、`linear-gradient(...0%,...100%)`
   这类在 `"..." % 颜色变量` 里会报 `ValueError: unsupported format character`。本会话踩了两次。
3. **趋势图要有 ≥2 天数据才画得出来** —— 第一天上线的看板必然是空的，这是正常不是 bug。
   **验证办法：另造一份多天模拟 JSON，用 `--in/--out` 参数渲染到临时文件去截图验证，
   验证完把临时文件删掉，真实数据一行不动。**（本会话用 8 天模拟数据验出了 7 条折线正常）

### 口径要写在看板上，不能只写在交付说明里
看板底部固定三条提示：①「未包含默认评价」不代表评价总量；②是自算口径、不等于平台 DSR；
③「近90天」是滚动窗口，变化 = 新增评价 − 滑出窗口的旧评价。
（不写在这，看板被单独转发出去后一定会被误读。）

## 专用浏览器：无人值守的正确形态（2026-09-21 加）

**为什么必须另开一个**：驱动十一日常那个浏览器 → 抢他的标签页、改乱他的筛选；他一关浏览器/重启，
14:00 那次采集直接失败。无人值守的任务不能有这种依赖。

### 🔑 最关键的一条坑：`BU_CDP_URL` 单独给**没用** —— 必须配 `BU_NAME`

实测：只给 `BU_CDP_URL=http://127.0.0.1:9445` 时，harness **仍然连到默认连接（用户那个浏览器）**，
返回的是用户浏览器当前页面的 URL —— **全程不报错，会静默连错浏览器**。
必须组成**命名连接**：

```bash
printf 'print(js("location.href"))' | \
  BU_NAME=pddstars BU_CDP_URL=http://127.0.0.1:9445 browser-use.EXE
```

**验证连对了没有**：`cdp('Target.getTargets')['targetInfos']` 列出的 page 标签，
必须和 `curl http://127.0.0.1:<端口>/json/list` **完全一致**才算连对了目标浏览器。

### 拉起专用浏览器（脚本里 `subprocess.Popen`，不阻塞）

```
chrome.exe --remote-debugging-port=9445
  --user-data-dir=<工作区>\项目：评价星级日采集\pdd-browser-profile
  --no-first-run --no-default-browser-check https://mms.pinduoduo.com/login/
```

- 先探活：`socket.connect_ex(('127.0.0.1', 9445)) == 0` → 活着就直接复用，不重复拉起
- 起来要等（实测 ~4s）→ 循环探活，最多 40s
- **起不来要退回默认浏览器**（`ensure_browser()` 返回空 env_extra），别让整个采集挂掉

### profile 自己记住登录态

实测「杀掉进程 → 干净环境重跑 → 日志『专用浏览器已拉起』→ 5 个范围全部采到」，
即**重启后仍是登录态**，不需要每天重登。⚠️ 所以 `pdd-browser-profile\` 目录**不能删**（删了要重登一次）。

### 端口占位表（本机，别撞车）

`9334` = 申诉复议工作台内嵌 ｜ `9444` = 上架工具外挂 ｜ `9555` = 售后采集外挂 ｜ **`9445` = 评价星级日采集专用**

### 探活 / 排障

- `netstat -ano | grep <端口>` → 看监听 + PID
- `curl -s http://127.0.0.1:<端口>/json/version` 返回 JSON = 真的是 DevTools 端点
  （用户主浏览器那个口在 `/json/list` 上返回 404，所以**别拿 `/json/list` 通不通判断一个口能不能用**）
- 测自动拉起：`taskkill /PID <pid> /T /F` 杀干净 → 再跑采集脚本

> **待观察（未验证，别当结论）**：用户在**自己**浏览器里退出登录，会不会把专用浏览器也带掉。
> 没拿他的账号做实验。若连续两天告警「未登录」，就是这个原因。

## 看板筛选：点图例只看某一条（十一 2026-09-21 要求）

原话：「几个ID趋势图可以放在一起，**但是要有一个筛选的方式**，这个方便单独看某一个ID的趋势线。」

### 交互设计（纯前端，单文件离线，无外部库）

图例 chip 当按钮用：

| 操作 | 效果 |
|---|---|
| 单击 chip | **只看这一条**（其余隐藏） |
| 再单击同一条 | 恢复看全部 |
| Ctrl/⌘/Shift + 单击 | 叠加多条（toggle） |
| 「全部显示」按钮 | 一键还原 |

```js
function dsrToggle(n, ev){
  var all = DSR.series.map(function(s){return s.n;});
  if(ev && (ev.ctrlKey||ev.metaKey||ev.shiftKey)){
    if(dsrVis.has(n)) dsrVis.delete(n); else dsrVis.add(n);
    if(!dsrVis.size) dsrVis = new Set([n]);        // 别让用户把最后一条也关掉
  } else {
    dsrVis = (dsrVis.size===1 && dsrVis.has(n)) ? new Set(all) : new Set([n]);
  }
  dsrDraw();
}
```

### 🔑 最关键的一条：隔离单条时 **Y 轴必须跟着重算**

不重算 Y 轴，被隔离的那条线会被压在全量跨度里、平得像一条直线 —— **筛选功能等于白做**。

做法：数据以 `const DSR={labels:[…], series:[{n,c,v:[…]}]}` 嵌进页面，
JS 每次按**当前可见序列**的 min/max 重画整张 SVG（网格 + Y 刻度 + X 标签 + 折线 + 末点圆点）。
全店那条线 `stroke-width` 可以宽一点（2.6 vs 2）。

### 两个必踩的渲染坑

1. **`X(i)` 要除以 `N-1`，只有 1 天数据时 N=1 → 除零 → 全 NaN，整张图画不出来**。写成：
   `function X(i){return N>1 ? pl+i*(W-pl-pr)/(N-1) : (pl+W-pr)/2;}`
2. **不要因为「只有 1 天」就把整个筛选区不渲染**。第一版用 `if len(pseries)>=1 or has_line:` 把整段藏了，
   十一当天打开看板会以为**筛选根本没做**。改成**永远渲染图例 + 图容器**，只有折线需要 ≥2 天
   （1 天时画点 + 提示「折线明天 14:00 后出来」）。

### 怎么验证交互（重要，别自己想当然）

- **聊天窗口右侧那个预览窗格不把点击派发给页面 JS** —— 在那里点图例毫无反应，
  **会误判成「功能没生效」**（本次先误判了一轮，差点回去改没错的代码）。
- 正确做法：用 CDP 在**真浏览器标签页**里开这个 HTML，再 `Runtime.evaluate` 驱动点击，
  **读回 Y 轴刻度文字**做判据：

```
全部显示 → 4.473~4.848 ｜ 点商品A → 4.647~4.687 ｜ 点全店 → 4.571~4.611 ｜ reset → 回 4.473~4.848
```

  轴区间变了 = 真隔离成功了。（**只数折线根数不够**：单点时本来就是 0 条折线，会误判。）
- 两种点法都要试：`el.click()`（走内联 onclick）和派发整套
  `['mousedown','mouseup','click'].forEach(t=>el.dispatchEvent(new MouseEvent(t,{bubbles:true})))`。

## 无人值守任务的加固清单（2026-09-21 审计出 3 个真漏洞）

十一问「这个流程还有什么问题吗」→ 逐项审，**这 3 个都会静默出事**：

| 漏洞 | 后果 | 修法 |
|---|---|---|
| **只校验主范围（全店）** | 采到第 3 个商品时掉登录 → 前两个有数后两个为空 → **照样落盘**、看板显示 `-`、**没人收到提醒** | **全范围校验**：所有范围 × 5 星逐格 `isinstance(v,int)`，任一格缺 → **整体不落盘 + 推告警** |
| **没有补跑** | 14:00 那次失败 = 这一天永久缺点、趋势断档，要等用户自己发现 | 加 **16:30 / 19:00 两个看门狗 cron**：只查「今天有没有数据」，**没有才补跑，有就零输出**（`no_agent` + 空 stdout = 不推任何消息，不打扰） |
| **看板生成失败不报警** | 数据存了但看板没更新，用户以为一切正常 | 拿 `subprocess` 的**返回码**，非 0 就单独推一条「数据采到了但看板生成失败 + 原因」 |

**补跑要能自证是补跑**：`run_daily.py` 读 `PDD_STARS_RETRY=1`，推文标题加「（补采）」，
十一一眼能区分补采和 14:00 正报。（也能用来人工重跑，不惊到人。）

**审计时固定问这 4 条**：
1. 登录态过期 → 有没有检测 + 告警 + 人工入口？
2. **跑到一半弹验证码** → 开头查一次不够（中途出现会读到空值）→ 靠「全范围校验兜住、不落盘」；
3. 电脑关机/休眠 → 14:00 跑空 → 告警 + 补跑能不能补上？
4. 推送通道挂了 → 有没有降级（微信→QQ）？**两个都挂**目前是静默丢失（数据不丢，只是没通知）—— 可接受但要说明。

**别把「跑得通」当「跑得住」**：三条修完必须**真的重跑一遍全链路**（本次实测 138s 全过），
且要在日志里看到新增那句『专用浏览器已拉起 / 已在运行』。
