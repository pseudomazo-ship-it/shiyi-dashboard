# 商品批准文号 × NMPA 官方注册信息 · 交叉核对

采集完「化妆品批准文号」后，十一会拿 NMPA（国家药品监督管理局）导出的官方表来对。

## 最关键的一条：两种号走两套系统，不能混着判“查不到”

| 号段 | 性质 | 查哪张表 |
|---|---|---|
| `国妆特字…` | **特殊**化妆品注册证号 | 特殊化妆品注册信息表 |
| `粤G妆网备字…` | **普通**化妆品备案号（省级备案） | 普通化妆品备案表（**不在**特殊表里） |

→ 把 `粤G妆网备字` 的号扔进「特殊化妆品注册信息」表里找，**必然找不到**，那是设计如此、不是问题。
本会话就先把两者混在一起报了“11 个查不到”，纠正后才看清：其中 **7 个是普通备案号（正常）**，真正要查的只有 **4 个国妆特字**。
**先按号段分类再比对，这一步不能省。**

## 输入两样

1. 采集汇总 xlsx 的「批准文号分布」页（文号 / 商品数 / 涉及店铺数 / 涉及店铺）
2. NMPA 导出表，列：`序号｜产品名称中文｜注册人中文｜注册证号｜批件状态`

## 核对脚本骨架

```python
from openpyxl import load_workbook
from collections import Counter

# 我方
wb = load_workbook(sum_path, read_only=True); ws = wb['批准文号分布']
mine = [(str(r[0]).strip(), r[1] or 0, r[2] or 0, str(r[3] or ''))
        for r in ws.iter_rows(min_row=2, values_only=True) if r and r[0] not in (None, '')]
wb.close()

# NMPA
wb2 = load_workbook(nmpa_path, read_only=True); ws2 = wb2.active
rows = list(ws2.iter_rows(min_row=1, values_only=True))
hdr = [str(x) for x in rows[0]]
ci = hdr.index('注册证号')
nmpa = {}
for r in rows[1:]:
    if not r or r[ci] in (None, ''): continue
    nmpa.setdefault(str(r[ci]).strip(), []).append(
        {'产品名称': r[hdr.index('产品名称中文')], '注册人': r[hdr.index('注册人中文')],
         '批件状态': r[hdr.index('批件状态')]})
wb2.close()

# A 我方→NMPA：分号段判
for code, n, shops, names in mine:
    if code == '(空)': continue
    if code.startswith('粤G妆网备字'):
        print(code, '普通备案号，不在特殊化妆品表里，跳过')
        continue
    print(code, '✅在册' if code in nmpa else '❌NMPA无此号')

# B NMPA→我方：有证但没在卖
mine_set = {c for c, *_ in mine if c != '(空)'}
for k, v in nmpa.items():
    if k not in mine_set:
        print('未使用:', k, v[0]['产品名称'], v[0]['批件状态'])
```

## 必领的诚实前提

「NMPA 查不到」只能读作 **“不在你给我的这份表里”**，**不等于药监局没登记**——那张表可能只导了部分主体。汇报时必须把这句写上，并让十一去官网逐个复核，**不要替他下“未注册”的结论**。

## 除了“有没有”，还要看“对不对”（本次真正抓到的问题）

把采集的 **产品名称 / 注册人** 与 NMPA 同名号的记录并排看，暴露三类问题：

1. **品牌张冠李戴**——商品标题打”蒙倩“，NMPA 登的产品名却是别家（如标题「蒙倩男士漂发剂」对应登记「三崎海蓝护发褪色粉」）。
2. **备案产品名与实际售卖颜色/品类不符**——如登记「蔻乐丝染发膏 枫叶橙红色」，实际卖的是「冷调榛果灰棕黑紫色」。这类最重（涉嫌套用他方备案号）。
3. **备案字段整行空白**——有文号，但产品名称/注册人两条都是空，属未填而非找不到。

另外看 **`批件状态`**：`当前批件` / `历史批件`。历史批件仍挂在在售链接上要关注；同一号在 NMPA 同时挂「当前+历史」两条记录的，也单独标出来。

## 交付形态

十一要的是 **商品ID 清单 + 批准文号 + 商品名称**，可直接粘进后台商品ID搜索框。必要时补三张表：`在册/查不到对照` / `NMPA未使用证号` / `批件状态明细`。
