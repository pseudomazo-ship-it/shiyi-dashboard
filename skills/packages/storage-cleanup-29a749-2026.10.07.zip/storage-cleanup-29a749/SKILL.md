---
name: storage-cleanup
description: |
  电脑存储空间分析与清理技能（Windows + macOS 双平台自适应）。
  当用户需要分析磁盘空间占用、清理C盘/D盘、释放存储空间、优化系统存储时使用此技能。
  触发词：清理电脑、存储空间、磁盘满了、C盘满了、空间不足、清理缓存、释放空间、disk cleanup、storage analysis。
  此技能执行完整的只读扫描→分析→报告→清理工作流，生成可视化HTML报告并可选择性执行清理。
  自动检测操作系统（Windows/macOS），使用对应的扫描逻辑和清理命令。
agent_created: true
---

# 存储空间分析与清理（双平台）

此技能执行完整的电脑存储空间分析和清理工作流：扫描→分析→生成HTML报告→清理。
自动检测 Windows / macOS，使用对应的扫描路径和清理命令。

## 工作流概览

```
第1步：扫描磁盘 → 第2步：生成HTML报告 → 第3步：确认清理方案 → 第4步：执行清理
```

## 第1步：扫描磁盘

运行扫描脚本获取磁盘占用数据：

```bash
python scripts/scan_storage.py --output /tmp/storage_report.json
```

脚本自动检测 `platform.system()`，根据平台执行不同的扫描逻辑。

### Windows 扫描内容
- 磁盘总览（C盘、D盘容量和使用率）
- 用户目录各文件夹大小
- AppData/Local 大目录排行（递归扫描，跳过 junction points）
- AppData/Roaming 大目录排行
- Windows 系统目录占用
- Program Files 占用
- 临时文件大小
- Electron 更新包缓存
- LiteSandbox 异常大日志文件
- D盘目录和大文件

### macOS 扫描内容
- 磁盘总览（根目录 `/` 容量和使用率）
- 用户目录各文件夹大小（跳过 Library）
- ~/Library 大目录排行
- ~/Library/Caches 缓存排行
- ~/Library/Application Support 应用数据排行
- /Applications 应用程序大小
- /System + /Library 系统目录大小
- Homebrew 安装目录大小
- Xcode/Developer 目录大小
- Node 生态（npm 缓存、pnpm store、bun）

扫描脚本输出 JSON 格式结果，包含 `platform`（系统类型）、`confidence`（信心值）、`size_bytes`（精确字节数）和 `size`（人类可读格式）。

## 第2步：生成HTML报告

读取扫描结果 JSON，注入到 HTML 报告模板中生成可视化报告：

1. 读取 `assets/report_template.html`
2. 读取扫描脚本输出的 JSON 数据
3. 将 JSON 数据替换模板中的 `/*__SCAN_DATA__*/null` 占位符
4. 将 `/*__CONFIDENCE__*/null` 替换为 `report['confidence']` 对象
5. 将结果写入工作目录下的 `storage_report.html`
6. 使用 `preview_url` 工具展示报告

报告包含：
- 磁盘总览卡片（容量、已用、可用、使用率进度条）
- 空间分布饼图（Chart.js）
- 大目录柱状图
- 优化建议表格（按收益排序，标注风险等级）
- 系统占用表
- 快速清理命令表（根据平台显示对应命令）
- **信心值**（1-10分，见下方评分规则）

## 第3步：分析并确认清理方案

根据扫描结果和平台，按风险等级分三个梯队向用户确认。

### Windows 清理方案

#### 第一梯队：绝对安全
- **LiteSandbox 异常大日志**：`%LOCALAPPDATA%\LiteSandbox\logs\` 下超过 100MB 的 .jsonl 文件
- **Electron 更新包缓存**：`%LOCALAPPDATA%\` 下 `*-updater` 目录
- **npm 缓存**：`%APPDATA%\npm-cache\_npx` 和 `_cacache`
- **pnpm 未引用包**：`pnpm store prune`
- **临时文件**：`%LOCALAPPDATA%\Temp\` 下的更新临时目录
- **pip 缓存**：`pip cache purge`

#### 第二梯队：需用户确认
- camoufox、ms-playwright、旧编辑器残留、chromium-browser-snapshots、openclaw-autoclaw
- 应用缓存（OpenAI、Quark、Google、Discord 等）

#### 第三梯队：系统级优化
- `cleanmgr /sagerun:1`（Windows 磁盘清理）
- `DISM /Online /Cleanup-Image /StartComponentCleanup /NoRestart`（清理旧更新组件）

### macOS 清理方案

#### 第一梯队：绝对安全
- **npm 缓存**：`rm -rf ~/.npm/_npx ~/.npm/_cacache`
- **pnpm 未引用包**：`pnpm store prune`
- **pip 缓存**：`pip cache purge`
- **Homebrew 缓存**：`brew cleanup`
- **系统缓存**：`rm -rf ~/Library/Caches/Homebrew`
- **Xcode 派生数据**：`rm -rf ~/Library/Developer/Xcode/DerivedData`
- **Xcode 旧版本 iOS 支持**：`rm -rf ~/Library/Developer/Xcode/iOS DeviceSupport`

#### 第二梯队：需用户确认
- **应用缓存**：`~/Library/Caches/` 下各应用缓存（如 Chrome、Spotify、Slack）
- **Application Support**：`~/Library/Application Support/` 下不用的应用数据
- **旧版 Homebrew 公式**：`brew autoremove`
- **Docker 镜像/容器**：`docker system prune`
- **不用的 /Applications 应用**

#### 第三梯队：系统级优化
- **Time Machine 本地快照**：`tmutil deletelocalsnapshots <date>`
- **清空废纸篓**：`rm -rf ~/.Trash/*`
- **系统日志**：`sudo rm -rf /private/var/log/asl/*.asl`

## 第4步：生成并执行清理脚本

根据平台生成对应的清理脚本：

### Windows：PowerShell 脚本 `cleanup_c_drive.ps1`
```powershell
$ErrorActionPreference = "SilentlyContinue"
# 定义 Get-FolderSize 和 Remove-FolderSafe 函数
# 按梯队分组执行清理
# 汇总结果并显示当前磁盘状态
```

### macOS：Bash 脚本 `cleanup_mac.sh`
```bash
#!/bin/bash
# 定义 get_dir_size 和 remove_safe 函数
# 按梯队分组执行清理
# 汇总结果并显示当前磁盘状态
```

执行方式：
- **Windows**：PowerShell 工具以管理员权限运行，或指导用户手动执行
- **macOS**：Bash 工具运行，部分操作需要 `sudo` 权限

## 信心值评分规则

每次扫描完成后，必须输出信心值（1-10分），并在 HTML 报告中展示。评分依据：

| 分数 | 条件 |
|------|------|
| 9-10 | 扫描完整覆盖所有目录，无访问拒绝，数据可信 |
| 7-8 | 绝大多数目录扫描成功，少量目录因权限/占用被跳过，不影响整体结论 |
| 5-6 | 多个重要目录无法访问（如 AppData 被沙箱拦截），数据可能不完整 |
| 3-4 | 大面积扫描失败，仅获取到部分数据，结论需谨慎对待 |
| 1-2 | 扫描基本失败，数据不可信 |

**扣分项：**
- 目录被沙箱拦截无法扫描：-2
- 大量文件被占用无法统计：-1
- 扫描超时中断：-2
- 无法获取磁盘总容量（`shutil.disk_usage` 失败）：-3

**低于 7 分必须标注原因**，说明哪些数据可能不完整。

## 关键注意事项

1. **只读优先**：扫描阶段绝对不修改任何文件
2. **junction points（Windows）**：`Application Data`、`Local Settings` 等是递归链接点，必须跳过
3. **符号链接（macOS）**：`~/Library` 下大量符号链接，扫描时需 `islink()` 检查
4. **LiteSandbox 日志泄漏**：Windows 常见空间杀手，单个 Node 进程日志可能膨胀到 10-20GB
5. **Xcode 派生数据（macOS）**：开发者常见空间杀手，可能占用 10-50GB
6. **pagefile.sys（Windows）**：虚拟内存文件，通常很大但不建议随意修改
7. **正在运行的应用**：其缓存/配置目录可能被锁定，清理时会部分失败，属正常现象
8. **macOS 系统完整性保护（SIP）**：`/System` 目录受保护，无法也不应修改
9. **区域设置**：默认使用简体中文，数字格式符合中文习惯
