"""
存储空间扫描脚本（双平台自适应）
用法: python scan_storage.py [--output report.json]
功能: 自动检测 Windows/macOS，扫描系统盘和数据盘的目录占用，输出 JSON 格式的分析结果
"""
import os
import sys
import json
import shutil
import platform
import argparse
from datetime import datetime

PLATFORM = platform.system()  # 'Windows' or 'Darwin'
IS_WINDOWS = PLATFORM == 'Windows'
IS_MACOS = PLATFORM == 'Darwin'
HOME = os.path.expanduser('~')

# ============================================================
#  平台通用工具
# ============================================================

SKIP_DIRS_WINDOWS = {
    'Application Data', 'Local Settings', 'Cookies', 'History',
    'NetHood', 'PrintHood', 'Recent', 'SendTo', 'Start Menu',
    'Templates', 'Temporary Internet Files', 'My Documents',
    '$RECYCLE.BIN', 'System Volume Information',
}

SKIP_DIRS_MACOS = {
    '.Trash', '.Spotlight-V100', '.fseventsd', '.vol',
    '.DocumentRevisions-V100', '.PKInstallSandboxManager',
}

SKIP_DIRS = SKIP_DIRS_WINDOWS if IS_WINDOWS else SKIP_DIRS_MACOS


def get_dir_size(path, max_depth=6, depth=0):
    total = 0
    try:
        with os.scandir(path) as it:
            for entry in it:
                try:
                    if entry.is_file(follow_symlinks=False):
                        total += entry.stat().st_size
                    elif entry.is_dir(follow_symlinks=False) and depth < max_depth:
                        if entry.name not in SKIP_DIRS and not entry.is_symlink():
                            total += get_dir_size(entry.path, max_depth, depth + 1)
                except:
                    pass
    except:
        pass
    return total


def fmt(size):
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f'{size:.1f} {u}'
        size /= 1024
    return f'{size:.1f} PB'


def classify_dir(name):
    name_lower = name.lower()
    if 'updater' in name_lower:
        return 'updater'
    if 'cache' in name_lower:
        return 'cache'
    if any(x in name_lower for x in ['npm', 'pnpm', 'pip']):
        return 'package_manager'
    if any(x in name_lower for x in ['playwright', 'chromium', 'camoufox', 'puppeteer']):
        return 'browser_engine'
    if any(x in name_lower for x in ['discord', 'quark', 'openai', 'google', 'slack', 'spotify']):
        return 'app_cache'
    return 'other'


def get_disk_usage(path):
    total, used, free = shutil.disk_usage(path)
    return {
        'total_bytes': total, 'total': fmt(total),
        'used_bytes': used, 'used': fmt(used),
        'free_bytes': free, 'free': fmt(free),
        'used_pct': round(used / total * 100, 1),
    }


def _safe_scan_listdir(path, min_size=1024*1024, max_depth=6):
    results = []
    try:
        for item in os.listdir(path):
            p = os.path.join(path, item)
            if os.path.isdir(p) and not os.path.islink(p):
                s = get_dir_size(p, max_depth=max_depth)
                if s > min_size:
                    results.append({'name': item, 'size_bytes': s, 'size': fmt(s), 'path': p, 'type': classify_dir(item)})
    except:
        pass
    results.sort(key=lambda x: x['size_bytes'], reverse=True)
    return results


# ============================================================
#  用户目录扫描（通用）
# ============================================================

def scan_user_profile():
    skip = {'AppData', '.ssh', '.workbuddy', '.config', '.local',
            '.claude-mem', '.codex', 'Library'} if IS_MACOS else \
           {'AppData', '.ssh', '.workbuddy', '.config', '.local', '.claude-mem', '.codex'}
    results = []
    try:
        for item in os.listdir(HOME):
            if item in skip:
                continue
            p = os.path.join(HOME, item)
            if os.path.isdir(p) and not os.path.islink(p):
                s = get_dir_size(p)
                if s > 1024 * 1024:
                    results.append({'name': item, 'size_bytes': s, 'size': fmt(s), 'path': p})
    except:
        pass
    results.sort(key=lambda x: x['size_bytes'], reverse=True)
    return results


# ============================================================
#  Windows 专用扫描
# ============================================================

def win_scan_appdata_local():
    return _safe_scan_listdir(os.path.join(HOME, 'AppData', 'Local'), min_size=50*1024*1024)


def win_scan_appdata_roaming():
    return _safe_scan_listdir(os.path.join(HOME, 'AppData', 'Roaming'), min_size=50*1024*1024)


def win_scan_system():
    return _safe_scan_listdir(r'C:\Windows', min_size=200*1024*1024, max_depth=3)


def win_scan_program_files():
    results = []
    for pf in [r'C:\Program Files', r'C:\Program Files (x86)']:
        if os.path.isdir(pf):
            try:
                for item in os.listdir(pf):
                    p = os.path.join(pf, item)
                    if os.path.isdir(p) and not os.path.islink(p):
                        s = get_dir_size(p, max_depth=3)
                        if s > 100 * 1024 * 1024:
                            results.append({'name': f'{os.path.basename(pf)}\\{item}', 'size_bytes': s, 'size': fmt(s), 'path': p})
            except:
                pass
    results.sort(key=lambda x: x['size_bytes'], reverse=True)
    return results


def win_scan_temp():
    results = []
    for name, path in [('Windows Temp', r'C:\Windows\Temp'), ('User Temp', os.path.join(HOME, 'AppData', 'Local', 'Temp'))]:
        if os.path.isdir(path):
            s = get_dir_size(path)
            results.append({'name': name, 'size_bytes': s, 'size': fmt(s), 'path': path})
    return results


def win_scan_updaters():
    patterns = [
        '@genieworkbuddy-desktop-updater', '@guanjia-openclawelectron-updater',
        '@mmx-agentelectron-updater', '@phoenixdesktop-updater',
        'autoclaw-updater', 'coze-updater', 'obsidian-updater',
        'sparkle-updater', 'iget-biji-desktop-updater', 'hermes-desktop-updater',
    ]
    al = os.path.join(HOME, 'AppData', 'Local')
    results = []
    total = 0
    for u in patterns:
        p = os.path.join(al, u)
        if os.path.isdir(p):
            s = get_dir_size(p)
            total += s
            results.append({'name': u, 'size_bytes': s, 'size': fmt(s), 'path': p})
    return results, total


def win_find_large_logs():
    logs_dir = os.path.join(HOME, 'AppData', 'Local', 'LiteSandbox', 'logs')
    results = []
    if os.path.isdir(logs_dir):
        try:
            for item in os.listdir(logs_dir):
                p = os.path.join(logs_dir, item)
                if os.path.isfile(p):
                    s = os.path.getsize(p)
                    if s > 100 * 1024 * 1024:
                        results.append({'name': item, 'size_bytes': s, 'size': fmt(s), 'path': p})
        except:
            pass
    return results


# ============================================================
#  macOS 专用扫描
# ============================================================

def mac_scan_library():
    """扫描 ~/Library 下的大目录（缓存、应用支持等）"""
    library = os.path.join(HOME, 'Library')
    skip_lib = {'Keychains', 'Preferences', 'Accounts', 'Mail', 'Messages', 'Safari'}
    results = []
    try:
        for item in os.listdir(library):
            if item in skip_lib:
                continue
            p = os.path.join(library, item)
            if os.path.isdir(p) and not os.path.islink(p):
                s = get_dir_size(p)
                if s > 100 * 1024 * 1024:
                    results.append({'name': f'Library/{item}', 'size_bytes': s, 'size': fmt(s), 'path': p, 'type': classify_dir(item)})
    except:
        pass
    results.sort(key=lambda x: x['size_bytes'], reverse=True)
    return results


def mac_scan_caches():
    """扫描 ~/Library/Caches 下的大缓存"""
    caches = os.path.join(HOME, 'Library', 'Caches')
    return _safe_scan_listdir(caches, min_size=100*1024*1024, max_depth=3)


def mac_scan_app_support():
    """扫描 ~/Library/Application Support 下的大目录"""
    app_support = os.path.join(HOME, 'Library', 'Application Support')
    return _safe_scan_listdir(app_support, min_size=200*1024*1024, max_depth=3)


def mac_scan_applications():
    """扫描 /Applications"""
    return _safe_scan_listdir('/Applications', min_size=100*1024*1024, max_depth=2)


def mac_scan_system():
    """扫描 /System 和 /Library"""
    results = []
    for path in ['/System', '/Library']:
        if os.path.isdir(path):
            s = get_dir_size(path, max_depth=3)
            if s > 100 * 1024 * 1024:
                results.append({'name': path, 'size_bytes': s, 'size': fmt(s), 'path': path})
    return results


def mac_scan_homebrew():
    """扫描 Homebrew 目录"""
    brew_paths = ['/opt/homebrew', '/usr/local']
    results = []
    for bp in brew_paths:
        if os.path.isdir(bp):
            s = get_dir_size(bp, max_depth=3)
            if s > 500 * 1024 * 1024:
                results.append({'name': bp, 'size_bytes': s, 'size': fmt(s), 'path': bp})
    return results


def mac_scan_xcode():
    """扫描 Xcode 相关目录（开发者缓存大户）"""
    xcode_paths = [
        (os.path.join(HOME, 'Library', 'Developer'), 'Developer'),
        ('/Library/Developer', 'Library/Developer'),
    ]
    results = []
    for path, name in xcode_paths:
        if os.path.isdir(path):
            s = get_dir_size(path, max_depth=3)
            if s > 500 * 1024 * 1024:
                results.append({'name': name, 'size_bytes': s, 'size': fmt(s), 'path': path})
    return results


def mac_scan_node_modules():
    """扫描全局 node_modules 和 npm/pnpm 缓存"""
    paths = [
        (os.path.join(HOME, '.npm'), 'npm 缓存'),
        (os.path.join(HOME, '.pnpm-store'), 'pnpm store'),
        (os.path.join(HOME, 'Library', 'Caches', 'pnpm'), 'pnpm 缓存'),
        (os.path.join(HOME, '.bun'), 'bun'),
    ]
    results = []
    for path, name in paths:
        if os.path.isdir(path):
            s = get_dir_size(path)
            if s > 100 * 1024 * 1024:
                results.append({'name': name, 'size_bytes': s, 'size': fmt(s), 'path': path})
    return results


# ============================================================
#  主逻辑
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='存储空间扫描（双平台）')
    parser.add_argument('--output', '-o', help='输出JSON文件路径')
    args = parser.parse_args()

    print(f'正在扫描磁盘... (平台: {PLATFORM})', file=sys.stderr)

    scan_ok = 0
    scan_fail = 0
    scan_notes = []

    report = {
        'scan_time': datetime.now().isoformat(),
        'platform': PLATFORM,
        'disks': {},
        'user_profile': [],
        'system_dirs': [],
        'program_dirs': [],
        'temp': [],
        'updaters': [],
        'large_logs': [],
        'library': [],
        'caches': [],
        'app_support': [],
    }

    # ---- 磁盘总览 ----
    if IS_WINDOWS:
        for drive in ['C', 'D']:
            if os.path.isdir(drive + ':\\'):
                try:
                    report['disks'][drive] = get_disk_usage(drive + ':\\')
                    scan_ok += 1
                except Exception as e:
                    scan_fail += 1
                    scan_notes.append(f'{drive}盘容量获取失败: {e}')
    else:
        try:
            report['disks']['/'] = get_disk_usage('/')
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'根目录容量获取失败: {e}')

    # ---- 用户目录 ----
    print('扫描用户目录...', file=sys.stderr)
    try:
        report['user_profile'] = scan_user_profile()
        scan_ok += 1
    except Exception as e:
        scan_fail += 1
        scan_notes.append(f'用户目录扫描失败: {e}')

    # ---- 平台专用扫描 ----
    if IS_WINDOWS:
        # AppData Local
        print('扫描 AppData/Local...', file=sys.stderr)
        try:
            report['appdata_local'] = win_scan_appdata_local()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'AppData/Local 扫描失败: {e}')

        # AppData Roaming
        print('扫描 AppData/Roaming...', file=sys.stderr)
        try:
            report['appdata_roaming'] = win_scan_appdata_roaming()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'AppData/Roaming 扫描失败: {e}')

        # Windows 系统目录
        print('扫描 Windows...', file=sys.stderr)
        try:
            report['system_dirs'] = win_scan_system()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Windows 目录扫描失败: {e}')

        # Program Files
        print('扫描 Program Files...', file=sys.stderr)
        try:
            report['program_dirs'] = win_scan_program_files()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Program Files 扫描失败: {e}')

        # Temp
        print('扫描临时文件...', file=sys.stderr)
        try:
            report['temp'] = win_scan_temp()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'临时文件扫描失败: {e}')

        # Updaters
        print('扫描更新包...', file=sys.stderr)
        try:
            report['updaters'], report['updaters_total'] = win_scan_updaters()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'更新包扫描失败: {e}')

        # Large logs
        print('扫描异常日志...', file=sys.stderr)
        try:
            report['large_logs'] = win_find_large_logs()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'日志扫描失败: {e}')

        # D drive
        if os.path.isdir('D:\\'):
            print('扫描 D 盘...', file=sys.stderr)
            try:
                report['d_drive'] = _safe_scan_listdir('D:\\', min_size=10*1024*1024)
                scan_ok += 1
            except Exception as e:
                scan_fail += 1
                scan_notes.append(f'D盘扫描失败: {e}')

    else:  # macOS
        # ~/Library
        print('扫描 ~/Library...', file=sys.stderr)
        try:
            report['library'] = mac_scan_library()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Library 扫描失败: {e}')

        # Caches
        print('扫描缓存...', file=sys.stderr)
        try:
            report['caches'] = mac_scan_caches()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'缓存扫描失败: {e}')

        # Application Support
        print('扫描 Application Support...', file=sys.stderr)
        try:
            report['app_support'] = mac_scan_app_support()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Application Support 扫描失败: {e}')

        # /Applications
        print('扫描 /Applications...', file=sys.stderr)
        try:
            report['program_dirs'] = mac_scan_applications()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'/Applications 扫描失败: {e}')

        # System
        print('扫描系统目录...', file=sys.stderr)
        try:
            report['system_dirs'] = mac_scan_system()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'系统目录扫描失败: {e}')

        # Homebrew
        print('扫描 Homebrew...', file=sys.stderr)
        try:
            report['homebrew'] = mac_scan_homebrew()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Homebrew 扫描失败: {e}')

        # Xcode
        print('扫描 Xcode...', file=sys.stderr)
        try:
            report['xcode'] = mac_scan_xcode()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Xcode 扫描失败: {e}')

        # Node/npm
        print('扫描 Node 生态...', file=sys.stderr)
        try:
            report['node_ecosystem'] = mac_scan_node_modules()
            scan_ok += 1
        except Exception as e:
            scan_fail += 1
            scan_notes.append(f'Node 生态扫描失败: {e}')

    # ---- 信心值计算 ----
    total_scans = scan_ok + scan_fail
    if total_scans == 0:
        confidence_score = 1
        confidence_reason = '所有扫描均未执行'
    elif scan_fail == 0:
        confidence_score = 10
        confidence_reason = '所有扫描区域均成功完成'
    elif scan_fail <= 2:
        confidence_score = 8
        confidence_reason = f'有 {scan_fail} 个区域扫描失败，不影响整体结论'
    elif scan_fail <= 4:
        confidence_score = 6
        confidence_reason = f'有 {scan_fail} 个区域扫描失败，数据可能不完整'
    else:
        confidence_score = 4
        confidence_reason = f'大面积扫描失败（{scan_fail}/{total_scans}），结论需谨慎'

    # 关键数据缺失扣分
    if IS_WINDOWS and 'C' not in report['disks']:
        confidence_score = max(1, confidence_score - 3)
        confidence_reason += '；无法获取C盘容量数据'
    elif IS_MACOS and '/' not in report['disks']:
        confidence_score = max(1, confidence_score - 3)
        confidence_reason += '；无法获取根目录容量数据'

    report['confidence'] = {
        'score': confidence_score,
        'reason': confidence_reason,
        'scan_ok': scan_ok,
        'scan_fail': scan_fail,
        'notes': scan_notes,
    }

    print(f'扫描完成！信心值: {confidence_score}/10', file=sys.stderr)
    if scan_notes:
        for note in scan_notes:
            print(f'  ⚠ {note}', file=sys.stderr)

    output = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f'报告已保存到: {args.output}', file=sys.stderr)
    else:
        print(output)


if __name__ == '__main__':
    main()
