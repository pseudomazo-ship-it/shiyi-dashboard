---
name: windows-system-settings
description: "Use when 要改 Windows 机器级设置（禁设备/IPv6 优先级等，需提权）。"
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows]
metadata:
  hermes:
    tags: [windows, 设备管理, PnP, IPv6, 提权, 网络]
    category: productivity
---

# Windows 机器级设置（提权改动）

触发：十一说「把 XX 设备禁掉」「XX 网站打不开」「把这个软件的开机自启关掉」这类
**要改 Windows 系统设置**的活 —— 不是改文件、不是跑业务脚本。

## 0. 三步铁律（每次都走完）

1. **先只读诊断**（不改任何东西）→ 拿客观证据再动手
2. **改前记录原值** → 写进回复当回滚信息
3. **改后必须验证**（读回系统状态）—— **不能只看命令退出码**

⚠️ 十一问过「**是不是需要重启一下电脑才生效**」。
**设备禁用、IPv6 前缀策略都是立即生效、且重启后保持的**。
但**要验证后再下结论**，不要凭感觉说「要重启」或「不用重启」。

## 1. 提权执行：Start-Process -Verb RunAs

我的 shell 不是管理员，`netsh` / `Disable-PnpDevice` 会直接报：
```
请求的操作需要提升(作为管理员运行)
```

✅ **可行写法**（会弹 UAC，十一点「是」才生效）：
```bash
powershell -NoProfile -Command "Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile','-Command','<要执行的命令>' -Wait; Write-Host '流程结束'"
```

- **`-Wait` 必须加** —— 否则我这边立刻返回，读回状态时改动还没落地，会误判成失败。
- 引号转义很烦：内层命令里的双引号写成 `\"`，`$false` 写成 `\$false`。
- ⚠️ **弹 UAC 前先跟十一说一声**（他要知道会弹窗）；他不在场时别静默弹。
- ⛔ **重启/关机不行** —— 那是硬禁（见 `windows-power-and-autostart` 第 1 节），**提权也过不去**，别试第二种写法。

## 2. 禁用 / 启用设备（Disable-PnpDevice）

场景：十一 2026-09-30 让我禁掉 UU 远程和向日葵的虚拟显示器（「我不用 XX 的虚拟屏功能」）。

### ① 查（先拿 InstanceId）
```powershell
Get-PnpDevice | Where-Object { $_.FriendlyName -match 'GameViewer|Oray|虚拟|Virtual Display' } |
  Select-Object Status, Class, FriendlyName, InstanceId | Format-List
```
⚠️ 中文设备名在 bash → PowerShell 传参**编码会乱** → **别硬拼中文名，先拿对象再取属性**。

### ② 禁 / 启
```powershell
Disable-PnpDevice -InstanceId 'ROOT\DISPLAY\0000' -Confirm:$false
Enable-PnpDevice  -InstanceId 'ROOT\DISPLAY\0000' -Confirm:$false
```
（都要提权，见第 1 节）

### ③ 🔴 验证：`Status` 会变成 `Error` —— **这是正常的，不要误判成失败**

```
Status  : Error
Problem : CM_PROB_DISABLED        ← 这才是「已禁用」的判据（Problem 值 22）
```

**判断按 `Problem` 字段，不要按 `Status`：**
```powershell
$d = Get-PnpDevice -InstanceId 'ROOT\DISPLAY\0000'
Write-Host ($d.Status + ' / ' + $d.Problem)
```
- `CM_PROB_DISABLED` = 已禁用 ✅
- `CM_PROB_NONE` + `Status: OK` = 正常在用

**再从「输出端」交叉验证一遍**（比看设备状态更直接）：
```powershell
Get-CimInstance Win32_VideoController | Select-Object Name, CurrentHorizontalResolution
# 被禁的虚拟适配器 → 分辨率列为空
Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams
# 只剩物理显示器 = 生效
```

### ④ 持久性（十一问「重启会不会自动启动」）

```powershell
# ⚠️ **不要写 `reg query "…" //v ConfigFlags`** —— 在 git-bash 里必然失败：
#    本次实测报 `ERROR: Invalid syntax. Type "REG QUERY /?" for usage.`
#    （MSYS 会把 `/v` 改写/拼坏成 `//v`；而同一条命令里的 `//v` 又会被它当参数原样传给 reg）。
#    **换 PowerShell 的 Get-ItemProperty，一次成功：**
Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Enum\ROOT\DISPLAY\0000' -Name ConfigFlags
# 批量核（本次两个设备一起查）：
foreach($id in @('0000','0001')){
  $k = 'HKLM:\SYSTEM\CurrentControlSet\Enum\ROOT\DISPLAY\' + $id
  $v = (Get-ItemProperty -Path $k -Name ConfigFlags -EA SilentlyContinue).ConfigFlags
  Write-Host ($id + ' ConfigFlags=' + $v + $(if($v -band 1){' 已持久禁用 ✅'}else{' 未禁用'}))
}
```
- **`ConfigFlags = 1`** = 持久禁用，**重启后仍然禁用** ✅
- 同类提醒：**git-bash 里调原生 Windows 工具，凡是带 `/xxx` 参数的都先怀疑 MSYS 改写**；
  能用 PowerShell 的 `Get-*` 就优先用它，比跟引号/斜杠搏斗省事。
  （位运算：`ConfigFlags -band 1` 为真即「已持久禁用」）
- ⚠️ **但有个例外要主动告诉他**：**装了驱动软件的虚拟设备，其自启进程可能把设备重新 Enable 回来**。
  本次实测 UU 远程的 `GameViewer` **就在开机自启列表里** —— `Get-CimInstance Win32_StartupCommand` 能查到。
  → 这种情况：**要么实测一晚看他会不会自己回来，要么把该软件的开机自启也关掉**（一劳永逸）。
  → 对照：向日葵那次 `SunloginService` 是 `Stopped`、自启列表里也没有它 → **不会捣乱**。
  （判断口径：**先查自启列表，再决定要不要提醒他这一条**，别一律说「重启后一定还是禁的」。）

### 本次实测记录（2026-09-30，本机）

| InstanceId | 设备 | 结果 |
|---|---|---|
| `ROOT\DISPLAY\0000` | GameViewer Virtual Display Adapter（UU远程）| 已禁用，ConfigFlags=1 |
| `ROOT\DISPLAY\0001` | OrayIddDriver Device（向日葵）| 已禁用，ConfigFlags=1 |
| — | NVIDIA GeForce GTX 1660 | 正常，1920×1080 |

## 3. IPv6 优先导致某些网站打不开（GitHub Pages 等）

### 症状
浏览器报「**无法访问此网站 / XXX 意外终止了连接**」，但命令行却通。

### ⓪ 🔴 第一步先分清两条路：浏览器走系统代理，我的 curl 不走（2026-10-06 真因就栽在这）

**这比查 IPv6 还要靠前，是排查「打不开」的第 0 步。**

| 谁 | 走哪条路 |
|---|---|
| Chrome / Edge 等浏览器 | **Windows 系统代理**（WinINET：`HKCU\...\Internet Settings` 的 `ProxyEnable` / `ProxyServer`） |
| 我 `terminal` 里的 curl | **直连** —— 除非显式 `-x` 或设了 `http_proxy` 环境变量 |

→ **「我 curl 通了」完全不能证明「浏览器能通」**，两条路根本不同。
2026-10-06 实测：curl 直连 **200**，同一个 URL 在真实 Chrome 里 `ERR_CONNECTION_CLOSED`。
（那天我一开始就是拿 curl 通来「证明站点没问题」，方向错了，白绕一圈。）

**判据：浏览器报错 **且** curl 直连 200 → 立刻怀疑系统代理**，跑下面二连：

```bash
# ① 系统代理开着吗、指向哪
powershell -NoProfile -Command "Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | Select-Object ProxyEnable,ProxyServer,ProxyOverride | Format-List"

# ② 同一 URL，走代理 vs 直连 —— 这一步是分水岭
curl -s -o /dev/null -w "via-proxy: %{http_code} %{time_total}s\n" -x http://127.0.0.1:7897 --max-time 25 "<url>"
curl -s -o /dev/null -w "direct   : %{http_code} %{time_total}s\n" --noproxy '*' --max-time 25 "<url>"
```
2026-10-06 实测：`via-proxy: 000 / 0.31s`（代理 0.3 秒就掐断连接）｜`direct: 200 / 0.99s`。

### ⓪-2 第三步：**换几个域名再走一遍代理** —— 区分「代理整个挂了」还是「只对这一个域名坏」

**跳过这步就会误判成「代理宕机」，然后去改错的东西。**

```bash
for u in "https://www.baidu.com" "https://github.com" "<出问题的URL>" "https://www.google.com"; do
  printf "  %-52s " "$u"
  curl -s -o /dev/null -w "code=%{http_code} t=%{time_total}s\n" -x http://127.0.0.1:7897 --max-time 15 "$u"
 done
```

**2026-10-06 实测**：baidu ✅200 ｜ github.com ✅200 ｜ google.com ✅302 ｜ **`pseudomazo-ship-it.github.io` ❌000（0.3s 断开）**
→ **代理本身是好的，唯独 `*.github.io` 走代理会被挪断**（而同域名直连反而通）。
→ 结论指向「代理客户端里 github.io 的分流规则坏了」，**不是**代理宕机。

### ⓪-3 三个候选修法（⚠️ 2026-10-06 **未实测**，只列方案，别当成已验证流程）

按「对他打扰最小」排序：
1. **在代理客户端里把该域名设为 DIRECT**（分流规则）—— 最干净，但要在他的客户端界面里改。
2. **加进 Windows 代理例外列表**：`HKCU\...\Internet Settings` → `ProxyOverride`（分段号分隔，追加 `*.github.io;github.io`）
   - HKCU，**不需要提权**；浏览器立即生效、不用重启
   - **不碰代理客户端配置，也不影响 git push**（git 用的是显式 `-c http.proxy=...`，不看系统代理）
   - ⚠️ 但直连 github.io 现在通≠以后一直通 —— 属「绕过」不是「治好」
3. **临时关掉系统代理**（设置 → 网络和 Internet → 代理）—— 最快，但影响所有走代理的流量

改前照第 0 节铁律：**先记录 `ProxyOverride` 原值**（回滚要用）；改后读回验证。

### 诊断：三连定位到 IPv6
```bash
curl -s -o /dev/null -w "HTTP %{http_code}\n" -m 15 "<url>"                        # 系统默认
curl -6 --noproxy '*' -s -o /dev/null -w "HTTP %{http_code}\n" -m 12 "<url>"       # 强制 IPv6
curl -4 --noproxy '*' -s -o /dev/null -w "HTTP %{http_code}\n" -m 12 "<url>"       # 强制 IPv4
nslookup <域名>                                                                     # 看是不是同时有 AAAA + A
```
本次结果：默认 **200** / IPv6 **000** / IPv4 **200**
→ **IPv6 那条路是断的**，而 DNS 同时返回 `2606:50c0:…`(AAAA) 和 `185.199.110.153`(A)，
**浏览器按 RFC 优先 IPv6 → 连不上**。

⚠️ **curl 会自动回退到 IPv4 所以显示 200** ——
**别因为「我 curl 通了」就断定问题在对端或用户网络**（本次我就先误判成「浏览器在走挂掉的代理」）。

### 修复：调 IPv6 前缀策略，让系统优先 IPv4（立即生效，不用重启）
```bash
netsh interface ipv6 show prefixpolicies                      # ① 先存档原值（回滚要用）
netsh interface ipv6 set prefixpolicy ::ffff:0:0/96 60 4      # ② 改（需提权，见第 1 节）
```
- 含义：把 **IPv4 映射前缀的优先顺序提到 60**（本机原值 46；IPv6 默认 40）→ 系统先试 IPv4。
- **不是禁用 IPv6**，只是改优先级；以后遇到 IPv6 有问题的站点都能通。
- 回滚：`netsh interface ipv6 set prefixpolicy ::ffff:0:0/96 46 4`
- ⚠️ 命令是 `show prefixpolicies`（**复数**）；写成 `prefixpolicy` 会报「找不到以下命令」。

### 验证
```bash
netsh interface ipv6 show prefixpolicies     # 应显示 60  ::ffff:0:0/96
ping -n 2 <域名>                              # 应解析到 IPv4 且能通
```
本次：策略 46 → **60** ✅；`ping` 解析到 `185.199.110.153`(IPv4)，82~93ms，0 丢包 ✅

> ⚠️ **诚实标注**：做完后十一转去处理别的需求，**没有回头确认浏览器是否恢复**。
> 系统层面已验证到位（策略生效 + 解析走 IPv4 + 可达），但**「他那边网页能打开了」这一步没闭环**。
> 下次遇同类：除了看策略，**一定要问他一句「现在能打开了吗」再收尾**。

> 🔴 **2026-10-06 复盘（重要）**：同类问题（十一「看板怎么打不开了」）**再次出现**，
> 这次真因**不是 IPv6 而是系统代理**（见上面 ⓪ 节）；同一天实测还发现
> **`::ffff:0:0/96` 的优先值又回到了 46** —— 上次改成 60 的已经没了。
> → **两条教训**：
> ① **别一上来就认定是 IPv6** —— 先跑 ⓪ 的「浏览器 vs curl 代理对比」，那才是更常见的真因；
> ② **上次改过的设置要重新核实、不能当成还在** —— 代理客户端/网络变化会把 prefixpolicy 重置回去，
>    每次现查 `netsh interface ipv6 show prefixpolicies`，不要引用「上次已经改成 60 了」。

## 3.2 代理对某个域名转发挂掉（更常见的同类，2026-10-06 实测）

### 症状
十一说「**<网站> 怎么打不开了**」（本次是 GitHub Pages 看板）。
浏览器报 `ERR_CONNECTION_CLOSED`（或「意外终止了连接」），**但网页本身没有任何问题**。

### 诊断：先分清「网站坏」还是「链路坏」

```bash
# ① 先证明网页本身是好的（jsdom 跑一遍，看能不能登录+渲染、有无 JS 错误）
node check_live_render.js <抓下来的html>     # 应输出「✅ 无 JS 错误」+ 表格行数
# ② 分路径测（关键）——一把就能定位
curl -s -o /dev/null -w "%{http_code}\n" -x http://127.0.0.1:7897 --max-time 15 "<url>"   # 走代理
curl -s -o /dev/null -w "%{http_code}\n" --noproxy '*' --max-time 15 "<url>"               # 直连
```

**本次实测**：
| 路径 | 结果 |
|---|---|
| 走代理 7897 | ❌ `000`，**0.3s 就断**（快断 = 代理侧掐的，不是超时）|
| 直连 | ✅ `200`，0.99s |
| 代理访问 baidu / github.com / google | ✅ 200 / 200 / 302（**代理没坏**）|
| **代理访问 `*.github.io`** | ❌ `000` |

→ **代理本身正常，只有 `github.io` 这个域名的转发挂了。**
（同一域名族走不同规则/节点，`github.com` 通而 `github.io` 不通是常见现象 → 某个节点挂或分流规则指错。）

⚠️ **别因为「我 curl 通了」就断定网站没问题** —— 我 curl 不带代理参数、默认直连，而**浏览器走系统代理**，
所以两边结论相反时，**先查代理**。也不要凭直觉说「你浏览器在走挂掉的代理」（本次我第一版结论就是错的）。

### 🔴 用真实浏览器复现（决定性证据，别只靠 curl）

```python
browser_exec: new_tab("<url>"); wait_for_load(); page_info()
# 报错就拿 body.innerText 看真实报错文案
# 平时好的时候：ERR_CONNECTION_CLOSED / 无法访问此网站
```
本次就是靠这一步**当场复现**了十一的报错，才敢说是环境问题。

### 修复（我能直接做、可逆、不需管理员）

把该域名加进 **Windows 代理例外列表**（HKCU，`ProxyOverride`，分号分隔，支持 `*.xxx`）：
```python
import winreg
KEY = r'Software\Microsoft\Windows\CurrentVersion\Internet Settings'
with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY, 0, winreg.KEY_WRITE) as k:
    winreg.SetValueEx(k, 'ProxyOverride', 0, winreg.REG_SZ, 原值 + ';*.github.io;github.io')
```
- ✅ 立即生效（Chrome 会收到 WinINET 变更通知），**不用重启**
- ✅ **只影响浏览器访问该域名**；**不影响 git push**（推代码用的是 `-c http.proxy=...` 显式参数，不走系统代理）
- ✅ 可逆：**改前先把原值存文件**（本次存 `cache/proxyoverride_orig.txt`），回滚 = 写回原值
- ✅ 不需管理员（HKCU）

**验证必须走真实浏览器**（`browser_exec` 打开 → 看 title / 登录 / 表格行数），不能只看注册表读回。
本次改完：`title=蒙倩品牌主体财务看板`、登录后 `43 行 × 22 列` ✅。

### 交付话术
- 先说「**不是看板的问题**」并给证据链（内容完好 + 哪条路不通）。
- 给**回滚命令** + 说明**为什么不选另外两个方案**：
  - ⛔ 「临时关系统代理」不推荐 —— 全局副作用，关掉后 google/github.com 全不通。
  - ✅ 「在代理客户端里把该域名设直连/换个节点」更治本，但需用户在客户端界面操作；
    本次客户端（`com.vortex.helper`）的 `config.yaml` 是**加密的**（base64 密文），我读不出规则 →
    **别硬憋，直说「治本得你在界面里点」**。
- ⚠️ 提醒：例外是**硬编码直连**，若将来该域名直连也被墙，会再次打不开 —— 到时删掉例外即可。

## 4. 交付话术（他在意的三点）

1. **给回滚命令** —— 他问过「重启会不会自动启动」，说明他在意可逆性。
   改完回复里直接附「怎么恢复」（原值 + 命令）。
2. **不要让他去点图形界面** —— 我能命令行做完就做完，只把 UAC 弹窗留给他点。
3. **定位错了要主动纠正** —— 本次我先说「你的浏览器在走挂掉的代理」（未验证），
   实测真因是 IPv6。**别让他按错的结论去改设置** —— 发现了就自己更正。

## 相关
- `windows-power-and-autostart` —— 重启/关机/自启、WOL、RTC 定时开机（**同类：机器级操作**）
- `windows-disk-cleanup` —— 磁盘/内存清理
- `windows-desktop-maintenance` —— 桌面图标 / .lnk 修复
