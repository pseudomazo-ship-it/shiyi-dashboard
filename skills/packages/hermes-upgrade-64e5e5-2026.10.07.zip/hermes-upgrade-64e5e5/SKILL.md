---
name: hermes-upgrade
description: "Upgrade Hermes on Windows when `hermes update` fails."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [hermes, update, upgrade, venv, force-venv, zip, git, windows]
---

# Hermes Agent upgrade on Windows

How to move Hermes (this own install) to a newer version safely, when the
one-command `hermes update` path is blocked. This is a **same-machine, real
execution** task — the upgrade touches the running install's `venv` and
`hermes_cli`, so data preservation and a clean process tree matter. Never
promise "upgraded" without a real `hermes --version` + gateway check afterward.

## When to Use
- User asks "can you upgrade Hermes" / "should I update" / reports `hermes update` failing.
- `hermes update` errors about `.pyd` locks, running processes, no git commits,
  untracked files, or "cannot reach the remote repository".
- You control this machine's own Hermes install and must move it to a newer version.

## When the user asks "should I update / can you upgrade Hermes"
1. Check current vs latest: `hermes --version` (e.g. `v0.20.6`), and the latest
   release tag via the GitHub API
   (`curl -s https://api.github.com/repos/NousResearch/hermes-agent/releases/latest`
   → `tag_name`, e.g. `v2026.8.31` = `v0.21.0`).
2. Warn if jumping a MAJOR version (e.g. 0.20 → 0.21) and the day-0 release is
   <1-2 weeks old. Advise: back up first, upgrade when the user can accept a
   restart + brief re-verify, or wait for it to settle.
3. **ALWAYS back up before touching it.** The user's data lives OUTSIDE the
   `hermes-agent` repo — back it all up together:
   - `state.db` (memory/sessions), `config.yaml`, `.env`
   - `skills/` (user-installed skills), `scripts/` (sentinel etc.)
   - `profiles/<name>/state.db` (specialist agents h-2..h-8), 人设档案 `.md`
   - Copy to `backup-before-upgrade-<YYYY.MM.DD>/`.

## Data-location fact (critical for a safe upgrade)
`E:\软件\Hermes\hermes-agent\` is the **code repo** (contains `venv/`,
`hermes_cli/`, the bundled `skills/`, `scripts/`). The user's **real data**
(`state.db`, `config.yaml`, `.env`, `skills/` user ones, `scripts/waiting_sentinel.py`,
`profiles/`, 人设) all live in `E:\软件\Hermes\` (the PARENT) — NOT under
`hermes-agent`. So replacing/overlaying `hermes-agent` source does NOT touch
user data. Verify this mapping before any overwrite.

## Why `hermes update` fails — diagnose in this order
1. **`git` path dead** → the install was done from a ZIP (no git history). You'll
   see `git rev-parse` exit 128 / "current branch 'master' does not have any commits
   yet" / everything is `??` untracked. `git pull` WILL NEVER work here.
2. **ZIP fallback refused** → "working tree has uncommitted changes or untracked
   files"; overlaying the ZIP would clobber them. This is correct safety behavior,
   do NOT force past it blindly.
3. **`--force-venv` blocked by running processes** → the updater halts because
   other Hermes processes (serve backends, the desktop app) hold `venv/*.pyd`
   locks. The checker lists the PIDs. On Windows `.pyd` files can't be replaced
   while a process has them open.

## Process-tree blocker (Windows): the desktop app is the parent
Every profile's `serve` backend is spawned by the **desktop app process**. If you
`taskkill` the `serve` PIDs, a supervisor (the app) **restarts them with new PIDs**
(whack-a-mole). Trace parents with:
`Get-CimInstance Win32_Process | where CommandLine -match 'hermes_cli|Hermes.exe'`
→ the parent chain shows `Hermes.exe` as the common ancestor. The real fix is
either (a) close the desktop app, or (b) if you must keep the session, use
`--force-venv` and accept the .pyd lock risk.

## The two safe upgrade paths

### Path A — stay in-session (preferred when the user can't close the app)
`hermes update --force-venv -y` — proceeds despite .pyd locks. Needs network to
`github.com`. Verify BEFORE running: `curl -s -o /dev/null -w "%{http_code}" https://github.com`
— if it times out (code 28 / no 200), the update fails with
`cannot reach the remote repository / Failed to connect to github.com`. Retry once
the user reconnects; do NOT re-run `hermes update` in a loop behind a flaky link.

### Path B — manual ZIP overlay (when `hermes update` can't run at all)
1. Download the release zipball: `curl -sL -o hermes.zip <zipball_url>` (the
   `zipball_url` from the release API; ~76MB).
2. `unzip` to a temp dir; the top folder is `NousResearch-hermes-agent-<sha>/`.
3. Overlay onto the repo: `cp -rf <extract>/. "/e/软件/Hermes/hermes-agent/"`
   (copy, do not delete — preserves any untracked user files that weren't removed).
4. Sync deps with the new lockfile: `uv sync --frozen` (v0.21 uses `pyproject.toml`
   + `uv.lock`, not `requirements.txt`).
5. Confirm the new version: `uv run python -c "import hermes_cli; print(hermes_cli.__version__)"`.
6. The running `serve` still hosts the OLD bytes — **the user must restart the
   desktop app** (fully quit + reopen) for the new version to load. Gateway and
   cron restart through the app.

## Verify after upgrade (the deliverable is evidence, not a claim)
- `hermes --version` → new version string.
- `hermes gateway start` then `hermes gateway status` → running. (After upgrade
  the gateway may not be auto-running; start it.)
- `hermes cron list` → sentinel job present & enabled.
- `hermes profile list` → specialists still listed.
- Check `/e/软件/Hermes/state.db` size still non-trivial, `.env` still has
  `FEISHU_APP_ID` etc. — confirms user data untouched.
- Check the gateway log for the platforms connecting (weixin/qqbot/feishu) and
  for a **benign `AttributeError: asyncio has no start_unix_server`** — that is
  a known, non-fatal Windows quirk in some versions; message flows (weixin
  inbound/outbound) prove it's cosmetic.

## Pitfalls (each hit this session)
- Do NOT pipe `hermes update` through `head`/`tail` — that hides the true exit
  code (a failed run can look like exit 0). Run it plainly.
- `taskkill //PID` in git-bash mangles the flag → use
  `powershell -NoProfile -Command "Stop-Process -Id <pid> -Force"` instead.
- `curl` without a `-A` (user-agent) on some mirrors returns 0-byte files; add
  one if a download is empty.
- After killing a serve PID, re-check before `hermes update` — the supervisor
  may have relaunched it with a new PID, so the blocker is still there. List
  again, don't assume the kill held.
- Deep `du`/`grep` across `hermes-agent` (it contains `venv/`) will time out —
  scope scans to specific paths, never walk the whole tree.

See `references/windows-incamera-upgrade-recipe.md` for the exact transcript-level
steps, error strings, and the VERIFIED Path B sequence from the v0.20.6→v0.21.0
upgrade.
