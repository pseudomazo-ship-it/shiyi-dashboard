# Windows in-place Hermes upgrade — verified recipe (v0.20.6 → v0.21.0)

Concrete, observed transcript from a real upgrade. Use the SKILL.md for the
decision frame; use this file for the exact commands/error strings you'll hit.

## Diagnosing why `hermes update` fails — real outputs

`hermes update -y` (first attempt):
```
✗ Other Hermes processes are running from this install's venv:
  PID 21588  python.exe ... -m hermes_cli.main --profile h-6 serve ...
  PID 26024  python.exe ... -m hermes_cli.main --profile h-8 serve ...
  PID 34524  python.exe ... -m hermes_cli.main --profile h-7 serve ...
  On Windows these keep native extension files (.pyd) locked ...
  Close the Hermes desktop app / other Hermes terminals, then re-run
  (or use `hermes update --force-venv` to proceed anyway)
```
→ The blocker list is real; these are per-profile `serve` backends.

`git status` inside `hermes-agent` (a ZIP install, no git history):
```
?? .coderabbit.yaml
?? .dockerignore
?? ... (entire tree untracked)
fatal: ambiguous argument 'HEAD': unknown revision ...
fatal: your current branch 'master' does not have any commits yet
```
→ ZIP installs have NO commits and NO `.git`; `git pull` can never work. The
`hermes update` "falling back to ZIP download" then refuses because the whole
tree is untracked.

`hermes update --force-venv` (head bit a network hiccup):
```
✗ Network error — cannot reach the remote repository.
  fatal: unable to access 'https://github.com/NousResearch/hermes-agent.git/':
  Failed to connect to github.com port 443 after 21083 ms
```
→ `--force-venv` still needs github.com reachable. Check FIRST:
`curl -s -o /dev/null -w "%{http_code}" --max-time 15 https://github.com` → want `200`.
If 28/timeout, stop; ask user to reconnect.

## Killing the whack-a-mole serve PIDs
`Stop-Process -Id <pid> -Force` works but the desktop app relaunches new PIDs.
Re-list before retrying — the blocker does NOT stay dead unless the app is closed.
The desktop app (`Hermes.exe`) is the parent of every `serve`; trace with:
`Get-CimInstance Win32_Process | where { $_.CommandLine -match 'hermes_cli|Hermes.exe' }`.

## Manual ZIP overlay (the path that finally worked, v0.20.6 → v0.21.0)

```bash
# 1. latest tag + zipball url
curl -s https://api.github.com/repos/NousResearch/hermes-agent/releases/latest \
  | grep -E '"tag_name"|"zipball_url"'           # e.g. v2026.8.31 (= v0.21.0)

# 2. download (~76MB)
curl -sL -o hermes-v0210.zip "https://api.github.com/repos/NousResearch/hermes-agent/zipball/v2026.8.31"

# 3. unzip; top-level dir is NousResearch-hermes-agent-<sha>/
unzip -q -o hermes-v0210.zip -d hermes-v0210-extract

# 4. overlay onto the repo (COPY, don't delete the dest)
cp -rf hermes-v0210-extract/NousResearch-hermes-agent-6e8f841/. "/e/软件/Hermes/hermes-agent/"

# 5. sync deps with the new lockfile
cd /e/软件/Hermes/hermes-agent && uv sync --frozen

# 6. confirm
uv run python -c "import hermes_cli; print(hermes_cli.__version__)"   # -> 0.21.0
```

Note: the release zip filename uses the TAG `v2026.8.31`, and the extracted dir
hash is a build/folder suffix, not the version. The `hermes_cli.__version__`
value is the authority that you actually landed on 0.21.0.

## Post-upgrade verification (must actually run, not assume)
```bash
hermes --version                     # -> Hermes Agent v0.21.0 (2026.8.31)
hermes gateway start                 # gateway not auto-running after upgrade
hermes gateway status                # -> process running
hermes gateway list                  # -> default running; specialists stopped
hermes cron list                     # sentinel job [active]
hermes profile list                  # specialists still present
# data untouched:
ls -la /e/软件/Hermes/state.db       # ~197MB
grep FEISHU_APP_ID /e/软件/Hermes/.env
# gateway log (E:\软件\Hermes\logs\gateway.log) should show the platforms
# connecting. A line "AttributeError: module 'asyncio' has no attribute
# 'start_unix_server'" appears AFTER the connect lines and is non-fatal —
# inbound/outbound weixin messages still flow, proving it's cosmetic.
```

## Key facts that repeated
- Because user data (`state.db`, `.env`, `config.yaml`, `skills/`, `scripts/`,
  `profiles/`, 人设) lives in `E:\软件\Hermes\` — the PARENT of `hermes-agent/`
  — overlaying the repo dir touches none of it. Always confirm this mapping
  before an overlay so you don't talk the user out of a safe path.
- `--force-venv` is the escape hatch when you must NOT kill the desktop app /
  current session, but it needs github reachable and accepts the .pyd-lock risk.
