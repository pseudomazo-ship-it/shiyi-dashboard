# Feishu Bitable API — create & shape a 多维表格 (after scope is granted)

This is the concrete recipe for building/editing a Base **once** the earlier
scope probe passes. The outer `feishu` skill covers the scope-gate (code
99991672). This reference is the "now you have scope, here's how to actually
build the table" half.

## 0. Get a tenant_access_token (every call needs it)

```python
import subprocess, json, re, os
# creds come from the user's .env — read directly, don't assume shell env carries them
creds = {}
for line in open(r"E:/软件/Hermes/.env", encoding="utf-8"):
    m = re.match(r'^\s*(FEISHU_APP_ID|FEISHU_APP_SECRET)\s*=\s*(.+)\s*$', line)
    if m: creds[m.group(1).strip()] = m.group(2).strip().strip('"').strip("'")
tok = json.loads(subprocess.run(
    ["curl","-s","--max-time","20","-X","POST",
     "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
     "-H","Content-Type: application/json",
     "-d",json.dumps({"app_id":creds["FEISHU_APP_ID"],"app_secret":creds["FEISHU_APP_SECRET"]})],
    capture_output=True,text=True).stdout)["tenant_access_token"]
```

## 1. Create the Base app (multidimensional table container)

```bash
curl -s -X POST "https://open.feishu.cn/open-apis/bitable/v1/apps" \
  -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"name":"售后补发表"}'          # NO folder_token key at all
```

- Success: `{"code":0,"data":{"app":{"app_token":"...","default_table_id":"tbl...","url":"https://my.feishu.cn/base/<app_token>"}}}`
- **Gotcha:** sending `"folder_token":""` (empty string) returns `code 9499 Bad Request`.
  **Omit the key entirely.** The Base lands in the default location.
- **Gotcha:** the terminal prints `name` as mojibake (`�ۺ󲷺۴�`) — that's only the
  Windows console encoding. The field/table name stored in Feishu is correct.
  Decode via the JSON API response, never trust the terminal echo.

## 2. A new Base ships with ONE default table + sample fields

`default_table_id` (e.g. `tblvjnUSy9p0Ab7O`). Query its fields:

```bash
curl -s "https://open.feishu.cn/open-apis/bitable/v1/apps/$APP/tables/$TBL/fields?page_size=50" \
  -H "Authorization: Bearer $TOK"
```

Default sample fields you'll want to REMOVE (they clutter the customer-facing form):
`文本` (type 1, is_primary=true — CANNOT be deleted/renamed via API), `单选` (3),
`日期`(5), `附件`(17), `数字`(2), sometimes `复选框`. Clean the non-primary ones.

## 3. Add a field — type codes

```bash
# text field
curl -s -X POST ".../apps/$APP/tables/$TBL/fields" -H "Authorization: Bearer $TOK" \
  -H "Content-Type: application/json" -d '{"field_name":"收件人姓名","type":1}'
# single-select — property.options must be a list of {"name": ...}
curl -s -X POST ".../fields" -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"field_name":"状态","type":3,"property":{"options":[{"name":"待核实"},{"name":"已完成"}]}}'
```

| type | ui_type | meaning |
|---|---|---|
| 1 | Text | 文本 |
| 2 | Number | 数字 |
| 3 | SingleSelect | 单选 (needs `property.options`) |
| 5 | DateTime | 日期 |
| 17 | Attachment | 附件 |

- **Gotcha: field_name must not collide with an existing field name**, or it
  returns `code 9499 Bad Request`. If you add a field twice (or a name collides
  with a default sample field) you get 9499 — list fields first, then add.
- Field ids come back as `field_id` in each item.

## 4. Rename / delete a field

```bash
# rename any NON-primary field
curl -s -X PUT ".../apps/$APP/tables/$TBL/fields/$FIELD_ID" \
  -H "Authorization: Bearer $TOK" -H "Content-Type: application/json" \
  -d '{"field_name":"新名称"}'
# delete
curl -s -X DELETE ".../apps/$APP/tables/$TBL/fields/$FIELD_ID" -H "Authorization: Bearer $TOK"
```

- **Gotcha:** the **primary key field cannot be renamed** — `code 99992402
  "field validation failed"`. Its name stays whatever Feishu defaulted it to
  (it's the first column). If the primary column name is ugly (e.g. "文本"),
  either accept it or rebuild the table so the first real column becomes primary.
  Verify before promising "I'll make the first column say 序号" — the API won't do it.

## 5. What the API returns vs what the user needs

Always end with a verifiable handle: `app_token` + `url` =
`https://my.feishu.cn/base/<app_token>`. Tell the user to open that link — it's
the real artifact. Never claim "built" on a bare `code:0` alone for the create
step; the app_token/url are the proof.

## Tips driven by this session (Windows / bash environment)

- Run the token exchange + mutations from `execute_code` (Python), not raw
  `terminal` bash, so JSON/encoding is handled. In Python, **do not read
  `/tmp/...`** — MSYS `/tmp` isn't visible to the native Python process that
  execute_code runs in. Read creds from `.env` with an explicit Windows path
  (`r"E:/软件/Hermes/.env"`) instead.
- Mutations are sequential & slightly rate-limited; batch field creation with a
  short Python loop, printing `code`/`msg` per field so a mid-run failure is
  visible and resumable.
