# Reading a Feishu wiki / Base 多维表格 — reproduce notes

Captured from a troubleshooting session where the user (十一) pasted a
`my.feishu.cn/wiki/...` link and asked "能读到吗?". He confirmed the
share setting "组织外可访问" was ON, yet text extraction failed.

The root cause was NOT the access setting — the content was a **Base 多维表格**,whose row data renders in a live grid and never appears as extractable text.

## Exact signals seen

- `web_extract` on the raw URL returned:
  - first: `CRAWL_EMPTY_CONTENT` (keyless Exa backend)
  - the access-setting changed nothing: second attempt returned `fetch_error`
- `browser_exec` failed fast, before touching the page:
  ```
  browser-harness: remote-debugging-setup: opened chrome://inspect/#remote-debugging
  in Chrome -- ask the user to tick "Allow remote debugging for this browser instance"
  and click Allow on the popup. Warn them Chrome shows ONE more Allow popup when the
  harness connects on the next attempt (per-connection approval; it is expected, not a
  re-ask). Retry after the user confirms; do not retry before.
  ```
- `drive_preview action='elements'` errored with:
  `The in-app browser only takes actions in the session the user is looking at.`
  → drive_preview needs the user to be viewing that session; fall back to
  `desktop_preview` read.
- `desktop_preview open` + `read` DID work and returned:
  ```
  {kind: url, title: Docs, url: https://my.feishu.cn/wiki/<token>?table=...&view=...}
  text: 紫盒色号表 / 最近修改: 8月22日 16:52 / 分享 / 数据表 /
        MQ（紫盒）色号查询 / 仪表盘 / 工作流 / 新建 / 表格 / 新建视图
  ```
  I.e. title + tab names only. The row data (the color-code table itself) was absent.
- Repeated `desktop_preview read` calls intermittently returned:
  `No preview tab is open, or the read timed out` — re-open (action='open') then read once.
  Do not retry fire identical read args (looks like a loop to the tool guard).

## Why it's a Base, not a doc

- Title had "表" + a query name (MQ（紫盒）色号查询).
- Header showed tabs: 数据表 / 仪表盘 / 工作流 / 视图 — the Base signature.
- When opened it redirected to `...?table=...&view=...` — a grid view URL.

## Recommended user-facing wording (short, cause-first)

When extraction fails on a Base, give the cause + the practical option, don't
just say can't read it:

> 能打开，但读不全。这是飞书**多维表格**，数据是动态渲染的，我只能抓到标题和表头，正文表格数据抓不出来。
> 三个办法：① 你导出成 CSV/Excel 发我（最快最稳）；② 你把要查的几行复制给我；
> ③ 你授权浏览器我用登录态读（要你手动点一次 Allow）。你想用哪个？还是你其实想让我基于它做什么？
