# Reading an existing Feishu Base via the Bitable API (CONFIRMED WORKING)

Captured from a session where the user (十一) pasted
`my.feishu.cn/wiki/WkMPwjqntiTcyZkPAguc2YZpnOh?...&table=tbl...&view=...`
and it turned out to be a **补发登记表** Base. It was READ successfully via the
API — no user export, no copy/paste, no browser auth needed.

This is the fastest real-data path when `.env` has Feishu credentials.

## 0. Creds & token — read from `.env`, then run everything in Python urllib

Do NOT build this as a bash `curl | python -c` pipeline. On this Windows + MSYS
bash host, that fails with **exit 49** (and `curl -o` to a Chinese path can
fail too). Reliable route: `execute_code` with `urllib`, reading creds from
`.env` via an explicit Windows path.

```python
import re
creds = {}
for line in open(r"E:/软件/Hermes/.env", encoding="utf-8"):
    m = re.match(r'^\s*(FEISHU_APP_ID|FEISHU_APP_SECRET)\s*=\s*(.+)\s*$', line)
    if m: creds[m.group(1).strip()] = m.group(2).strip().strip('"').strip("'")

import urllib.request, json
TOKEN = json.loads(urllib.request.urlopen(urllib.request.Request(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    data=json.dumps({"app_id":creds["FEISHU_APP_ID"],"app_secret":creds["FEISHU_APP_SECRET"]}).encode(),
    headers={"Content-Type":"application/json"}), timeout=30).read())["tenant_access_token"]

def api(path):
    req = urllib.request.Request("https://open.feishu.cn/open-apis"+path,
        headers={"Authorization":"Bearer "+TOKEN})
    return json.loads(urllib.request.urlopen(req, timeout=30).read().decode())
```

## 1. wiki link → Base app_token

The pasted link is a wiki NODE token (the `<token>` after `/wiki/`), not the
Base's app_token. Resolve it:

```
GET /open-apis/wiki/v2/spaces/get_node?token=<wiki_token>
```

Returns (abridged):
```json
{"code":0,"data":{"node":{
  "title":"补发登记表","node_type":"origin","obj_type":"bitable",
  "obj_token":"QMqDbcx11a35sYslwDRcEaEVn2d"   // <-- this is the Base app_token
}}}
```

`obj_type` tells you it's a Base (vs a doc). `obj_token` is the app_token for
all `bitable/v1/apps/<app_token>` calls.

## 2. list tables

```
GET /open-apis/bitable/v1/apps/<app_token>/tables
```

Returns `data.items[].table_id` + `data.items[].name`. A Base usually has ONE
named table. Notes on the sample: `?table=tblA874xp4xmQoxr&view=...` in the
link names which table/view the user was viewing.

## 3. read the schema (fields)

```
GET /open-apis/bitable/v1/apps/<app_token>/tables/<table_id>/fields
```

Returns `data.items[].{field_id, field_name, type}`. Type codes: 1 Text, 2
Number, 3 SingleSelect, 5 DateTime, 17 Attachment.

## 4. fetch records

```
GET /open-apis/bitable/v1/apps/<app_token>/tables/<table_id>/records?page_size=100
```

Returns `data.items[]` where each `item.fields` is the row dict. `data.has_more`
flags pagination (loop with `page_token` if > 100).

## Gotcha: a Base can contain legitimately EMPTY rows

The 补发登记表 had only one field (`文本`, type 1) and 5 records whose `fields`
turned out to be `{}` — empty placeholder rows. That's valid Feishu state, not
an API bug. **Confirm with the user whether the table really has no data
before reporting "empty / no data", and check whether a field structure that
looks bare (single `文本` column) matches what they expect.**

## When NOT to use this path

- If the scope probe returns `99991672` (missing `drive:drive` / `bitable`
  scopes), the app cannot read the Base — see the main SKILL.md scope section
  and route to grant-scope or manual-export instead. Do not keep poking the API.

## Staying reliable across transient kernel/network issues

- **Fetch a FRESH `tenant_access_token` in whatever script reads the data.**
  This session the token's `expire` came back `3328` (~55 min), not the
  `7200` the docs claim. Reusing a token you pulled earlier (or hardcoded)
  returns `{"code":99991663,"msg":"Invalid access token..."}`. Pull a new one
  from `.env` creds at the start of the same run.
- **The `execute_code` kernel's network can drop mid-session** (python
  `ConnectionRefusedError 10061` or `RemoteDisconnected`), while `terminal`
  curl to the very same URL succeeds. That's a kernel socket hiccup, not a
  Feishu outage. When it happens, **don't retry inside the kernel — write the
  whole fetch to a `.py` file with `write_file`, then run it from `terminal`
  (`python <file>`).** A standalone script is immune to the kernel's socket
  state and is the dependable fallback. It reads `.env` and does its own
  pagination with a short `time.sleep(0.2)` between pages.
- Pagination: loop on `data.has_more` / `page_token`, carrying them into the
  next `records` call. This session yielded **5662 rows** across many pages.<
