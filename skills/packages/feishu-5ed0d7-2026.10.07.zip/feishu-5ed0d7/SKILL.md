---
name: feishu
description: "Read Feishu (Lark) wiki/doc/Base 多维表格 shared via link."
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Feishu, Lark, Wiki, Base, 多维表格, Docs, Documents]
    related_skills: [blocked-page-recovery, grounded-citations]
---

# Feishu (飞书 / Lark) content

Use when the user shares a `my.feishu.cn` link (wiki, doc, or Base 多维表格)
and asks you to read, extract, or work with its content. This is a recurring
platform for the user (十一), not a one-off — treat the whole class, not just
the one link.

## What the URL tells you

- `my.feishu.cn/wiki/<token>` — a wiki tree node. It can be a **document**
  OR a **多维表格 (Base)**. You can't tell from the URL alone; open it first.
- `my.feishu.cn/base/<app_token>` — a Base link carrying the token directly;
  **no wiki resolution step needed**. It may carry `?table=<tbl>&view=<vew>`
  pinning a specific table/view.
- `my.feishu.cn/share/base/view/<shr...>` — a **share link**. Anonymous fetch
  returns the Feishu **login page** (not an error body), and it still does even
  after the user has turned on 组织外可访问 — share links demand a logged-in
  viewer. Don't read that as "blocked": go straight to the API path (app
  creds), or ask the user for the `/base/<token>` form of the same table.
- If the page title reads like "<Name>表 / <Name>查询 / 数据表" and the
  header shows tabs (数据表 / 仪表盘 / 工作流 / 视图), it is a **Base 多维表格**
  — dynamic content. **Standard text extraction will NOT get the row data.**
- If it opens as a normal doc, text extraction usually works once access is
  granted.

## Access path ladder (cheapest that works first)

1. **web_extract on the raw URL.** Returns `fetch_error` / empty for almost
   all Feishu URLs. Low success — treat as a quick try, not dependable.
2. **desktop_preview open + read** — this is the reliable path for the
   Hermes desktop app. `desktop_preview action='open'` renders the page
   (the user sees a tab); `read` returns the visible text. On a Base, this
   gets the **title + header/tab names only**, not table rows.
3. **browser_exec** — the Browser Use harness opens a Chrome instance that
   needs the user to tick "Allow remote debugging for this browser instance"
   on the popup, and Chrome shows a SECOND Allow popup when the harness
   connects. Until the user does this it fails fast with a remote-debugging
   error. This is a manual-authorization step, not a code bug.
4. **drive_preview** (interactive driving) only works **in the session the
   user is looking at**. If it errors "only takes actions in the session the
   user is looking at", switch to desktop_preview read instead.

## Hard limitation: Base 多维表格 row data is NOT text-extractable

A Feishu Base renders rows through a live grid component. `web_extract`,
`desktop_preview read`, and browser text extraction all return only the
headers/tabs — the table body never appears as text. **Do not keep retrying
the same extraction. Instead, in this order:**

1. **Bitable API read** (fastest, best) — **check `.env` for FEISHU_APP_ID /
   FEISHU_APP_SECRET first.** This user's env usually has them; if present,
   the API returns the actual row data with no user action needed — no
   export, no copy/paste, no browser auth. Full recipe:
   `references/reading-bitable-via-api.md`.
2. Ask the user to **export** it: Feishu Base `...` menu → 导出 → CSV/Excel,
   then send you the file or paste the content.
3. Ask the user to **copy/paste** the relevant rows directly into chat.

### Reading an existing Base via API (wiki link → records; CONFIRMED WORKING)

When the user pastes a `my.feishu.cn/wiki/<token>` link (it may carry a
`?table=<tbl>&view=<vew>` fragment identifying a specific table/view):

1. Resolve the wiki node → get the Base `app_token`:
   `GET /open-apis/wiki/v2/spaces/get_node?token=<wiki_token>` returns
   `data.node.obj_type` (`bitable`) and `data.node.obj_token`.
2. List the Base's tables (`/bitable/v1/apps/<app_token>/tables`) and the
   target table's fields (`.../tables/<table_id>/fields`) to read the schema.
3. Fetch records (`.../tables/<table_id>/records?page_size=100`) — each
   record's `fields` dict is a row.

**Windows/bash pitfall (hit this session):** piping curl into `python -c`
fails with **exit 49** in MSYS bash, and `curl -o` with a Chinese Windows
path can fail too. **Do the whole thing from `execute_code` (Python
urllib), not a bash pipeline** — that's the reliable route. Also a Base may
legitimately contain empty rows (`fields: {}`) — confirm with the user
whether that's expected before reporting "no data".

**Two more pitfalls hit in a later read (add to the same recipe):**
- **The `execute_code` kernel's network can transiently die** (python
  `ConnectionRefusedError 10061` / `RemoteDisconnected`) while a `terminal`
  curl to the same endpoint succeeds. That's a kernel socket drop, not a
  Feishu outage — don't burn retries inside the kernel. Fallback that
  actually worked: **write the fetch to a `.py` file (`write_file`) and run
  it with `terminal` `python <file>`**; the script itself reads `.env` and
  re-fetches the token. This is the dependable route when the kernel's
  network flakes.
- **The API token expires fast** (`expire` came back ~3328s ≈55min this
  session, not the doc's 7200) and reusing a hardcode/cached token returns
  `code:99991663 Invalid access token`. **Always fetch a fresh
  `tenant_access_token` inside the same script/run** that reads the data,
  never trust one pulled earlier.
- **`sort` is REJECTED on the LIST endpoint** — `GET .../records?page_size=100&sort=[{"field_name":"日期","desc":true}]` returns **`code 1254016 InvalidSort` with `items: []`**, which reads exactly like "the table is empty". It is not; that endpoint just doesn't take the parameter. **To get ordered / newest rows use the SEARCH endpoint:** `POST /bitable/v1/apps/<app_token>/tables/<table_id>/records/search` with the sort in the **body** — `{"sort":[{"field_name":"日期","desc":true}],"page_size":500}`. Verified: returned the newest 500 rows in one call. (Reusable fetcher: `scripts/fetch_bitable_latest.py`.)
- **Don't pull the whole table just to see the latest day.** A 5-9k-row Base is ~60 pages and gets killed at the 120s timeout. Search + `sort desc` + first page = the latest records in a single request. Note the search endpoint can return more than `page_size` (asked 100, got 500).
- **Date fields (type 5) MUST be converted in China time (UTC+8):** `datetime.datetime.fromtimestamp(ts/1000, tz=timezone(timedelta(hours=8)))`. Using `utcfromtimestamp` shifts the ENTIRE batch **one day earlier** (a 9/5 row reports as 9/4). Catch it by cross-checking a stable id (e.g. 问卷编号) against what the user sees on screen, then fix the tz before reporting any per-day count.
- **Cross-check which Base you actually read before concluding "no data"**: two Bases with near-identical names can coexist (one with real daily 业绩 values, one stale/empty), and the app can have access to one but not the other. Confirm by fetching a field list, not by name.

## Creating / editing a Base via API — check app scope FIRST

Before you promise "I'll build this 多维表格 for you", verify the user's Feishu
app actually has cloud-doc / bitable scope. A bot app built only for messaging
(chats) finds the create endpoints **denied with code 99991672**, and the error
explicitly lists the missing scopes.

Probe (no side effects, ~2 calls):
```bash
# 1. exchange app credentials for a tenant_access_token
curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d '{"app_id":"$FEISHU_APP_ID","app_secret":"$FEISHU_APP_SECRET"}'

# 2. try to read any drive file — this surfaces the granted scopes
curl -s "https://open.feishu.cn/open-apis/drive/v1/files?page_size=10" \
  -H "Authorization: Bearer $TOKEN"
```

If step 2 returns `{"code":99991672,"msg":"Access denied. One of the following
scopes is required: [drive:drive, drive:drive:readonly,
space:document:retrieve]..."}` the app **cannot read OR create Bases/docs**. The
error body hands you the exact consent link:
`https://open.feishu.cn/app/<app_id>/auth?q=drive:drive,...`

**Then do NOT keep trying the API.** Route the user to one of:
1. **Grant scope** (lasting fix): open the consent link, tick 多维表格/云文档
   scope, publish a version. Afterwards the API can create/read Bases directly.
2. **User creates an empty Base manually** (fastest start): they click
   新建→多维表格, share the link, and you configure fields via browser
   login-state (desktop_preview / browser automation), since you have no API
   write scope.

Rule: never claim "Base created / row written" without the scope probe passing
AND a verifiable handle (app_token + URL) coming back.

**Once scope IS granted, the full create-and-shape recipe** (create app, add
typed fields, rename/delete, primary-key gotcha, `folder_token` pitfall) is in
`references/feishu-bitable-api.md`. Read it before building a Base for the user
— it encodes the exact endpoints and the 9499 / 99992402 error causes so you
don't hit them.

## Interaction discipline

- When a Feishu link fails to extract, **tell the user the real cause** and
offer the practical path — do NOT just say "can't read it". **Check `.env`
for Feishu creds first: if present, the API read is the fastest honest
answer; otherwise export/copy is.** Don't promise "can't" until you've
checked the creds.
- Give the practical recommendation (export vs copy vs authorize browser)
  and ask which they want, rather than silently looping on extraction.
- **If the user re-sends the SAME link with no instruction, they are not
  answering your question — they want the data.** Don't ask "你想让我干什么"
  a second time. Re-read the table and go one level deeper than last time:
  report real aggregates (row counts, sums, per-dimension breakdowns, data-quality
  flags) instead of repeating the same structural summary. Asking twice in a row
  reads as stalling.
- When the user confirms a share setting like "组织外可访问" (accessible
to people outside the org), trust it — the access setting is usually NOT
the blocker for a Base; the dynamic grid is. Still open/read to confirm
before concluding.

## Pitfalls

- **Don't loop** on repeated `desktop_preview read` failures with identical
args — the pane intermittently reports "No preview tab is open, or the read
timed out". Re-open with `action='open'`, then read once. If it still fails,
switch strategy (export path), don't fight the pane.
- **Don't conclude "not found / blocked"** from web_extract alone on a
Feishu URL — feed the URL to desktop_preview open and actually render it.

See `references/reading-fei-shu-wiki-base.md` for the concrete reproduce
steps and the exact error strings hit during this territory's discovery.

For this user's **recurring Bases** (which link maps to which table, the field
schema to expect, and the standard "今天数据怎么样" recipe — 运营数据登记 is the
frequent one) see `references/shiyi-recurring-bases.md`; the re-runnable fetcher
is `scripts/fetch_bitable_latest.py` (search + sort desc + UTC+8 day grouping).
