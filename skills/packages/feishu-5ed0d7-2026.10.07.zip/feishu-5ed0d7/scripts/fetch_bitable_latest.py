# -*- coding: utf-8 -*-
"""Fetch the NEWEST rows of a Feishu 多维表格 (bitable) and group them by day, China time.

Why this exists:
  * the LIST endpoint REJECTS `sort` -> `code 1254016 InvalidSort` with items:[]
  * pulling a whole 5-9k-row table (~60 pages) blows the 120s timeout
  * records/search with sort-in-body returns the newest rows in ONE request

Usage:
  python fetch_bitable_latest.py <app_token> <table_id> [date_field] [days]
  python fetch_bitable_latest.py Q6PZbQRH3aZum0skE3Pc8WCVnPh tbl9bX2VE4PXRRiM 日期 3

Credentials: FEISHU_APP_ID / FEISHU_APP_SECRET from the environment, else from a
.env on the usual Hermes paths.
"""
import json
import os
import sys
import datetime
import urllib.request
from collections import Counter
from datetime import timezone, timedelta

CN = timezone(timedelta(hours=8))


def load_env():
    aid = os.environ.get("FEISHU_APP_ID")
    sec = os.environ.get("FEISHU_APP_SECRET")
    if aid and sec:
        return aid, sec
    for p in (r"E:\RuanJian\Hermes\.env", r"E:\软件\Hermes\.env",
              os.path.expanduser("~/.hermes/.env")):
        if not os.path.exists(p):
            continue
        for line in open(p, encoding="utf-8", errors="replace"):
            if line.startswith("FEISHU_APP_ID="):
                aid = line.split("=", 1)[1].strip().strip('"')
            if line.startswith("FEISHU_APP_SECRET="):
                sec = line.split("=", 1)[1].strip().strip('"')
        if aid and sec:
            break
    if not (aid and sec):
        sys.exit("missing FEISHU_APP_ID / FEISHU_APP_SECRET")
    return aid, sec


def post(path, body, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request("https://open.feishu.cn/open-apis" + path,
                                 data=json.dumps(body).encode(), headers=headers)
    return json.loads(urllib.request.urlopen(req, timeout=25).read().decode())


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    app, tbl = sys.argv[1], sys.argv[2]
    date_field = sys.argv[3] if len(sys.argv) > 3 else "日期"
    days = int(sys.argv[4]) if len(sys.argv) > 4 else 3

    aid, sec = load_env()
    tok = post("/auth/v3/tenant_access_token/internal",
               {"app_id": aid, "app_secret": sec})["tenant_access_token"]

    body = {"sort": [{"field_name": date_field, "desc": True}], "page_size": 500}
    resp = post("/bitable/v1/apps/%s/tables/%s/records/search" % (app, tbl), body, token=tok)
    if resp.get("code") != 0:
        sys.exit("search failed: %s %s" % (resp.get("code"), resp.get("msg")))
    items = resp.get("data", {}).get("items", [])

    def day(fields):
        ts = fields.get(date_field)
        if not isinstance(ts, (int, float)):
            return None
        # UTC+8 — utcfromtimestamp would shift every row one day earlier
        return datetime.datetime.fromtimestamp(ts / 1000, tz=CN).strftime("%Y-%m-%d")

    counts = Counter(d for d in (day(i.get("fields", {})) for i in items) if d)
    print("rows fetched:", len(items))
    for d in sorted(counts, reverse=True)[:days]:
        print("  %s : %s rows" % (d, counts[d]))

    if not counts:
        return
    latest = sorted(counts, reverse=True)[0]
    rows = [i.get("fields", {}) for i in items if day(i.get("fields", {})) == latest]
    print("\n=== %s (%d rows) ===" % (latest, len(rows)))
    total = 0.0
    for fs in rows:
        name = (fs.get("店铺名称（拼多多旗舰店）") or fs.get("店铺名称（拼多多个人店）") or "?")
        try:
            perf = float(str(fs.get("当日总业绩", 0)).replace(",", ""))
        except (TypeError, ValueError):
            perf = 0.0
        total += perf
        print("  %-26s %-6s %12s" % (name[:26], fs.get("负责人", ""), fs.get("当日总业绩", "")))
    print("  TOTAL 当日总业绩: %,.2f".replace("%,", "{:,}").format(total) if False else
          "  TOTAL 当日总业绩: {:,}".format(round(total, 2)))


if __name__ == "__main__":
    main()
