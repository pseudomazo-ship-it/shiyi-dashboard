---
name: pinduoduo-merchant-automation
description: Automate Pinduoduo merchant backend appeals via CDP. Production path is the workbench's embedded browser (app remote-debugging-port 9334), NOT a separate Chrome 9333.
---

# Pinduoduo 商家后台自动化（内嵌浏览器 CDP）

> ⚠️ **生产路径 2026-08-30 已切换**：现在自动化在**工作台内嵌浏览器**里就地操作（应用级 `--remote-debugging-port=9334` 暴露无边框 `browserWin`），**不再用独立 Chrome 9333**。用户明确要求"在软件内网页自动操作、不另弹浏览器"。完整架构与单标签陷阱见 `references/embedded-browser-automation.md`；下方"环境与启动"里的 Chrome 9333 命令是**旧路径（仅离线诊断/对照用，别再当生产入口）**。

对拼多多商家后台做自动化时，**生产路径 = 工作台右侧内嵌浏览器**（`src/main.js` 里 `frame:false, skipTaskbar:true, parent:mainWindow` 的 `browserWin`，定位到工作台右侧像内嵌），**不是**工作台的录制/回放（旧链路/开发校准用），**也不是**独立 Chrome。GUI 电子工作台是壳，驱动内嵌浏览器提交申诉/复议的是 `data/cdp-run-full.js` / `data/cdp-run-review.js`（它们连 9334 端口，走 `data/cdp-driver.js`）。

## 内嵌浏览器自动化（新生产路径）核心要点

- **暴露内嵌浏览器为 CDP 目标**：`src/main.js` 在 `app.whenReady` 前加 `app.commandLine.appendSwitch('remote-debugging-port', '9334');`。于是 `browserWin`（内嵌浏览器）的 webContents 成为 `http://127.0.0.1:9334/json` 下的 page 目标；自动化脚本改连 9334（`data/cdp-driver.js` 与脚本里的 `CDP_PORT=9334`），**不再连独立 Chrome 9333**。
- **单标签 / 就地导航（最大坑）**：内嵌浏览器是**单一 webContents**。它的 `setWindowOpenHandler` 把"新窗口"改成 `webContents.loadURL(u)` **就地加载**——所以申诉/复议的"新标签"（如 `negativeExperience?orderSn=`、复议 `negativeExperienceReconsider`）都会被就地导航，**不会新开标签**；表单是页内模态框/就地路由。因此：
  - `closeTabsByUrl(...)` **必须 no-op**（`Target.closeTarget` 会关掉这唯一窗口 → 窗口消失/`ECONNREFUSED`）。就地导航根本没"旧标签"要关。
  - **不要 `waitTab('negativeExperience')`/等新标签**——就地导航永远等不到；导航后在同一目标上重连/继续操作。
- **确保 browserWin 已打开再跑**：`appeal:run-cdp`/`review:run-cdp` 处理器开头 `if (!browserWin || browserWin.isDestroyed()) openBrowserWindow('https://mms.pinduoduo.com/')`，否则 9334 上无 mms 目标，`connectTo` 会回退到工作台页面乱执行。
- **checkReady 校验改为"内嵌浏览器在线且已登录"**（读 9334 的 `mms.pinduoduo.com` 页面判登录态，不读 9333）；日志/文案用"内嵌浏览器(9334)"。
- **导航/提交类按钮一律用 JS `el.click()`（内嵌 SPA 里坐标点击对它们无效）**：申诉的 `查看详情`/`我要申诉`/`提交`/`确认并提交`（`cdp-run-full.js`）与复议的 `发起复议`/`提交复议`/`确认并提交`（`cdp-run-review.js`）都**不能用** `clickByText`/`clickByExpr`（`Input.dispatchMouseEvent` 坐标点击），**必须 `client.eval(...el.click()...)`**；抽一个 `jsClickByText(client,text)` 工具函数（`document.querySelectorAll('a,button,span,div')` 过滤 exact 文本 + `offsetWidth>0`，`el.click()`）。实测：`查看详情` 用坐标点击**不跳转**（URL 停在列表页 `?from=list`、找不到「我要申诉」→ 3 笔全跳过），`el.click()` 能跳到 `detail?ticketSn=...`。判点击成功不要用 `res.ok`（`clickByText` 返回 `{ok}`），`jsClickByText` 返回布尔。完整可运行配方（jsClickByText 代码 + 提交后验证兜底 + 验证检测健壮版）见 `references/embedded-browser-js-click.md`。
- **内嵌浏览器 vs 独立 Chrome 是两个登录会话**：内嵌用 `persist:appeal_tool_01` 分区，独立 Chrome 用 `chrome-profile2`。切到内嵌路径前确认内嵌浏览器已**在正确店铺**登录（`curl -s http://127.0.0.1:9334/json` 找 `mms.pinduoduo.com` 页面读 body：含"后台首页/常用功能"=已登录，含"扫码登录/账号登录"=未登录）。

## 环境与启动

```bash
# 起专用 Chrome（9333，登录态存 chrome-profile2）
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9333 \
  --user-data-dir="<工具目录>\chrome-profile2" \
  --no-first-run --no-default-browser-check \
  "https://mms.pinduoduo.com/"
```

- 登录态持久化在 chrome-profile2，启动后检查是否已登录：`curl -s http://127.0.0.1:9333/json/version` 返回说明端口就绪；再连页面读 body，含“后台首页/常用功能”=已登录，含“扫码登录/账号登录”=未登录。
- 重要：**9333 的专用 Chrome ≠ 工作台 Electron 内嵌浏览器**（后者用 persist 分区，独立登录态）。处理前以专用 Chrome 显示的店铺为准；账号信息里可看到“蒙倩旗舰店/十一蒙倩旗舰店”。
- Node：系统 PATH 可用 `node`（本机 v22）；找不到时用 `C:\Users\Administrator\.workbuddy\binaries\node\versions\<ver>\node.exe`。
- 本机有 `ELECTRON_RUN_AS_NODE=1` 环境变量会破坏 electron，工作台启动脚本会自动清除（改 electron 时别忽略）。

## 申诉自动化流程（消费者负向体验补偿）⚠️ 以本节的「模态框」为准

> ⚠️ **模型矛盾信号（待复核）**：某次调试曾观察到「我要申诉」跳到**新标签 `/orders/appeals/negativeExperience`**，含「提交申请」按钮 + placeholder「请选择申诉原因」**下拉输入框** + “申诉提交后将无法修改”红线——与此处“模态框 + 5卡片 + 无下拉”的已验收模型**冲突**。那次调试**中途中断、未端到端提交、DOM 读取自相矛盾**，故**不能当作定论覆盖已验收模型**。处理：再度失败先按下方模态框模型排查；若确观察到新标签，用 `dry-run` 摸清真实表单再固化，别凭一次未完成调试推翻旧模型。
>
> **补充证据（2026-08-30 后续诊断）**：另一次诊断**确认了 `negativeExperience` 确实是实体 tab**——CDP `/json` 标签列表里能看到 `mms.pinduoduo.com/orders/appeals/negativeExperience?orderSn=...&ticketSn=...`（通常 4-5 个），且表单页含**申诉金额(3.00元) + *申诉原因 下拉(placeholder"请选择申诉原因") + 提交申请**，**无 textarea/file input 于裸表单**。这与“新标签+下拉+提交申请”模型一致，而**与“详情页内模态框+5卡片”模型矛盾**。但该次诊断也在读表单结构途中卡住，**尚未端到端 dry-run/提交验证**。⚠️ **两个模型都可能正确——取决于拼多多当前版本/入口**：`cdp-run-full.js` 现有代码同时处理了两种（`closeTabsByUrl('negativeExperience')` + 详情页 `modalOpen` 检测）。**改造脚本时务必先 `--dry` 用“当前实际 tab 结构”确认走哪条，再改选择器**，不要只依赖 SKILL.md 的文字结论。

完整链路（2026-08-30 实测，已修正此前错误的"新标签"说）：

```
明细列表页 customer_complain_appeal?from=list
  → 点「查看可申诉订单」（不是「查询」）
  → 点列表第一条「查看详情」  (新tab: /aftersales/.../detail?ticketSn=MP...)
  → 详情页点「我要申诉」
  → 弹出「发起申诉」模态框（就在详情页内，不是新标签）
  → 选申诉原因(卡片) → 填话术 → 传凭证
  → 点「提交」→ 点「确认并提交」二次确认 → 完成
  → 回明细页，循环下一笔
```

关键实测结论（详见 `references/appeal-automation.md`）：
- **表单是详情页内的「发起申诉」模态框**（lightbox），**不是**新开的 `negativeExperience` 标签。点「我要申诉」后**不要 waitTab('negativeExperience')**——永远等不到。应检测详情页出现"发起申诉"+"提交"按钮，然后**在同一个 detail tab 的 DOM**（`detail.client`）里操作。
- **提交按钮是「提交」**，且点「提交」后会弹「**确认并提交**」二次确认——**必须补点**，否则申诉停在待确认态，日志里的"已受理"是误判。
- 申诉原因是 **5 个可点卡片**（商品有问题但已与消费者达成一致 / 商品有问题已补偿消费者 / 消费者未表达商品问题 / 商品无问题消费者误解 / 其他）；用 `clickByText(cfg.reason)` 选中，**不是**下拉框。
- 话术 textarea + file input 在**选中原因后**才出现在模态框里；此前抓不到是正常的。
- 成功判定：点「提交」+「确认并提交」后页面跳走/弹提示（尾部常是"斌便以…诈骗警示"通知页），才是真办结；若只按"受理/处理中"匹配会误判（确认框文案也含这些字）。

## 复议（reconsideration）自动化 ⚠️ 与申诉不同

复议是对"已被判负"的申诉再审，入口/表单/注意点都与申诉不同，完整见 `references/review-automation.md`。核心几条：

- **入口**：订单申诉页(orders/appeals) → 点「去复议」→ 打开 `/orders/appeals/negativeExperienceReconsider` → 「以下申诉可发起复议」列表 → 点「发起复议」→ 同页模态框。**不能直连 URL**（SPA 需初始化，直连后点「发起复议」不弹窗）；不要 `closeTabsByUrl('negativeExperienceReconsider')` 再直连，**复用已加载的复议 tab** 或经「去复议」进入。
- **表单**：复议原因下拉(placeholder「请选择」，含「其他」) + 复议描述(textarea) + 复议凭证(图1/3+视频0/1) + `提交复议`；描述/凭证区在选中原因后才出现。
- **⚠️「发起复议」必须用 JS `el.click()`，坐标点击（`clickByText`/`Input.dispatchMouseEvent`）无效**——这是复议页与申诉页最大区别（点了返回 ok 但没有弹窗、无 iframe、body 不变）。「其他」下拉选项要**按同下拉列表去重**（选与已知选项「商品无问题」同容器的那个），否则会点到页面其他「其他」、表单不展开。完整可运行的配方见 `references/review-automation.md`。
- **⚠️ 头号坑：复议凭证必须与首次申诉不同**。平台校验「请补充与首次申诉不同的有效凭证，无效凭证会导致复议失败」。复用申诉的同一张凭证会被拦截（表单不关、订单仍在可复议列表），**无线上副作用、可安全重试**。→ 复议必须配独立的、不同于申诉的凭证（即复议要拆独立配置/独立 evidence 目录，不能与申诉共用）。
- **成功判定会误判**：body 正则 match「已提交/已受理」不可信。真判断 = 表单已关 + 该订单从「可复议」消失（进入「复议记录」），切「复议记录」tab 核对。
- 复议同样「提交后不可修改、不可撤回」→ dry-run 兜底 + 用户确认后才真跑。

## 安全与纪律（硬性）

- **真实提交不可撤回**。跑之前必须让用户明确确认（本用户的口诀：`需要你确认后我再执行`）；不要静默提交。
- **先 dry-run 再真跑**：`node data/cdp-run-full.js 1 --dry`（或 `DRY_RUN=1`）+ 在提交前加 `--dry` 短路（只填不点提交）。dry-run 验证选择器/填充，再拿确认跑真的。
- **绝不破解拼多多反机器人验证**（验证码/滑块）。不可靠，且会触发店铺风控、伤账号申诉权重。用户对这一条立场明确。正确做法：检测关键词（`验证码|滑块|安全验证|拖动下方滑块|人机验证|安全校验|风险确认|完成验证`）→ 命中就**暂停并标记**（`detectVerification`），交由用户人工过，别硬闯；同时用**随机人类节奏**（`jitter(ms, spread)` 随机延时）降低触发频率。
- 只操作已登录的正确店铺；提交前核对账号。
- **启动前置体检**：`cdp-run-full.js` 已在主循环前内置 `checkReady()`——校验「内嵌浏览器(9334)在线 + 已登录 + 凭证已配」（不读 9333），任一不满足即列出问题并 `exit(1)`（避免空转/误提交）。改脚本时别删掉这步；手动跑批前也应先肉眼确认同三项。
- **工作台 GUI 的「申诉原因」下拉要与弹窗 5 个卡片选项保持一致**（renderer/index.html），别再用旧的"非签收未收/签收未收"那套（那是另一种申诉场景的选项，会点不中）。

## 排查技巧

- 自定义下拉/浮层下，**AX 树（Accessibility.getFullAXTree）比 DOM 抓取稳**；`Page.captureScreenshot` 在慢页面会吊死，尽量用 AX 树取文本。
- 有通知浮层会挡住表单：先按 Escape 关掉再交互（但通知面板不一定吃 Escape，见下）。
- **`connectTo(pattern)` 有回退陷阱**：找不到匹配标签时会**静默回退到任意 mms 页面（常是首页）**。若首页恰好有同名元素（如「查看详情」），脚本会在首页乱点，进到无关页（曾误入 `aftersales-ssr/detail`）。**连上后必须校验实际 URL**：不含目标 pattern 就 `Page.navigate` 到目标 URL 再操作。
- **CDP 专用 Chrome 大量探测会堆积标签**，连到的常是旧/杂标签导致行为异常；周期性用 `Target.closeTarget` 清掉多余 page 标签。**注意：关光所有标签会让 Chrome 退出（ECONNREFUSED）**——用 `--user-data-dir=chrome-profile2` 重启（登录态仍在）。
- 内联 `node -e "..."` 里带反引号/`${}` 会被 shell 转义破坏——**写成 `.js` 文件再跑**（如 `data/diag-*.js`）。

## 目录速览（订单申诉复议自动处理工具）

- `data/cdp-run-full.js`：生产申诉主脚本（`node data/cdp-run-full.js <N>`；`--dry` 为 dry-run）。
- `data/cdp-driver.js`：CDP 封装（`connectTo/connect/getPage/CDPClient/runAppeal/sleep`；CDPClient 有 `eval/clickByText/clickByExpr/waitText/typeInto/uploadFiles`）。
- `data/appeal-config/config.json`：申诉原因 + 话术；`data/appeal-config/evidence/`：凭证图(1-3张)。
- `chrome-profile2/`：专用 Chrome 登录态（含拼多多 Cookie）——**整包不可外发**。
- `renderer/`：Electron 工作台 UI；`src/main.js`：主进程（含 fitBrowserZoom 宽度自适应缩放，见下）。
- **授权/打包/.bat 编码**（2026-08-30 新增）：`gen-license.js`（机器码→授权码，管理员保留勿分发）、`生成授权码.bat`、`打包给使用者版.bat`、`data/license.dat`(机器码|授权码)、**启动器 `【蒙倩】--订单申诉复议工作台.bat`（⚠️ 真名不是 `启动工作台.bat`，那名字不存在）**。完整机制（getMachineCode/makeAuthCode/isLicensed/授权窗口、打包剔除清单、中文 .bat 需 GBK 编码+chcp 936）见 `references/license-and-packaging.md`。

## 两套运行引擎（改「暂停」前必读）

这个工作台有**两套互相独立的运行引擎**，它们的暂停能力完全不同——改 UI/按钮前先确认走哪条：

- **① 回放引擎**（`src/player.js`，入口 `play:start`）：状态机**完整支持暂停**（`this.state='paused'`，`async pause()`/`resume()`，验证码/找不到元素会自动置 `paused` 等人工），`preload` 已暴露 `playPause`/`playResume`，`main.js` 有 `ipcMain.handle('play:pause'/'play:resume')`。**启动准备**区走这条。
- **② CDP 自动化**（`data/cdp-run-full.js`，入口 `appeal:run-cdp`）：**是一条外部 CDP 子进程**（`spawn(process.execPath,[scriptPath,maxRounds])`），主进程只 `start`/`kill`——**没有 pause/resume**。它是真正的生产申诉入口。

**陷阱**：`renderer/app.js` 的状态位识别 `paused`（badge/disabled 逻辑都有），但这些是给回放引擎用的。**给「订单申诉」页（CDP 路径）加「暂停」按钮≠直接调用 `playPause`**——那不会暂停 CDP 子进程。要在 CDP 路径上做真·暂停，必须改 `cdp-run-full.js`：在每步迭代间检查一个暂停信号（标志文件或 IPC），命中就 `await waitUntil(resumed)`。如果只是想先落地，可把「暂停」接到 `appeal:stop-cdp`（kill）作为等效停止，但要向用户说明它不可续跑。**先问用户要“可继续的暂停”还是“等效停止”，别默认。**

**已实现的真·暂停（信号文件模式）**：本轮已按“可继续的暂停”方案落地——主进程用 `data/pause.flag` 标志文件（`appeal:pause-cdp` 写 / `appeal:resume-cdp` 删），子进程 `cdp-run-full.js` 在**每笔之间** `await waitIfPaused()` 轮询该文件（存在→暂停等待，被删→继续），并在 `appeal:stop-cdp` 里清 flag 防止残留。完整代码/文件清单/坑见 `references/cdp-pause-signal-file.md`。**暂停点在“每笔之间”而非笔中**，避免在不可逆的「提交」中途卡住——这是安全默认；如需笔中暂停需在 `processOneOrder` 内加更细检查。

## GUI 布局约定（2026-08-30 精简后，改界面别推翻）

- 侧边栏**只保留两页**：`订单申诉` + `复议处理`。已删掉：首页、运行记录、设置、店铺管理（含 app.js 里 store 模块；**删功能时必须连 `init()` 里的调用一起删**——曾因留着 `await initStore()` 而函数已删，导致初始化 ReferenceError）。main.js/preload 对应 handler 留着无害，app.js 已不调用。改界面时别加回去。
- **页顶运行条**（`app-run-bar`，订单申诉页与复议处理页**各有一套**）：`🏪 打开商家后台` + `▶ 开始处理[申诉/复议]`(蓝) + `⏸ 暂停`(橙) + `■ 停止`(红)。按钮 id：申诉= `appealOpenBackend`/`appealStartTop`/`appealPauseTop`/`appealStopTop`；复议= `reviewOpenBackend`/`reviewStartTop`/`reviewPauseTop`/`reviewStopTop`。`renderer/app.js` 的 `setStatus`（申诉）/`setReviewStatus`（复议）按 `canRun/canPause/canResume/canStop` 控制 disabled+文字（暂停态开始按钮变「▶ 继续」）。配置卡里**不要**再放旧的 `appealStart`/`appealStop`（会与顶部重复）。
- `打开商家后台` → `openBackend()`：`api.showBrowser()` 后 `api.navigate('https://mms.pinduoduo.com/home/')`，展示辅助浏览器并跳到后台（可看订单申诉/复议处理入口）。
- **「启动准备」卡片已整体删除**（两页都删）。删除时连带删掉 app.js 对以下 id 的**未加守卫**引用，否则空引用报错：`homeOpenBrowser`/`reviewOpenBrowser`/`homeOpenWorkbench`/`reviewOpenWorkbench`/`homeStartReview`/`homeConfigState`/`homeEvidenceState`/`reviewOpenAppeal`/`revEvidenceState2`。已改为把「打开商家后台」绑到 `appealOpenBackend`/`reviewOpenBackend`。
- 人为操作区尽量靠左上：页顶运行条 + `① 申诉配置与运行` 卡片置顶（申诉原因下拉 / 话术 textarea 可编辑 / 选择更换凭证图片 / 保存配置 / 最大笔数）。配置卡之后**只剩「② 实时处理日志」高框**（`.log-box` height 420px，两页同款）；**「能力边界」「运行规则」「高级：页面改版后重新录制…」均已删**（2026-08-30 终版）。
- **复议处理页**已配独立一套：自己的页顶运行条 + `复议配置与运行` 卡片（`reviewReason` 下拉 / `reviewContent` 话术 / `reviewPickEvidence`+`reviewEvidenceList` 凭证 / `saveReviewConfig` / `reviewMaxRounds`）+ `实时处理日志`(`reviewLog`) + 高级录制(`reviewRecStart/Stop`)。
- 已**删除**：`软件价值`(363次/1118元)卡片、`提交不可撤回`红条、旧的重复「开始/停止」按钮、`店铺管理`页+JS模块、`启动准备`卡。
- **两页的「浏览器环境/配置状态/本轮进度」三张 metric 卡已删**（2026-08-30 末，用户嫌冗余）。`renderer/index.html` 里 `.metric-grid` 已从两页移除；但 `/renderer/app.js` 仍写着 `$('statRecording')`/`$('statRounds')`/`$('revStatRounds')`——**删 metric 元素时必须把这些引用改成 `if ($('id'))` 守卫**，否则空引用报错（本轮已改）。
- **新增「店铺选择」面板（两页都有，位于「打开商家后台」上方；这是下拉式切换店铺，与已删的「店铺管理」页无关，别把两者混同）**：UI = **下拉框选店铺 + `🔑 登录所选店铺` + `📥 导入表格` + `📤 导出模板`**（`#appealStoreSelect`/`#reviewStoreSelect`、`#appealStoreLogin`/`#reviewStoreLogin`、`#appealStoreImport`/`#reviewStoreImport`、`#appealStoreExport`/`#reviewStoreExport`）。**用户明确不要账号/密码表格显示**——账号密码**仅用于登录、不显示**。⚠️ **这套店铺功能主进程早已实现，别另起炉灶用 localStorage 重写**：`src/main.js` 一直有 `loadStores/saveStores/parseCsv/loginStore` + `store:list/save/import-csv/export-template/pick-csv/login/logout` IPC（此前某轮加过、当时被误当\"冗余\"跳过）。正确做法：renderer（app.js）用 `api.storeList/storeSave/storeLogin/storePickCsv/storeImportCsv/storeExportTemplate`（preload 暴露），只渲染下拉框并调这些 IPC；`store:login` 直接复用主进程 `loginStore(account,password)`（`executeJavaScript` + React setter 填 `#usernameId`/`#passwordId`、点「账号登录」标签、点「登录」）。**坑**：①新增 `store:*` handler 前**先 grep 是否已存在**——曾因重复注册 `ipcMain.handle('store:login', ...)` 直接启动报 `Attempted to register a second handler for 'store:login'`；②下拉 `<select>` 要补 `.store-select` 深色样式（深底/浅字/边框/option 深底），否则默认白下拉在深色主题很扎眼；③登录页默认「扫码登录」tab，**必须先点「账号登录」**才出现真实输入框；④登录逻辑在 `loginStore`（主进程），**不要另写独立登录脚本**（曾写 `data/cdp-login.js` 属冗余，删）；⑤店铺数据存主进程（`loadStores/saveStores`，`data/` 下），重启不丢，两页共用一份。
- 改完界面**同步 `src/main.js` 的 `--smoke-test` 通过条件**（现在用 `#appealStartTop` 判 `opPanel`，`pages>=2`）；`renderer/index.html` 的「申诉原因」下拉必须与弹窗 5 个卡片选项一致。

## 改界面/功能踩过的坑（记牢）

- **“上传图片不可用”的典型根因**：选完图只更新了 info/state 文字、没把图片列表渲染出来。`refreshXxxEvidence()` 更新文字后**还必须 `renderXxxEvidence(list)`** 渲染列表（含 `.evidence-item` + ✕ 移除按钮）。申诉/复议各自要有对应的 render 函数。
- **复用同一 config 的冲突（已解决，2026-08-30 已拆分）**：曾因复议复用申诉配置存储（`appealConfigLoad/Save`/`appealConfigPickEvidence`）导致两页共用同一份 config.json + evidence 文件夹、互相覆盖。**已拆分**——复议独立一套：`data/review-config/`（自己的 config.json + evidence/），`src/main.js` 新增 `review-config:load/save/pick-evidence/remove-evidence` handlers，`src/preload.js` 暴露 `reviewConfigLoad/Save/PickEvidence/RemoveEvidence`，`renderer/app.js` 复议页改用 `reviewConfig*`，`data/cdp-run-review.js` 的 `CONFIG_DIR/EVIDENCE_DIR` 指向 `review-config/`。**坑**：老工作台窗口仍跑旧代码（`appealConfig*`），重启工作台才加载拆分；拆分前在复议页改话术再点保存会误写进申诉的 `appeal-config/config.json`（这就是"两页话术互相覆盖"的来源）。另外 `review-config/` 是全新空目录，首跑前需在复议页保存话术 + 挑一张**不同于申诉**的凭证图（平台强制），否则 `checkReady` 会报"未配置凭证"且真提交被"与首次申诉相同"拦截。
- **并发/多智能体改同一批文件**：若 patch 提示“modified by sibling subagent / 本文件被其他进程改过”，改前重读、改后 grep 确认无对已删元素的引用。未加 `if ($('id'))` 守卫的 `$('id').addEventListener` 在元素被删后会空引用报错——删 UI 元素时把对应 JS 引用一起清理或加守卫。
- **"点了开始但无法运行"的常见假象：确认弹窗拦截**。若「开始处理申诉」是经一个"确认开始"模态框，且**「确认并开始」默认 disabled**、要先勾选"我已确认…"复选框才启用——用户会卡在"点了没反应/无法运行"。修复：**让开始按钮直接启动**（与复议一致：校验配置→保存→`appealRunCdp`），绕开确认弹窗。本次"申诉不能跑、复议能跑"的根因正是申诉多了这个确认弹窗而复议没有；另注意确认弹窗/旧文案里的"专用 Chrome"要一并改成"内嵌浏览器"。

## 验证需人工介入 → 亮黄提醒 + 自动续跑（本轮加的体验）

- 脚本 `data/cdp-run-full.js` 用 `waitHumanVerification(client, log, 300000)`：检测到验证关键词 → 打印 `【需人工介入】⚠️ 检测到验证/安全校验…` 标记 → 每 3s 轮询直到验证消失 → `✅ 人工已处理验证，继续运行`；**5 分钟超时 → 跳过本轮**（不卡死）。替换了旧的"一检测到就跳本轮"。
- GUI（`renderer/app.js`）在 `api.onLog` 里 `\需人工介入/.test(msg)` → `showHumanAlert()`。**⚠️ 用户明确要求（2026-08-30 末）：只需任务栏亮黄，不要在工作台内弹任何横幅/对话框**——`showHumanAlert()` 已改为**空操作**（不再显示 `#humanAlert`），工作台内无弹窗。用户过完验证 → 脚本检测到验证消失 → **自动接着跑**。若以后要加回界面提示，必须先确认用户接受"工作台内有弹窗"。
- **既没改成破解验证**——仍是"检测+等人工"，只是把"停下来喊人"升级成"亮黄提醒 + 等人工 + 自动续跑"。这是安全合规且体验更顺的默认。

### ⚠️ 验证检测必须健壮（否则"反复无效执行、不等5分钟"）——2026-08-30 修复

**根因**：早期 `detectVerificationOnly` 只读 `document.body.innerText`。**拼多多滑块/验证码常在 iframe（极验/同盾）或特殊遮罩里，父页 body.innerText 抓不到 → 判定"没验证" → `waitHumanVerification` 立刻 `return true` → 脚本不等待、继续点 → 反复无效执行**（用户实测："没等5分钟、直接继续反复无效执行"）。

**修复（申诉/复议脚本 `detectVerificationOnly` 同改）**：命中任一即判"出现验证"——①`body.innerText`+`documentElement.innerText` 合并匹配关键词；②**验证相关 iframe**（`iframe.src/name/title` 含 `captcha|verify|geetest|yidun|slider|pccaptcha|tou|验证`）；③**验证遮罩元素**（`div/span` 的 `className/id` 含 `geetest|yidun|captcha|slider|安全验证|验证码|tou-pin|移动滑块` 且 `offsetWidth/Height>0`）。关键词集含：`验证码|安全验证|拖动滑块|请完成验证|人机验证|安全校验|风险确认|滑块|图形验证|请输入验证码|完成验证|拖动滑块完成拼图|请点击|点击刷新|向右拖动|验证失败`。

**关键点：`waitHumanVerification` 必须在更多位置调用**——不只弹窗后/提交前，还要在**连上详情页后（waitText 之前）、进入复议页后（点「发起复议」之前）**各调一次，验证一出现就真正卡住等待，而不是跳过/反复重试。

**⚠️ 提交动作本身会弹验证（极易漏）**：点「提交」/「提交复议」**之后**很可能弹出「拼多多安全验证 · 拖动圆形滑块完成旋转拼图」（因提交频率/该会话被风控）。**必须在点提交后、二次确认前**再调用一次 `detectVerificationOnly` + `waitHumanVerification`——只检查提交前会漏，导致脚本判"未见成功提示"进下一轮、又点又撞验证（这正是用户报告的"反复无效执行、不等5分钟"的另一种根因，与检测不健壮并列）。流程：`点提交 → 若 detectVerificationOnly 命中 → 亮黄+waitHumanVerification(≤5分钟) → 人工滑完 → 再补点「确认并提交」→ 结果判断`。

**⚠️ 验证检查还必须前置到「成功判定」处（2026-08-30 末次修复）**：验证可能在点「确认并提交」**之后**才弹出，此时页面 body **同时含着「已受理」和「拼多多安全验证/滑块」**——若只按成功正则匹配，`已受理` 命中而滑块仍在 → 误判成功直接进下一轮、又点又撞验证（用户再度反馈"没等5分钟"）。**正确：结果判断前先 `detectVerificationOnly`**，命中则 `waitHumanVerification` 再重查一次；仍命中（超时未处理）→ 跳过本轮；确认页面**无「安全验证/滑块」**后才判成功。申诉/复议的 `第7步 结果判断` 都按此改。

**任务栏亮黄（唯一提醒，2026-08-30 末）**：主进程两处 `push(line,level)`（`cdpProc`/`reviewProc` 的 stdout 转发）里检测 `String(line).includes('【需人工介入】')` → `mainWindow.flashFrame(true)`（Windows 任务栏闪烁）。**要点：仅 `flashFrame(true)` 一次常因窗口在前台被 Windows 立即停掉**——必须补几次 `false→true` 连锁再闪（如 `[1400, 3200].forEach(t => setTimeout(() => { flashFrame(false); flashFrame(true); }, t))`），才能确保稳定亮黄。这是当前**唯一**的人工提醒手段（工作台内已不弹横幅）。

**⚠️ 亮黄必须会\"自动熄灭\"（否则任务栏一直闪，2026-08-31 修复）**：`flashFrame(true)` 把闪烁开着后，**原来没有任何地方调 `flashFrame(false)` 去关它**——人工处理完验证、或 5 分钟超时跳过、或进入下一笔继续循环时，任务栏会**一直闪下去**。用户明确要求\"人工处理/等满5分钟进入循环时就取消亮黄\"。修复（申诉 `cdpProc` + 复议 `reviewProc` 两个 `push` 都改）：加模块级标志 `let taskbarFlash = false;`——①遇 `【需人工介入】`→ `taskbarFlash=true` + `flashFrame(true)` + 补闪；②补闪回调（`[1400,3200].forEach` 里的 `setTimeout`）**先 `if (!taskbarFlash) return;`**（防止取消后补闪又点亮）；③出现以下任一 → `taskbarFlash=false` + `flashFrame(false)`：`人工已处理验证`（用户处理完）、`本轮因验证未处理` / `本轮跳过`（5分钟超时）、`========== 自动化结束`（跑完）、**进入下一笔的轮次标记**。⚠️ 轮次标记**申诉= `===== 第 X/N 笔 =====`、复议= `===== 第 X/N 笔复议 =====`**（带\"复议\"后缀），所以取消正则要用 `/===== 第 \\d+\\/\\d+ 笔/`（**不要**用带结尾 `=====` 的完整匹配，否则匹配不上复议格式）。

## 多店铺登录/切换（SPA 账号密码表单自动填写）

登录页是 SPA（静态 HTML `input`=0），默认「扫码登录」；点「账号登录」标签后出现真实 `请输入账号名/手机号` + `请输入密码` 输入框，可用 `executeJavaScript` + **React 原生 setter**（`Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set` + 派发 `input`/`change`）自动填。**单 partition 约束：同时只有 1 店在线**，切店=用新账号覆盖 cookie 重登。导入导出 CSV 用简易解析（BOM strip/引号/CRLF）。完整实现与坑见 `references/multi-store-login.md`。

**⚠️ CSV 导入"读不到内容/下拉没店铺"的真根因 = 编码，不是解析——2026-08-31**：中文 Excel「另存为 CSV」默认是 **GBK/ANSI** 编码。若 `fs.readFileSync(p,'utf8')` 读 → 中文全变乱码 → `store:import-csv` 的**表头匹配**（需要 `店铺名称/账号/密码`）失败 → 返回"表头需包含…"→ `store:save` 从未被调用 → **`data/stores/stores.json` 根本没生成** → 下拉一直是"— 选择店铺，自动登录 —"空。**修复（在 `store:pick-csv` 读文件处）**：读 Buffer，同时用 `buf.toString('utf8')` 和 `new TextDecoder('gbk').decode(buf)`（Node 内置，免装 iconv-lite）解码，**哪套更像中文表头就用哪套**：`hk = (s)=> /店铺|账号|密码|帐号|用户名/i.test(s)`；`if (hk(gbk) && !hk(utf8)) text=gbk; else if (cjk(gbk) > cjk(utf8)*1.5) text=gbk;`（`cjk`=中文正则计数）。表头列名要含 `店铺名称`、`账号`、`密码`；用「导出模板」导出的标准 CSV 最稳。诊断：`cat data/stores/stores.json` 不存在 = 导入链路在 save 前就断了。

**⚠️ 清空话术/凭证/店铺数据，光清 config.json + evidence 目录不够——index.html 里写死的默认话术会顶替显示（2026-08-31 用户反馈"软件内还是有自带申诉话术"）**。`renderer/index.html` 把申诉/复议话术**硬编码成 textarea 的默认文本**（`<textarea id="appealContent" rows="7">…质检团队…</textarea>`、`<textarea id="reviewContent" rows="6">…复核…</textarea>`）。而 `refreshEvidence()`/`refreshReviewEvidence()`（app.js）只在**配置非空**时才覆盖 textarea（`if (res.cfg && res.cfg.content && !$('appealContent').value.trim()) $('appealContent').value = res.cfg.content;`）——所以 config.content 一清成空，反而**露出 HTML 写死的话术**。**修复**：清空时必须把 index.html 里这两个 textarea 的默认文本也改成空（`<textarea id="appealContent" rows="7"></textarea>`），否则怎么清 config 都还在。凭证图**没有**写死（`renderEvidence` 从 evidence 目录读，目录空即显示"未配置"/0 张）；店铺清空=`data/stores/stores.json` 写成 `[]`。

**要点**：判断 UI 是否被"清空"，别只看配置文件/目录，还要**grep index.html 里有没有写死的默认值顶着**；且要看渲染层是"按配置覆盖"还是"仅在非空时覆盖"——后者在清空后会漏出默认值。清完重启工作台 + 读运行中 DOM 复核（`appealContent.value`/`evidenceList .evidence-item` 数量）。

**⚠️ loginStore 慢加载必须轮询等输入框，别固定等——2026-08-31**：本机拼多多页面加载**很慢（30~60s）**，`loginStore` 原来只 `await 15000` 就填 → 页面没加载完 → `#usernameId`/`#passwordId` 还没出现 → **填不进账号密码**（用户能看到登录页但输入框空）。**修复**：把固定等待改成**轮询**——用 `waitFor(js, timeoutMs=60000, interval=1000)` 反复 `executeJavaScript` 直到返回真：先等到「账号登录」标签可点并点击，再等到 `#usernameId`（或 placeholder 匹配）出现才填，再等 `#passwordId` 出现填密码，最后点「登录」。选择器用 `#usernameId`/`#passwordId` 优先、placeholder（`/请输入账号|账号名|手机号|账号/`）兜底；用原生 setter + `input`/`change` 事件。若账号框 60s 未出现 → 返回 `{ok:false, message:'登录页账号输入框未出现'}`（`accReady` 守卫），别继续填。

## 内嵌网页宽度自适应缩放（fitBrowserZoom）⚠️ 2026-08-30 修复"忽大忽小"

给工作台右侧“辅助浏览器窗口”自动按窗口宽度缩放网页、去掉横向滚动条。**⚠️ 不要"先重置到 100% 再缩回合适"**——`wc.setZoomFactor(1)` + 等 300ms 再缩放，会在每次加载/导航/窗口变化时造成界面**先放大再缩小地抖（忽大忽小、比例不稳定）**（用户实测反馈）。正确做法：**不重置，直接用当前缩放量内容宽**（scrollWidth 是 CSS 像素、与视觉 zoom 无关），并只在变化 >3% 时调整：
```js
const m = await wc.executeJavaScript('({sw:Math.max((document.documentElement&&document.documentElement.scrollWidth)||0,(document.body&&document.body.scrollWidth)||0)})');
const pw = win.getContentBounds().width;   // 物理内容宽(主进程取，稳定)
const cur = wc.getZoomFactor() || 1;
if (!m.sw || m.sw * cur <= pw) return;            // 该缩放下已不超宽 → 不动，避免反复调整
let target = Math.max(0.6, Math.min(0.98, pw/m.sw*0.99));
if (Math.abs(target-cur)/cur < 0.03) return;       // 变化 <3% 不动，防抖动
await wc.setZoomFactor(target);
```
要点：①不要 `setZoomFactor(1)` 先重置（会闪一下大再变小）；②用 `getContentBounds().width`（物理）÷ `scrollWidth`（CSS），不要用 `clientWidth`（随缩放重置而抖动）；③加 `m.sw*cur<=pw` 无溢出早返 + `>3%` 阈值，避免反复微调。

**⚠️ 加宽窗口（想"更接近 100%"）同样会弄坏自动化——不是改 zoom，是改 DOM——2026-08-31 实测**：用户要求"把右侧内嵌浏览器加宽让页面更接近自然比例"。把 `src/main.js` 里 `mainWindow.width` 从 1560 加到 1780（浏览器区 ≈1076→≈1296，首条内嵌页加载后实测 `clientW=2214`）后，`node data/cdp-run-full.js 1 --dry` 在「点『我要申诉』」**失败**：第一次 JS click 报 ✅ 但「发起申诉」弹窗**没开**（重试 2 次仍失败，`diag-detail2.js` 显示点击后无表单 textarea/file-input、无原因选项）。根因：更宽的布局让页面里「我要申诉」**出现多个文本节点**，`jsClickByText` 按"子节点最少"排序去点，宽时排到**一个纯文本/非交互的"我要申诉" span**→ onclick 不触发→弹窗不出现；窄宽时恰好点到真按钮。**A/B 验证**：还原 mainWindow 到 1560 + 重启工作台 + `--dry` → **全绿**（选原因/填说明/传凭证都过），确认是加宽所致、与订单状态无关。
- **教训**：①**任何窗口宽度/缩放/布局改动后，必须重跑 `cdp-run-full.js 1 --dry`（以及复议 `cdp-run-review.js 1 --dry`）确认没断**，不能只信"看起来正常/更宽了"。②`jsClickByText`/「发起复议」这类"按 exact 文本匹配 + 子节点最少"的启发式**脆**——同一页面在不同宽度/viewport 下会命中不同节点（一个 `<span>` 文本 vs 真 `<button>`）。要迁到新宽度必须先把它改成**专点真可交互元素**（候选里优先 `<button>`/`<a>`/`[role=button]`，或按父容器的点击委托收窄，而不是只按 `el.click()` + 排序）。③在没加固点击前，加宽"为自然比例"**保持当前宽度**（1560，browser≈1076，zoom≈0.86 能正常跑）别强改。④**改完 A/B（还原对比）再下结论**——先确认是改动而非偶发页面状态，再归因（本轮就是靠还原+复跑判断出"非宽度无关、是元素定位"。）

### 登录/扫码页必须保持 100%（加宽问题的真正解法）— 2026-08-31

用户说"比例还是太小/想更接近 100%"时，**真正的动机往往是登录页的"扫码登录"二维码太小、手机扫不了**——整页被 `fitBrowserZoom` 缩到 ~0.86，二维码跟着变小。**正确解法不是加宽整窗（会弄坏申诉，见上），而是让"登录/扫码页不缩放"**，登录页和申诉页的需求就不再冲突：

- 在 `fitBrowserZoom()` 开头加守卫：当前 URL（`wc.getURL()` 小写）命中 `/login|passport|扫码|qrcode|verify/i` → 直接 `return`（不缩放）→ 登录页保持 100%。
- 在 `browserWin.webContents.on('did-finish-load')` 里：URL 命中 login/passport/扫码 → `webContents.setZoomFactor(1)`，并且 **+300ms 再补一次**——因为 **Electron 的 zoom 在同 webContents 的跨页面间是持续的**：先看了申诉页（缩到 0.86）再跳登录页会**继承 0.86**，只靠 fitBrowserZoom 的"跳过"不够，必须显式重置回 1。
- 效果：登录页 100%（二维码可扫）、申诉/复议页照常自适应缩放（自动化不回归）。二者互不干扰。
- 验证：已登录状态下直接导航 `/login/` 多半会跳回首页量不到真实二维码，靠①代码逻辑（守卫+重置都在）；②申诉 `--dry` 不回归（登录守卫只命中 login URL，不碰申诉页）。

**⚠️ 只设 zoom=1 仍糊 = 登录页在小窗里缩放——2026-08-31 末次诊断**：若登录页"重置 100% 后还是很糊/很小"，真正根因往往不是缩放因子，而是**内嵌 `browserWin` 被拖小成 320×240 最小窗**（或 `lastBrowserBounds` 记忆了小值），`fitBrowserZoom` 只能把整页缩到 ~0.6 去塞 → 全页（含扫码二维码）极小模糊——此时 zoom=1 在 320 小窗里也救不了。诊断信号（CDP 读该页）：`window.innerWidth≈320` 但 `document.documentElement.clientWidth≈533`、`window.outerWidth=320` → 页面被缩到 ~0.6 塞进 320 窗。**修复**：登录页除 `setZoomFactor(1)`，还要 **`lastBrowserBounds=null` + 把 `browserWin` 显式放大到正常区域尺寸**（`setBounds({x:content.x+484, y:content.y, width:Math.max(900, content.width-484), height:Math.max(650, content.height-30)})`）+ 延时补一次 `syncBrowserWinPosition()`。这样登录页原尺寸清晰、二维码可扫。⚠️ 用 `Math.max(900, content.width-484)` 落在 content.width-484（主窗 1560 时 = 1076，即申诉页可跑的安全尺寸），**不要强压到更宽**（会复现"加宽弄坏申诉"的坑，见上节）；且该逻辑只命中 login/passport URL，不碰申诉页。⚠️ CDP 测窗口尺寸不可靠（`window.outerWidth` 对无边框/后台窗常误报 320），**以肉眼截图为准**。

## ⚠️ 内嵌浏览器黑屏修复（缩到任务栏再打开是黑屏，要挪窗口才重绘）——2026-08-30

**现象**：把工作台最小化到任务栏，再点开时工作台右侧**内嵌网页是黑屏**，必须挪动主窗口才把网页显示出来。

**根因**：本机无显卡、用 `--disable-gpu` 软件渲染。Windows 下窗口从最小化恢复后**内容不会自动重绘**，需一次交互（挪动/聚焦）才触发重新 present → 黑屏。

**修复尝试（`src/main.js`）**：给主窗口加 `restore`/`focus`/`show` 事件，触发时强制内嵌浏览器重绘（改过多个版本，见下）。
⚠️ **截至本轮结束仍未真正确认修复**：用户实测**两次仍黑屏**（第一次 setBounds+invalidate+resize 版、缩到任务栏再打开还是黑）。已试但**未验证成功**的几种强重绘：①同值 `setBounds`+`webContents.invalidate()`+`dispatchEvent(resize)`（无效）；②hide→show 强制重合成 + invalidate + 重应用缩放 `setZoomFactor(×1.0001)`（无效）；③**真实微移窗口 2px 再归位**（等效用户手动挪动窗口——用户确认\"挪动窗口就能恢复\"，说明需一次**真实位置/尺寸变化**才触发合成器重呈现）。**不要**把以上任何一种当成已解决的方案写进结论；若仍黑，下一步试：更大位移（挪 10px+）、或在主窗口 restore 时对 browserWin 做 `hide→show` 且退出 `--disable-gpu`（若可软渲染）、或检验是否与 `parent:mainWindow` 的子窗口合成有关。**黑屏优先级低于自动化可用性**——**不要靠去掉缩放来治黑屏**（去掉缩放会触发页面响应式布局、隐藏申诉/复议表单字段，直接弄坏自动化，见 fitBrowserZoom 节）。

## 买家触达 / 物流跟单 / 评价引导（非自动化，是渠道+合规问题）
本技能主体讲的是“后台自动化（CDP）”。但如果问题变成“**怎么在物流节点给买家推消息 / 做跟单 / 催评**”，那是**触达渠道 + 合规**问题，不是 CDP 问题，别一上来就想着写脚本。已核实的渠道事实（拼多多官方「智能物流提醒短信」0.1 元/单覆盖发货派送签收、晓多的「售中跟进/签收后主动确认」、为什么“客服聊天窗口主动推消息”没有独立第三方、催评红线与三条合规话术模板）见 `references/pdd-buyer-touch-channels.md`。
