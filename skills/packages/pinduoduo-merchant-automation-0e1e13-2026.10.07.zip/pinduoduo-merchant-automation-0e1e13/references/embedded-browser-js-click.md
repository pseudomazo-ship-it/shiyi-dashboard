# 内嵌浏览器：导航/提交按钮用 JS click + 提交后验证兜底（2026-08-30 实测）

## 背景
内嵌浏览器（`browserWin`，app `--remote-debugging-port=9334` 暴露）是单 webContents、SPA 就地导航。实测发现**两类点击用坐标（`clickByText`/`clickByExpr`/`Input.dispatchMouseEvent`）无效**：
1. **导航类按钮**（改变页面）：申诉 `查看详情`（坐标点后 URL 停在 `customer_complain_appeal?from=list`，找不到「我要申诉」→ 3 笔全跳过；`el.click()` 能跳到 `detail?ticketSn=`）。`查看可申诉订单`/`查询`（tab 切换）同理易抖。
2. **提交类按钮**（触发弹窗/提交动作）：申诉 `我要申诉`/`提交`/`确认并提交`，复议 `发起复议`/`提交复议`/`确认并提交`。

## 工具函数（申诉与复议脚本各放一份）
```js
async function jsClickByText(client, text, log) {
  try {
    const ok = await client.eval(`(() => {
      const nodes=[...document.querySelectorAll('a,button,span,div')].filter(
        (el)=>(el.innerText||el.textContent||'').trim()===${JSON.stringify(text)}&&el.offsetWidth>0&&el.offsetHeight>0);
      if(!nodes.length) return false;
      nodes.sort((a,b)=>a.children.length-b.children.length);
      nodes[0].click();
      return true;
    })()`).catch(() => false);
    if (log) log('点「'+text+'」(JS click): '+(ok?'✅':'❌ 未找到'));
    return !!ok;
  } catch { if (log) log('点「'+text+'」(JS click): ❌ 异常'); return false; }
}
```

**判成功用布尔**（非 `res.ok`）；`clickByText` 返回 `{ok}`，`jsClickByText` 返回布尔——把 `if (!res.ok)` 的检查同步改成 `if (!okValue)`。

## 提交后验证兜底（点「提交」/「提交复议」后必加）
提交动作可能触发「拼多多安全验证 · 拖动圆形滑块完成旋转拼图」。**必须在点提交之后、二次确认之前**加检测+等待：
```js
const submitOk = await jsClickByText(detail.client, '提交');  // 或 '提交复议'
log('点「提交」(JS click): '+(submitOk?'✅':'❌'));
await sleep(2500);
if (await detectVerificationOnly(detail.client)) {           // 提交后才弹 -> 这里必须查
  log('⚠️ 提交触发安全验证——已亮黄提醒，请人工完成验证，完成后自动继续');
  await waitHumanVerification(detail.client, log);            // ≤5min，人工滑完自动继续
  await sleep(2500);
}
// 二次确认（验证处理后可能需要补点「确认并提交」）
let confirmed = await jsClickByText(detail.client, '确认并提交');
if (!confirmed) confirmed = await jsClickByText(detail.client, '确认提交');
```

## 验证检测要对 iframe/遮罩健壮
`detectVerificationOnly` 不能只读 `document.body.innerText`——滑块/验证码常在 iframe（极验/同盾）或遮罩里。合并 `body+documentElement.innerText`、查验证 iframe（`src/name/title` 含 geetest|yidun|captcha|slider|验证）、查遮罩元素（class/id 含 geetest|yidun|安全验证|验证码|移动滑块）。命中任一即判"出现验证"。关键词集含：`验证码|安全验证|拖动滑块|请完成验证|人机验证|安全校验|风险确认|滑块|图形验证|请输入验证码|完成验证|拖动滑块完成拼图|请点击|点击刷新|向右拖动|验证失败`。

## 任务栏亮黄
主进程 `push(line,level)`（`cdpProc`/`reviewProc` 的 stdout 转发）里检测 `String(line).includes('【需人工介入】')` → `mainWindow.flashFrame(true)`（Windows 任务栏闪烁）。界面内亮黄横幅另由 renderer `showHumanAlert()` 触发（`/需人工介入/` 匹配）。
