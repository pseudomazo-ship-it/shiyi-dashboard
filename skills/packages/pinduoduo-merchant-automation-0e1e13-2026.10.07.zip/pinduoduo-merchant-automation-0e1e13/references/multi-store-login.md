# 多店铺账号密码登录（SPA 表单自动填写）

在拼多多商家后台做「批量登录 / 切换店铺」时的可靠技术。**已验证（2026-08-30）**：登录页是 SPA，但点击「账号登录」标签后出现真实可填的账号/密码输入框，可用 `executeJavaScript` + React 兼容 value setter 自动填写。

## 关键事实（实测）

- `https://mms.pinduoduo.com/login/` 返回 200 页长 ~6650，但**静态 HTML 里 `input` 标签 = 0**——登录表单是 JS 动态渲染的 SPA。**别用 http/https GET 抓静态源码判断表单**，必须加载出真实 DOM。
- 默认是「**扫码登录**」（"打开拼多多商家版App扫码登录"）。页面文字含「**账号登录**」标签，点击后切换出真实表单。
- 切换「账号登录」后出现的输入框（实测 DOM）：
  - 账号：`<input type=text placeholder="请输入账号名/手机号">`（无 name/id，靠 placeholder 匹配）
  - 密码：`<input type=password placeholder="请输入密码">`（无 name/id，靠 type/password 匹配）
  - 按钮：「登录」文字按钮（还有「忘记密码」）

## 自动填账号密码（React 兼容）

拼多多表单是 React 受控组件——**裸设 `.value` 不生效**，必须用原生 setter + 派发事件，否则 React 看不到值：

```js
// 在 BrowserWindow webContents.executeJavaScript 里执行
// 填账号
const inp = [...document.querySelectorAll('input')].find(
  x => x.offsetWidth>0 && x.type==='text' && /请输入账号|账号名|手机号/.test(x.placeholder||''));
if (inp) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
  setter.call(inp, '账号');          // 用原生 setter 写值
  inp.dispatchEvent(new Event('input',{bubbles:true}));   // React 监听 input
  inp.dispatchEvent(new Event('change',{bubbles:true}));  // 再补 change
}
// 填密码：filter input[type=password]，同样 setter+dispatch
// 点登录：找 innerText.trim()==='登录' 的可见按钮，.click()
```

## 完整登录流（main.js 的 store:login）

```
导航到 https://mms.pinduoduo.com/login/  → 等 SPA 加载(~15s)
→ executeJavaScript 找到并点「账号登录」标签 → 等 ~1.8s
→ 填账号(原生 setter+input/change) → 填密码(同) → 等 0.8s
→ 点「登录」按钮
```

## 多店切换的架构约束（重要）

- 登录态 = **单个 `SESSION_PARTITION` 的 cookie**（Electron 里 `browserWin` 和 `loginWindow` 共享 partition）。**同一时刻只有 1 个店铺在线**。
- 「批量登录/切换店铺」= 逐个登录，**每次用新账号覆盖 cookie**。切店 = 用下一个账号重新登录。
- **不能同时多店铺并行**——除非拆成多 partition / 多浏览器实例（会牵动整个自动化架构），此用户场景按单会话做即可。
- "当前店铺"用变量记录（`currentStoreName`），UI 显示「当前：XX」徽标。

## 登录后可能触发的验证

- 拼多多登录**可能弹滑块/短信验证**（账号密码登录比扫码更容易触发）。代码只负责任务「填好+点登录」，**验证需人工过**——提示用户到浏览器窗口处理，别硬破。
- 密码存 `data/stores/stores.json`（本地 `stores/` 目录），只在用户本机；**表格里密码列不显示在 UI**（渲染后用 `textContent=` 只显示账号）。

## 导入导出登录表格（CSV）

- 表头：`店铺名称,账号,密码`。导入用简易 CSV 解析器（支持引号包裹、逗号、CRLF、BOM）。
- 表头字段做**模糊匹配**（名称/店铺/账号/密码 的中英文别名），找不到三列就报错提示当前表头。
- 解析注意：`\uFEFF` BOM 要 strip；空行跳过；首行当表头。
