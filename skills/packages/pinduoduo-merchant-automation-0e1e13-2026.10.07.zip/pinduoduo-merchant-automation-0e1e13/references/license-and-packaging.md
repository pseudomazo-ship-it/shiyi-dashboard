# 授权机制 + 打包给使用者 + .bat GBK 编码（2026-08-30）

## 1. 授权/机器码机制（防外泄：每台机器绑定唯一授权码）

> 用途：内部工具首次使用需激活。使用者把「机器码」发给管理员 → 管理员用 `gen-license.js` 生成「授权码」→ 使用者填入激活。防止软件被随意复制扩散。

### 核心函数（都在 `src/main.js` 顶部常量区）

```js
const LICENSE_SECRET = 'MengQianAppealTool_2026_InternalOnly_V2'; // 必须与 gen-license.js 完全一致
const LICENSE_FILE   = path.join(__dirname, '..', 'data', 'license.dat');

function getMachineCode() {
  let base = '';
  try {
    const out = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { windowsHide: true }).toString();
    const m = /MachineGuid\s+REG_SZ\s+(\S+)/i.exec(out || '');
    if (m) base = m[1].trim();
  } catch {}
  if (!base) { try { base = os.hostname() + '|' + os.arch() + '|' + ((os.cpus()[0] || {}).model || ''); } catch {} }
  const h = crypto.createHash('sha256').update(String(base)).digest('hex').toUpperCase();
  return h.slice(0, 20).replace(/(.{4})(?=.)/g, '$1-');   // 5 组 x4 位：XXXX-XXXX-XXXX-XXXX-XXXX
}
function makeAuthCode(mc) {
  const mac = crypto.createHmac('sha256', LICENSE_SECRET).update(String(mc).trim().toUpperCase()).digest('hex').toUpperCase();
  return mac.slice(0, 20).replace(/(.{5})(?=.)/g, '$1-');  // 4 组 x5 位：XXXXX-XXXXX-XXXXX-XXXXX
}
function isLicensed() {
  const raw = fs.readFileSync(LICENSE_FILE, 'utf8').trim();
  if (!raw) return false;
  const [machine, auth] = raw.split('|');
  return String(machine||'').trim().toUpperCase() === getMachineCode().toUpperCase()
      && String(auth||'').trim().toUpperCase() === makeAuthCode(machine).toUpperCase();
}
```

### 启动门禁
- `app.whenReady().then(() => { if (process.argv.includes('--no-auth') || process.argv.includes('--smoke-test') || isLicensed()) createWindow(); else showLicenseWindow(); })`。
- `showLicenseWindow()`：小窗（title 授权激活, width 460, height 450, resizable:false, alwaysOnTop:true, webPreferences 同主窗）,加载 **data:URL HTML**（展示机器码 + 输入授权码 + 激活按钮），按钮调 `window.appealApi.licenseActivate(code)`。
- `ipcMain.handle('license:activate', (_e, code) => { if (code.trim().toUpperCase() === makeAuthCode(mc).toUpperCase()) { fs.writeFileSync(LICENSE_FILE, mc + '|' + code.trim().toUpperCase(), 'utf8'); closeWin(); createWindow(); return {ok:true}; } return {ok:false, message:'授权码无效...'}; })`。
- `preload.js` 暴露 `licenseActivate: (code) => ipcRenderer.invoke('license:activate', code)`。

### 管理员生成授权码（`gen-license.js`，**分发前必须删除**）
```js
// node gen-license.js <机器码>  → 输出授权码
const crypto = require('node:crypto');
const SECRET = 'MengQianAppealTool_2026_InternalOnly_V2';   // 与 main.js 一致
const mc = String(process.argv[2] || '').trim().toUpperCase();
const mac = crypto.createHmac('sha256', SECRET).update(mc).digest('hex').toUpperCase();
console.log('机器码: ' + mc);
console.log('授权码: ' + mac.slice(0, 20).replace(/(.{5})(?=.)/g, '$1-'));
```

### 容易踩的坑
- **`reg query` 在 bash 内联 `node -e "..."` 里会因转义被破坏**（`\\SOFTWARE` 被吃）→ 用 `.js` 文件跑，别内联。文件里 `'...\\SOFTWARE...'` 才干净。测试失败时先确认是转义问题还是真失败（本机 MachineGuid 是能读到的：`reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid` → `MachineGuid  REG_SZ  xxxxxxxx-xxxx-...`）。
- **`makeAuthCode` 与 `gen-license.js` 必须用同一 SECRET + 同一 `mc.toUpperCase()`**，否则授权码对不上。
- **`.bat` 中文字符乱码** → 写 GBK（见第 3 节）。
- `license.dat` 是"本机授权"，**别放进使用者的包**（对方机器码不同，会直接判未授权 → 弹激活窗，这正是想要的）。

---

## 2. 打包"给使用者"的干净版本（剔除敏感/管理员文件）

一个可运行的 "ready-to-use" 包必须带上 electron 运行时（`node_modules/electron` 约 325M），并**剔除**下面的敏感/管理员文件。

### 保留
`src/`、`renderer/`、`node_modules/electron/`、`package.json`、`使用说明.md`、`【蒙倩】--订单申诉复议工作台.bat`（启动器，⚠️ **真名不是 `启动工作台.bat`**——那名字在项目里不存在，曾因此打包出来的使用者版缺启动器）、`一键处理申诉.bat`、`打开商家后台.bat`，以及 `data/` 里**仅**：
- `cdp-driver.js`、`cdp-run-full.js`、`cdp-run-review.js`
- `appeal-config/config.json` + 空 `appeal-config/evidence/`
- `review-config/config.json` + 空 `review-config/evidence/`

### 剔除（敏感/管理员/开发/临时）
| 项 | 原因 |
|---|---|
| `gen-license.js`、`生成授权码.bat` | 含生成授权码的密钥——留着对方就能自授权 |
| `data/license.dat` | 本机授权（对方要重新激活） |
| `chrome-profile2/` | 本机拼多多登录态（Cookie），整包不可外发 |
| `data/appeal-config/evidence/*`、`data/review-config/evidence/*` 的图 | 产品证/截图（敏感 + 对对方是错误凭证） |
| `data/runs/`、`data/*.flag`、`debug.log`、`start-console.ps1`、`backup_pause_130502/`、`启动工作台.bat.tmp` | 日志/临时 |
| `data/` 里除上述 3 个外的所有 `cdp-*.js`（cdp-diag/check/test/verify 等） | 仅开发诊断用 |

### 打包脚本要点（`打包给使用者版.bat`）
- `set "SRC=%~dp0"`、`set "DEST=%~dp0..\\内部工具-给使用者版\\订单申诉复议工作台"`。
- `xcopy /e /i /q /y "%SRC%src" "%DEST%src"`、同样复制 renderer、`node_modules\\electron`。
- `mkdir "%DEST%data"` + 按上面"保留表"逐个 `copy`；`mkdir "%DEST%data\\appeal-config\\evidence"` + `review-config\\evidence`。
- 最后 `powershell -NoProfile -Command "Compress-Archive -Path '%DEST%' -DestinationPath '%DEST%.zip' -Force"`。
- 脚本内不要引用任何被剔除的文件（否则报错）。

---

## 3. `.bat` 中文乱码修复（写中文批处理）

中文 Windows 的 CMD 默认按 **GBK** 读 .bat；若 .bat 存成 **UTF-8**，中文会全部乱码（`title 生成授权码` 显示成乱码）。

**正确做法**：用 Python 把 .bat 写成 **GBK 编码 + CRLF**，并在脚本里 `chcp 936 >nul`（切到 GBK 代码页与文件一致），**不要**用 `chcp 65001`（UTF-8）配 GBK 文件，否则 `chcp` 之后的中文 echo 会因编码不一致再乱。

```python
import io
content = """@echo off
chcp 936 >nul
title 生成授权码
...
"""
io.open(r"生成授权码.bat", "w", encoding="gbk", newline="\r\n").write(content)
```

要点：①Python `io.open(..., encoding='gbk', newline='\r\n')`；②`chcp 936 >nul`；③别配 `chcp 65001`；④纯英文/拼音内容可完全避开编码问题（备选）。
