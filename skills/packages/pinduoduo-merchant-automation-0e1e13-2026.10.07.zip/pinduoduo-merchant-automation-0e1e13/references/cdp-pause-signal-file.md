# Adding real pause/resume to the CDP automation subprocess (signal-file pattern)

The CDP appeal engine (`data/cdp-run-full.js`) is launched by the main process as
an **external spawned child** (`spawn(process.execPath, [scriptPath, maxRounds])`),
so it has no IPC channel back to the UI. The `renderer/app.js` `paused` UI states
belong to the **replay engine** (`player.js`), NOT this path. To give the 订单申诉
page a real, resumable 暂停 (the user asked for "新增暂停" on the top bar, and chose
**resumable** over "stop" semantics), use a **signal file** that the child polls
between rounds. This is the pattern that was implemented and `node --check`-validated
this session.

## Layout of the change (5 files)

| File | Change |
|---|---|
| `src/main.js` | add `appeal:pause-cdp` / `appeal:resume-cdp` handlers that write/delete a flag file; clear the flag on `appeal:stop-cdp` |
| `src/preload.js` | expose `appealPauseCdp` / `appealResumeCdp` |
| `data/cdp-run-full.js` | `waitIfPaused()` — poll the flag file between rounds; resume when it disappears |
| `renderer/index.html` | top `.app-run-bar` with 开始处理申诉 / 新增暂停(**暂停**) / 停止 buttons |
| `renderer/app.js` | wire top buttons; `setStatus` syncs the top bar (paused→button reads "继续") |
| `renderer/styles.css` | `.app-run-bar` + `.btn-warn` |

## Signal-file mechanism

Main process (in `src/main.js`, near `cdpProc`):

```js
const CDP_PAUSE_FLAG = path.join(__dirname, '..', 'data', 'pause.flag');

function cdpSetPaused(paused) {
  try {
    if (paused) fs.writeFileSync(CDP_PAUSE_FLAG, String(Date.now()));
    else if (fs.existsSync(CDP_PAUSE_FLAG)) fs.unlinkSync(CDP_PAUSE_FLAG);
  } catch (e) { /* ignore */ }
}

ipcMain.handle('appeal:pause-cdp', () => {
  if (!cdpProc) return { ok: false, message: '自动化未在运行，无法暂停' };
  cdpSetPaused(true);
  sendStatus('paused');
  return { ok: true };
});
ipcMain.handle('appeal:resume-cdp', () => {
  if (!cdpProc) return { ok: false, message: '自动化未在运行，无法继续' };
  cdpSetPaused(false);
  sendStatus('playing');
  sendLog('▶ 已继续（人工解除暂停），重新开始处理', 'success');
  return { ok: true };
});
```

Child (`data/cdp-run-full.js`, main loop):

```js
const PAUSE_FLAG = path.join(ROOT, 'data', 'pause.flag');
async function waitIfPaused(log) {
  let wasPaused = false;
  while (fs.existsSync(PAUSE_FLAG)) {
    if (!wasPaused) { log('⏸ 已暂停（人工触发），正在等待继续…'); wasPaused = true; }
    await sleep(800);
  }
  if (wasPaused) log('▶ 已继续，重新开始处理');
}
// in the per-round loop, AFTER processOneOrder and BEFORE the inter-round jitter:
await waitIfPaused((m) => console.log('[' + round + '] ' + m));
```

## Pitfalls confirmed this session

- **Clean up the flag on stop.** `appeal:stop-cdp` must `cdpSetPaused(false)` after
  killing the process — a leftover `pause.flag` makes the NEXT run pause immediately.
- **Subprocess pause happens at round boundaries, not mid-step.** The safest place is
  between completed rounds (`await waitIfPaused(...)` before the inter-round `jitter`),
  so you never pause mid-`提交` (irreversible). If the user needs mid-step pause,
  they'd need finer-grained checks in `processOneOrder` — but that risks stopping in
  the middle of an irreversible submit; round-boundary is the safe default.
- **Don't call the replay engine's `playPause` from the CDP page's pause button** — it
  pauses `player.js`, not the CDP child. Verify which engine (`appeal:run-cdp` vs
  `play:start`) the button actually drives before wiring.
- Top-bar 开始 button reuses `requestAppealStart()` (config validation + confirm modal);
  don't bypass that — it's the gate that prevents submitting with empty话术/凭证.
- Confirm the user wants **resumable** pause vs stop-equivalent before implementing;
  this user picked resumable. If stop-equivalent, just wire pause to `appeal:stop-cdp`.
