# 行政复议（reconsideration）自动化 — 2026-08-30 实测

对拼多多「消费者负向体验补偿」的**复议**做自动化。与申诉不同，复议是对"已被判负/判定后"的申诉再审，入口和表单都不同。生产脚本 `data/cdp-run-review.js`（主进程 `review:run-cdp` spawn 它，`node data/cdp-run-review.js <N>`，`--dry`/`DRY_RUN=1` 为 dry-run）。

## 真实入口与流程（已验证）

```
订单申诉页 orders/appeals
  → 点「去复议」（在「消费者负向体验申诉」卡片下）
  → 打开标签 /orders/appeals/negativeExperienceReconsider?reconsiderSecondaryTabKey=negativeExperience
  → tab「全部可复议申诉 / 复议记录」；列表标题「以下申诉可发起复议」
     表头：订单编号 | 商品信息 | 问题类型 | 处理金额(元) | 处罚时间 | 复议倒计时 | 操作
     操作列 = 「发起复议」+「查看详情」（每行都有）
  → 点第一行「发起复议」 → 同页模态框（negativeExperienceReconsider 页内，非新标签）
  → 复议原因（下拉输入框，placeholder「请选择」）
  → 复议描述（textarea，最多300字）→ 复议凭证（上传图片 1/3 + 上传视频 0/1）
  → 点「提交复议」→（如有）「确认并提交」二次确认 → 完成
```

复议页顶部还能看到统计「近30天复议成功140单，返还金额420元」；每行带「29天xx时xx分后不可复议」倒计时（超过即无法复议）。

## ⚠️ 关键坑（这条最重要）

**1. 复议凭证必须与首次申诉不同。** 平台表单红字校验：
> 「请补充与首次申诉**不同**的有效凭证，无效凭证会导致复议失败」

- 若复议直接复用申诉的 `evidence1.jpg`（共用同一凭证文件夹），平台识别为"与首次申诉相同"→ **拦截提交**。
- 表现：点「提交复议」后表单**不关闭**、订单**仍留在可复议列表**（仍显示「发起复议」按钮）、日志成功正则却可能误报「✅ 已提交」。
- **无线上副作用**：订单仍可复议、未被消费，可安全重试。
- **结论**：复议必须用**独立的、不同于申诉的凭证**。这正是「复议需拆独立配置/独立凭证存储」的硬理由——不能与申诉共用 config.json + evidence 文件夹。

**2. 入口不能直连 URL。** 直接 `Page.navigate` 到 `negativeExperienceReconsider` 后点「发起复议」**不弹窗**（SPA 未初始化）。必须先经「去复议」进入。**注意：复用已加载的旧 tab 也只是“有时”能开、不稳定**——最稳的是每轮开头 `closeTabsByUrl('negativeExperience?')` + `closeTabsByUrl('negativeExperienceReconsider?')`（清旧），再 orders/appeals → 点「去复议」→ 重连 negativeExperienceReconsider → 点「发起复议」（配下面的 JS click + ≤3 重试）。

**3. 成功判定会误判。** 用 body 正则（`/已提交|已受理|复议成功|审核中/`）匹配会误报——表单未关、订单未移出也算"成功"。**真判断 = 表单已关闭 + 该订单从「可复议」列表消失（进入「复议记录」）**；核对页切到「复议记录」tab 看订单是否出现。

**4. 复议同样不可撤回。** 表单红字「请如实填写以下内容，**提交后不可修改**。若您提交的内容不属实，平台将无法通过您的复议」。→ 一律 dry-run 兜底 + 用户明确确认后才真跑。

## 复议原因真实下拉选项

`placeholder="请选择"` 的下拉输入框，实际选项包含（抓取时注意「其他」也确实存在，用正则容易漏）：
- 其他
- 商品无问题，消费者误解
- 商品有问题，但已与消费者达成一致其他售后方案
- 商品有问题，但消费者主动表示无需处理
- 消费者未表达商品问题（含售后详情内未描述问题等）

## 关键选择器/实现要点（2026-08-30 复测修正，这节是运行成功的关键）

- 表单是**同页模态框**（negativeExperienceReconsider 页内），操作 `list.client`（该页 tab 的 CDPClient），不要等新 tab。
- **⚠️「发起复议」必须用 JS `el.click()`，坐标点击无效。** 这是本页与申诉页最大区别：`clickByText('发起复议')`/`Input.dispatchMouseEvent` 坐标点击**找到了按钮、返回 ok，但不触发 SPA 的 modal handler**（点了没反应：无 iframe、无弹层、body 不变、订单仍留列表）。改用 JS：
  ```js
  const btns=[...document.querySelectorAll('button,a,span,div')].filter(el=>/发起复议/.test(el.innerText)&&el.offsetWidth>0);
  btns.sort((a,b)=>a.children.length-b.children.length); btns[0].click();
  ```
  成功标志 = 页面出现「提交复议/复议原因」。多试（Esc 清残留 + 重试 ≤3 次）。
- **⚠️复议原因「其他」要按“同下拉列表”去重。** 页面上「其他」不止一个；直接 `clickByText('其他')` 偶尔点到别的（看似选上但表单没展开，后续填描述/传图全失败）。**可靠做法**：展开下拉后，找 exact 文本=目标 且**祖先链（≤8 层）同时含「商品无问题」**（一个确定的复议选项）的候选，`el.click()`——才选的是本下拉的「其他」。选完等 2.5s 再填。
- **复议描述 textarea、凭证上传区在选中复议原因后才出现**（和申诉一样，选前 textareas=[]、fileInputs=[]）。所以**必须「先选原因→再填/传」**；填描述/上传各做 ≤3 次重试（每次间隔 1.8s），避免原因刚选好、表单还没展开就抓空。
- 成功后可打二次确认「确认并提交/确认提交」（申诉流程有，复议按需补点）。
- 脚本复用申诉脚本的同款基建：`checkReady`（Chrome9333 在线+已登录+凭证已配）、`jitter` 随机人类节奏、`waitHumanVerification`（验证→「需人工介入」→亮黄→等人工→自动续）、`waitIfPaused`（`data/pause.flag` 暂停信号）、`DRY_RUN` 短路。

## 验收纪律（沿用申诉）

1. `node data/cdp-run-review.js 1 --dry` → 选原因/填描述/传图全绿（0 提交）。
2. 用户明确确认 → 真实跑 `node data/cdp-run-review.js 1`。
3. 跑完**核实**：切「复议记录」tab 确认该订单已进入复议记录/不再在可复议列表，而非只看脚本日志的「✅ 已提交」。
