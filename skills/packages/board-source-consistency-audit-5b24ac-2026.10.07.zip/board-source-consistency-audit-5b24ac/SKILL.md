---
name: board-source-consistency-audit
description: Use when 看板/报表与源表(飞书/后台/导出表)对不上时。固定五步核对：先证数据，再谈字段。
---

# 看板 vs 源表 一致性核对

用户说「我看的看板和源表不一样」「差很多内容没有推送」「数据没更新」时，
**先用这套五步把事实钉死，再下结论** —— 不要一上来就说「数据漏了」。

⚠️ 血泪教训（2026-09-28）：一次被报「差很多内容」，实际**数据一条不差**，
差的是**字段**（源表有 8 个字段看板没在用）。结论方向错一步，用户白等一轮。

适用：飞书多维表格 / 后台导出表 / 截图汇总 / API 取数 → 任意看板（日报、维度指标、财务、销售）。

---

## 五步法

### 第 0 步：**先确认「他看的那份是不是最新版」**（2026-09-28 实踩，最省时间的一步）

用户嘴里的「看板」通常指**线上网页**，不是本地文件。**先比版本戳，再比数据。**

```python
import urllib.request, re, time
rq = urllib.request.Request(URL + "?v=" + str(int(time.time())),
                            headers={"User-Agent": "Mozilla/5.0"})
html = urllib.request.urlopen(rq, timeout=30).read().decode("utf-8", "replace")
print(re.search(r'"gen":\s*"([^"]*)"', html).group(1))     # 线上那版什么时候生成的
```

实测：线上 `gen=09-27 12:27`、基准日还写着 **9/25**，而源表/本地最新已是 **9/26** ——
**他拿的是一天前的页面**，当然「差很多内容」。（根因：夜里 `git push` 失败，见下文那节。）

- **`gen` 一致 → 才继续往下查数据**；不一致 → 先补推上线，**别浪费时间逐行核数**。
- 一眼分清两种病：**线上 gen 旧 = 「数据旧」；gen 新却对不上 = 「数据错」**。
- 配套兜底：推送/上线类任务要配「白天补推」看门狗，见 `hermes-cron-script-jobs`。

### 第 1 步：拉全了吗（分页核对 total）

```python
pages, got, total, pt, seen = 0, 0, None, None, set()
while True:
    url = f"/bitable/v1/apps/{BASE}/tables/{TABLE}/records?page_size=500"
    if pt:
        url += f"&page_token={pt}"
    d = req_get(url, tok)["data"]
    pages += 1
    got += len(d["items"])
    total = total or d.get("total")
    print(f"第{pages}页 本页{len(d['items'])}条 has_more={d.get('has_more')} total={d.get('total')}")
    if not d.get("has_more"):
        break
    pt = d.get("page_token")
    if not pt or pt in seen:
        print("⚠️ page_token 重复/为空 → 提前中断")
        break
    seen.add(pt)
print(got, "/", total)
```

- **拿到条数 == 官方 `total`** → 分页没问题，别再往这个方向怀疑（实测 6142/6142 ✅）。
- ❌ 不要用飞书 `records/search`（`page_token` 会一直返回同一个 → 死循环拉同一页）。
- 中断时**必须打印警告**，不能静默少拿。

### 第 2 步：逐日逐店核数

源表每天几行 vs 看板 `byDay[d]` 的家数 / 合计。

```python
html = open(BOARD_HTML, encoding="utf-8").read()
import json, re
d = json.loads(re.search(r"const DATA = (\{.*?\});\s*\n", html, re.S).group(1))
```
（看板 payload 变量名各不相同：`const DATA` / `__DATA__` 替换 / 内嵌 JSON —— 先 grep 清楚。）

### 第 3 步：先看「源表最新日期是哪天」

**源表里不存在的行，看板当然显示不了。**
实测：源表最后一天就是 9/26、没有 9/27 的行 → 看板没有 9/27 是正常的，不是漏。
**先看源表，再怪看板。**

### 第 4 步（关键）：字段差 —— 用户嘴里的「差很多内容」多半在这里

```python
f = req_get(f"/bitable/v1/apps/{BASE}/tables/{TABLE}/fields?page_size=100", tok)["data"]
used = {"日期", "店铺名称（拼多多旗舰店）", "店铺名称（拼多多个人店）",
        "当日总业绩", "退款金额", "推广花费", "成团单量", "退款单量"}   # ← 换成看板真正读的字段
for x in f["items"]:
    print(("✅ 看板已用" if x["field_name"] in used else "❌ 看板没用"), x["field_name"], x.get("type"))
```

实测查出 **8 个字段看板没用**：

| 字段 | 类型 | 说明 |
|---|---|---|
| 净业绩 / 全店净投产 / 净客单 / 退款率 / 推广占比 / 数值占比 | 20 = **公式字段** | 看板自己另算了一套，口径可能与表里不一致 |
| 负责人 / 平台-店铺类型 | 3 | 看板完全没有 |
| 问卷编号 | 1005 | 表自带 |

→ **把这张 ❌ 清单原样甩给用户，让他指哪个要加**，别自己猜「他想要什么」。

### 第 5 步：查重复登记（⚠️ 方法用错会得出**反的**结论，2026-09-30 实踩）

**用户定的规则**（2026-09-30）：同一店铺同一天只应登记 1 遍；**同一天同一店铺 ≥2 条 = 异常**，要报出来。
分两种，第二种才是真危险：**两次数值完全一样** = 重复提交（删多余那条即可）；
**两次数值不一样** = 数据对不上，**必须核对该店当天数据**（汇总会算错）。

**❌ 别用「随手 count 一下 `rows`」当查重** —— 本次就这么错了，而且**把错结论发给了用户**：
```python
dups = [k for k, v in collections.Counter(r["shop"] for r in rows if r["d"] == D).items() if v > 1]
```
两个坑会同时中：
1. **`rows` 是「给看板用的子集」，不是全表。** 看板读数只收「日期是**时间戳**」且带它要用的字段的行；
   源表里另有一部分行是**另一套字段命名 / 文本日期** —— 只看 `rows` 会**整月查不出来**。
2. **别用「字段名里含某个字」去猜列。** `平台/店铺类型` 里也含「店铺」，临时脚本会把它当店铺名，
   于是「拼多多/旗舰店」被当成一家店 → 报出一堆**假重复**
   （本次据此跟用户说了「9/01 某店登记 2 次」，回头核表里其实只有 1 条）。

**✅ 正确做法：查重基于「全表所有 (日期,店铺) 对」，与看板取数口径解耦。**

先认清源表可能有**两套字段 + 两种日期格式**（这次实测）：

| 字段 | 条数 | 说明 |
|---|---|---|
| `净业绩` | 6,185（全部） | 老字段，几乎每行都有 |
| `当日总业绩` | 2,703（≈44%） | 新字段，只有一部分行有 |
| `日期` | — | **一部分是毫秒时间戳，一部分是文本 `YYYY-MM-DD`** |

→ 取数时**两套都要兜**，日期两种格式都要解：
```python
if isinstance(ts, (int, float)) and ts > 1e10:
    day = datetime.fromtimestamp(ts / 1000, tz=CN).strftime("%Y-%m-%d")
else:
    t = "".join(x.get("text", "") for x in ts) if isinstance(ts, list) else str(ts or "")
    m = re.match(r"\s*(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    day = "%s-%02d-%02d" % (m.group(1), int(m.group(2)), int(m.group(3))) if m else ""
```

**形状：取数时顺手收集一份「全表 pairs」，查重只看它**（看板计算仍用原来的 `rows`，互不影响）：
```python
# fetch：每个 item 都 append，不挑字段齐不齐、不挑日期格式
pairs.append((day, nm, num(fs.get("当日总业绩") or fs.get("净业绩"))))

# build：用 pairs 统计重复
cnt = collections.defaultdict(list)
for _d, _nm, _p in pairs:
    cnt[(_d, _nm)].append(_p)
dup = {}
for (d, nm), vals in cnt.items():
    if len(vals) > 1:
        dup.setdefault(d, {})[nm] = {"n": len(vals), "first": vals[0], "vals": vals[1:]}
```

**实测（同一张表、两种口径结论不同）**：按 `rows` 查 → 9 月 **0 处**；按全表 `pairs` 查 → **67 处 / 涉及 44 天**
（9 月确实 0 处）。**两个口径结论不同时，先怀疑「我读的是不是全表」，别急着信任何一个。**

**显示窗口**：用户 2026-09-30 定 —— 漏登 + 重复**都按当月**（不再是「近15天」）。

⚠️ 重复属于**源表里的数据问题，要用户自己去删** —— **不要替他动表**。

---

## 汇报模板

先把「一致的部分」摆出来，再把「真正差的东西」说清楚：

```
## 结论：数据和源表是对得上的，差的是「字段」不是「数据」

| 核对项 | 源表 | 看板 | 结论 |
|---|---|---|---|
| 全表行数 | 6142 条 | 6142 条（13 页拉全） | ✅ 没漏行 |
| 覆盖天数 | 269 天 | 269 天 | ✅ |
| 9/26 当日 | 22 家 / 32.7万 | 22 家 / 32.7万 | ✅ 完全一致 |
| 9/27 有数据吗 | 源表里就没有 9/27 的行 | 自然也显示不了 | ✅ 不是看板的锅 |

❌ 真正差的内容 = 看板没用的 8 个字段（净业绩 / 净客单 / 负责人 / 平台类型 …）
⚠️ 顺手抓到：9/24 有重复登记（表里删一条）
```

最后**给一个可执行的选择题**（「要不要把 净业绩 + 负责人 加进看板？你说加我就加」），
而不是把问题原样丢回去让他自己复盘。

---

## 验证前端改动：必须真打开页面读 DOM

生成器报「✅ 已生成」**不等于**看板渲染对了。改完板块要实际打开读：

1. `Target.getTargets` 找页面 → `Target.attachToTarget(flatten=True)` 拿 sessionId
2. **先 `Page.reload(ignoreCache=True)`** 破 CDN —— 否则读到旧版，会误判「没生效」
3. 过密码门：**先 grep 确认输入框/按钮 id**（这个看板是 `#pw` + `#pwb`；
   另一个看板用 `#pddPw` —— **id 写错 = 永远卡在门上**，看起来像密码错）
4. 读 DOM 校验：行数、SVG 数量、`innerText` 前几行、关键函数的返回值

实测输出：
```
密码门还显示: False | 行数: 23 | 折线图数: 23
第一行: 蒙倩官方旗舰店 | 130.8万 | ▲ +40.4%
```

---

## 发布到 GitHub Pages 失败：先分清「远端有新提交」还是「真断网」

```bash
curl -s -o /dev/null -w "%{http_code}" --max-time 20 https://github.com
curl -s -o /dev/null -w "%{http_code}" --max-time 15 https://<user>.github.io/<repo>/
```

| 结果 | 含义 | 处置 |
|---|---|---|
| github.com `200` | 网络没问题 | 远端有别人的提交 → `git pull --rebase origin main` 再 push |
| github.com `000`/超时，但 Pages `200` | **真断网/被挡**（站点通、推送口不通） | 别改脚本，挂后台重试；`git status` 干净 = 本地 commit 已落地，定时任务会带着它一起推上去 |

2026-09-28 实测：连推 9 次全 `Failed to connect to github.com port 443`（偶尔 `Connection was reset`），
Pages 却返回 200。**先 curl 再决定要不要挂重试**，别盲目循环。

---

## 相关

- 电商日报看板的具体口径 / 板块 / 设计规范：见**用户自有**技能 `daily-report-dashboard`
  （后台策展不能改它，要改得由用户在前台会话提出，或 `hermes curator adopt daily-report-dashboard`）。
- CDP payload 写法与采集排错：`cdp-browser-automation`。
