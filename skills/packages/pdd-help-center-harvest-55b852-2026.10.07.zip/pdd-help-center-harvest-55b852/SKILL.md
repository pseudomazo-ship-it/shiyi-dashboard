---
name: pdd-help-center-harvest
description: "Use when 采集拼多多商家后台帮助中心全站内容（走 cambridge 接口，秒级）。"
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [拼多多, 帮助中心, 采集, CDP, 接口, IMA知识库]
    related_skills: [cdp-browser-automation, web-console-data-harvest, ima-notes-and-kb-workflow]
---

# 拼多多帮助中心全站采集

## 何时用
十一要「把拼多多帮助中心内容存进知识库」「采集帮助中心」时。

## 结论前置：别逐条点，直接调接口

全站 **136 个二级模块 / 3,473 条 / 62 万字**：

| 方式 | 耗时 |
|---|---|
| 逐条点击列表（点→读→返回→重翻页） | 约 12.5 小时 |
| **走 cambridge 接口** | **90 秒** |

## 核心接口（2026-10-03 实测有效）

在已登录拼多多的页面上下文里 fetch（自动带 cookie），**不要**用外部 HTTP 直连。

### ① 模块树
```
POST /cambridge/api/businessLesson/moduleList
body: {}                       ← 试 {} / {"source":1} / {"type":1} / {"parentId":0}
返回: [{id, moduleName, moduleType, secondModuleList:[{id, moduleName}]}, ...]
```
实测结构：**22 个一级模块 + 136 个二级模块**，二层字段名是 `secondModuleList`（不是 children/subModules）。

### ② 条目列表（含正文）
```
POST /cambridge/api/businessLesson/lessonList
body: {"secondModuleId": 71, "start": 0, "length": 20}
返回: {success:true, result:{total:302, list:[{id, lessonName, contentText(HTML正文), firstModuleId, firstModuleName, secondModuleId, secondModuleName, fileType, teacher, introduction}]}}
```

**参数名坑（少一个就报错，报错信息会直说缺哪个）**：
- `secondModuleId` —— **必填**，错写成 `moduleId` / `second_module_id` 都报「二级模块id不能为空」
- `start` —— 偏移量，必填（**不是 page**）
- `length` —— 每页条数，必填（**不是 pageSize**）
- 翻页靠 `start += len(list)`，不是页码

## 完整流程

```bash
# 0) 先开带调试端口的 Chrome，让十一自己扫码登录拼多多商家后台
"C:/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9555 --remote-allow-origins=* \
  --user-data-dir="D:/Agent.GongZuoQu/Hermes.GZQ/---日常沟通---/chrome-pdd" \
  "https://www.pinduoduo.com/"

# 1) 探测模块树
python pdd_help_api.py --probe

# 2) 全量采集（136 模块，约 90 秒）
python pdd_help_api.py --all

# 3) 生成 md 笔记（切分模式）
python build_notes.py --mode hybrid      # ★推荐：按模块切，单模块>60条才拆（158 篇）
python build_notes.py --mode module      # 每模块一篇（134 篇，有 256KB 大文件风险）
python build_notes.py --mode chunk10     # 每 10 条一篇（415 篇，碎）

# 4) 上传 IMA（断点续传，重跑即接上）
node ima_upload_help.cjs                 # 全量
node ima_upload_help.cjs --limit 1       # 先测 1 篇
node ima_upload_help.cjs --reset         # 清断点重来
```

脚本位置：`D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\`
- `pdd_help_api.py` —— 接口采集器（主）
- `build_notes.py` —— 切 md（`--mode hybrid|module|chunk10`）
- `ima_upload_help.cjs` —— 批量传 IMA（断点续传）
- `cdp.py` —— 通用 CDP 工具（`--url` 列表页 / `--on <片段> "<js>"` 执行 / `--open <url>` 新标签）
- `pdd_help_grab.py` —— 旧的逐条点击版（**慢，仅接口失效时备用**）

## 切分粒度怎么选（重要）

全站 3,473 条 / 62 万字，实测：

| 模式 | 篇数 | 平均 | 最大 | 评价 |
|---|---|---|---|---|
| chunk10（每10条） | 415 | 6 KB | 24 KB | 太碎，同话题被切开 |
| module（每模块） | 134 | 21 KB | **256 KB** | 大文件传 IMA 有风险 |
| **hybrid（>60条才拆）** | **158** | **11 KB** | **74 KB** | ✅ **推荐** |

**为什么选 hybrid**：小模块（如「小额打款」36 条）整块一篇，检索一次命中全部同话题内容；大模块（「订单售后」195 条）拆成 4 篇，避开 IMA 单篇体积上限。中位体积 10 KB，超 60 KB 的只有 10 篇。

**IMA 单篇体积上限的经验值**：控制在 **80 KB 以内**安全（踩过 `ENAMETOOLONG`，大 md 不能走命令行传参，要 `require()` 直接调）。

## 上传 IMA 的正确姿势

```js
// ① 建笔记（import_doc 没有 title 参数，标题必须写在 content 首行）
const raw1 = await imaApi('openapi/note/v1/import_doc', { content_format: 1, content: md全文 });
const noteId = JSON.parse(raw1).data.note_id;

// ② 挂进目标文件夹（folder_id 是关键；省略就落到根目录）
await imaApi('openapi/wiki/v1/add_knowledge', {
  media_type: 11, title, knowledge_base_id: KB, folder_id: FOLDER,
  note_info: { content_id: noteId }
});
```

**必须回读验证**（只看接口返回不够）：
```js
imaApi('/openapi/wiki/v1/get_knowledge_list', {
  knowledge_base_id: KB, folder_id: FOLDER, limit: 50, cursor
})  // 循环到 is_end，数条目、查重名
```
实测 158 篇全部落地、0 标题异常、上传脚本 `--limit 1` 先试跑再全量（每篇间隔 1.2 秒，158 篇约 8 分钟）。

## 坑：不同模块可能同名
全站有 **1 组**同名二级模块：「店铺装修」同时属于「店铺管理」(id=99) 和「海淘店铺」(id=171)。生成时文件名用 `一级__二级` 不会冲突，但 IMA 里会出现两篇同名笔记（**IMA 无改标题接口，只能用户手删**）。靠正文首行的「来源：→ 一级 / 二级」区分。



### 1. 猜接口一定失败`/latitude/api/help/topic/list`、`/api/help/topic/list` 全返回 `{"error_code":40010,"error_msg":"未知URL"}` —— 参数对了也没用，路径是错的。**不要猜，去挖。**

### 2. hook XHR 抓不到接口
注入 `XMLHttpRequest.prototype.open` + `fetch` 之后翻页，`window.__log` 是空的 —— 因为帮助中心列表**翻页是前端本地切**，不发请求（点第 16 页后 URL 没变、DOM 只留 2 条）。
**正确姿势**：用浏览器自己的资源日志反向找，**不用管 hook 时机**：
```js
performance.getEntriesByType('resource')
  .filter(r => /help|topic|faq|knowledge|list|query/i.test(r.name))
  .map(r => r.name)
```
实测就这么挖出了 `cambridge/api/businessLesson/lessonList`。

### 3. 列表点进文章再返回，页码会重置到第 1 页
逐条点击版必须**每次点击前检查当前页并重翻**（`li[class*=PGT_pagerItemActive]` 读当前页）：
```js
// 检查
var act = document.querySelector('[class*=PGT_pagerItemActive]'); act.innerText
// 翻页
var ls = document.querySelectorAll('li[class*=PGT_pagerItem]');
for (...) if (ls[i].innerText.trim() === '目标页') ls[i].click();
```

### 4. 分页控件只显示「1 2 3 4 5 … 末页」
点第 6 页会失败（`no page 6`）—— 中间页要先点 5 让 6 冒出来。**这也是逐条点击版不可靠的原因之一，接口版没这问题。**

### 5. 正文选择器（逐条版用）
```
div.rule-content        ← 干净正文，含面包屑首行「一级模块 / 标题」，末尾有「这条知识对你有帮助吗？」要裁掉
div.TopicItem_topicItem__39gzL   ← 列表条目（CSS Modules，class 带 hash）
```

### 6. contentText 是 HTML，必须清洗
含 `<p>` `<span style="...">` `<a href>` `<img src>`。清洗规则：
- `<img>` → `[图]`（库里不需要图片）
- `<a>` → 只留文字（URL 太长；规则表链接会失效）
- `</p>` `</div>` `</li>` `<br>` → 换行；`</td>` → ` | `
- 去 `\u200b`、把 `\xa0` 换空格、压缩连续空行

### 7. 视图窗口别缩放，浏览器别别人用
十一扫码登录时**不缩放**；采集期间不要让别的脚本/窗口碰同一个 Chrome（会互相干扰 DOM 状态）。

### 8. 环境
- 开采集前先 `netstat -ano | grep 9555` 确认端口，再 `curl http://127.0.0.1:9555/json/version` 确认 CDP 活着（**端口 LISTENING ≠ CDP 可用**，9222 就遇到过端口在但服务不通）
- 飞书/IMA 上传是另一回事，**读飞书要关代理**，调 IMA 走 node + `ima_api.cjs`
- 后台跑用 `terminal(background=true, notify=true)`，脚本自己写进度文件，便于断点

## 产出与去向

```
D:\Agent.GongZuoQu\Hermes.GZQ\数据--PDD帮助中心\
  api\modules.json          模块树（22 一级 / 136 二级）
  api\mod_<id>.json         每个二级模块的条目（含全文）
  笔记\<模块>_NN.md         切好的 md
  .progress_<id>.json       逐条版断点
```

IMA 目标：知识库「拼多多-电商学习📚」`MxOZ443nc9bRu7vPPaXwcCG6adRfPe61qKbM5P_DuCY=`
下的文件夹「拼多多丨帮助中心」`folder_7492456249585829`
（根目录还有：日常学习-记录 / 原著材料 / 多多进宝 / 营销活动 / 营销工具 / 规则相关 / 推广营销 / 基础知识）

## 注意事项

- 登录环节**必须十一自己扫码**，绝不碰验证码（平台风控 + 不合规）
- 403/验证页出现 → 亮黄提醒 + 暂停等人工，不要硬刷
- 采集只读，不改店铺任何数据
- 接口每页间隔 `sleep 0.35` 防限流（实测 136 模块全量跑完无限流）
