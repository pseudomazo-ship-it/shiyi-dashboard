---
name: hermes-desktop-workspace
description: "Bind a chat window to a folder; confirm workspace changes."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [hermes, desktop, workspace, project, desktop_project, session, folder]
---

# Hermes Desktop Chat Window — Workspace Binding

A Hermes desktop chat window can be *bound* to a folder: that folder becomes the window's workspace. This skill covers HOW to bind it (the `desktop_project` tool), the user's standing rule about binding, and how to detect + confirm a workspace change.

## When to use
- User attaches a folder to a chat window, or says "this window's workspace is <path>" / "以后这个窗口就用这个文件夹".
- User asks to move a chat window to a different folder/project.
- You need to confirm which project/folder a window is currently anchored to.

## Bind a chat window to a folder (desktop_project)

Use the `desktop_project` tool (NOT `cd`), the intentional way to move a session's workspace:

```
desktop_project(action='create', name='<human name>', path='D:/.../<folder>')
desktop_project(action='switch', name_or_slug_or_id='<id>')   # move an existing window
```

- `create` = make a new project anchored to `path` AND switch this chat into it.
- `switch` = deliberately move this chat into an existing project by name/slug/id.

## Verify the bind actually took effect
Don't trust the create/switch result string alone:
1. `desktop_project(action='list')` → the new project should show `active: true`.
2. `terminal pwd` → should now be the bound folder (the session cwd follows it).
3. `ls -la` the folder → it exists and is writable.

If `pwd` still shows the old dir, the window did NOT re-home — re-do the switch or surface it to the user rather than assuming.

## This user's standing rule (十一 — 2026-09-01)
> 聊天窗口附加的哪个文件夹，该文件夹就是这个聊天窗口以后的工作区。
> 如果发生变化需要提醒这个聊天窗口是否变更工作区。

So for this user:
- A chat window's folder (attached or named by them) = that window's permanent workspace. All subsequent work in that window uses it.

### ⚠️ 2026-09-20 补充规则：产出文件**不再默认放窗口工作区**

十一 2026-09-20 定（**产出落盘以这条为准**，窗口绑定仍管上下文）：

> 文件就只需要一份最新的（旧的、副本删除）放在工作区内，工作区根：
> `D:\Agent.GongZuoQu\Hermes.GZQ`（**2026-09-21 改；旧根 `D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\Hermes Agent` 已弃用，已由用户删除**）
> 所有产出文件固定放这里；每交代新任务/新内容 → 自行在该根目录下新建子文件夹分类存放（按任务 + 文件信息命名），**不再默认丢窗口工作区**。

执行要点：
- **产出落盘位置 = 全局工作区根**下的分类子文件夹（`数据--xxx` / `文档--xxx` / `脚本--xxx` / `软件--xxx` / `项目：xxx`），**不是** `desktop_project` 绑定的窗口工作区。
- **已有合适分类 → 归入**；**全新主题 → 自建文件夹**（不再问）。
- **只留最新一份**：旧版直接删，**不留副本**（含给桌面预览的 `desktop-deliver` 副本）。
- ⚠️ **目录名里的 emoji 会被改成 `--`**：`公司🔴主体财务仓库快递` → `数据--主体财务仓库快递`，`电商💚店铺产品数据运营` → `电商--店铺产品数据运营`。**写路径前先 `ls`/`os.listdir` 确认实际名字。**
- ⚠️ **中文路径在 bash 里可能匹配失败**（`cd "中文目录"` 报 No such file / 通配符 `公司*主体*` 也失配，编码问题）：改用 Python（`os.listdir`/`os.path.exists`）或 Hermes 文件工具处理，不要硬用 shell。
- **交付**：直接给工作区路径；不再复制到 `desktop-deliver` 等中转目录。

### ⚠️ 2026-09-21 补充规则：**永久工作区 vs 临时工作区**（改动权限收紧）

十一 2026-09-21 定（**优先级高于上面“只留最新一份、旧版直接删”的惯性**）：

> 永久的工作区还是你目前正在使用的这个。以后只会单独临时给你分配工作区，到时候我会单独跟你讲。
> 临时工作区可能是多个开放入口，大家一起在里面工作，去拄、修改某一文件。临时工作区完全由你指定和管理；
> **即使已经分配给你，凡涉及修改、调整、覆盖、移动、重命名或删除文件，都必须先征得我明确同意。**

| 场景 | 改 / 删 文件 |
|---|---|
| **永久工作区** `D:\Agent.GongZuoQu\Hermes.GZQ` | 按“只留最新版”照旧可直接删旧版 |
| **临时工作区**（多人共用 / 多入口） | **一律先问**，拿到明确同意才动 —— 不自动删、不自动覆盖、不自动改名 |

- **为何**：临时工作区是**多人共用**的，里可能有**别人正在用或引用的文件**。按“只留最新一份”自动删，很可能删掉别人还要的东西。
  **这种地方“先问”优先于“效率”。**
- 十一点名分配前，**默认只在永久工作区干活**；
  **不主动扫描/归集/保全其他 Agent（Codex、Work Buddy 等）的工作区**（除非他点名）。
- **需要借用其他 Agent 工作区里的内容时**：**先拷一份到自己的永久工作区**，再在副本上改 —— **绝不直接改别人工作区里的原件**。
- **If a window's workspace is about to change (or you notice it changed), tell the user and ask to confirm** — never silently re-home a window. First-class requirement.
- When they create a NEW chat window (or a new folder under an existing project), the same rule applies.

### ⚠️ 写产出前先确认「当前根」（2026-09-21 实测踩坑，两次同类错）

**规则：动手建文件/文件夹前，先 `ls` 一次工作区根。** 不要凭记忆里的路径直接写 —— 根会整体迁移，而**旧的 `desktop_project.primary_path` 不会自动跟着更新**。

两次实际踩到（同一天）：
1. 按惯性把成品写进用户的 `Work Buddy\运营、商品工作区\`（那是**用户自己的区**，不是我的产出区）→ 用户问「为什么文件不在工作区」。
2. 在**已作废的旧根** `…【龙虾】三哥工作区\Hermes Agent\` 下新建了项目文件夹（根当天 08:19 已迁到 `D:\Agent.GongZuoQu\Hermes.GZQ`，我 09:47 还在旧路径建）→ 用户问「为什么不在最新的工作区」。

**怎么做：**
- 建文件/文件夹前：`ls -1 <根>`（或 `find <根> -maxdepth 1`）。已有合适分类 → 归入；没有 → 新建。
- **权威规则文档就在工作区里**：`<根>\文档--Hermes工作规则\Hermes工作规则汇总_*.md`（含工作区根、命名前缀、md→IMA 口径）。**根一旦迁移，先读这份再动手**，别只信记忆或 `desktop_project` 的路径。
- **判断根是否已迁移的信号**：老 `Hermes Agent\` 下只剩你一两个新建的文件夹（旧内容全没了）= 已经被整体迁走，你在空壳上干活。
- `desktop_project(action='list')` 的 `primary_path` **可能还是旧路径**（实测：整根迁移后仍指向已删除的旧目录）——它只能说明窗口绑过哪，不能证明目录还在。列完还要 `ls` 验证。

### 已建错地方 / 迁移文件夹时的路径坑（2026-09-21 实测）

- **`mv` 报 `Permission denied` 或 `Device or resource busy` 的最常见原因 = 这个 shell 的 cwd 就停在要迁/删的目录里**。先 `cd` 到无关目录（如 `cd /d/` 或 `cd /tmp`）再 `mv`/`rm -rf`。
- `rm -rf` 清不掉的空壳目录，可先用 `robocopy 源 目标 /E /MOVE /NFL /NDL /NJH /NJS`（Windows 原生）兜底复制+删源；它也可能留下一个删不掉的空目录 —— **空壳无数据风险，报告给用户、等句柄释放（重启）再清，别反复重试**。
- **MSYS 路径不要直接喂给原生程序**：`python /d/Agent.GongZuoQu/x.py` 会被原生 python 解成 `D:\d\Agent.GongZuoQu\x.py`（报 No such file）。给 git/python/node 等原生程序用 `D:/Agent.GongZuoQu/x.py` 这种正斜杠**原生盘符**路径；`/d/...` 只适合 bash 内建命令（`cd`/`ls`）。
- 迁完后**必须回头改硬编码旧路径的转发脚本**（例如 `~\.hermes\scripts\` 下给 cron 用的入口脚本里的 `TARGET`）——不改的话定时任务到点直接失败。

Worked bindings for this user:
- 日常沟通🌅 → 已改名 `---日常沟通---`（去 emoji）；旧根 `...\Hermes Agent\---日常沟通---`，2026-09-21 随整根迁到 `D:\Agent.GongZuoQu\Hermes.GZQ\---日常沟通---`（原 desktop project id `p_c466f6ed`，created 2026-09-01）。
- Project roots under `...\三哥工作区\Hermes Agent\`: 电商💚店铺产品数据运营 / 公司内部事项沟通🔴 / 日常沟通🌅 / 软件：自动处理退款工作台.

## Note: window workspace vs global workspace
- This is a **chat-window-level** workspace, set via `desktop_project`. Separate from the user's **global** work root (**2026-09-21 起 = `D:\Agent.GongZuoQu\Hermes.GZQ`**；旧根 `D:\...\三哥工作区\Hermes Agent` 已弃用并由用户删除) and from the process-level `cwd`. Binding re-homes THAT window only.
- A newly created project shows `active: true`; the previous active project flips to `active: false`. Confirm the right one is active for THIS window.

## Pitfalls
- Don't use raw `cd` to move a chat window's workspace — use `desktop_project`; `cd` changes the process cwd for the current turn but doesn't re-home the window's persistent project association.
- If a folder doesn't exist yet (user just named a new one), create may still succeed — the empty folder is made on the fly. Verify it exists before assuming the bind is usable.
- Don't silently switch a window's workspace mid-task. If the user asked for something and you realize the current window is bound to the wrong folder, surface the mismatch and ask.
