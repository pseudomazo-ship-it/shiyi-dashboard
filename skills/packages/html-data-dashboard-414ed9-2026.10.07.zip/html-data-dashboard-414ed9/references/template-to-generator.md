# 「别人手搓的单文件看板」→ 生成器（完整配方）

来源：2026-10-06 十一丢来一份新版《数据日报》HTML（55KB，数据全部写死在 JS 里），
说「**以后在这个日报看板内更新数据**」。产出 `scripts/daily_dashboard_v2.py` + `scripts/templates/daily_report_v2.html`。

## 0. 先判断「要改的是设计还是数据」

手搓看板的形态：CSS 全在 `<style>` 里、数据是 `<script>` 里几个 JS 字面量
（`const names=[…]`、`const data={day:{…},d7:{…},…}`、`const monthly=[…]`，明细行是 `"a,b,c|d,e,f"` 管道串）。

- ❌ **不要重写 HTML/CSS** —— 那样做出来的和他给的**长得不一样**，等于白做。
- ✅ **模板锁成文件，生成器只做「字面量替换」**：取数 → 算出 JS 字面量 → 正则替换进模板 → 写盘。
- 模板另存 `scripts/templates/<name>.html`；生成器**复用旧生成器的取数与聚合**
  （本次用 `importlib.util.spec_from_file_location` 直接 import `daily_dashboard.py`，
  拿它的 `fetch_all()` / `build()`，不重写一遍取数）。
- 判断哪些是「数据」：把他给的那份产物里**每次都会变的**挑出来 = 数据
  （日期／金额／店名／结论文案／预警条目／表头计数），其余 = 设计。

## 1. 🔴 回归验证法：拿旧产物当标准答案（最省事、最可靠）

这类产物**自带一个基准**：只要基准日规则一致（如「23:00 前报前天」），
用同一份源数据重跑，生成的数字**必须与旧产物逐位相同**。

```
比对项：kpis（含环比）/ totals / score / total / rows（明细串）/ monthly / 预警文案 / 结论文案 / 表头计数
```

本次靠这个抓出 **4 个 bug**（预警①对比基准错、小结「标准线」对齐错、`万万`重复、`names` 错位）
—— **没有这个基准，这些错都会静默上线**。

⚠️ **只比集合不比顺序**：`rows` 的内部分配顺序可以不同（见下条），要另外单独验「同序」这条。
⚠️ 模板原件的 `names` 顺序可能**不是**按业绩排的（本次就不是）—— 只要它内部自洽就正确，
**别为了「和原件一致」去改自己的排序逻辑**，JS 渲染时会自己重排。

## 2. 🔴 按下标取值的映射：`names[i]` ↔ `rows[i]` 必须严格同序

手搓看板里常见这种写法：

```js
function rows(raw){return raw.split("|").map((s,i)=>{const a=s.split(",");return {name:names[i],…}})}
```

店名是**按下标**从 `names` 取的，`rows` 串里**只有数值没有店名**。
⇒ 一旦错位，**全表店铺张冠李戴，而页面看着完全正常**（不报错、排版不变），最难发现。

**做法**：定一个**全局唯一次序**（本次 = 30天业绩降序），`names` 和**所有时段**的 `rows` 都用它；
某店在某档没有数据时**仍要占位**（补 `0.00,0.0,…`），否则后面全错位。

```python
order = sorted(s30, key=lambda x: -s30[x]["p"])      # 全局唯一次序，先算一次
built = {k: build_period(m, base, k, P[k], order) for k in periods}
names_js = json.dumps(order, ensure_ascii=False)     # 与所有 rows 同序
```

**自检**：`len(names) == len(rows.split("|"))`，再抽一行核对「该店该档的业绩」能对上。

## 3. 🔴 正则替换越界：`.*?</div></div>` 会吞掉后面一大段

替换头部 `<div class="stamp">…</div>` 时写成 `<div class="stamp">.*?</div></div>`
（以为后面还有一层闭合）→ 非贪婪 `.*?` 会一路找到**后面第一个** `</div></div>`，
把中间整块 HTML（含 `</section><section>`）一起删掉。

**症状**：页面照样能生成，但 `html.count('<section') != html.count('</section>')`（本次 9 / 7）。

**做法**：
1. 替换前确认目标的**真实闭合层数**（`<div class="stamp">…</div>` 只有一层）；
2. **生成后必跑配平自检，不配平就中止写盘**：
   ```python
   for tag in ("section", "div", "article", "ul"):
       if t.count("<" + tag) != t.count("</" + tag + ">"):
           print("❌ 结构自检失败:", tag); sys.exit(1)
   ```
3. 替换统一用 `re.subn(pat, lambda m, s=new: s, tpl, count=1, flags=re.S)`——
   **lambda 返回 `s` 可以避开反斜杠 / `\1` 被解释的问题**。
4. **替换后打印未匹配的 pattern**（`if cnt == 0: print("⚠️ 未匹配", pat[:60])`）——
   否则某个正则该改的地方悄悄没改，你还以为成功了。

## 4. ⚠️ Python 里给「含 % 的中文句子」做 `%` 格式化 → `ValueError`

`"…高于 46% 的 %d 家店铺" % n` 会炸：
`ValueError: unsupported format character '?' (0x7684)`（`%` 后面那个汉字被当成格式符）。

- **规矩**：中文字符串里的字面 `%` 一律写 `%%`；或改用 `.format()` / f-string。
- 同源 bug：`"%s万" % total`，而 `total` 本身就是 `"203.42万"` → 输出 `"203.42万万"`。
  **带单位的字符串变量，拼接前先确认它是否已自带单位**（本次两处都犯了，靠回归比对才发现）。

## 5. 注入「密码门」（原模板没有，线上又必须有）

旧看板的门禁可以直接搬：CSS `#gate` + HTML 覆盖层 + JS（FNV 哈希 + sessionStorage）。要点：
- 内容容器加 `id="app" style="display:none"`，`unlock()` 里 `gate.style.display='none'; app.style.display=''`；
  ⚠️ **先确认模板的主体容器叫什么**（本次是 `<main class="page">`，不是旧版的 `#app`）。
- **哈希必须用 `Math.imul`**（`x * 0x01000193` 超双精度 → 哈希不匹配 → 密码永远进不去）。
- 盐值与哈希**沿用旧的**（本次 `fnv(pw+'shiyi-daily-2026') === 'e818342'`，密码 `11`），
  这样别处已登录的窗口和用户习惯都不变。
- 新 CSS 用**模板自己的设计令牌**（`var(--surface)/var(--line)/var(--blue)/var(--red)`）——
  别把旧看板的 `--brand/--ink3/--surface2` 搬进来，那些变量在新模板里**不存在**，样式会静默失效。
- ⚠️ 改完用 `drive_preview` **输一次密码**验一遍 —— 桌面预览窗能直接输入。

## 6. 非破坏性上线：先上新路径，别覆盖旧产物

十一还没拍板时，**不要直接覆盖线上正在用的那份**：
- 新产物先推到一个**新路径**（本次 `daily/v2/index.html` → `/daily/v2/`），旧路径原样不动。
- 推送只 `git add <新目录>`，**别 `git add -A`** —— 这类 repo 常有别的任务在推。
- 核实打**远端**：`curl -s ".../daily/v2/?v=$(date +%s)"` 后 grep 标题／生成时间／店数／哈希；
  **别只看 `git push` 返回 0**（返回 0 ≠ 线上已更新，Pages 还要构建 30~90s）。
- 切不切主路径 → **交给十一拍板**。

## 7. 交付话术（他要的是「能用的成品」）

- 给**链接**（他手机上看）+ **本地副本路径**（桌面上看）。
- 把「我拿旧产物当基准逐位比对」这件事**写给他看** —— 这是最能建立信任的一句。
- 把「我自己写错又修掉的地方」**点名列出来**（他要求「给结果前全面自检，把通过项和问题一并发出」）。
- 结尾**只问真正要拍板的 1~2 件事**（本次：切不切主路径 / 缺的那天数据补不补），
  ⛔ 不要抛多题 clarify 表单（他会回传全空、然后说「停下」，见 `feishu-api` 的
  `references/monthly-metric-contest.md`）。
