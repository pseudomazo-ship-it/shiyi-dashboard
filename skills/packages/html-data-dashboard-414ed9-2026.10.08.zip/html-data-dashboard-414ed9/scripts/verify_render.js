// Verify a single-file HTML dashboard actually renders (not just parses).
// Mocks document/window/sessionStorage/btoa/etc then runs the real <script>s.
// Usage: node verify_render.js <path/to/dashboard.html> [expected_total_sales_substring]
// Prints: whether it threw, rendered card/table sizes, row count, resultMeta,
// and the value of the first stat card containing '总销售额'.
// Uses: confirm a data-payload swap landed and the page opens without a browser.
const fs = require('fs');
const file = process.argv[2];
const want = process.argv[3] || '';   // e.g. '88,247,790'
if (!file) { console.error('usage: node verify_render.js <dashboard.html> [want_substr]'); process.exit(2); }
const html = fs.readFileSync(file, 'utf8');

function makeEl(id){ return { id, tagName:'div', value:'', textContent:'', innerHTML:'', style:{},
  classList:{ add(){}, remove(){}, contains(){return false}, toggle(){} },
  addEventListener(){}, appendChild(){}, querySelectorAll(){return []}, querySelector(){return null},
  focus(){}, select(){}, dataset:{} }; }
const elements = {};
function get(id){ if(!elements[id]) elements[id]=makeEl(id); return elements[id]; }

global.document = {
  getElementById: (id)=>{ if(id==='searchInput'){ const e=makeEl(id); e.addEventListener=()=>{}; return e; } return get(id); },
  querySelectorAll: ()=>[], querySelector: ()=>null, createElement: ()=>makeEl(''),
  body: { classList:{ add(){}, remove(){}, contains(){return true}, toggle(){} } },
};
global.window = global;
global.sessionStorage = { getItem:()=>'', setItem(){} };
global.setInterval = ()=>0;
global.setTimeout = (fn)=>fn && 0;

global.btoa = (s)=>Buffer.from(s,'utf8').toString('base64');

// Run every <script> block in order
const scripts = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
let ok = true;
try {
  for (const s of scripts) {
    if (!s.trim()) continue;
    const fn = new Function('document','window','sessionStorage','setInterval','setTimeout','btoa','Intl','Date','Number','Math', s);
    fn(document, global, global.sessionStorage, ()=>0, ()=>{}, global.btoa, Intl, Date, Number, Math);
  }
} catch (e) { ok = false; console.log('SCRIPT THROW:', e.message); }

console.log('threw:', !ok);
const stats = (elements['statsCards']||{}).innerHTML || '';
const table = (elements['tableBody']||{}).innerHTML || '';
console.log('statsCards chars:', stats.length);
console.log('tableBody chars:', table.length);
console.log('table row count:', (table.match(/<tr/g)||[]).length);
console.log('resultMeta:', (elements['resultMeta']||{}).textContent || '(n/a)');
const statText = stats.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ');
const i = statText.indexOf('总销售额');
if (i >= 0) console.log('sales card:', statText.slice(Math.max(0,i-2), i+24));
if (want && statText.indexOf(want) >= 0) console.log('MATCH want:', want, '=> FOUND');
else if (want) console.log('MATCH want:', want, '=> NOT FOUND');
