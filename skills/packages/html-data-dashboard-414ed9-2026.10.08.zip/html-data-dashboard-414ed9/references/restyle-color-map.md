# 单文件看板换配色 · 配方与映射表

**实测日期**：2026-09-27（十一第二次要「换个美化风格」；第一次 2026-09-25 是整体 UI 重构）

## 结论：别重写 CSS，做色值映射替换

| | 重写 `<style>` | **色值映射替换** |
|---|---|---|
| 工作量 | 几小时 | **几十秒** |
| 回归风险 | 高（版式、折叠、sticky、响应式都可能被碰坏） | **极低（只动颜色字面量）** |
| 可对比性 | 说不清「到底哪里变了」 | **diff 一看就是色值** |

## 实测数据

- 原件 `<style>` 里共 **53 个不同 hex**，全文替换命中 **100 处**
- 产物 ~546 KB（体积由内嵌数据决定，换色不影响）
- 替换后结构自检：`section 8/8`、`div 90/90`、`function render 8→8`、旧色残留 0

## 步骤

```python
import re
# ① 列原件 <style> 里所有色值 —— 这步有诊断价值（见下节）
css = txt[txt.find("<style>"):txt.find("</style>")]
hexes = sorted(set(re.findall(r"#[0-9a-fA-F]{6}\b", css)))

# ② old→new 映射表，全文 str.replace（表见下）
new = txt
for a, b in MAP.items():
    new = new.replace(a, b)

# ③ 顺带收圆角（目标风格更克制时）
new = new.replace("border-radius:20px", "border-radius:16px")
new = new.replace("border-radius:18px", "border-radius:12px")

# ④ 后检断言
assert new.count("<section") == new.count("</section>")
assert len(re.findall(r"<div[\s>]", new)) == new.count("</div>")
assert new.count("function render") == orig.count("function render")
assert not [h for h in MAP if h in new]     # 旧色残留必须为 0
```

⚠️ 正则**别塞进 f-string**（反斜杠会 `SyntaxError`，整个 cell 不执行）——先算成变量。

## 诊断信号：原件里混进了 Fluent Design 色值

原件出现 `#0078d4` `#323130` `#605e5c` `#107c41` `#00cc6a` `#8a8886` `#c8c6c4`
→ 这些**不是生成脚本可以产出的**（脚本只产蓝系 `#2563eb`/`#e7eaf0` + 一组语义色）
→ **说明 HTML 被别的窗口 / agent 直接改过**

**处理**：先以生成脚本重出一份干净原件再换色。否则换色 = 把别人的未审改动固化进新风格。
（同源现象：曾发现生成的 HTML 被塞进 9 条额外 CSS 规则，其中一条把手机端 `.kpis` 改成
`position:static`，把「顶部指标卡不冻结」的口径反向覆盖了。）

## 「源色板 → Stripe Style」映射表（可直接复用）

Stripe 目标色板：主色 `#635bff` / 深蓝 `#0a2540` / 背景 `#f6f9fc` / 边框 `#e6ebf1` /
成功 `#0e9f6e` / 警告 `#c47f00` / 危险 `#e0426a` / 点缀 `#7a73ff` `#00a8cc`

```python
MAP = {
 # 主色系（蓝/靛）→ Stripe 紫
 "#2563eb":"#635bff","#3b82f6":"#7a73ff","#1d4ed8":"#4f46e5",
 "#eef4ff":"#f0efff","#a5b4fc":"#b3aeff","#7facf7":"#a49dff",
 "#0078d4":"#635bff","#005a9e":"#4f46e5","#106ebe":"#5850e0",
 "#b3d8f2":"#d9d6ff","#deecf9":"#eeecff","#d9e5ef":"#e3e8ef",
 "#f5f9fd":"#f7f9ff",
 # 背景 / 边框 / 中性
 "#f4f6f9":"#f6f9fc","#fafbfc":"#f8fafc","#fafcff":"#f8fafc",
 "#e7eaf0":"#e6ebf1","#d5dae3":"#cbd5e1","#e1e1e1":"#e3e8ef",
 "#f3f2f1":"#f6f9fc","#faf9f8":"#f8fafc","#c8c6c4":"#cbd5e1",
 "#e8e7e6":"#e6ebf1","#fde7e9":"#fdecf1",
 # 文字
 "#12151b":"#0a2540","#323130":"#0a2540","#5a6474":"#425466",
 "#605e5c":"#425466","#6b6967":"#425466","#8a8886":"#8898aa",
 "#98a1b0":"#8898aa",
 # 语义色（成功 / 警告 / 危险）
 "#0ea472":"#0e9f6e","#00cc6a":"#0e9f6e","#107c41":"#0e9f6e",
 "#e9f8f3":"#e6f6f1","#dff6e8":"#e6f6f1","#cfeee2":"#c9ece0",
 "#4fd1a5":"#5ddba9",
 "#e08600":"#c47f00","#8a6200":"#a76a00","#fff7e8":"#fff8e6",
 "#fff3d0":"#fff4d6",
 "#e5484d":"#e0426a","#a4262c":"#c7335a","#fdeeee":"#fdecf1",
 # 点缀
 "#7c5cf0":"#7a73ff","#6b4bb7":"#635bff","#f2effe":"#f1f0ff",
 "#eee8fa":"#f1f0ff",
 "#0891b2":"#00a8cc","#007c91":"#00a8cc",
 "#e6f7fb":"#e6f8fb","#e3f5f8":"#e6f8fb",
}
```

## 换到别的风格

映射表是「任意源色板 → 目标色板」的一次性产物。换目标风格时保持同样结构，
把右侧换成 `stylekit` 的 `fetch-style.py <slug>` 打印出的 colors 值即可。
**别为了好看顺手改 `id`/`class` 或 JS** —— 页面渲染完全依赖它们。
