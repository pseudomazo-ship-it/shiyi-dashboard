# 看板交互四件套（2026-10-08 定，领航员看板 + 数据日报 双站实做）

十一 对「看板」有一组固定追问，做新看板时**默认就要带上**，别等他提：

```
① 每个板块能展开收起、默认收起
② 时段/口径筛选按钮【单独一条放页面最顶部】，切换时【全页联动】
③ 趋势线每个节点，鼠标放上去显示「日期 ｜ 数值」
④ 明细表的指标列都能点表头排序（升序/降序）
```

他在同一天里对**两个不同的看板**各提了一遍 ③④ —— 属于「同一个流程做了第二次」，
所以这份配方是默认项，不是可选项。

---

## ① 折叠：只包 `.card`，KPI 卡不折

```js
/* CSS: .card.collapsed > *:not(h2){display:none!important}
        .card h2{cursor:pointer;user-select:none}
        .card h2::after{content:"▾";margin-left:8px}
        .card.collapsed h2::after{transform:rotate(-90deg)} */
document.querySelectorAll('.card > h2').forEach(h=>h.onclick=()=>h.parentNode.classList.toggle('collapsed'));
document.querySelectorAll('.card').forEach(c=>c.classList.add('collapsed'));   // 加载即全部收起
```

- **KPI 卡（`.kpis`）不折叠** —— 一进来就要看到数。
- ⚠️ 收起态里 `clientWidth === 0`，里面的图会画成极小尺寸 → 必须配「宽度兜底 + 展开时重绘」
  （见 SKILL.md 第 19 条）。
- ⚠️ 验证时**先把板块点开再量**，否则量到 0 或空。

---

## ② 时段按钮置顶 + 全页联动（关键：一个 data-ts 走天下）

**先想清楚**：时段切换要影响的不只是柱子/线，还包括 KPI 四卡、优化建议、区间总结、
花费板块、店铺明细。这些东西**散在不同板块里**，早期做法是给每个板块各发一个 data 属性
（`.advbox[data-adv]`、`.panel[data-ts]`…）再逐个配对切 —— **漏一个就会出现
「切了时段，只有一块没跟着变」**，而且后人加板块极易忘记同步。

✅ **统一成一个属性**：任何要随时段变的内容，外层都包
`<div class="tsblock" data-ts="0">`（0=当天、1=近7天…），切换只做一件事：

```js
let cur = 0;
function setTs(i){
  cur = i;
  document.querySelectorAll('.tab').forEach((t,k)=>t.classList.toggle('on', k===i));
  document.querySelectorAll('.tsblock').forEach(b=>b.classList.toggle('on', +b.dataset.ts===i));
  // 顺带：重算 sticky 表头的 top、重绘折线（收起态宽度为 0）
  setTimeout(()=>{ if(window.__trendSel) renderLine(window.__trendSel); }, 60);
}
document.querySelectorAll('.tab').forEach((t,i)=>t.onclick=()=>setTs(i));
setTs(0);
```

```css
.tsblock{display:none}   /* 只显示当前时段的 */
.tsblock.on{display:block}
```

- **时段按钮条单独放页面最顶部**（`.tabs-wrap`，在 KPI 之上），别塞进某个板块里。
- 一段内容有多个时段版本时，**并排生成 N 份 `.tsblock`**（服务端预生成，不走前端取数）——
  这样切换是纯 `display` 切换，零延迟、不闪。
- 新加板块时**包一层 `.tsblock[data-ts=N]` 就自动跟上**，不用改 `setTs()`。

---

## ③ 节点悬停：自定义 tooltip，**不要原生 `<title>`**

⚠️ **原生 `title` 会被十一 当成「没有这个功能」**：要停 1~2 秒才弹、样式土、
小圆点上极难命中。第一版用 `title=` 交付后他**又提了一遍**同样的需求 —— 这就是被打回的信号。

✅ **正解**：节点上挂 `data-tip`，全局一个 `#ttip` 浮层 + 事件委托。

```js
(function(){
  var tp=document.createElement('div'); tp.id='ttip'; document.body.appendChild(tp);
  document.addEventListener('mouseover',function(e){
    var t=e.target.closest&&e.target.closest('.pt');      // 多套图共用一个委托
    if(!t||!t.dataset.tip) return;
    tp.textContent=t.dataset.tip; tp.style.display='block';
    var r=t.getBoundingClientRect();
    tp.style.left=Math.min(window.innerWidth-tp.offsetWidth-10,
                  Math.max(10, r.left+r.width/2-tp.offsetWidth/2))+'px';
    tp.style.top =Math.max(10, r.top-tp.offsetHeight-10)+'px';
  });
  document.addEventListener('mouseout',function(e){
    var t=e.target.closest&&e.target.closest('.pt');
    if(t) tp.style.display='none';
  });
  document.addEventListener('scroll',function(){tp.style.display='none';},true);  // 滚动时收起，别飘在错位置
})();
```

```css
#ttip{position:fixed;z-index:9999;display:none;background:#0f172a;color:#fff;
      font-size:12.5px;padding:6px 10px;border-radius:7px;pointer-events:none;
      white-space:nowrap;box-shadow:0 8px 22px rgba(15,23,42,.28);
      font-variant-numeric:tabular-nums}
```

节点生成（HTML 绝对定位那套，见 SKILL.md 第 29 条）：

```python
dots += ('<i class="pt" style="left:%.2f%%;top:%.2f%%;background:%s" data-tip="%s ｜ %s"></i>'
         % (px(i)/w*100, py(v)/h*100, col, day, val))
```

⚠️ **换成 `data-tip` 后要把原生的 `title=` 全部清掉** —— 两套同时存在会「先弹原生的、再弹自定义」，
看着像重影。自检：`html.count('data-tip=')` 应等于节点数、**旧 `title="2026…` 残留应为 0**。

⚠️ 节点数会到几千（本次 2134 个）→ 用**事件委托**（绑在 `document`），不要一个个 `onmouseover`。

---

## ④ 明细表：点表头排序

```python
# 表头：data-col = 列序（0 起），数值列加 data-type="num"
'<table class="table sortable"><thead><tr>'
  '<th data-col="0">店铺</th>'
  '<th data-col="1" data-type="num">业绩</th>'
  '<th data-col="2" data-type="num">环比</th>…'
# 单元格：数值列挂 data-v = 真实数值（排序用），显示文本另算
'<td data-v="%s">%s</td>' % (raw_number, display_text)
```

```js
document.querySelectorAll('table.sortable').forEach(function(tb){
  var body=tb.querySelector('tbody');
  tb.querySelectorAll('th[data-col]').forEach(function(th){
    th.onclick=function(){
      var c=+th.dataset.col, num=th.dataset.type==='num';
      var dir=th.dataset.dir==='asc'?'desc':'asc';
      tb.querySelectorAll('th[data-col]').forEach(function(x){delete x.dataset.dir;x.classList.remove('asc','desc')});
      th.dataset.dir=dir; th.classList.add(dir);
      var rows=Array.prototype.slice.call(body.querySelectorAll('tr'));
      rows.sort(function(a,b){
        var x,y;
        if(num){ x=parseFloat(a.children[c].dataset.v||a.children[c].textContent)||-1e9;
                 y=parseFloat(b.children[c].dataset.v||b.children[c].textContent)||-1e9;
                 return dir==='asc'?x-y:y-x; }
        x=a.children[c].textContent.trim(); y=b.children[c].textContent.trim();
        return dir==='asc'?x.localeCompare(y,'zh'):y.localeCompare(x,'zh');
      });
      rows.forEach(function(r){body.appendChild(r)});
    };
  });
});
```

```css
table.sortable th[data-col]{cursor:pointer;user-select:none}
table.sortable th[data-col]::after{content:"⇅";margin-left:6px;font-size:11px;color:#94a3b8}
table.sortable th[data-col].asc::after{content:"▲";color:#2563eb}
table.sortable th[data-col].desc::after{content:"▼";color:#2563eb}
```

三个必做细节：

- **`data-v` 存真实数值** —— 否则按「62.24%」「1,234」这类显示文本排，会按字符串比大小，
  9.0% 排到 100% 后面。
- **「合计」行必须固定最后**：给它一个 `tr.total`，排序后 `body.appendChild(totalRow)` 补回去；
  否则合计行会被排到中间（十一 的表里都有合计行）。
- **空值/未登记统一沉底**：`|| -1e9` 兜底即可，别让它插在中间。
- ⚠️ 排序是**改 DOM 顺序**，下一次 `renderTable()` 重渲染会复位 —— 可接受；
  要保留就把 `{col,dir}` 存起来在 render 末尾重放一次。

**验证判据（真浏览器，不能用预览面板）**：点表头 → sleep 1s → 读前 3 行的该列值，
**确认是升序**；再点一次 → 确认降序。本次实测：业绩升序 `0.67万 / 0.67万 / 0.68万`，
再点 `31.62万 / 20.65万 / 18.75万` ✅。

---

## ⑤ 「太旷/还是太空」= 要你主动压缩留白

十一 会连着两轮说「占位太空旷了」「如图，还是太空」。空的主因有三类，逐类收：

```
① 板块默认收起 → 看上去一大片空白（这部分是设计，交付时顺口说明一句）
② 统计分档 2×2 排 → 改成【一行排完】（4 档就 4 列）
③ 间距/字号偏大 → 收 page padding、板块 margin-bottom、标题字号、卡片内边距
```

```css
/* ② 分档一行四列（窄屏再降级） */
.bands{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:14px}
@media(max-width:1100px){.bands{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:640px){.bands{grid-template-columns:minmax(0,1fr)}}

/* ③ 压缩留白 */
.page{padding-top:26px;padding-bottom:44px}
.mast{margin-bottom:14px}
.kpis{gap:12px;margin-bottom:14px}
.section{margin-bottom:14px}
.section-head{margin-bottom:10px}
.section-head h2{font-size:16px}
```

⚠️ 用 `minmax(0,1fr)` 而不是 `1fr` —— 列里有长店名/表格时 `1fr` 的 min-content 下限会把列顶开。

**验证「真的排成一行」读几何，不靠肉眼**：四档的 `offsetTop` 应全部相等、
且父容器 `getComputedStyle(...).gridTemplateColumns` 解析出 **4 个等宽值**。

---

## ⑥ 结论/总结区要放【页面顶部】

十一 2026-10-08 明确：「把结论放在顶部（数值水位上面）」。
原来的位置在页面最底部（店铺明细 → 异常预警 → 今日结论），他觉得要翻到底才知道结论。

**默认层级**（新看板照这个排）：

```
KPI 卡
今日结论 / 总结        ← 顶部，紧跟 KPI
数值水位 / 主指标深挖
趋势走势
排行 / 明细
异常预警
长周期（30天）趋势与结论
```

⚠️ 结论区是**随时段切换**的 → 它本身也要包 `.tsblock[data-ts=N]`（见 ②）。
⚠️ 挪板块时注意：`renderSummary()` 之类只按 `id` 找容器，**挪位置不用改 JS**，
但折叠初始化（`querySelectorAll('.card > h2')`）要在挪完之后的 DOM 上跑 —— 顺序别错。

**自查一条命令看板块顺序**（比翻源码快）：
```python
import re
order=[m.group(1) for m in re.finditer(r'<h2>([^<]+)</h2>', html)]
print(order)
```

---

## ⑦ 异常预警板块：每一类都要写出【具体是哪几处】

十一 原话：「近30天重复登记 3 处**要表达出异常细节写出来**」。
只报「重复登记 3 处」不算交付 —— 每一类异常都要列出**日期 ｜ 店名 ｜ 具体数值**：

- **重复登记**：`10-05 ｜ 洗护官方旗舰店　同日登记 2 条（当日业绩 7,491.70 元）`
- **漏登**：`09-12 ｜ 只登了 21/23 家　缺：XXX、YYY`
- **数值离谱**：`近7天 ｜ 植萃草本染发坊　数值 207.20%（退款占 166.54% ＋ 推广占 40.66%，业绩 8,602 元）`

⚠️ **单位别猜**。重复登记那份 `vals` 数组存的可能是**当日业绩金额**而不是百分比 ——
先读生成它的那段代码确认语义再拼文案。本次第一版写成了 `7491.70%`，是标错了单位。
⚠️ 条数用记录里的 `n` 字段，**不要用 `len(vals)`** —— vals 可能是去重后的值列表，
会显示成「同日登记 1 条」（看起来根本不是重复）。

### 🔴 离谱值必须【跨所有时段】查，不能只看当日

本次第一版只在**当天**数据上找离谱店 → 结果「当日无」，而十一 明明在**近7天**那一列看到 207.20%。
根因：**当天的业务是正常的，离谱是长区间累计出来的**。

```python
PERIODS = [("当日", b, b), ("近3天", b-timedelta(days=2), b), ("近7天", b-timedelta(days=6), b),
           ("当月", b.replace(day=1), b), ("近30天", b-timedelta(days=29), b)]
for pname, a_, b_ in PERIODS:
    for n, s in agg(a_, b_):
        if not s["p"]: continue
        sc = (s["r"] + s["a"]) / s["p"] * 100     # 数值 = 退款占比 + 推广占比
        rf = s["r"] / s["p"] * 100
        if sc >= 100 or rf >= 100:                  # 阈值：≥100% 即报
            crazy.append((pname, n, sc, rf, s["a"]/s["p"]*100, s["p"]))
```

文案里要带上**判定门槛**和一句提示（「多半是当日业绩极小、或退款/推广填错，需人工核一遍」），
否则看的人不知道 100% 这条线是哪来的。

---

## 验证口径（这两站统一）

1. **改完生成器 → 重跑生成 → 本地读 HTML 断言**（板块顺序、`data-tip` 计数、`sortable` 表数）。
2. **推送后必须开真浏览器验**（`browser_exec`）——「动作 → 断言」中间 `sleep(1~2)`。
3. **预览面板的结果不能当结论**（点击派发不一定真）。
4. 测悬停时**先切到有趋势线的时段**（如近7天）——「当天」那种柱形图里没有 `.pt` 节点，
   会误报「找不到节点」。本次就先把默认面板当成没节点。
