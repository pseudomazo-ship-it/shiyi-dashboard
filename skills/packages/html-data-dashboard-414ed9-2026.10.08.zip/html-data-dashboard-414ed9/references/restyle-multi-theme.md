# 单文件看板「批量换风格」配方（2026-09-27 实测）

场景：用户说「换个美化风格」「单独复制一份做看板我看一下风格」「多做几个我看看」。
目标：在**不动数据/JS/结构**的前提下，给同一个看板产出 N 套配色供挑选。

实测产物：10 个风格版本，每个 ~678 KB，全程几十秒。

---

## 0. 铁律

- **只改颜色 + 字体 + 卡片圆角。** `id=` / `class=` 一个都不改，`function render` 计数前后必须一致。
- **生产件不碰**：成品 HTML、生成脚本、线上，一律不动。只在试验目录里出副本。
- 用户拍板后才谈「把样式搬回生成脚本」（看板是脚本生成的，手改 HTML 次日会被覆盖）。

```
D:\<工作区>\数据--数据日报\风格试验\
├─ 00_风格对比.html          ← 对比页（缩略图 + 色板 + 链接）
├─ 1_<风格>_日报看板.html     ← 每个风格一个完整可用文件
├─ ...
└─ screenshots\              ← 每版一张首屏截图
```

---

## 1. 穷举原件的颜色（**别只抓 6 位 hex**）

```python
css = html[html.find('<style>'):html.find('</style>')]
hexx   = re.findall(r'#[0-9a-fA-F]{3,6}\b', css)   # ← 必须含 3 位简写
rgbx   = re.findall(r'rgba?\([^)]*\)', css)          # ← 白卡毛玻璃在这
```

实测原件里有：

| 形态 | 例 | 数量 | 漏了会怎样 |
|---|---|---|---|
| 6 位 hex | `#2563eb` `#e7eaf0` | 53 个色值 | — |
| **rgba 白卡** | `rgba(255,255,255,.76/.82/.72)` | **3 处** | **深色主题：底黑卡白，数字看不见** |
| **3 位简写** | `#fff` | **10 处** | 同上（部分） |
| rgba 黑（阴影） | `rgba(0,0,0,.05)` | 6 处 | 深色下阴影几乎不可见（可接受） |

---

## 2. 把散色归成「语义角色」（17 类）

关键：**`surface`（卡片背景）必须单列**，不要跟 `bg`（页面背景）混成一个角色。

```python
SEMANTIC = {
    "surface":  ["rgba(255,255,255,.82)","rgba(255,255,255,.76)","rgba(255,255,255,.72)"],  # 先跑
    "brand":    ["#2563eb","#3b82f6","#1d4ed8","#0078d4","#005a9e","#106ebe"],
    "brand_l":  ["#eef4ff","#deecf9","#b3d8f2","#f5f9fd"],
    "ink":      ["#12151b","#323130"],
    "ink2":     ["#5a6474","#605e5c","#6b6967"],
    "ink3":     ["#8a8886","#98a1b0"],
    "bg":       ["#f4f6f9","#fafbfc","#fafcff","#f3f2f1","#faf9f8"],
    "line":     ["#e7eaf0","#d5dae3","#e1e1e1","#c8c6c4","#e8e7e6","#d9e5ef"],
    "good":     ["#0ea472","#00cc6a","#107c41","#4fd1a5"],
    "good_l":   ["#e9f8f3","#dff6e8","#cfeee2"],
    "warn":     ["#e08600","#8a6200"],
    "warn_l":   ["#fff7e8","#fff3d0"],
    "bad":      ["#e5484d","#a4262c"],
    "bad_l":    ["#fdeeee","#fde7e9"],
    "violet":   ["#7c5cf0","#6b4bb7","#a5b4fc","#7facf7"],
    "violet_l": ["#f2effe","#eee8fa"],
    "cyan":     ["#0891b2","#007c91"],
    "cyan_l":   ["#e6f7fb","#e3f5f8"],
    "white":    ["#fff","#ffffff"],   # ← 最后跑，避免误伤 rgba 里的 255
}
```

**替换顺序有讲究**：
1. `surface`（rgba，带 alpha，最先）
2. 其余语义角色
3. `white`（`#fff` → surface，**必须最后**，否则会先把 rgba 里的 `255` 打碎）
4. 字体 `font-family`（`re.sub(..., count=1)`）
5. 卡片圆角（`re.sub` 只命中 `.card{...border-radius:var(--r)}` / `.kpi{...}`）

---

## 3. THEMES 表 + dark 分支

每个风格给 17 个色 + 字体 + 圆角：

```python
THEMES = {
  "1_Stripe紫": dict(name="Stripe", bg="#f6f9fc", surface="#ffffff", line="#e6ebf1",
      ink="#0a2540", ink2="#425466", ink3="#8898aa",
      brand="#635bff", brand_l="#f0efff",
      good="#0e9f6e", good_l="#e6f6f1", warn="#c47f00", warn_l="#fff8e6",
      bad="#e0426a", bad_l="#fdecf1", violet="#7a73ff", violet_l="#f1f0ff",
      cyan="#00a8cc", cyan_l="#e6f8fb",
      ff='"PingFang SC",system-ui,sans-serif', r_card="14px", r_pill="6px"),
  "4_Linear深": dict(name="Linear Style", dark=True,        # ★ 深色必须打标
      bg="#0a0a0b", surface="#16161a", line="#2a2a30",
      ink="#f7f8f8", ink2="#b4b8c5", ink3="#7a7f8c",      # ★ 浅色文字
      brand="#5e6ad2", brand_l="#1e1f2e",
      good="#27ae60", good_l="#14251c", warn="#f2c94c", warn_l="#2a2517",
      bad="#eb5757", bad_l="#2b1a1a", violet="#8b7fd4", violet_l="#221f38",
      cyan="#2d9cdb", cyan_l="#132430",
      ff='"PingFang SC",system-ui,sans-serif', r_card="10px", r_pill="5px"),
}
```

**深色主题三件事，缺一个就废：**
1. `surface` 用**更高 alpha**（.82→.88 / .76→.82），否则卡片半透会透出深底、发灰。
2. `ink` **整组反转**成浅白（`#f7f8f8`）；`ink2/ink3` 同步提到灰阶亮端。
3. 所有 `*_l` **浅底反转**成深底（`#e6f6f1`→`#14251c`），否则浅底配浅字。

```python
def hex2rgba(h, a):
    h = h.lstrip('#'); h = ''.join(c*2 for c in h) if len(h)==3 else h
    r,g,b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return f'rgba({r},{g},{b},{a})'

if t.get("dark"):
    for old, a in [("rgba(255,255,255,.82)",".88"),
                   ("rgba(255,255,255,.76)",".82"),
                   ("rgba(255,255,255,.72)",".80")]:
        new = new.replace(old, hex2rgba(t["surface"], a))
else:
    for old in ["rgba(255,255,255,.82)","rgba(255,255,255,.76)","rgba(255,255,255,.72)"]:
        new = new.replace(old, hex2rgba(t["surface"], old[-4:-1]))
```

---

## 4. 每次必跑的后检断言

```python
so, sc = html.count('<section'), html.count('</section>')
do, dc = len(re.findall(r'<div[\s>]', html)), html.count('</div>')
assert so == sc and do == dc                              # 结构配平
assert html.count('function render') == orig.count('function render')   # JS 零改动
assert not [o for olds in SEMANTIC.values() for o in olds if o in html] # 旧色零残留
```

实测换色命中数：浅色版 103~144 处；深色版修好后 123 处。
**命中数突然变多，通常是多覆盖了 rgba/`#fff` —— 这是好事，不是坏事。**

---

## 5. 验证：读 computedStyle，不要看截图

深色 bug 一眼扫截图很可能漏过（第一版就是「看着像深色主题」但数字全白底浅字）。
用 CDP 读实际计算值：

```js
const k=document.querySelector('.kpi'), v=document.querySelector('.kpi .v');
({bodyBg:getComputedStyle(document.body).backgroundColor,
  bodyColor:getComputedStyle(document.body).color,
  kpiBg:getComputedStyle(k).backgroundColor,
  kpiValColor:getComputedStyle(v).color})
```

合格判据 —— **卡片底色与文字色一深一浅**：
```
浅色版：bodyBg rgb(246,249,252) / kpiBg rgb(255,255,255) / kpiVal rgb(10,37,64)
深色版：bodyBg rgb(10,10,11)   / kpiBg rgb(22,22,26)    / kpiVal rgb(247,248,248)   ← 对比度 ~13:1
```
同亮（如 bodyBg 黑 + kpiBg 白 + kpiVal 浅灰）就是漏换，回去补 `surface`。

---

## 6. 批量截图（给用户「看」）

**看板通常有密码门**，截图前先用 JS 摘掉，否则截到的是输入框：

```python
cdp('Emulation.setDeviceMetricsOverride', width=1400, height=1000,
    deviceScaleFactor=1, mobile=False)          # 手机优先的场景可换 390x844
for f in files:
    goto_url('file:///' + f.replace('\\','/'))
    wait_for_load(); time.sleep(1.1)
    js("(() => { const g=document.getElementById('gate'); if(g) g.remove();\
         const a=document.getElementById('app'); if(a) a.style.display=''; return 1; })()")
    time.sleep(.8)
    shutil.copy(capture_screenshot(), os.path.join(SHOTS, key + '.png'))
```

**每张图要用 `vision_analyze` 回读确认**，问三件事：主色是什么 / 能不能看到数字 / 有没有显示成密码框。
它抓到过「空白」「截成密码门」「深色版白卡浅字」三类问题——**纯看文件大小是分辨不出来的**。

---

## 7. 对比页

一个纯静态 HTML：卡片网格 = 首屏截图 + 风格名 + 一句话描述 + **6 个色块（主色/文字/背景/好/坏/警告）**，
点图开完整看板。顶部写一句「**全部基于同一份真实数据，只换配色和字体**」——用户最关心的就是数据没被动。
用 `desktop_preview` 打开，报告只说「变了什么 + 自查结果」，**不重复贴看板数据**。

---

## 8. 备选风格来源

`stylekit` 技能（`E:\RuanJian\Hermes\skills\creative\stylekit`）：
```
python scripts/fetch-style.py <slug>      # 打印 colors / tokens / aiRules
```
适合数据看板的：`stripe-style`（紫 #635bff，金融 SaaS）/ `shopify-clean`（绿 #008060，最贴电商）/ 
`notion-style`（黑白极简）/ `linear-style`（深色）/ `apple-style`（留白多，信息密度低）/ 
`corporate-clean` / `github-style` / `dashboard-layout` / `minimalist-flat` / `fluent-design`。

⚠️ 深色风格（Linear）**手机上看偏暗、长时间看数据累眼**——给用户选时要主动说这一句。

---

## 9. 踩过的坑

- **只抓 6 位 hex** → 漏 rgba 白卡 + `#fff` → 深色主题下数字不可见。**本次最大教训。**
- **f-string 里不能有反斜杠**：`f"{len(re.findall(r'<div[\s>]', t))}"` → 
  `SyntaxError: f-string expression part cannot include a backslash`，**整个 cell 一行都不执行**
  （表现为「文件没生成」）。先把正则结果算成变量再插值。
- **原件色值本身就是诊断信号**：若里面混着 Fluent 的 `#0078d4` / `#323130` / `#107c41`，
  说明这份 HTML **被别的窗口/agent 直接改过** → 先用生成脚本重出一份干净原件再换色。
- **截图目录会攒重复文件**（同一版本截两次），交付前清一次，只留一套。
