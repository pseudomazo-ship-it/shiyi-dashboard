# 单文件看板「换风格」实战手册（2026-09-27 数据日报看板）

补充 `SKILL.md` 第 14~18 条。这里放**可照抄的操作顺序**和**踩过的真实数字**。

## 0. 铁律

1. **改生成器，不改产物 HTML** —— 产物次日定时重建，手改白干。
2. **只动「色值 + font-family + 圆角」**；JS、`id=`、`class=`、内嵌数据对象**一个都不碰**。
3. **改前备份**：`shutil.copy(SRC, SRC + ".bak_" + datetime.now().strftime("%Y%m%d_%H%M%S"))`。
4. **试验版放独立目录**（`…\数据--数据日报\风格试验\`），生产件/生成器/线上都不碰，
   等用户拍板再搬回生成器。

## 1. 三遍穷举颜色（漏一遍就出深色 bug）

```python
import re
t = open(SRC, encoding="utf-8").read()

re.findall(r"#[0-9a-fA-F]{6}\b", t)      # 实测 62 个
re.findall(r"#[0-9a-fA-F]{3}\b", t)      # ★ #fff 简写，实测 ×19 —— 漏了就是漏了卡片底
re.findall(r"rgba?\([^)]*\)", t)          # ★ 毛玻璃白卡在这，实测 ×3
```

**只看 hex 6 位 = 交付废品。** 深色主题下漏掉 `rgba(255,255,255,.76)`，
结果就是「页面变黑、卡片还白、文字已变浅」→ KPI 主数值对比度约 1.3:1，肉眼看不见。

### 诊断信号：颜色能告诉你文件被谁动过
生成器只产出一套配色。若原件里混进 **Fluent Design** 的
`#0078d4` / `#323130` / `#605e5c` / `#107c41`，说明这份 HTML **被别的窗口 / agent 直接改过** →
先用生成器重出一份干净原件再换色，否则等于把别人的改动固化进新风格。

## 2. 17 类语义角色表（核心资产）

换风格不是「53 个色值逐个硬映射」，而是**先归语义、再按语义换**。

| 语义 | 原色值（数据日报看板实测） | Minimalist |
|---|---|---|
| bg | `#f4f6f9` `#fafbfc` `#fafcff` `#f3f2f1` `#faf9f8` | `#ffffff` |
| **surface**（毛玻璃，单列） | `rgba(255,255,255,.82/.76/.72)` | `rgba(250,250,250,.92/.90/.88)` |
| **white → surface** | `#fff` ×19 | `#fafafa` |
| line | `#e7eaf0` `#d5dae3` `#e1e1e1` `#c8c6c4` `#e8e7e6` `#d9e5ef` `#edebe9` `#eef1f6` | `#e5e5e5` |
| ink | `#12151b` `#323130` | `#000000` |
| ink2 | `#5a6474` `#605e5c` `#6b6967` | `#525252` |
| ink3 | `#8a8886` `#98a1b0` `#98a2b3` | `#a3a3a3` |
| brand | `#2563eb` `#3b82f6` `#1d4ed8` `#0078d4` `#005a9e` `#106ebe` | `#000000` |
| brand_l | `#eef4ff` `#deecf9` `#b3d8f2` `#f5f9fd` | `#f5f5f5` |
| good | `#0ea472` `#00cc6a` `#107c41` `#4fd1a5` `#047857` | `#00b894` |
| good_l | `#e9f8f3` `#dff6e8` `#cfeee2` `#d7efdf` `#f1faf4` | `#e6faf6` |
| warn | `#e08600` `#8a6200` `#b45309` | `#d9a400` |
| warn_l | `#fff7e8` `#fff3d0` | `#fffbe6` |
| bad | `#e5484d` `#a4262c` `#be123c` | `#e6395f` |
| bad_l | `#fdeeee` `#fde7e9` | `#ffeaf0` |
| violet | `#7c5cf0` `#6b4bb7` `#a5b4fc` `#7facf7` | `#7c3aed` |
| cyan | `#0891b2` `#007c91` | `#0891b2` |

**语义色那一档也要换成目标风格的语义色**，不能只换主色 ——
否则浅绿底 pill 配新主色会变得刺眼。

## 3. 执行顺序（顺序本身就是坑）

```python
# ① 毛玻璃先换（按语义色 + 保留 alpha）
for o, a in [("rgba(255,255,255,.82)","0.92"),
             ("rgba(255,255,255,.76)","0.90"),
             ("rgba(255,255,255,.72)","0.88")]:
    t = t.replace(o, hex2rgba(surface, a))

# ② 语义色（bg 放前面；不要把 #fff 混在这一轮，会污染 #fffbe6）
for sem, olds in SEM.items():
    for o in olds: t = t.replace(o, TARGET[sem])

# ③ 纯白 —— ★ 词边界，放最后
#    实测：#fff7e8 -> #fffbe6 -> #fafafabe6（非法 9 位），一次踩出 13 处
t, nw = re.subn(r"#fff(?![0-9a-fA-F])", TARGET["surface"], t)

# ④ font-family / 圆角
# ⑤ 收尾必检
assert re.findall(r"#[0-9a-fA-F]{7,}\b", t) == [], "出现非法色值 = #fff 没加词边界"
```

## 4. 结构坑：`#app` 是 12 栏 grid

```css
.wrap>header,.wrap>.tabs,.wrap>.kpis,.wrap>footer{grid-column:1/-1;min-width:0}
.wrap>section{grid-column:1/-1;min-width:0;margin-top:28px}
```

**只匹配 `section`。** 为「两板块并排」加 `<div class="twocol">` 时它不匹配 →
只占 1 栏。1440px 桌面实测：`.twocol` 宽 **93px**、两列各 38px。

```css
/* 修法 */
.wrap>.twocol, #app>.twocol{grid-column:1/-1;min-width:0;margin-top:28px;
  display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);
  gap:18px;align-items:start}
```

**排查口诀：宽屏下某板块宽 ~90px ⇒ 没跨栏**（不是内容问题）。

## 5. 「并排两栏（不合并）」清单

- **两个独立 `<section>`** + 各自折叠按钮，只包一层 `.twocol` —— 不可真合并内容。
- `minmax(0,1fr)` 而非 `1fr`（`1fr` 的 min-content 下限会被宽表格顶开）。
- 窄栏三处修正：
  1. `.twocol > section{margin-top:0 !important}`（抵消 `.wrap>section` 的 28px）
  2. `.twocol .ni{flex-direction:column}` —— 否则 `.nm{flex:0 0 auto}` **把店名挤断**
  3. `.twocol table{min-width:700px}` + 店名列 `min-width:170px` —— 宁横滑不截断
- `@media(max-width:1100px)` 变单栏，`.ni` 恢复横向、表格 `min-width:620px`。

## 6. 验证（读数值 + 看图，缺一不可）

**A. 生成器结构自检**：输出应有 `✅ 结构自检通过（section/div 均配平）`。

**B. computedStyle（判深色/浅色是否真落地）**：
```js
var k=document.querySelector('.kpi'), v=document.querySelector('.kpi .v');
({bodyBg:getComputedStyle(document.body).backgroundColor,
  bodyColor:getComputedStyle(document.body).color,
  kpiBg:getComputedStyle(k).backgroundColor,
  kpiValColor:getComputedStyle(v).color})
```
深色应形如 `bodyBg rgb(10,10,11)` / `kpiBg rgb(22,22,26)` / `kpiVal rgb(247,248,248)`
—— **卡片底色与文字色必须一深一浅，同亮就是漏换。**

**C. 两栏几何**：`.twocol` 宽 == `#app` 宽；两列各占一半；
两个子 section 的 `left` 差 > 100px；店名单元格 `scrollWidth <= clientWidth + 1`。

**D. 数据没坏**：`.kpi`=6、`#shoptbl tbody tr`=24、`#noticeBody .nblk`=3、`render` 函数计数与原件一致。

**E. 截图 + 视觉过一遍**：`cdp('Emulation.setDeviceMetricsOverride', width=1440,height=1050,...)`
桌面 + 手机 390×844；跳过密码门 `js("document.getElementById('gate').remove()")`。
⚠️ **只报「色值换了几处」不算验证** —— Linear 深色版就是换色数正常但全看不见。

## 7. 工具坑

- `browser_exec` 的 `js()` 写多行 `map`/箭头函数偶发 `SyntaxError` → 改普通 `for` 循环即可。
- 旧 zip 被占用（用户开着）→ `os.remove` 报错属正常，换名输出新的，别硬刚。
- 深色主题要单独一条分支（`dark=True`），否则 rgba 白卡不会跟着变。
