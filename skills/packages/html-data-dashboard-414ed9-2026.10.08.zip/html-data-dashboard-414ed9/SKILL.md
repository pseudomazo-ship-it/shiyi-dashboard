---
name: html-data-dashboard
description: Update embedded data in an HTML dashboard; keep auth/JS.
version: 1.0.0
author: Nous Research
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [dashboard, html, web, data-viz, qdata, 看板]
    category: productivity
---

# HTML Data Dashboard Maintenance

Scope: self-contained single-file HTML dashboards where the numbers are
embedded as a JS object inside `<script>` (commonly a `const QDATA = {...};`
or similar), the page renders tables/cards client-side, and it may be
password-gated. The recurring job is: **swap the embedded data for a newer
value set (often from Excel/CSV source sheets) while leaving the password
token, page structure, all JS, styles, and filters untouched.**

典型例子：蒙倩主体财务看板（`const QDATA` + `PASSWORD_TOKEN` + 密码门）。

## When to Use

- 用户给一个 HTML 看板，让你参考 Excel/CSV/新数据「更新同步」一下。
- 需要替换自包含网页里内嵌的数据对象，且「保持密码不变 / 功能不变」。
- 给单文件看板做数据增量、补漏、改统计口径。
- 需要给无浏览器环境的页面做「能不能真跑起来」的验证。

## Golden Rule

**Don't break the payload contract.** 密码 token、`btoa(...)` 校验逻辑、
表头列名、筛选函数、CSS 一律不改。只替换数据对象；用边界正则定位它，
替换后立即校验 token 仍在。

## Workflow

1. **Locate the payload with a boundary regex**, not substring guess.
   ```python
   import re
   m = re.search(r'const QDATA = (\{.*?\});\nconst PASSWORD_TOKEN', html, re.S)
   payload = m.group(1)
   ```
   用**结束锚点**（后面紧跟的 `;\nconst PASSWORD_TOKEN`）而非裸 `}`，因为对象里
   含无数嵌套 `}`。
2. **Read source sheets BY CELL COORDINATES, not by text dump.**
   `read_file` 把 xlsx 转成 TSV 是按视觉对齐的；当一张表混有「带月份的收入行」
   和「季度级支出行」两种行型时，TSV 列会错位。用 openpyxl `iter_rows(values_only=True)`
   按坐标读，最稳。若当前 Python 没装 openpyxl，用 `uv run` 拉临时环境：
   `uv run --with openpyxl python script.py`。
3. **Build an aggregation script, then VALIDATE against the ORIGINAL dashboard before trusting it.**
   这是关键一步：先用模板/源数据聚合出一版 full/quarter/month，拿去和原看板
   `QDATA.full` 逐主体对比。**若销售/核心数字与原看板完全一致，只差几笔支出，
   说明聚合逻辑可信，那几笔差异就是「要同步的新值」**；若销售全对不上，说明
   口径/列映射错了，先修正再继续。
4. **Rebuild all layers the dashboard reads.** 常见三层：`full`（累计）、每季度、
   每月。缺一层，用户切「季度/月度」筛选就显示旧值或空。重建后做**闭环校验**：
   某层全表合计 = 各子层合计。
5. **Replace, back up first.** `shutil.copy` 原 HTML 到 `cache/` 备份，再写回成品。
   写回后**独立重算**一次（从新文件重新提取 payload 求和），确认数字、状态分布、
   主体数都对。
6. **Verify it renders, not just parses.** 见下方「无浏览器验证」。

## 口径 Pitfall（重要，容易算错）

- **totalExp 含推广+技术**：`totalExp = promo + tech + ware + goods + other`，
  不是只有支出（ware+goods+other）。漏加 promo/tech 会让支出占比骤降、看起来
  「更健康」——这是假象。
- **月度层通常不含支出**：看板口径常规定「未填月份的季度支出/开票只计入季度与
  累计，不分摊到月」。即 月度 只有 sales/promo/tech（支出=0、开票=0），
  支出落在季度层和 full。
- **闭环校验**：`full 总支出 == Σ(季度 总支出)`；`Σ(季度) - Σ(月度)` = 全表
  ware+goods+other 之和。对得上，三层才闭合。
- **比率分母=当月/当季销售**，销售额为 0 时比率应置 0 或 '-'，避免除零 NaN。

## 无浏览器验证（页面能否真渲染）

付费/授权浏览器常被拦截（Chrome 远程调试弹窗、登录态依赖）。对纯 client-side
单文件看板，用 **Node + 极简 DOM mock** 执行真实 `<script>`，读渲染后的关键元素：

```bash
node scripts/verify_render.js <path\ to\ dashboard.html>
```

它会 mock `document/window/sessionStorage/btoa/setInterval` 等，跑完整脚本，
输出：是否抛错、`statsCards`/`tableBody` 字符数、表格行数、`resultMeta` 文本，
以及「总销售额」等关键卡片的真实值。**能出数 = 真能渲染**，不止是语法通过。

另外可用 Node 编译检查快速排除语法错误：`new Function(script)` 若抛异常说明脚本
本身坏了（旧 V8 如 py_mini_racer 对新语法会误报，别用）。

## 从零做一版看板时：十一的设计体例（2026-09 多轮纠正后定稿）

适用于「数据→自己生成一版 HTML 看板」（不是更新旧看板的 QDATA）。以下都是**他明确提过、我踩过被纠**的点：

**内容取舍（他会在看板上做减法）**
- **不放金额字段**：看板里不要成交金额/客单价这类钱数（实测被要求整批删）。订单数/件数/人数/评价/条数/占比/比率可以留。
- **不放衍生占比列**：如「订单占比」这种为派生而派生的列不要（被点名删）。占比只在它本身就是分析主角时才留（如中老年 vs 年轻的份额趋势）。
- **分类维度要逐项拆开**：说「1-5 星作区分」＝**每个星级各一张卡/tab**，每张卡带自己的条数/占比/比率/趋势，不要只给一张混合汇总表。
- **主指标要做主角**：他要看的那个指标（如 DSR）→ 顶部大字 + **自己的趋势折线**；**且每个分组分项也要各自的趋势图**（他说过「这几个 ID 的 DSR 也需要体现趋势图」）——一是总览多线对比图，二是每张分项卡里的 mini sparkline。
- **表格装全量**：Excel 出「所有数据在一个页面内」＝**单工作表**装完全部板块（堆叠分段，不分 sheet），冻结首行 + 打印自适应一页宽；估算/补录/平台提供的单元格用**蓝字**，计算所得黑字。

**视觉**
- **默认要浅色系**（被明确要求改）：底 `#f4f6f9` / 白卡片 + 淡阴影 `0 1px 3px rgba(16,24,40,.04)` / 主色蓝 `#2563eb`；不是财务看板那套深色 `#0f1117`。
- 星级用柔和梯度绿→红；涨跌用绿/红小字，不要大面积色块。
- **2026-09-27 起，数据日报看板的口径色改为 Minimalist Flat（黑白极简）**：
  底 `#ffffff` / 卡片 `#fafafa` + `1px #e5e5e5` / 主色 `#000000` / 成功 `#00b894` /
  警告 `#d9a400` / 危险 `#e6395f` / 点缀 `#7c3aed` / 青 `#0891b2`。
  用 `#2563eb` 那套算旧版，别拿旧的往新件上套（细节见第 17 条）。
- **他要看风格时，一批给 10 套 + 一张对比页**（截图 + 色板 + 可点开完整看板），
  他会在一次里挑完（实测「还有其他风格吗？多做几个我看看」→ 一次性给 10 套就定稿）。

**渲染必做的 5 个检查（都实际出过问题）**
1. **折线图必须有 Y 轴刻度 + 网格线**——只有一条线会被评价「看不出数值」。
2. **宽表套 `.tablewrap{overflow-x:auto}`**，否则窄窗口（如桌面预览面板）里表格会把整页撑宽，看起来「标题被切、卡片不见了」。
3. **Python 拼 HTML 时，CSS 里的 `%` 一律写 `%%`**（若整段用 `%` 格式化拼接）——`linear-gradient(180deg,#fff 0%,#fafbff 100%)` 会报 `unsupported format character ','`。
4. **环比/差值要限小数位**：`'%+g'` 会吐出 `+0.0391645`；DSR 类差值先 `round(x,4)` 再格式化。
5. **多序列对比图别把「最新值」标在右端**（会重叠）——把各系列的最新值放成图例 chips。
6. **要「能筛选、单独看某一条线」时：图例当按钮 + Y 轴跟着缩放。** 十一 2026-09-21 明确要过：「几个趋势图可以放在一起，但是要有一个筛选的方式，方便单独看某一个 ID 的趋势线。」做法（纯前端、无外部库、离线可用）：
   - 序列数据内嵌成 `const DSR = {labels:[…], series:[{n,c,v:[…]}]}`，图例 chips 带 `data-n` + inline `onclick`：**单击＝只看这一条 ／ 再点＝看全部 ／ Ctrl(⌘)·Shift+点＝叠加多条**，另给一个「全部显示」按钮。
   - **关键：Y 轴必须按「当前可见序列」重算，不是固定全量区间。** 一条 4.6→4.7 的线放在 4.0→5.0 的轴上就是一条直线，等于白给；渲染函数每次从可见集合取 min/max 重绘（上下各留 ~30% padding）。
   - `x(i)` 在只有 1 个点时 `/(N-1)` 会除零 → 写成 `N>1 ? … : 居中`。
   - **数据不足时也要把这段渲染出来**（只有 1 天就画点，并在提示行写「折线要 ≥2 天，筛选明天起可用」）——整段用 `if 有≥2天` 隐藏掉，用户会以为功能没做。
7. **生成器脚本改文件名要改脚本里的常量，不能只改盘上的文件。** 定时任务每天重新生成，手改名字下次就被覆盖回旧名。改 `OUT = os.path.join(BASE, '<新名>.html')`，**顺手把 `<title>` 与 `<h1>` 同步**（截图/书签/窗口标题才对得上），并检查标题里的店铺名和紧邻副标题是否重复。旧文件名不保留别名（用户规则：同内容只留最新版）。
8. **用户给的成品名按原样用，不要自行「修正」。** 这次他给的是 `护发造型-.评价星级日采集`（中间一个 `-.`），照用，并在同一句里补一句「如果那个 `.` 是手误、你要的是 `护发造型-评价星级日采集`，说一声我改」——不要沉默地改名，也不要为这个多问一轮。
9. **长表的表头要滚动冻结（sticky）** —— 十一 2026-09-25 明确要求：「看各店铺明细数据时，店铺/业绩/数值/推广费占比/退款占比/客单价这些名称要在页面内保持置顶冻结，方便对应指标名称」。三处必踩坑：
   - **容器 `overflow-x:auto` 会让 `position:sticky` 失效** → sticky 只相对**最近的 scroll 容器**生效，容器自己不滚 = 等于没冻结。必须把 `.tw{overflow-x:auto}` 改 `overflow:visible`，同时 `table{min-width:520px}` 改 `min-width:0` 让它自适应；列多时给过 6 列表头 `white-space:normal` + 字号降一档（14.5→13.5px）、内边距 12→11px，否则窄屏下「推广费占比」会挤。
   - **页面已有 sticky 元素时（如顶部 KPI 卡 `top:0`）新表头会被盖住** → 表头 `top` 用 CSS 变量跟随：`th{position:sticky;top:var(--kpiH,0px);z-index:9}`，JS 按 `.kpis` 的 `getBoundingClientRect().height` 写 `--kpiH`，并在 `resize` / `orientationchange` / `click`（切时段、折叠板块）后重算 + `setTimeout(…,300)` 兜一次。
   - sticky 后 `border-bottom` 会被下一行盖住 → 补 `box-shadow:inset 0 -2px 0 <边框色>`。
   - **验证要读 computedStyle，不是看「没报错」**：`getComputedStyle(th).position==='sticky'`、`top` 是否等于 KPI 高度、`scrollIntoView()` 后 `th.getBoundingClientRect().top >= kpis.getBoundingClientRect().bottom - 4`。
10. **改看板的 CSS/JS，必须同步改「生成脚本」** —— 定时任务每天重新生成 HTML，**只改盘上的成品文件，次日就被覆盖回去**。本次（运营日报看板）要同时动三处：①本地成品 `日报看板.html`；②生成脚本 `E:\RuanJian\Hermes\scripts\daily_dashboard.py`（CSS 在模块级 `HTML_TPL` 里、JS 在结尾 `render(7)` 之后、`</script>` 之前）；③重新生成并 push 线上。改完 grep 一遍脚本，确认那段代码在脚本里也存在，再跑一次脚本 + 拉线上页面核对（`grep -c` 找新函数名 / 新 CSS 关键字）。
   同一原理的另一面：脚本里的输出文件名/常量也是「改盘上文件没用」（见上条 7）。
11. **生成器要自带「结构自检」，写盘前先验标签配平。** 实踩（2026-09-27）：用 `patch` 往 HTML 模板里
    插一个新板块，**漏写了一个 `</section>`** → 后面 5 个板块全被嵌套进新板块里，
    页面布局整个乱掉，用户报「看板内容全乱了」。
    排查：`html.count('<section') == html.count('</section>')`（同理 `<div>`），8 开 7 闭就是它。
    **修法（做进生成器，不再靠人眼）**：写盘前跑一遍配平检查，不配平就**中止写盘并报错**，
    并打印 `✅ 结构自检通过（section/div 均配平）`。以后加板块再漏闭合也产不出乱版。
    定位技巧：用 devtools 读 `#app > section` 的**数量与顺序**，与预期的板块清单对比 ——
    嵌套错误会让顶层 section 变少，一眼看出。
12. **改造期间若要「先本地、后线上」，明确用 `--no-push`（或等价的只生成开关）。**
    用户会主动说「你先不用同步在网页内，先把文件优化好，我确定好了再拍板同步」——
    这种时候：①一律只生成不推；②每次交付都明确报出「本地已改 / 线上仍是旧版（未同步）」；
    ③**只有他说「可以同步」才推**，不自作主张上线未确认的版本。
    本地看效果用 `desktop_preview` / 预览面板（密码门可用 `drive_preview` 输密码），
    比 `browser_exec` 截图快（大页面截图会超时）。
13. **把成品交给外部工具（Codex 等）做视觉美化时的协作规矩。**
    HTML 是脚本生成的，直接让对方改 HTML → **次日定时任务一跑就白改**。交付前先存一份
    `_基准_<用途>_<日期>.html` 做 diff 基准，并把这**三条禁令**明确告诉对方：
    - 只改 `<style>` 里的 CSS 与 HTML 结构排版，**不动 `<script>` 里的 JS 逻辑**（数据全靠它渲染）；
    - **不改任何 `id=""` / `class=""` 名字** —— JS 靠这些找元素，改名 = 数据全空；
    - **不动内嵌的数据对象**（`const QDATA/DATA = {…}`）。
    对方改完回来：用基准 diff 把**样式改动搬回生成脚本**（不能只留 HTML 里的改动）→
    重生成 → 跑结构自检 → 逐项验证 → 再问用户是否上线。
14. **换配色 / 美化风格：别重写 CSS，做「色值映射替换」。**（2026-09-27 实测；这是第 2 次被要求换风格）
    用户会说「换个美化风格」「单独复制一份做看板我看一下风格」。做法：
    - **独立复制到试验目录**（如 `数据--数据日报\风格试验\<风格名>_看板.html`），
      **生产件（成品 / 生成脚本 / 线上）一律不碰**，用户拍板后才谈搬回生成脚本。
    - **不重写整段 `<style>`** —— 重写几百行会连带改版式，且看不出「到底哪里变了」。
      建 old→new 映射表，**用「一次性 `re.sub` + 回调」替换**（⛔ 不要用 `str.replace` 串行 —— 见下方链式替换坑）。
      **实测 53 个色值 / 命中 100 处，几十秒完成**。
    - 🔴🔴 **绝不能用「逐个 `str.replace`」串行替换 —— 会链式替换**（2026-09-30 连踩两次）：
      映射表里若同时有 `#000000 → #ffffff`（浅色主题的「纯黑主色」换成深色主题的白）
      和 `#ffffff → #121212`（白底换深底），**前一步的产物会被后一步再吃一遍**：
      `--ink:#000000` → `#ffffff` → **`#121212`** ＝ **黑字黑底，整个看板文字消失**。
      ✅ **正解：一次性 `re.sub` + 回调查表，每个匹配只查一次**：
      ```python
      KEYS = sorted(COLOR_MAP, key=len, reverse=True)   # 长 key 优先（8位hex / rgba 必须先匹配）
      PAT  = re.compile("|".join(re.escape(k) for k in KEYS))
      t = PAT.sub(lambda m: COLOR_MAP.get(m.group(0), m.group(0)), t)
      ```
      `re.sub` **一次扫描到底、不会重扫自己产出的文本**，所以安全；`str.replace` 串行才会互相污染。
      - ⚠️ **「替换成功 N 处」这个计数没有验收价值** —— 两次都是靠后来查 `--brand` 才发现被改坏。
        ✅ **改完必须读回最终渲染值做断言**：`--ink` **不能等于 `--bg`**（相等就是又黑字黑底了），
        `--brand` 应该是你设的那个强调色。
      - 通用：凡「批量改语义变量值」的脚本，**验收看渲染结果，不看替换计数**。
    - ⚠️ **8 位 hex（`#1db9541f` 这类带 alpha 的）是合法的** —— 「非法色值」检查要排除 8 位，
      否则会把正常的 `#RRGGBBAA` 全报成异常（本次误报 15 处，全是刚写的合法值）：
      `r"#(?:[0-9a-fA-F]{7}|[0-9a-fA-F]{9,})(?![0-9a-fA-F])"`。
    - 🔴 **`:root` 不能重复定义 —— 生成器本身也会被别的窗口同时改**（2026-09-30）：
      实测 `daily_dashboard.py` 里被另一个窗口插进一整层「Fluent Design · 统一视觉层」，
      **它自带一个 `:root`**（在文件后段）；我在文件开头又加了一个 → **后定义者赢，我的令牌被静默覆盖**
      （症状：源码里 `--brand` 是蓝的，渲染出来却是白）。
      - 改配色前先 `grep -c ":root{" <生成器>` —— **正常是 2**（一个令牌层 + 一个字体层）。
        出现 3 个＝有第二个窗口插了令牌层：**先弄清哪一处生效，别在上面再叠一层**。
      - **不要重复定义 `:root`**：直接改生效那一处（本次最终做法＝把我新加的那段整段删掉、留对方的）。
      - 改完**读回渲染值**确认（`getComputedStyle`），别只看源码改没改。
    - ⚠️ **只列 `#[0-9a-fA-F]{6}` 是错的 —— 会漏掉 rgba 白卡，深色主题直接废掉。**
      实踩（2026-09-27，做 Linear 深色版）：只映射了 53 个 hex，**漏了卡片背景
      `rgba(255,255,255,.76)`（毛玻璃，×3）和 3 位简写 `#fff`（×10）**。
      结果：**页面底色变黑、卡片仍是白的** → 浅色字压在白卡上，
      **6 张 KPI 主数值对比度约 1.3:1，肉眼看不见**（用户要的就是看数，等于交付废品）。
      正确做法 —— 穷举三遍：
      ```python
      re.findall(r'#[0-9a-fA-F]{3,6}\b', css)              # hex（含 #fff 简写）
      re.findall(r'rgba?\([^)]*\)', css)                    # rgba/rgb（白卡毛玻璃在这）
      ```
      并把 **`surface`（卡片/面板背景）单列一个语义角色**，不要跟 `bg` 混。
      - ⚠️ **替换 `#fff` 必须带词边界，否则会把别的色值改坏。** 实踩（2026-09-27）：
        `t.replace("#fff", x)` 会把 `#fffbe6`、`#fff7e8` 这类**前 4 位当成 `#fff`** 换掉，
        产出 `#fafafabe6`、`#fafafafff` 这种**非法 9 位色值**（一次踩出 13 处）——
        对应的 CSS 规则直接失效，而页面上几乎看不出来。
        正确写法：`re.sub(r"#fff(?![0-9a-fA-F])", target, t)`；
        收尾必检：`re.findall(r"#[0-9a-fA-F]{7,}\b", t)` **必须为空**。
        同一轮里“先换语义色、再换 `#fff`”的顺序也会制造这类污染：
        `#fff7e8 → #fffbe6 → #fafafa+be6`，所以词边界不是可选项。
    - ⚠️ **深色主题要单独走一条分支，不能跟浅色共用 hex 替换。**
      rgba 里换色必须**重建字符串并保留原 alpha**，不能只 replace 色值：
      ```python
      def hex2rgba(h, a):                      # '#16161a', '.76' → rgba(22,22,26,.76)
          h = h.lstrip('#'); h = ''.join(c*2 for c in h) if len(h)==3 else h
          r,g,b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
          return f'rgba({r},{g},{b},{a})'
      ```
      给主题加 `dark=True` 标记，深色分支里 `surface` 用**不透明些的 alpha**（.82→.88）防止透出底色。
      同时确认**浅色系语义色（`*_l` 浅底、`ink` 文字）在深色主题里必须整组反转**
      （`ink` → 浅白 `#f7f8f8`，`good_l`/`bad_l` 等浅底 → 深底 `#14251c`/`#2b1a1a`）。
    - **验证必须读 computedStyle，不能只看截图/「没报错」。** 深色 bug 肉眼扫一眼很可能漏过，
      读实际计算值一秒判定：
      ```js
      const k=document.querySelector('.kpi'), v=document.querySelector('.kpi .v');
      ({bodyBg:getComputedStyle(document.body).backgroundColor,
        bodyColor:getComputedStyle(document.body).color,
        kpiBg:getComputedStyle(k).backgroundColor,
        kpiValColor:getComputedStyle(v).color})
      ```
      深色版应形如 `bodyBg rgb(10,10,11)` / `kpiBg rgb(22,22,26)` / `kpiVal rgb(247,248,248)`
      —— **卡片底色和文字色必须一深一浅**，同亮就是漏换。
    - **一次做 N 个风格给人挑**时（用户会说「多做几个我看看」）：用一个 `THEMES` 字典
      （每个风格 17 个语义色 + 字体 + 圆角）驱动同一个 `build()`，**语义角色表**把原件的
      53 个散色归成 17 类，换风格只换这张表。完整配方、17 角色表、批量截图与对比页做法见
      `references/restyle-multi-theme.md`。
    - **`id=` / `class=` 一个都不改，JS 与数据对象零改动**（JS 全靠它们找元素）。
      圆角可顺带收一点（20px→16px、18px→12px）以贴合更克制的目标风格。
    - **后检断言（每次必跑）**：`<section>`/`<div>` 配平、`function render` 计数与原件一致、
      **映射表里的旧色在全文残留为 0**。
    - ⚠️ **f-string 里不能出现反斜杠**：`f"{len(re.findall(r'<div[\s>]', t))}"` 会报
      `SyntaxError: f-string expression part cannot include a backslash`，**整个 cell 一行都不执行**
      （表现为「文件没生成」）。先把正则结果算成变量再插值。
    - ⚠️ **列色值本身就是诊断手段**：生成脚本只产出一套色（如蓝系 `#2563eb` / `#e7eaf0`）；
      若原件里混进 **Fluent Design** 的 `#0078d4` / `#323130` / `#605e5c` / `#107c41`，
      说明这份 HTML **被别的窗口 / agent 直接改过** → 先以生成脚本重出一份干净原件再换色，
      否则等于把别人的改动固化进新风格。
    - **风格规格从哪来**：`stylekit` 技能（`E:\RuanJian\Hermes\skills\creative\stylekit`）：
      `python scripts/fetch-style.py <slug>` 打印该风格的 colors / tokens / aiRules。
      ⚠️ **`--list` 会 404** —— 列风格要调 `curl -s https://www.stylekit.top/api/styles`（148 种）。
      ⚠️ 输出里的字号/圆角是**上限约束**：`data-dense` 明确禁 `rounded-xl` 以上、禁 `p-6` 以上，
      照做会得到「外部疏、内部密」的数据看板节奏 —— 正好是十一要的「简约清爽」。
      适合数据看板的备选：`stripe-style`（紫 #635bff + 深蓝 #0a2540，金融 SaaS）/`shopify-clean`
      （绿 #008060，最贴电商）/`notion-style`（黑白极简）/`linear-style`（深色，手机酷但看久累眼）/
      `apple-style`（留白多、信息密度低）。现成的「源色板 → Stripe」映射表见
      `references/restyle-color-map.md`。
    - **交付**：`desktop_preview` 打开试验版（密码门用 `drive_preview` 输一次），
      报告**只说「变了什么」+ 自查结果**，**不要重复贴看板数据**（用户在预览里直接看）。
      ⚠️ 换风格 ≠ 同步上线，见上条 12。
15. **`#app`（=`.wrap`）本身就是 12 栏 grid —— 往里包一层 `<div>` 会塌成 1 栏（~93px）。**
    （2026-09-27 实踩）生成器里跨栏靠的是后代选择器：
    ```css
    .wrap>header,.wrap>.tabs,.wrap>.kpis,.wrap>footer{grid-column:1/-1;min-width:0}
    .wrap>section{grid-column:1/-1;min-width:0;margin-top:28px}
    ```
    **它只匹配 `section`。** 当你为了「两板块并排」加一层 `<div class="twocol">` 时，
    这个 div 不匹配任何跨栏规则 → 只占 1 栏。1440px 桌面实测：`.twocol` 宽 **93px**，
    里面两列各 38px，用户看到的是「页面塌了 / 板块挤成一条」。
    修法：给包裹 div 补上跨栏 —— `.wrap>.twocol, #app>.twocol{grid-column:1/-1;…}`。
    **排查口诀：宽屏下某个板块宽度只有 ~90px ⇒ 就是没跨栏**，不要去查内容或宽度设置。
    （旁证：`.wrap>section.notice,.wrap>section:has(#sumHead){grid-column:span 6}` 早就写在生成器里，
    说明「两栏」原本就是设计意图，只是后来被覆盖成整行 —— 要并排时优先复用这套 grid，别另起一套。）
16. **「两个板块并排（不合并）」的正确做法**（2026-09-27 十一原话：「把各店铺明细和数据提示，
    这两个指标放在同一行内（不合并）」）：
    - **「不合并」= 保留两个独立 `<section>` + 各自折叠按钮，只包进一层 `.twocol` grid。**
      千万不要真把两块内容拼进一个 section —— 那样折叠按钮会只剩一个。
    - 容器：`display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px;align-items:start`
      —— **用 `minmax(0,1fr)` 而不是 `1fr`**：`1fr` 的 min-content 下限会被宽表格顶开，列宽失控。
    - **窄栏里三处专门修正（不加必出问题）**：
      ① `.twocol > section{margin-top:0 !important}` —— 抵消全局 `.wrap>section` 的 28px 上边距；
      ② `.ni{flex-direction:column}` —— 「数据提示」条目本是横向 flex，窄栏里
         `.nm{flex:0 0 auto}` 不收缩会**把店名挤断**（截图可见「…官方旗舰店（丽…」）——
         改成店名一行、说明一行即可；
      ③ 表格 `min-width:700px` + 店名列 `min-width:170px` —— 宁可让卡片横向滚动，也不截断店名。
    - **响应式兜底**：`@media(max-width:1100px){grid-template-columns:minmax(0,1fr)}` 变上下单栏，
      并把 `.ni` 恢复横向、表格 `min-width:620px`（手机上一栏比两栏清楚得多）。
    - **验证判据（读数值，不靠肉眼）**：`.twocol` 宽 == `#app` 宽；两列各占一半；
      两个子 section 的 `left` 差 > 100px；店名单元格 `scrollWidth <= clientWidth + 1`（不截断）。
17. **最终选定的风格 = Minimalist Flat（2026-09-27 十一从 10 套里拍板）。**
    黑白极简 + 高饱和语义色：底 `#ffffff` / 卡片 `#fafafa` + `1px #e5e5e5` / 主色 `#000000`
    / 成功 `#00b894` / 警告 `#d9a400` / 危险 `#e6395f` / 点缀 `#7c3aed` / 青 `#0891b2`；
    字体换成 `"PingFang SC","HarmonyOS Sans SC","Microsoft YaHei",system-ui`（去掉 Segoe UI 系）。
    **见到 `#2563eb` / `#0078d4` / `#323130` 说明是从旧文件拿的，别用。**
    落地脚本：一次性换肤 `E:\RuanJian\Hermes\scripts\apply_minimal_theme.py`，
    批量出风格 `E:\RuanJian\Hermes\scripts\stylekit_variants.py`。
    
    **⚠️ 2026-09-30 更新：十一又提了一次「色调我要浅色的」，配色换成下面这套**
    （参考 stylekit 的 `data-dense` + `dashboard-layout`；换肤脚本 `scripts/apply_light_theme.py`）：
    ```
    背景 #f6f8fb（极浅蓝灰，比纯白有质感）  卡面 #ffffff  次级 #f8fafc  边框 #e2e8f0
    文字 #0f172a / #64748b / #94a3b8（三级）
    主蓝 #2563eb  绿 #10b981  橙 #f59e0b  红 #ef4444  紫 #8b5cf6  青 #06b6d4
    小圆角 · 极浅阴影 · 数字 tabular-nums
    ```
    - **对比度自检**：正文/背景 ≥ 16（AAA）、次文字/卡面 ≥ 4.5（AA）、卡面/背景 ≈ 1.0x（微妙分层）。
    - **深色残留排查**：`grep -c "#121212\|#181818\|#242424\|#282828\|#1db954" <生成器>` 应为 **0**。
      ⚠️ **但这个 hex grep 不够 —— 它过了，用户仍会说「还有暗色」**（2026-09-30 实踩，白跑一轮）：
      真正的残留是 **rgba 毛玻璃面板**，`rgba(18,18,18,0.90)` 这类：
      ```bash
      grep -nE "rgba\( *(1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9]|0) *, *[0-9]{1,3} *, *[0-9]{1,3} *, *0\.[89]" <生成器>   # 应为空
      ```
      - ⚠️ **小数位写法不一致是漏网主因**：上一轮的映射表只写了 `.90`，而代码里是 **`0.90`** → 没匹配上。
        批量替换前先把 **`.9x` 和 `0.9x` 两种写法都列进 key**。
      - **最可靠的验收不是 grep，是扫「所有可见元素的实际背景色」**：
        ```js
        document.querySelectorAll('body,.card,.kpi,header,.tabs,.tab,section,table,th,td').forEach(el=>{
          const bg = getComputedStyle(el).backgroundColor;
          const m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/);
          if(!m || (m[4] !== undefined && parseFloat(m[4]) < 0.3)) return;   // 透明的不算
          if(+m[1] < 70 && +m[2] < 70 && +m[3] < 70) 报错;   // **深色背景应为 0 个**
        });
        ```
        本次改完后输出 `darkBg: []` 才算干净。
    - 🔴 **另一类「看不见」不是背景暗，是白底上写白字**（2026-09-30 实踩）：
      **图表是 SVG，深色版用 `stroke="#ffffff"` 画折线、`fill="#ffffff"` 画仪表盘数字** ——
      浅色底上等于隐形。一律改 `#2563eb`（线）/ `#111827`（数字）。
      ⭐ **同一个坑的隐藏形态：tooltip 的业绩数值。** 十一原话：「**每个日期对应的业绩数据是白色字看不见，改成蓝色**」。
      根因：**`#sttip` 在 CSS 里有 4 处定义**（基础 / `#sttip .d` 日期行 / 背景 / 日期行覆盖）——
      **背景被后一处盖住了、而 `color` 没被盖** → 白底白字；日期行反而因为是另设的颜色而看得见。
      所以现象是「**只有数值看不见，日期看得见**」。
      - 规矩：**改任何被重复定义的选择器时，把全部定义一起看**，不能只改一处。
      - 自检：`getComputedStyle(document.querySelector('#sttip')).color` **不能是 `rgb(255,255,255)`**。
    - **2026-09-30 最终落定：Corporate Clean（企业简洁风）**，换肤脚本 `scripts/apply_corporate_clean.py`：
      ```
      底 #f8fafc(slate-50)  卡片 #ffffff + shadow-sm + 1px #e5e7eb(gray-200)
      文字 #111827 / #4b5563 / #9ca3af    主色 #2563eb(blue-600)  hover #1d4ed8
      绿 #22c55e / 橙 #f59e0b / 红 #ef4444 / 紫 #8b5cf6 / 青 #06b6d4
      圆角 12px   动效 ≤200ms（卡片 200 / 按钮 150）
      ```
      ⚠️ **光换 `:root` 不够 —— 这套风格要求一个「交互层」，不落就等于风格漂移**：
      `.card`/`.kpi` hover `translateY(-2px)` + 阴影升 `shadow-md` + 边框变 `#d1d5db`；
      `button`/`.tab` active `scale(.98)`；`:focus-visible` `outline:2px solid #2563eb; outline-offset:2px`；
      表格行 hover `#f9fafb`；数字 `tabular-nums`；**必须有 `@media (prefers-reduced-motion:reduce)` 降级**
      （注入位置：`</style>` 之前）。
      风格自带的硬清单（`required` / `forbidden`）要逐条兑现，例如 Corporate Clean 的
      `卡片 bg-white + rounded-xl + shadow-sm + border gray-200`、以及**任何地方不得 `rounded-none`**。
      ⚠️ **stylekit 输出里的 class 名是 Tailwind 味的**（`rounded-xl`/`shadow-sm`/`bg-white`），
      这套看板是手写 CSS + 语义变量 → **别照抄 class 名，要翻译成 token**（`shadow-sm` → `--sh1` 等）。
    - 🔴 **浅色是硬要求，不是「看风格而定」**：**别因为是「Spotify / Linear / Vercel 风」就默认做成深色** ——
      那些风格的代表作是深色，但**十一这里一律要浅色底**。本次我先按 Spotify 做成深色 `#121212`，被打回重做。
    - **他给参考网页 + 截图让我「效仿」时：截图定「感觉」，`fetch-style.py` 规格定「数值」，两个都要**
      （截图用 `vision_analyze` 看）。
18. **`browser_exec` 的 `js()` 里写多行 `map`/箭头函数偶发 `SyntaxError`** → 用普通 `for`
    循环重写同一条表达式即可（实测改写后立刻正常）。别因此判定「`js()` 不能用」。
    （同理，一次 `js()` 只干一件事、把判断写在 Python 侧，比憋一大段 JS 稳。）
19. **折线图的「悬停看数值」：别用 SVG 原生 `<title>`，也别写死画布宽度。**（2026-09-28 实踩）
    十一原话：「每个节点把鼠标放上去可以看到对应日期的业绩数据，另外…拉满横向空间。」

    **① 原生 `<title>` 当 tooltip ≈ 等于没有**
    旧写法是数据点上放 `<circle r="3.6"><title>09/25　35.2万</title></circle>` ——
    **圆点只有 3.6px 很难精确停在上面**，且原生提示要**等 1~2 秒**才弹。用户会说「看不到」，
    而那其实不是“没显示”，是“太难点”。
    ✅ **正解：每天一个铺满整列的透明热区 + 复用全局自定义 tooltip**
    ```js
    const colW = n > 1 ? cw / (n - 1) : cw;          // 每列宽度
    const x0 = Math.max(PL, q[0] - colW / 2);
    const x1 = Math.min(W - PR, q[0] + colW / 2);
    hits += `<rect class="lhit" x="${x0}" y="${PT}" width="${x1-x0}"
        height="${H-PT-PB}" fill="transparent"
        data-d="${sel[i]}" data-v="${(vals[i]/10000).toFixed(2)}"/>`;
    // ⚠️ 热区组拼到 SVG 最后（最上层），否则被折线盖住
    ```
    - **CSS / 事件选择器两个类共用**：`.sthit,.lhit{...}`、`closest('.sthit,.lhit')` ——
      一个页面上可能已经有一套同款热区（本次是「各店铺走势」的 `.sthit`），**直接复用别重写**。
    - ⚠️ **`data-v` 的单位必须跟已有那套一致**。提示框是直接 `+ v + ' 万'` 拼的；
      传原始值会显示成 `2026-09-0129.34 万` 这种**粘在一起的怪东西**（实测踩到）。

    **② ⚠️ 隐藏容器的 `clientWidth === 0`（最阴的一个）**
    「板块默认全部收起」时容器是 `display:none` → **`clientWidth` 返回 0** →
    宽度兜底到最小值 → **7 天的图 viewBox 只有 320 宽**，根本没拉满。
    原本写死 `Math.max(560, n*62)` 也有同样毛病（7 天时留一堆白）。
    ✅ **两道保险都做**：
    1. **宽度兜底**（测不到就用窗口宽度估）
       ```js
       let boxW = box.clientWidth;
       if(!boxW || boxW < 320){
         const fb = document.documentElement.clientWidth || 1280;
         boxW = Math.max(320, Math.min(fb, 1480) - 120);
       }
       const cw = Math.max(boxW - PL - PR, (n - 1) * 24);
       ```
    2. **展开时重绘**：render 时存 `window.__trendSel = sel`；
       折叠事件里判断展开的板块含图容器就 `setTimeout(()=>renderLine(window.__trendSel), 60)`。

    **③ 验证这种图必须「先展开再量」** —— 收起状态下量到的宽度是 0，会误判成“没拉满”。
    实测对照值（改完应逐项吻合）：
    ```
    展开后：cardW 1478 / boxW 1438 / viewBox "0 0 1438 250" / fillRatio 1.000 ✅
    悬停：dispatchEvent(mouseover) → 提示框 display:block，内容 “9/1　2026-09-01 / 29.34 万” ✅
    热区数：近7天=7 / 当月=27 / 近30天=30 ✅
    ```

**验证「筛选/交互」这类功能：必须到真浏览器里点，桌面预览面板的结果不能当结论。**
实测 2026-09-21：在聊天窗口右侧预览面板里点图例 chip，工具回报 `clicked span "…"` 且元素无变化；**同一次用 CDP 把真实鼠标事件序列派发到同一个 chip，函数立刻生效**（Y 轴从全量区间缩到该序列自己的区间）。（这是当天的观察，预览面板的点击派发可能随版本变化——所以做法是「换真浏览器复测一次」，而不是直接断定功能坏了。）
固定验证通道（`browser_exec`，可脚本化、不靠手点）：
1. 打开 `file:///<看板绝对路径>` 的 `Target` → `Target.attachToTarget{flatten:true}`；
2. `typeof 函数名` 确认 JS 已定义（先排除脚本报错）；
3. 读初始态：`document.querySelectorAll('#dsrChart polyline').length` + Y 轴刻度 `[...document.querySelectorAll('#dsrChart text')].slice(0,5).map(e=>e.textContent)`；
4. 触发：`document.querySelector('.chip[data-n="…"]').click()`（验证 inline handler）或直接 `函数名('…', {})`（验证函数本体）；
5. 再读一遍对比——**判定标准是「Y 轴区间变了 / 折线数变了」**，不是「没报错」。
交付时明确告诉用户：**双击 HTML 用浏览器打开**才能筛选，聊天预览里点不动。

**怎么验证趋势图（数据不足时）**
新建看板当天往往只有 1 天数据，趋势图不会出现。验证方法：**另造一份多天模拟 JSON 渲染到临时文件**（生成脚本预留 `--in/--out` 参数）→ 截图看效果 → **删掉模拟文件**。
不要往真实 `daily.json` 里写假数据，也不要因为只有 1 天就不验证。

**小样本要在页面上说明**：条数很少的分项（如个位数评价）单条差评就能把均分打到底——页面上要写一句提醒，否则会被读成真问题。

## 「别人手搓的单文件看板」→ 生成器（2026-10-06）

十一 会直接丢一份手搓的单文件看板（数据全写死在 JS 字面量里）说「**以后在这个看板内更新数据**」。
本次产物：`scripts/daily_dashboard_v2.py` + `scripts/templates/daily_report_v2.html`（新排版《数据日报》）。
完整做法见 **`references/template-to-generator.md`**。四条最贵的：

20. 🔴 **回归验证法：拿旧产物当标准答案。** 这类产物**自带基准** —— 只要基准日规则一致
    （如「23:00 前报前天」），用同一份源数据重跑，生成的数字**必须与旧产物逐位相同**。
    比对项：KPI（含环比）/ totals / score / total / 明细串 `rows` / 月度行 / 预警文案 / 结论文案 / 表头计数。
    本次靠它抓出 **4 个 bug**（预警对比基准错、小结「标准线」对齐错、`万万`重复、`names` 错位）——
    **没这个基准，这些错全都静默上线**。改造单文件看板时，**先跑回归、再谈美化**。
    ⚠️ **只比集合不比顺序**：`rows` 的内部分配顺序可以不同（见下条），另外单独验「同序」。

21. 🔴 **`names[i]` ↔ `rows[i]` 必须严格同序**（手搓看板最阴的一类错）。
    常见写法把店名与数值**分开存**：
    ```js
    function rows(raw){return raw.split("|").map((s,i)=>{const a=s.split(",");return {name:names[i],…}})}
    ```
    `rows` 串里**只有数值没有店名**，店名按**下标**从 `names` 取 ⇒ 一旦错位，
    **全表店铺张冠李戴，而页面看着完全正常**（不报错、排版不变），只有逐店对账才能发现。
    **做法**：定一个**全局唯一次序**（本次 = 30天业绩降序），`names` 和**所有时段**的 `rows` 都用它；
    某店在某档没数据时**仍要占位**（补 `0.00,0.0,…`），否则后面全部错位。
    **自检**：`len(names) == len(rows.split("|"))`，再抽一行核对「该店该档的业绩」能对上。
    ⚠️ 原件 `names` 的顺序可能**不是**按业绩排的 —— 只要它内部自洽就正确，
    **别为了「和原件一致」去改自己的排序逻辑**，JS 渲染时会自己重排。

22. 🔴 **正则越界：`<div class="x">.*?</div></div>` 会吞掉后面一大段。**
    （本次实踩）以为目标 div 后面还有一层闭合而多写了一个 `</div>`，非贪婪 `.*?` 就一路找到
    **后面第一个** `</div></div>`，把中间整块 HTML（含 `</section><section>`）一起删掉 ——
    页照样能生成，但 `html.count('<section') != html.count('</section>')`（本次 9 / 7）。
    - 替换前**先确认目标的真实闭合层数**；
    - 统一用 `re.subn(pat, lambda m, s=new: s, tpl, count=1, flags=re.S)`
      （lambda 返回 `s` 可避开反斜杠/`\1` 被解释）；
    - **替换后打印未匹配的 pattern**（`if cnt == 0: print("⚠️ 未匹配", pat[:60])`）——
      否则某个正则该改的地方悄悄没改，你还以为成功了。
    - 配平自检见第 11 条（生成后、写盘前）。

23. ⚠️ **给无门禁的模板「注入」密码门（而不是自己写一套）。**
    手搓模板常常没有门禁，但线上必须有。搬旧看板那套即可：CSS `#gate` + HTML 覆盖层 +
    JS（FNV + `sessionStorage`）。要点：
    - 内容容器加 `id="app" style="display:none"`，`unlock()` 里
      `gate.style.display='none'; app.style.display=''`；
      ⚠️ **先确认模板主体容器叫什么**（本次是 `<main class="page">`，不是旧版的 `#app`）。
    - **哈希必须用 `Math.imul`**（见第 3 条）；**盐值与哈希沿用旧的**（本次
      `fnv(pw+'shiyi-daily-2026') === '552b9a90'`，密码 `12511251`），这样别处已登录的窗口与用户习惯不变。
    - 新 CSS 用**模板自己的设计令牌**（`var(--surface)/--line/--blue/--red)` ——
      别把旧看板的 `--brand/--ink3/--surface2` 搬进来，那些变量在新模板里**不存在**（样式会静默失效）。
    - ⚠️ 改完用 `drive_preview` **输一次密码**验一遍 —— 桌面预览窗能直接输入。

24. ⚠️ **非破坏性上线：先上新路径，别覆盖线上在用的那份。**
    十一 还没拍板时（新排版/大改版），**不要直接覆盖 `daily/index.html`**：
    - 新产物推到**新路径**（本次 `daily/v2/index.html` → `/daily/v2/`），旧路径原样不动；
    - 推送只 `git add <新目录>`，**别 `git add -A`** —— 这类 repo 常有别的任务在推（根 `index.html` 常有他人改动）；
    - 核实打**远端**：`curl -s ".../daily/v2/?v=$(date +%s)"` 后 grep 标题／生成时间／店数／哈希，
      **别只看 `git push` 返回 0**（返 0 ≠ 线上已更新，Pages 还要构建 30~90s）；
    - 切不切主路径 → **交给他拍板**（同第 12 条）。

25. ⚠️ **中文字符串里的 `%` 做 `%` 格式化会炸。**（本次实踩）
    `"…高于 46% 的 %d 家店铺" % n` → `ValueError: unsupported format character '?' (0x7684)`
    （`%` 后面那个汉字被当成格式符）。**字面 `%` 一律写 `%%`**，或改用 `.format()` / f-string。
    同源 bug：`"%s万" % total`，而 `total` 本身已是 `"203.42万"` → `"203.42万万"`。
    **带单位的字符串变量，拼接前先确认它是否已自带单位**（本次两处都是靠回归比对才发现的）。
    （第 3 条是 CSS 里的同一个坑，这里是 Python 语法的坑。）

26. 🔴 **`re.sub` 的「替换串」会把 `\n` 当转义还原成真换行 —— 内联 JSON 被写坏。**（2026-10-07 实踩）
    把新数据写回 HTML 时最容易中标，而且**页面直接白屏**（症状是 `json.loads` 报
    `Invalid control character at: line 1 column 259`）：
    ```python
    # ❌ 翻车：replacement 传字符串时，\n 会被 re 当转义处理
    src = re.sub(r'const skills=\[.*?\];\n', 'const skills=' + inline + ';\n', src, flags=re.S)
    #   → inline 里所有的 \"\\n\" 变成真实换行 → JS 字符串字面量被截断
    # ✅ lambda：replacement 原样拼接，不解释任何转义
    src = re.sub(r'const skills=\[.*?\];\n', lambda m: 'const skills=' + inline + ';\n',
                 src, count=1, flags=re.S)
    ```
    · 这个坑**只有 `re.sub` 有**，`str.replace()` 不会。和第 22 条同源（那次是 `\1` 被反向引用）。
      **凡往 HTML 里写大段数据/JSON，replacement 一律用 lambda。**
    · **写完必跑自检**：把内联数据抠出来 `json.loads()` 一遍 —— 能解析才算写对，
      别只看「文件变大了」。
    · ⚠️ **一旦写坏，不要在坏文件上继续改**：从改动前的备份盖回去再重跑。
      （本次靠 `_backup_<日期>\` 里改动前的 `skills.html.bak` + `skills_data.json.bak` 救回来。）

27. 🔴 **内联数据的 `id` 撞号 → 点 A 卡，详情却显示 B。**
    数据里用 `id` 当查找键（`items.find(x => x.id === selected)`）时，**新增条目若又从头编号**
    （`skill-0`…）就会和已有条目撞号；`find` 永远返回**先出现**的那条 →
    详情面板里是另一个条目。
    症状极具误导性：**卡片标题是对的、详情是错的**（不报错、排版正常），
    很容易被误判成「DOM 顺序 / 浏览器缓存 / 点击没生效」而绕远路（本次绕了好几轮）。
    · **改法**：合并后**统一全局重编号 + 断言唯一**：
      ```python
      for i, e in enumerate(merged): e['id'] = f'skill-{i}'
      assert len({e['id'] for e in merged}) == len(merged)
      ```
    · **排查口诀：出现「点 A 显示 B」，先查 ID / 键是否唯一，再看前端。**
    · 同类：任何 `{key: …}` 形态的嵌入数据，**同名 key 后者覆盖前者**，
      症状是「有一条数据神秘消失」。

28. ⚠️ **页面若带「选中文字时点卡片不切换」的保护，自动化点击会全部失效 —— 那是设计行为，别改页面。**
    （2026-10-07，技能看板卡片 `onclick` 第一行：`if(window.getSelection()?.toString().trim())return;`
    —— 这是十一明确要求「文字可选中复制、选中时不误触卡片切换」的落地。）
    · 表现是「点了没反应 / 详情还是上一条」，很容易被当成 bug 去翻前端代码。
    · ✅ **做法：在同一个 `js()` 表达式里**先 `window.getSelection().removeAllRanges();`，再点击。
      分两次调用可能被中间的选区状态破坏。
    · ✅ **判定「点击真的生效」要比对卡片标题 vs 详情标题是否相等**，不要只看「没报错」。
    · ✅ 详情若是浮层、靠 `location.hash` 变化驱动（移动端全屏详情），
      **加类是异步的** → 断言 `mobile-open` 之类的类名前要 `await` 一次。
    · ✅ 移动端用 `cdp('Emulation.setDeviceMetricsOverride', width=390, height=844, deviceScaleFactor=3, mobile=True)`，
      跑完 `cdp('Emulation.clearDeviceMetricsOverride')` 还原。

29. **卡片里的迷你趋势线（sparkline）：线用 SVG、点用 HTML —— `preserveAspectRatio="none"` 会把 SVG 圆点拉成椭圆。**
    （2026-10-08 领航员看板实做）十一要求「趋势图占比太小可以大一些」+「每个节点悬停显示日期和数据」。

    **① 拉伸变形**：要让线撑满卡片宽度，SVG 得写 `width:100%` + `preserveAspectRatio="none"` ——
    但 `<circle>` 也跟着被横向拉伸，圆点变瘦椭圆。
    ✅ **分开画**：线/合格线虚线留在 SVG 里（拉伸无所谓），**节点改成 SVG 之外的一层 HTML 绝对定位小圆点**：
    ```html
    <div class="spk"><svg viewBox="0 0 500 72" preserveAspectRatio="none">…线…</svg>
      <i class="pt" style="left:12.5%;top:38%;background:#16a34a" title="2026-10-02 ｜ 54.0%"></i>…</div>
    ```
    ```css
    .spk{position:relative;width:100%;height:72px}
    .spk svg{width:100%;height:72px;display:block}
    .spk .pt{position:absolute;width:7px;height:7px;border-radius:50%;
             transform:translate(-50%,-50%);border:1.5px solid #fff;cursor:crosshair}
    .spk .pt:hover{width:12px;height:12px;z-index:6}   /* 放大 → 好点中 */
    ```
    坐标换算：`left = px(i)/w*100%`、`top = py(v)/h*100%`（复用 SVG 同一套 px/py 函数）。
    ⚠️ **hover 放大到 12px 是关键** —— 小圆点 + 原生 `title` 的毛病就是「停在上面很难」（见第 19 条）。
      放大 + 白描边后命中率够用，**比给每列铺透明热区简单得多，卡片里的小图优先用这套**。
    🔴 **但放大 + 原生 `title` 仍然不够（2026-10-08 被打回）**：交付后十一 又提了一遍
      「趋势线条每个节点鼠标放上去显示对应时间和数据」—— 说明原生 `title`（等 1~2 秒、样式土）
      在他看来等于没有。**节点上改挂 `data-tip`，配一个全局 `#ttip` 浮层 + 事件委托**
      （即时弹出、深色小气泡、跟着节点定位），并把旧的 `title=` 属性全清掉。
      完整代码见 `references/dashboard-interactions.md` ③。
    ⚠️ 一个页面几十上百个节点时 HTML 层会很多（本次 22 店 × 4 时段 = 858 个节点），
      页面 190 KB —— 可接受，但别再无节制加层。
    ⚠️ 金额类 sparkline 要传个 `money=True` 开关：Y 轴上下界不含 60% 合格线、
      节点 tooltip 走 `¥%.1f`，颜色也别用达标色（用蓝色）。

    **② 卡片网格 + 筛选按钮**（他要「每个板块都能筛达标/不达标」）：
    卡片写 `data-ok="1|0"`，筛选按钮组固定在网格**外面**（`f.parentNode.querySelector('.sgrid')`），
    点击时只切元素的 `display`，不动数据。
    ⚠️ 网格里同时有 `.scard`（趋势卡）和 `.col`（柱状图柱）两种元素时，
      选择器必须写 `grid.querySelectorAll('.scard,.col')`，否则「当天」那个板块筛不动。

    **③ 只放「有数据的店」**：整段没数据的店（各时段 series 都为空）直接 `continue` 掉，
    不要渲染成「数据不足（0 天）」的占位卡 —— 十一明确要求「没有数据的店铺名不显示在看板内」。

30. **看板的「定位」要跟用户确认到一句话级别 —— 同一个页面可以既是考核看板又是纯阅览看板。**
    （2026-10-08）领航员看板最初按「加班判定」的口径做（KPI 是加班人数/总监陪同、明细表带判定列、
    运营汇总写「加班/正常」），十一随后要「**关于加班方面的信息都剔除，主要阅览领航分**」——
    KPI 换成达标店铺/平均分/达标率/花费，明细表列名改「达标状态」，运营汇总改「X/Y 达标」。
    **教训**：口径借用了另一个业务（加班判定）时，**先问一句「这个页面主要给谁看什么」**；
    判定型页面和阅览型页面的元素完全不同，做错整版要重改。
    （反向也一样：加班通知那边仍需保留判定逻辑，两处只共享数据口径、不共享展示。）

31. **「每个板块都能展开/收起，默认收起」是新看板的默认体例**（2026-10-08 十一定；数据日报与领航员看板都是这个形状）。
    三件套（纯 CSS + 十几行 JS，无外部依赖）：
    ```js
    /* CSS: .card.collapsed > *:not(h2){display:none!important}
            .card h2{cursor:pointer}   .card h2::after{content:"▾"}
            .card.collapsed h2::after{transform:rotate(-90deg)} */
    document.querySelectorAll('.card > h2').forEach(h=>h.onclick=()=>h.parentNode.classList.toggle('collapsed'));
    document.querySelectorAll('.card').forEach(c=>c.classList.add('collapsed'));   // 加载即全部收起
    ```
    - **只包 `.card`；KPI 卡（`.kpis`）不折叠** —— 一进来就要看到数。
    - ⚠️ 收起态里 `clientWidth === 0`，里面的图会画成极小尺寸 —— 见第 19 条的两道保险。
    - ⚠️ 加了折叠后，「动作 → 断言」的验证要**先把目标板块点开**再量宽度/查元素，否则量到 0 或空。

32. **板块清单会变，所以每个板块都做成独立 `.card` + 独立 `<h2>`。**（2026-10-08 一轮里被改了三处）
    删掉整个「运营汇总」板块；把各时段的「优化建议」从时段面板搬到顶部、与「目标线」合并成一个
    `🎯 目标线与优化建议` 板块。**两块内容塞进同一个 `.card` 里，后面要拆就得动 DOM**；
    各自成块时，删/挪只是移动一段字符串。
    - 建议要跟时段联动时：**统一包 `.tsblock[data-ts="i"]`，由一个 `setTs(i)` 全页联动** ——
      ⚠️ 早期是给每类板块各发一个 data 属性（`.advbox[data-adv]`、`.panel[data-ts]`…）再逐个配对切，
      **漏一个就出现「切了时段只有一块没变」，后人加板块极容易忘**。已回归统一机制，
      新板块**包一层 `.tsblock[data-ts=N]` 就自动跟上**，不用改 `setTs()`。
      详见 `references/dashboard-interactions.md` ②。
    - 某时段「全部达标」时给一块兜底文案（如「本时段所有有数据的店铺均达标」），别留空白块。

33. 🔴 **`daily_dashboard_v2.py` 的 `--push` 是「文档里有、代码里没有」。**（2026-10-08 实踩）
    它开头 docstring 写着 `python daily_dashboard_v2.py --push  # 生成并推 GitHub Pages`，
    但 `main()` 里**只有生成 + `strip_ui()`，一处 git 调用都没有**（`grep git` 只剩注释和 `REPO` 常量）。
    ⇒ 手动跑完以为推上去了，其实**只写到了本地仓库目录**，线上还是旧版。
    ✅ **手动改完自己提交**：
    ```bash
    cd E:/RuanJian/Hermes/cache/shiyi-dashboard-git && \
    git add daily/index.html && git commit -q -m "数据日报：…" && \
    git -c http.proxy=http://127.0.0.1:7897 -c https.proxy=http://127.0.0.1:7897 push origin main
    ```
    ⚠️ 真正的自动推送在 **cron 的转发脚本**那条链上（23:45 生成 → 23:55 推送/发链接），
    不是生成器 —— 判「改完能不能自动上线」要看 cron 链，别信这个脚本的参数。
    （通用：**脚本 docstring 不是契约**，先 `grep` 确认真的实现了再依赖它。）

34. **「把店按阈值分档摆出来」是十一偏好的呈现形态**（2026-10-08）。
    数据日报「数值水位」里按 **46 / 48 / 50 三条线分四档**（≤46% 达标 / 46-48 / 48-50 / >50），
    每档一个小卡、左色带分级（绿/黄/橙/红）、档内列店名 + 数值、标题旁写「N 家 · 档位说明」；
    领航员看板那边则是「每个时段一组 全部/达标/不达标 筛选按钮」。
    ⇒ **他要的是「把店分层摆出来」，不是只给一个总数**；做这类板块默认按阈值分组，
    并让分档**跟时段切换一起重算**（不要写死一份）。
    ⚠️ **分档要【一行排完】，不要 2×2**：2026-10-08 他先要「四档」，我排成 2×2，
    他回「**还是太空**，46% 以内、46-48、48-50、50% 以上这四个栏目**放在一排**」。
    🔴 **改成 4 列还不够 —— 第二轮他又说「把横向空间铺满，不要有空旷区域」**：
    根因是这四档的**父容器本身就是多列 grid**（本次 `.core` = `1.3fr 1fr`：左列环形图、
    右列构成图例），四档作为第三个子元素被自动放进**左列** → 实测只有 822px（四列各 184px），
    右边 632px 整块空着。**修法：`grid-column:1/-1` 跨满整行**（1454px / 各 343px），
    并加 `align-items:start` —— 不加则「只有 1 家店」那档被 `stretch` 拉成和 11 家那档一样高。
    **诊断口诀：某区块宽度只有父容器的约一半 ⇒ 父容器是多列 grid，给子元素 `grid-column:1/-1`。**
    验收读几何：`bands.right - core.right == 0`（右侧剩余空白 0px）。
    见 `references/dashboard-interactions.md` ⑤（含「太旷」的四类成因、诊断脚本与压缩清单）。

35. **看板交互四件套 —— 新看板默认就要带上，别等他提**（2026-10-08 定）。
    十一 在**同一天里对两个不同看板各提了一遍**同样的要求，属于「同一流程做了第二次」：
    ```
    ① 每个板块能展开收起、默认收起
    ② 时段/口径筛选按钮【单独一条放页面最顶部】，切换时【全页联动】
    ③ 趋势线每个节点悬停显示「日期 ｜ 数值」（自定义 tip，不是原生 title）
    ④ 明细表的指标列都能点表头排序（升序/降序）
    ```
    四件的完整代码（`setTs` 全页联动、`#ttip` 委托、`data-v` 表头排序、压缩留白 CSS）
    与验证判据见 **`references/dashboard-interactions.md`**。
    两条最省返工的：
    - **排序必须给数值列挂 `data-v` = 真实数值**，否则按显示文本排（`9.0%` 排到 `100%` 后面）；
      且**「合计」行排序后要补回表尾**，它会被排进中间。
    - **结论/总结区放【页面顶部】**（紧跟 KPI，别沉到页面最底）—— 他原话「把结论放在顶部（数值水位上面）」。

36. **异常预警板块：每类异常都要写出【日期 ｜ 店名 ｜ 具体数值】，且离谱值要跨所有时段查**（2026-10-08）。
    他原话：「近30天重复登记 3 处**要表达出异常细节写出来**，另外就数据对比特别离谱的店铺也要在登记异常内」。
    - 只报「重复登记 3 处」**不算交付** → 列到 `10-05 ｜ 洗护官方旗舰店　同日登记 2 条（当日业绩 7,491.70 元）` 这一级。
    - 🔴 **别只在「当日」找离谱值**：第一版只看当天 → 报「当日无」，而他在**近7天**那列明明看到 207.20%。
      根因是**当天正常、离谱是长区间累计出来的** → 必须遍历 当日/近3/近7/当月/近30天 五个口径都查。
    - ⚠️ 拼文案前**先读生成数据的代码确认单位**（重复登记那份 `vals` 存的是**当日业绩金额**，
      不是百分比；条数用 `n` 字段，别用 `len(vals)` —— 会显示成「登记 1 条」）。
    详见 `references/dashboard-interactions.md` ⑦。

- **成品文件名后缀用「当天日期」，不是内容/统计周期日期。** 例如内容截止的
  财报若今天是 `2026.08.31`，成品命名 `xxx2026.08.31.html`（即改版当天），
  不要沿用内容里的 `xxx2026.08.24`。用户明确纠正过这一点。
- **同内容只保留最新版**：成品落地后，旧命名版、旧备份（含 `cache/` 下的
  `_old_backup`）一并删除，只留一个最新成品。备份只是为了写回前的安全，
  写完即清除，不堆积。
- 交付时用 `MEDIA:` 给出成品路径即可，并说明它已替换旧版。

## References

- `references/zhuti-dashboard-sync.md` — 蒙倩主体财务看板的完整同步案例：
  QDATA 结构、三类源表列布局、聚合+闭环校验、发现并补全的 3 处漏记支出。
- `references/restyle-color-map.md` — 单文件看板换配色的配方与实测数据；含一份可直接复用的
  「53 色值 → Stripe Style」映射表、后检断言、Fluent 色值诊断信号。
- `references/restyle-multi-theme.md` — **批量换风格配方（一次出 N 套供挑选）**：穷举颜色
  （含 rgba 白卡 / `#fff`）、17 类语义角色表、`THEMES` + `dark` 分支写法、hex2rgba、
  后检断言、computedStyle 验证判据、去密码门批量截图 + 对比页、9 个备选风格。
  **做深色主题前必读 —— 只抓 hex 会让白卡配浅字、数字全看不见。**
- `references/restyle-layout-and-grid.md` — **换风格的操作手册 + 版面坑**：三遍穷举颜色的代码、
  完整 17 角色映射表、`#fff` 词边界（非法 9 位色值）、`#app` 12 栏 grid（包 div 塌成 93px）、
  「并排两栏不合并」的完整 CSS 清单、五步验证（结构自检 / computedStyle / 两栏几何 / 数据完整 / 截图）。
  **要做两栏布局或深色主题时必读。**
- `references/template-to-generator.md` — **把「别人手搓的单文件看板」变成生成器的完整配方**：
  先判断设计 vs 数据、模板锁文件只换字面量、**回归验证法**（拿旧产物逐位对账）、
  `names[i]↔rows[i]` 同序陷阱、正则越界、`%%` 格式化、密码门注入、非破坏性上线（先上新路径）。
  **收到「以后在这个看板内更新数据」这类需求时先读它。**
- `references/dashboard-interactions.md` — **看板交互的完整代码**（折叠 / 时段置顶+全页联动
  `setTs`/ 自定义 `#ttip` 节点悬停 / `data-v` 表头排序 / 压缩留白 CSS / 结论置顶 / 异常明细写法 /
  **右下角常驻浮动「规则」面板（`column-reverse` 向上展开 + 必须 append 到 body）** /
  **分档区 `grid-column:1/-1` 跨满整行 + `align-items:start`**）。
  **做任何新看板、或他提「节点悬停显示数据」「表头点排序」「板块收起」「太空旷 / 没铺满」
  「把口径放右下角」时先读它** —— 这几件他在同一天对两个看板反复提，是默认项。
