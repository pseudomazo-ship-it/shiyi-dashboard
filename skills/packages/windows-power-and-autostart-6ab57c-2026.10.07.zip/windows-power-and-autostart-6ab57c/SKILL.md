---
name: windows-power-and-autostart
description: "Windows 重启/关机/自启核查。Use when 用户要重启电脑或问重启后还在吗。"
version: 1.1.0
license: MIT
author: Hermes Agent
platforms: [windows]
metadata:
  hermes:
    tags: [windows, reboot, shutdown, autostart, uptime]
    category: productivity
---

# Windows：重启 / 关机 / 自启（机器级操作）

触发：十一说「帮我重启一下电脑」「重启好了吗」、或问「重启之后你还在吗」。

## 1. ⛔ 重启/关机命令我执行不了——这是硬禁，不是权限/授权问题

`shutdown` / `reboot` 在 agent 的**无条件禁止清单**上。实测报错原文：

```
BLOCKED (hardline): system shutdown/reboot. This command is on the unconditional blocklist
and cannot be executed via the agent — not even with --yolo, /yolo, approvals.mode=off,
or cron approve mode.
```

- **别再试第二种写法**（PowerShell `Restart-Computer`、计划任务、`ctypes` 调 `ExitWindowsEx`…）—— 那是在绕安全限制，不做。
- 也别把「用户已授权」当成能过：**与授权无关**，是执行层直接拦。
- **对十一要说清**：不是我在推诿，然后立刻给替代路径（下面 2.1）——**只说「我做不到」是没交付的**。

## 2. 替代路径

### 2.1 让十一自己跑（10 秒）
```
Win + R → shutdown /r /t 60 → 回车      （60 秒后重启）
反悔：shutdown /a
```
- 他常说「我现在不方便」→ 给他**第二条**：本机装了 **向日葵 AweSun**，手机远程连上后按 Win+R 跑同一条命令即可（向日葵在开机自启里，重启后自己回来）。
- ⚠️ 如果 Hermes 桌面端弹了授权框，**点「允许」也没用**——别让他白点。

### 2.2 重启前必须先提醒他
| 会中断 | 说明 |
|---|---|
| 所有 Chrome 窗口 | 采集/上架用的专用浏览器也关；多数登录态在 profile 里能保住，但后台可能要重新扫码 |
| 正在跑的自动化 | 提前查端口 9444/9555/9334 与工作区 log 的 mtime |
| 未保存的文件 | 开着的 Excel/WPS 会丢 —— 先存（可先用内存/进程清理技能里的枚举找 `~$*.xlsx`）|
| ~~定时任务~~ | **不受影响**：重启后照跑（cron 在硬盘上）|

## 3. 判断「机器到底重启过没有」——别靠感觉

```bash
wmic os get lastbootuptime /value     # 最后一次开机时间
shutdown /a                           # 报「没有正在进行中的关机」= 没有待执行的重启
```
- 用 `lastbootuptime` 和当前时间算 uptime：**uptime 远大于 1 小时 ⇒ 没重启过**。
- 实例（2026-09-25）：十一说「现在重启，我授权」→ 命令被硬拦 → 我提醒他自己跑，但他没看到；
  后来他问「重启好了吗」，查 `lastbootuptime = 09-21 08:58`（已运行 2 天 10 小时）⇒ **根本没重启**。
- ⚠️ 这比“说一句我做不到”重要：**结论要从证据出**，不要顺着用户的语气假定「已经重启了吧」。

## 4. 「重启后你还在吗」怎么答

去查**三处自启**（本机 Hermes 网关三处都配了）：

| 位置 | 查法 |
|---|---|
| 启动文件夹 | `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\`（本机有 `Hermes_Gateway.vbs`）|
| 注册表 Run | `HKLM/HKCU ...\CurrentVersion\Run`（本机有 `HermesGateway`）|
| 计划任务 | `schtasks /query /tn Hermes_Gateway` |

答复口径：网关自启 ⇒ 开机后 **QQ/微信/飞书都会自动重连**；会话记录、长期记忆、技能、定时任务**都在硬盘上**，不受断电影响。

## 5. ⚠️ 绝不要挂「重启完成后报信」的定时任务（2026-09-25 实际犯错）

我当时挂了一条 `in 5m` 的一次性任务去报「重启完成」，结果：**机器压根没重启，它到点照样发了**：

> ✅ 电脑已重启完成，我回来了

—— 一条**假消息**，还得我回头给十一道歉澄清。

**正确做法**：定时任务里如果要用「上次运行后的世界变了」来报结论，**必须自己先验证状态**（这里 = 查 `lastbootuptime`）；
验证不了就**别挂这条报信任务**，改成「重启完你回来说一声，我立刻确认在线」。
> 同类同源：哨兵/看门狗类任务都得先核实再报，不要「到点就宣布成功」。

## 6. 「能不能设置电脑自动开机」——先分清**关机 / 睡眠 / 休眠**（2026-09-28）

十一问过这个。**问这句时他的真实目的几乎总是「保证定时任务不会因为电脑关了而漏跑」** ——
先按这个假设回答，再问他一句确认（别只丢技术方案）。

### 三种状态，能不能被唤醒完全不同

| 状态 | 能否定时自动开机 | 怎么做 |
|---|---|---|
| **关机**（shutdown）| ❌ **Windows 层面做不到** | **只能进 BIOS 设 RTC Alarm** |
| **睡眠**（S3）| ✅ 能 | 计划任务 + `WakeToRun`（**我能直接配**）|
| **休眠** | ✅ 能 | 同上 |

⚠️ **计划任务只能唤醒「睡眠/休眠」，叫不醒「已关机」** —— 这一条最容易被误解成“配个任务就行”。

### 诊断三连（先跑这个，再谈方案）

```bash
powercfg /a                       # 本机支持哪些睡眠状态
powercfg /waketimers              # 当前已挂的唤醒定时器
powercfg /devicequery wake_armed   # 哪些设备能唤醒（网卡在里面才谈得上 WOL）
```

### ⛔ WOL（网络唤醒）的死结：**它需要外面有人发包**

十一贴过 BIOS 里开 WOL 的步骤（ErP=Disabled、Wake on LAN=Enabled …）。**那部分没错，但不解决他的问题**：

```
关机 ──→ 需要有人发「魔术包」──→ 开机
            ↑
      谁发？电脑自己关了，发不了
```

**WOL 只是“允许被唤醒”，不是“到点自己醒”** —— 必须有**一台常开的设备**（路由器/另一台机器/树莓派）去发包。
这台机器自己就是跑 Hermes 的那台，**它关着的时候没人给它发包**。

**如果他的目的就是“到点自己开机跑任务”→ 应该用 RTC Alarm，不是 WOL。**

### ✅ RTC Alarm（BIOS 定时开机）—— 无人值守的正解

不需要任何外部设备，主板自己按点开机。**必须在 BIOS 里设（软件层碰不到）**：
- 位置：`Power Management` / `APM Configuration` 一带（跟 WOL 那块相邻）
- 名字各家不同，见到的有：`RTC Alarm` / `Wake Up Event` / `Power On By RTC` /
  `Resume By Alarm` / `Wake System From S5`
- 一般能设「每天 HH:MM」或「某日某时」→ 设完 **F10 保存**
- **我给操作步骤，他自己进去点几下**（我不可能重启机器进 BIOS；重启本身也是硬禁，见第 1 节）

### 查 Windows 侧 WOL 到底开没开

```powershell
# 本机实测：网卡 Realtek Gaming GbE，MAC 18-C0-4D-EF-CB-08
Get-NetAdapterAdvancedProperty -Name '<网卡名>' |
  Where-Object { $_.DisplayName -match 'Wake|WOL|Magic|Shutdown' } |
  Select-Object DisplayName, DisplayValue
```
关注这三项（本机 2026-09-28 实测**都已是 1**，即 Windows 侧本来就没问题）：
```
*WakeOnMagicPacket = 1     魔术包唤醒
*WakeOnPattern     = 1
S5WakeOnLan        = 1     ★ S5 = 关机状态也能唤醒
```
→ 所以「WOL 用不了」**不是 Windows 设置的问题** —— 别在这上面绕，直接指向发包方/RTC。

### ⚠️ 坑：中文网卡名在 bash 里读不出来

`Get-NetAdapterAdvancedProperty -Name '以太网'` 经 bash → PowerShell 传参**编码会乱**，返回空。
✅ 绕法：**不要硬拼中文名** —— 先拿对象再取属性，或用 `InterfaceIndex`：
```powershell
$a = Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -First 1
Get-NetAdapterAdvancedProperty -InterfaceDescription $a.InterfaceDescription
```
（同理：本机 `chcp 65001` 不一定救得了 bash 的传参编码，**换成传对象/索引最稳**。）

### 给十一的推荐顺序（下次照这个说）
1. **干脆不关机**，或设成睡眠 + 定时唤醒 —— **我能全自动配完，不用他碰 BIOS**
2. **BIOS 设 RTC Alarm** —— 真·关机也能开机，但要他自己操作
3. **WOL** —— 只在「有路由器/另一台常开设备发包」时才可行，最后考虑
