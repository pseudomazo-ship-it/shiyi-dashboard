---
name: web-console-data-harvest
description: Use when 要从登录态后台/管理台批量取数出表（探域/吉客云/拼多多/得物等）。含接口发现升级阶梯：优先走页面自身接口，四条路都试过才退回「列表→详情→返回」逐条采集。
---

# 登录态后台 · 分页表格批量取数

**触发**：十一给一个**已登录、已筛好**的后台 URL 说「采集一下这页数据」「把每一页登记一下，一共 N 页」「把这个表给我」。
典型案例：探域 `agent.tanyuai.com` 财务中心/积分消耗明细、吉客云、拼多多商家后台、任何 antd/Element 管理台。

**一句话方法**：不要手点 N 页 —— 先找出这个页面**自己调的那个分页接口**，用**页面自己的 `fetch`** 把 N 页一次性拉回来，再分段导出成表。

---

## 0. 铁律

- **只读**：不点保存/提交/删除，**不改他的筛选条件**（他筛好的就是他要的）
- **采集前读一遍筛选条件**（开始/结束时间等）并**如实报出实际范围**（见 §2 的坑）
- **采完必须复位**：页面回到他原来的状态（示例：我测试点到第 2 页 → 要帮他点回第 1 页）
- **交付必须能对账**：条数 = 页面显示的 total；报 ✅ 通过项 + ⚠️ 问题（十一的硬性要求）

---

## 1. 先切到那个标签页（别新开 tab）

他已经登录并筛好了，所以**要用他那个 tab**：

```python
for t in list_tabs():
    print(t['title'], t['url'], t['targetId'])
switch_tab(<targetId>)          # 认目标 id；它会移动 horse 标记，不改 Chrome 可见标签
current_tab()                   # 确认切对了（title/url）
```

⚠️ **别用 `cdp('Target.attachToTarget', targetId=...)` + 带 `sessionId` 的 `Runtime.evaluate` 去指目标**：
实测它会落在默认标签上（我从「探域」的 targetId 读回来的是另一个站点的页面）→ **`switch_tab()` 才是正路**。

### ⭐ 先花 5 秒试这个：`new_tab(url)` 往往直接就是登录态（2026-10-06/07 两次实测）

**browser_exec 启的浏览器带着十一的 cookie** —— 别一上来就去驱动他那个窗口：

| 站点 | 实测 |
|---|---|
| WPS 金山表单（他的私有表单） | `new_tab(url)` 直接打开，页头显示「此表单你已填过 **28** 次」= 与他一模一样 |
| 飞书 wiki / 多维表格（需要登录） | `new_tab(url)` 直接渲染出表，`document.title` 是文档名而非登录页 |

**所以优先级是**：① `new_tab(url)` 试一下 → 已是登录态就用它（**不抢他焦点、不动他的标签页**）；
② 不行再退回 §1 的 `switch_tab()` 指他的标签；③ 再不行才走 §10 的 9555 CDP 直连。
⚠️ 登录页/扫码页 **不要缩放**（100% 才能扫码），需要登录就**停下来问十一**，不猜凭据。

---

## 2. 先看清页面：列 / 行数 / 分页 / 筛选（一次 js 拿全）

```js
(() => { const o = {};
  o.th = [...document.querySelectorAll('th')].map(t => t.innerText.trim().replace(/\s+/g,' '));
  o.rows = document.querySelectorAll('.ant-table-tbody .ant-table-row').length;
  o.pg = [...document.querySelectorAll('[class*=agination i]')].map(e => e.innerText.trim().replace(/\s+/g,' ')).slice(0,3);
  o.inputs = [...document.querySelectorAll('input')].map(e => ({ph: e.placeholder, val: e.value}));
  return o; })()
```

- 分页区会直接告诉你「**共 3637 条数据**」+「100 条/页」→ 页数 = `ceil(总数/每页)`（3637 → 37 页，与用户说的 37 页对上 = 筛选没错）
- **顺手读筛选框**（`inputs` 里 placeholder=`开始时间`/`结束时间`）→ 这一步经常抓到关键问题
- ⚠️ **antd 表格**：`.ant-table-tbody tr` 比数据行**多一行**（`tr.ant-table-measure-row`，101 vs 100）→ 用 `.ant-table-row` 或按 `td` 数过滤
- 有些 UI 的数据**不在 `<table>` 里**（`tbody tr` = 0）：先看 `document.body.innerText` 有没有你的数据，再决定选择器

### ⚠️ 坑：用户说的范围和实际筛选经常不一致

**实例**：十一说「近七天的消耗积分情况，我已经筛选好了」→ 输入框实际是 `2026-09-01 ~ 2026-09-07`（当天 9/22，真正的最近 7 天是 9/15–9/21）。

**处理**：**照他筛的采**（他要的是屏幕上那个）→ 采完**在结论里点明实际范围** + 给一句「要真的是最近 7 天，说一声我 1 分钟重采」。
不要：自己改筛选 ✗ / 默认他说的就对、不核对 ✗ / 停下来先问要不要改（他等着数据）✗

---

## 3. 找接口 + 抓请求体（决定快慢与准不准）

### 3.1 从资源时间线里捞接口

```js
performance.getEntriesByType('resource').map(e => e.name)
  .filter(u => /api|list|paginate|page/i.test(u) && !/\.(js|css|png|jpg|svg|woff|ttf)/i.test(u)).slice(-20)
```
（本次命中 `POST https://agent.tanyuai.com/api/gc/points-bill/paginate`）

### 3.2 挂 hook 抓请求体（参数形状只能这么拿到）

```js
window.__hooked = 1; window.__cap = [];
const rec = (u, m, b) => { if (String(u).includes('points-bill')) window.__cap.push({url:String(u), method:m, body:b||null}); };
const of = window.fetch;                           // hook fetch
window.fetch = function(...a){ try{ const u = typeof a[0]==='string'?a[0]:a[0].url; const o = a[1]||{}
  rec(u, o.method||'GET', typeof o.body==='string'?o.body:null); }catch(e){} return of.apply(this,a); };
const _o = XMLHttpRequest.prototype.open, _s = XMLHttpRequest.prototype.send;   // 有的前端走 XHR
XMLHttpRequest.prototype.open = function(m,u,...r){ this.__u=u; this.__m=m; return _o.call(this,m,u,...r); };
XMLHttpRequest.prototype.send = function(b){ try{ rec(this.__u,this.__m,typeof b==='string'?b:null); }catch(e){} return _s.call(this,b); };
```

然后**点一下第 2 页**触发一次请求（antd 分页是普通 React，`el.click()` 就生效），读 `window.__cap`：

```json
[{"url":"/api/gc/points-bill/paginate","method":"POST",
  "body":"{\"startTime\":\"2026-09-01\",\"endTime\":\"2026-09-07\",\"pageSize\":100,\"pageIndex\":2}"}]
```

✅ **必须确认「筛选参数在请求体里」**：在 → 可以放心重放 N 页；**不在 → 筛选是前端做的，重放会拿到全量数据 ✗**（那就只能老实点页，或接受全量并说明）。

### 3.3 用页面自己的 fetch 重放

- **在页面上下文里 `fetch`**，cookie/鉴权头自动带上 ✓
- ❌ 不要在 Python 里用 urllib/curl 重放（会丢鉴权，且某些站点有签名）
- 先**只取第 1 页 dump 返回形状**再写循环：本次是 `{code:1, msg:'操作成功!', data:{results:[…], total:3637, pageIndex, pageSize}}`
  —— ⚠️ **`code:1` 才是成功**（不是 0），别把别的系统的成功码照搬过来

### 3.4 页面「加载时就把数取回来了」→ 点不出请求，改用**预注入嗅探器**

**症状**：数据明明就在页面上（表格/图表都渲染了），但点任何按钮**都不发新请求**
（`performance` 里没有新增条目）→ 说明数据是**页面初始加载时一次性取回来的**，
而**加载后才挂的 hook 已经错过了它**（本次实测：不预注入 → 抓到 0 条）。

**正解：在文档创建前注入 hook，再 reload**

```python
cdp('Page.enable', session_id=sid)
cdp('Page.addScriptToEvaluateOnNewDocument', source=INJECT_JS, session_id=sid)
cdp('Page.reload', ignoreCache=False, session_id=sid)
time.sleep(25)                                    # 等它把初始请求全发完
log = json.loads(jsv("JSON.stringify(window.__NETLOG||[])") or '[]')
```

`INJECT_JS` = 把 **fetch 和 XHR 都包一层，同时记 URL / 请求体 / 响应体** ——
现成可改的 payload 见 `scripts/sniff_preload_payload.py`（直接在 browser-use harness 里跑）。

**实测收获（2026-09-25 拼多多「综合体验星级」页）**：
- 表格数据 10 项 + 30 天趋势都在页面上，**点趋势图图标不发任何请求** → 数据是首屏取的
- 预注入嗅探一次就抓到 `POST …/mallNavigator/queryUpgradeMallNavigatorList`，
  **真实请求体是 `{"beginDate":"2026-08-26","endDate":"2026-09-24"}`**
- 之前用 `{}` / 空 body 去猜这个接口，**全是 500** ✗ —— `{}` 能通的是另一个接口（`…NavigatorInfo`）。
  **教训：别用猜的 body 判定接口死活，先拿到真实请求体**
- 顺带发现：趋势图是 canvas（echarts，但**没挂 `window.echarts`**、DOM 上也没有 `__ec_*` 私有键）
  → **从图表里掏数据是死路，抓它背后的 list 接口才是正路**

⚠️ **三个坑**（本次都踩了）：
1. **别自己调 `performance.clearResourceTimings()`** —— 本次清完之后后续探测全返回空，
   白跑好几轮（它是给自己对比用的，不是「清给页面用」）
2. **响应体要用 `res.clone().text()`** —— 直接读原 response 会**把 body 消费掉**，页面自己就拿不到了 ✗
3. **hook 要 fetch + XHR 都包** —— 只包一个会漏（不同前端库不定走哪个）

---

## 3.5 接口发现升级阶梯（四条路，**别提前认输**）

**先看代价差**：拼多多帮助中心全站 3,473 条 ——
**逐条点 12.5 小时 vs 走接口 90 秒**。十一 2026-10-03 就因为看到我在逐条点，
直接说「**这个效率有些慢**」→ 我回头挖，五分钟就挖到了接口。**先挖接口，再谈怎么点。**

按顺序试，**四条都空才退到 §10**：

1. **资源时间线（§3.1）—— 过滤别太窄**
   ⚠️ 先用 `new URL(e.name).host` **按域名列全**，看清这个站有哪些域，再挑路径。
   本次先用 `/api|rule|category|list|detail|query/i` 只捞出一堆埋点（`prd-otel-*/api/traces`），
   放宽后 `cambridge/api/businessLesson/*` 才浮出来。**埋点会盖过真接口。**
2. **预注入嗅探（§3.4）** —— 「页面有数据但点不出请求」的场景。
3. **下载 JS chunk 搜接口路径（最兜底，前两条都空时用）**
   前端代码里一定有接口常量。取 JS：`document.querySelectorAll('script[src]')` 拿 URL（注意 CDN 域，
   不在主域下）→ `curl` 下来 → 按关键词 grep：
   ```bash
   grep -ohE '[a-zA-Z0-9_/.~-]*(merchant-study|getDocument)[a-zA-Z0-9_/.~-]*' *.js | sort -u
   ```
   ✅ 得物实测：hook 抓不到、performance 里只有埋点时，靠这条**一次拿到全部 5 个接口路径**
   （`getCategoryTree` / `page` / `votePage` / `getDocumentDetail` / `documentSearch`）。
   ⚠️ 路由壳 chunk（几十 KB）里没有，接口常在被异步加载的**大 chunk / 主包**里 → 多下几个再 grep。
4. **拿参数名：POST 空 body，读服务端的校验报错**
   **参数名不用猜** —— 服务端会把缺的字段念给你听。本次 PDD 用 `{}` 打过去，直接回：
   ```
   参数校验失败: length不能为空 & 二级模块id不能为空 & start不能为空
   ```
   → 三个参数名（`length` / `secondModuleId` / `start`）一次到位，**还顺带知道分页是偏移量不是页码**。
   ⚠️ **先分清「路径错」和「参数错」**：路径错 → 404/405 或站点自己的暗号
   （PDD `{"error_code":40010,"error_msg":"未知URL"}`、得物 nginx `405 Not Allowed`）；
   参数错 → **带字段名的校验文案**。别把两种混着试。
   ⚠️ **别拿空 body 的失败判定接口坏了** —— 得物那次回 401 就不必再猜（见 §3.6）。

5. **「官方 API 被权限挡住」≠「没接口」—— 换身份：用页面自己的登录态读内部接口**（2026-10-07 飞书多维表格实测）
   官方 OpenAPI 报权限错（飞书 `1254302 RolePermNotAllow`）时，**点页面上不会冒出任何新请求**
   （数据是渲染时就在的），但**页面自己调的那个内部 GET 接口带着 cookie 就能用**，返回的是结构化 JSON。
   ⚠️ 前提：读的是**用户自己账号可见**的数据，不是绕过权限去够别人的东西。
   飞书的具体接口与解码（响应体是 gzip+base64）见 `feishu-api` → `references/bitable-browser-session-read.md`。

6. **UI 怎么点都不动时，同一个通道也能「写」—— 最后的兜底**
   （2026-10-07 Cloudflare 后台实测：React + Radix 的按钮对 JS `click()` 和 CDP
   `dispatchMouseEvent` **都无反应**，`click_at_xy` 也没用）
   ```js
   // 页面上下文里直接调它自己的管理 API：cookie 自动带，不用 API Token、不用 CSRF header
   fetch('/api/v4/zones?name=<域名>', {credentials:'include'})
   fetch('/api/v4/.../<id>', {method:'PUT', credentials:'include',
        headers:{'Content-Type':'application/json'}, body: JSON.stringify({...})})
   ```
   - **先 `GET` 一次摸清资源 id 和字段名**，再动手改（别拿猜的字段名试写）
   - ⚠️ **写入的边界**（别让这条越界成「随便改线上」）：
     只在十一**明确要求做那个变更**时用（他授权的是「你去改 X」）；
     不可逆动作（提交/发布/删除）仍要他明说；
     改完**立刻回读 API 确认**，并在交付里报出改前/改后的实际值
   - 与 §3.6 的区别：签名接口**不能重放**；console 自己的 API **带着登录态就能用**

**✅ 找到接口的验收标准**：能在页面上下文里 `fetch` 用它、返回体里**有你需要的字段**，
再进 §4 循环取数。**找不到就老实走 §10**，别耗在这里。

---

## 3.6 签名接口的边界（**不做的事**）

有些站**每个请求都在前端算签名**。得物 `stark.dewu.com` 实测：每个 body 里带 `sign`，
`SK` 硬编码在前端 JS，算法是 md5 —— 我**已经定位到源码**，但**不复现**。

**判据**（命中即归本节）：响应 401 + 文案像「签名认证失败」；或 body/header 里有
`sign` / `signature` / `nonce` / `timestamp` 这类字段。

**为什么不做**（写给未来的自己和十一）：
- 属于**绕过平台接口防护**，和「不碰验证码」同一类；
- 算法一改脚本全废，**不是能长期维护的东西**；
- 高频重放容易触发风控。

**但先试这条路（2026-10-04 得物实测成功）：让页面自己发请求，我只读结果。**
签名由页面算，我当读者 —— 完全合规，而且比逐条点快得多：

1. **驱动页面产生请求 + hook 截获响应**（拿列表全部 id）
   —— ⚠️ hook 要挂 `fetch` **和** XHR：得物用的是 fetch，只挂 XHR 捕获数恒为 0
2. **直接 `goto_url(详情URL)`** —— 页面自己带正确 sign 去请求，我读渲染出的正文
   （比「点标题→读→返回」快 2~3 倍，因为不用每轮重载列表页）

✅ 得物实测：340 条 / 162 万字，**40 分钟**采完并入库
（完整流程、实测数字、坑表见 `references/dewu-rule-center.md`）。

**所以「接口要签名」≠「采不了」，它只意味着「不能重放接口」。**
2026-10-03 曾因此下结论「得物采集未完成」—— 第二天就证明是错的。

**真的都试不通时才停下来报告 + 给选项**，说清三件事：
① 结构/接口/参数**已经全摸到了**；② 卡在签名这一层；③ 给 2~3 条可走的路
（先只采一个模块打样 / 官方导出功能 / 接受慢速逐条）。
❌ 不要默默去破解，❌ 也不要假装采不到就直接交白卷。

---

## 4. 循环取数：页面后台跑 + 轮询（harness 硬限制，必踩）

⚠️ **`js()` 有 5 秒响应上限** → 直接写 `js(async () => { for (37 次 fetch) … })` 必报：
`Runtime.evaluate timed out after 5s waiting for the daemon`

**正解：启动 + 轮询两步**

```js
// 第一次调用：立刻返回 'started'，活得扔后台
window.__all = []; window.__prog = {done:0, of:37, n:0, total:null, bad:[], finished:false};
(async () => {
  for (let p = 1; p <= 37; p++) {
    try {
      const j = await (await fetch(API, {method:'POST', headers:{'Content-Type':'application/json'},
                      body: JSON.stringify({...原始参数, pageIndex: p})})).json();
      (j.data && j.data.results || []).forEach(r => window.__all.push(r));
      if (j.data && j.data.total) window.__prog.total = j.data.total;
    } catch (e) { window.__prog.bad.push(p); }
    window.__prog.done = p; window.__prog.n = window.__all.length;
  }
  window.__prog.finished = true;
})();
return 'started';
```

```python
import time, json
for _ in range(20):                      # 之后每 4 秒轮询一次
    time.sleep(4)
    st = js('JSON.stringify({done:__prog.done,n:__prog.n,total:__prog.total,bad:__prog.bad,finished:__prog.finished})')
    if json.loads(st)['finished']:
        break
```
（实测：37 页 / 3637 条约 40 秒跑完，`bad: []`）

---

## 5. 把数据运出来：页面拼 CSV + 分片取回

数据留在页面里（`window.__all`），**别指望一次返回 170KB** —— 页面里拼成 CSV，按字符切片拿：

```js
window.__csv = head + '\n' + rows.map(r => [r.f1, r.f2, r.f3].map(esc).join(',')).join('\n');
return {len: window.__csv.length, rows: rows.length};
```

```python
CH, off, parts = 28000, 0, []
while off < L:
    parts.append(js('window.__csv.slice(%d,%d)' % (off, min(off+CH, L)))); off += CH
text = ''.join(parts)
assert len(text) == L                    # 长度必须对得上
open(path, 'w', encoding='utf-8-sig', newline='').write(text)   # utf-8-sig → Excel 双击不乱码
```

---

## 6. 三条硬校验（缺一条别交付）

1. **条数 = 页面 total**（本次 3637/3637，0 失败）—— 这是唯一能证明「没漏页」的证据
2. **行数 = 页数 × 每页**（3637 = 36×100 + 37 ✓）
3. **勾稽/值域**：本次「应扣积分 = 实扣积分」3637 行全相等（差额 0）→ 写进交付说明（有差异要点名差在哪几行）

### 看起来「重复」的行，先查原始字段再下结论
本次 10 组「时间+店铺+消耗类型」完全相同的行 → 查接口原始字段发现 `platform` 分别为 1/5/7、`thirdShopId` 不同
= **同一店名在不同平台**，不是重复登记 → 交付时注明，别当成脏数据删掉。

---

## 7. 出表

- 目录：`<工作区>\数据--<主题>\`；文件名带**日期区间**（如 `探域积分消耗_2026.09.01-09.07.xlsx`）
- xlsx：**明细（全部行 · 冻结首行 · `auto_filter` · 数值 `#,##0`）** + 按日汇总 + 按维度汇总；`page_setup.fitToWidth=1` 打印一页宽
- 再存一份**原始 CSV** + 一份**汇总 md**（十一习惯两边对着看）
- 交付话术：文件表（MEDIA:）→ 合计/按日/TOP 数字（表格）→ ⚠️ 实际筛选范围 → ✅/⚠️ 自检
- ⚠️ **`MEDIA:` 路径必须和磁盘文件名逐字一致**：2026-09-29 少写一个 `0`（`09.25-9.27` ✗ vs 真名 `09.25-09.27` ✓）→ 十一那边**点不动、报「表格无法下载」** ✗。发之前用路径变量或 `ls` 回读，别手打
- **按店/按天汇总**：按 `shopName` 过滤 → 按真实归属日（见坑表）分组求和；**占比的分母用「当天全店合计」**，不是多天合计
- **十一说「美化」时的成品样式**（2026-09-29 一次通过 ✓）：标题带 `14304F` 白字 15 号粗体居中｜表头 `1F4E79` 白字加粗｜隔行浅底 `F4F8FB`｜细边框 `D6E2EC`｜数字右对齐 + 千分位｜合计行 `DCEAF7` 蓝字加粗 + 上边框加粗｜关键列加 `DataBarRule` 数据条｜`showGridLines=False`｜行高 20~24｜打印一页宽 + 水平居中
  ⚠️ 他的文件常是**多块表**（如「积分消耗登记」+「实际聊天人数登记」）→ **只上样式，不动数据 / 行列位置 / 合并格**；他说「直接在原文件上改」= 同路径覆盖，不另存（先查 `~$` 锁）

---

## 8. 坑表（都踩过）

| 坑 | 真相 |
|---|---|
| 用 `attachToTarget`+`sessionId` 指目标标签 | 不生效（读到默认标签的页面）→ 用 `switch_tab()` |
| `js()` 里 await 一长串循环 | harness 5s 上限 → **启动 + 轮询** |
| 一次把整表塞回 Python | 太大 → 页面拼 CSV + 分片 `slice` |
| 以为 `.ant-table-tbody tr` 就是行数 | 多一行 measure row → 用 `.ant-table-row` |
| 在 Python 里重放接口 | 丢鉴权 → 用**页面自己的 `fetch`** |
| 只看接口名不看 body | 筛选参数必须在 body 里，否则重放 = 全量 ✗ |
| 照用户说的「近7天」直接干 | 实际筛选常不同 → **采集前读筛选、交付时报实际范围** |
| 页面不显示的字段就当没有 | 行对象里常有 `platform`/`thirdShopId` 等，用来解释「重复」 |
| 采完不管页面 | 必须复位（点回第 1 页），他还要接着用 |
| **时间列 = 小时桶的结束时刻** | 单日、跳天都一样：拉 9/25-9/27 会看到 `09/28 00:00` 的行 —— 那是 **9/27 的最后一小时**，**归到 9/27** ✓（按天汇总必须先做这个修正，否则每天合计错、还多出一个假日期；2026-09-29 按天汇总用的就是这个规则：`时间==00:00 → 日期-1`）|
| 把「多出来的那一天」当脏数据删 | 别剔别慌 ✓ 它是正常桶边界；只修正归属，不要丢行（丢行就与页面 total 对不上了）|
| 拿别的系统的成功码 | 本次 `code:1` = 成功（不是 0）—— **先 dump 返回体再写判断** |
| 点按钮抓不到新请求 | 数据是**页面加载时**取的 → **预注入 hook + `Page.reload`**（§3.4） |
| 探测到一半开始什么都抓不到 | 自己调了 `performance.clearResourceTimings()` ✗ |
| 想从 canvas / 图表里掏数据 | 掏不出来（echarts 常不挂 window）→ **抓它背后的 list 接口** |
| **整张表格是 canvas 渲染**（飞书多维表格、部分报表后台）→ `document.body.innerText` 里一个单元格文字都没有 | 🔴 **别退回「截图 + 肉眼看/OCR」**（2026-10-07 实踩：想读 44 行 × 15 列，得滚好几屏、还把相邻列的值读串了）→ **先用预注入 hook 抓它自己的接口**（§3.4）。截图只能用来确认「表名/列名长什么样」，**取数必须走接口** |
| 用 `{}` 猜接口 body，一直 500 | 参数在请求体里，**只有预注入 hook 拿得到**；别据此判定接口坏了 |
| 响应体读不到 / 页面随后报错 | 读 body 没用 `res.clone()`，把原始 response 消费掉了 ✗ |
| 采集报 `NameError: name 'bail' is not defined` | 🔴 **不是登录问题**，是 payload 自己的 bug：payload 是**顺序执行的顶层脚本、没有函数提升**，`bail()` 被调用时它还没定义 → 报错**把真正的 `NO_PAGE`/`OPEN_FAIL` 盖掉**，害人误判成掉登录（2026-09-27 实踩）→ 见 §9 |
| 只在资源时间线里按窄正则找接口 | 埋点（`*/api/traces`）会盖过真接口 → 先按 host 列全再挑（§3.5 第 1 条）|
| 点不动就下结论「这页没有接口」 | **还有 JS chunk grep 一条路**（§3.5 第 3 条）。PDD 走接口 90 秒 = 逐条点的 **1/500**；十一为此专门说过「这个效率有些慢」|
| 用猜的参数名反复试接口 | POST `{}` 让服务端把缺的字段名念出来（§3.5 第 4 条）；同时能分清路径错 vs 参数错 |
| 接口要 `sign` 还想硬啃 | 归到 §3.6：**报告 + 给选项**，不复现签名、不假装采不到 |
| 用 `el.click()` / CDP `dispatchMouseEvent` 驱动 Angular 路由 | 都不动 → 换 **Browser Use `click_at_xy`**（§10 末节）|
| 换了 `click_at_xy` 还是点不动（React + Radix 后台） | 🔴 **别继续调坐标猜时机** —— 走**它自己的 API**：页面上下文 `fetch('/api/...')`，cookie 自动带，增删改查都能做（§3.5 第 6 条）。实测 Cloudflare 后台就是这么绕过整个 UI 的 |
| 点分页数字想翻到第 6 页以后 | 控件只渲染 `1 2 3 4 5 ••• N` → 用 **`li[class*=ant-pagination-next]`**，一路点到底（`disabled` 即到头）。PDD 与得物都踩过 |
| hook 只挂了 XHR（或只挂 fetch） | 不同前端库走不同 → **两个都挂**。得物用 fetch，只挂 XHR 时捕获数恒为 0，差点又误判成「页面不发请求」|
| 切分类/换页时 hook 丢了 | 切分类 = 导航 → hook 重置 → **先把当前分类的 id 全收完，再动下一个** |
| 靠正则裁正文，没抽查结果 | 正则不匹配时**静默不裁**（不报错）→ 得物 340 条全带导航头。**裁完必抽查 2 条开头**；已采错的可以事后清洗 JSON，不用重采 |
| 长正文按「每 N 条」切分 | 得物中位 3,610 字/条 → 每 10 条 ≈ 140 KB 超 IMA 上限 → **按字数装箱**（贪心累加 ≤ 2 万字/篇，单条正文不切断）|
| `browser_exec` 批量任务中途超时 | 默认 300s → 显式传 `timeout_s`（最大 1800），每批 ≤150 条 + 每 40 条落盘 |
| 缓存左侧层级树的节点坐标 | 展开一级后坐标全变 → **每次点击前重取** |
| 点完立刻读数据 | 异步没加载完 → 读到上一条的残留（crumb 与 total 错位）→ 等 3s + **核对面包屑/页码/total** |

---

## 9. payload 脚本自身的三条写法纪律（2026-09-27 实踩）

browser-use 的 payload 是**顺序执行的顶层脚本**（不是模块，没有函数提升），踩过的坑：

1. **helper 必须定义在第一次被调用之前** —— `bail()` / `jsv()` / 常量都一样。
   ⚠️ 反面：`bail` 定义写在「找页面」之后，页面一没开出来就调 `bail` → `NameError`，
   **把真实错误码整个盖掉**，看报错只会以为「是不是掉登录了」，白排查。
   自检：`def bail` 的行号必须 **小于** 它第一次被调用的行号。
2. **错误码必须真的报出来** —— `bail(code, msg)` 要把 `code` 写进 `__RESULT__`，
   否则上层只能看到 `NO_RESULT`，分不清是没登录 / 页面没开 / 选择器变了。
   排查顺序：**先看脚本自己有没有 bug，再去怀疑登录态**（登录态最容易跟着背锅）。
3. **别在 payload 里再套一层三引号 JS**（`JS = """..."""`）—— 嵌套引号会**静默返回空 dict**；
   拆成几次独立的 `jsv(...)` 调用。

## 10. 抓不到接口时的「列表 → 详情 → 返回」逐条采集（2026-10-03 拼多多帮助中心实踩）

**什么时候走到这一步**：走完 **§3.5 的接口发现阶梯**仍然没有可重放的接口，
或**详情内容不在列表返回体里**（列表只给标题，正文必须点进去才有）。

> ⚠️ **2026-10-03 重要更正**：本节原先记的是「拼多多帮助中心没有可抓的接口，只能逐条点」——
> **这个结论是错的**。后来找到 `POST /cambridge/api/businessLesson/lessonList`
> （body `{"secondModuleId":71,"start":0,"length":20}`，一次 20 条**带完整正文**），
> **全站 136 个模块 / 3,473 条 90 秒采完**，而逐条点是 12.5 小时。
> **当时的错**：只用窄正则扫了一遍资源时间线就下结论「没接口」。
> **铁律：走完 §3.5 全部四条路之前，不要退到本节。**

### 🔴 头号坑：点进详情再 `history.back()`，列表页码被重置回第 1 页

**症状**：第 1 页 20 条采得很顺；一进第 2 页就出事 —— 第 1 条正常（拿到第 2 页首条），
**之后每条读回来都是第 1 页的**（脚本日志全是 `[skip] 已采过`，采了一轮等于白跑）。

**❌ 错解**：以为「返回后还停在原页」——只在第 1 页做测试时**根本看不出问题**，必须跨页测才能暴露。
**✅ 正解（十一提的，实测有效）**：**别记「上一条在第几页」，改成每次点击前校正页码**：

```python
JS_CURPAGE = """(function(){
  var act = document.querySelector('[class*=PGT_pagerItemActive]');
  return act ? (act.innerText||'').trim() : '';
})()"""

for i in range(len(titles)):
    for _try in range(4):                        # 返回后页码会重置 → 点之前先翻回目标页
        if str(await c.js(JS_CURPAGE) or '').strip() == str(page): break
        await c.js(JS_GOTO_PAGE % (page, page))   # 点分页控件里文本 == page 的那个 li
        await asyncio.sleep(1.6)
    titles = json.loads(await c.js(JS_TITLES))    # ★ 翻页后 DOM 变了，标题要重取
    await c.js(JS_CLICK_T % (i, i))
```

「每条点之前校正」比「记住上一条在第几页」更稳：漏页、跳页、脚本中断都不会错位。

### 断点续采（长任务必备）

302 条 × ~13 秒 ≈ 55 分钟，中途必被打断。**每采完一条就把 `{done:[id...], items:[...], page:N}` 落盘**，
下次启动先读它 → 跳过已采 id、从记录的 page 继续。实测第 2 页恢复时 20 条走 `[skip]`、
随后直接进第 3 页，**零重复**（`唯一 id 数 == 条数`，交付前必须核这一条）。

### 关键选择器 / 定位法（PDD 帮助中心，CSS Modules 带 hash）

| 用途 | 选择器 |
|---|---|
| 列表条目 | `[class*=TopicItem_topicItem]`（`it[i].click()` 生效）|
| 正文容器 | `.rule-content` —— 干净、**无导航噪音**，`innerText` 直接可用 |
| 正文首行 | 就是面包屑「分类 / 标题」→ 一行同时拿到**分类**和**标题** |
| 文章 id | 点进去后 `location.href.match(/[?&]id=(\d+)/)`（**列表 DOM 里没有 id**）|
| 当前页码 | `[class*=PGT_pagerItemActive]` |
| 翻页控件 | `li[class*=PGT_pagerItem]`，取文本 == 页码的那个 |
| 本类总数 | `document.body.innerText.match(/共\s*\d+\s*条帮助/)` |

⚠️ **列表条目上没有 id / `data-*` 属性、也没有 href** —— 想拿 id **只能点进去**，
所以「先批量取 id、再直接构造 `?id=xxx` 跳转」这条路**走不通**，别浪费时间试。

### 自建 CDP 脚本直连十一已登录的那个 Chrome

十一自己用 `--remote-debugging-port=9555 --user-data-dir=<工作区独立目录>` 开的实例，
browser-use 自带 harness **连不到它**（会另起自己的浏览器、还可能弹「Allow remote debugging?」）。
用 `websockets` 直连即可（本机可参照 `脚本--PDD采集/grab_pdd.py`）：

```python
urllib.request.urlopen("http://127.0.0.1:9555/json/version")   # → webSocketDebuggerUrl（浏览器级）
urllib.request.urlopen("http://127.0.0.1:9555/json/list")      # → 各 tab 的 page ws，按 URL 片段挑目标
# 连 page 的 ws → {"method":"Runtime.enable"}
#              → {"method":"Runtime.evaluate","returnByValue":True,"awaitPromise":True}
```

- **登录交给十一自己扫码** —— 不碰验证码（硬规则）；我只负责开实例 + 读页面
- 给独立 `--user-data-dir`，**不污染他日常的 Chrome**
- 跑之前先 `netstat | grep LISTENING | grep :9555` 确认端口在听、`/json/version` 有响应
  （**端口 LISTENING ≠ CDP 可用**：本次 9222 被别的进程占着但服务不响应）

### 🔴 驱动 SPA 路由必须用**真实鼠标事件**（2026-10-03 得物实踩）

得物规则中心是 **Angular**（`zone.js`）。同样一个「点第 2 页」：

| 方式 | 结果 |
|---|---|
| `el.click()`（JS） | ✗ 无反应 |
| CDP `Input.dispatchMouseEvent`（mousePressed+mouseReleased，坐标已确认正确且在视口内） | ✗ 无反应 |
| **Browser Use 的 `click_at_xy(x, y)`** | ✅ **一次就通** —— 翻到第 2 页、列表内容变了；点分类 URL 从 `categoryId=0` 变 `categoryId=1013790004` |

**⚠️ 得物规则中心不需要登录** —— 所以可以直接用 Browser Use 自带的浏览器（不用非得连十一那个 9555 实例）。
**判据**：CDP 那边怎么点都「没反应」时，**别再调坐标**，换 `click_at_xy` 试一次。

四条操作纪律：
1. **坐标必须在视口内**：先 `el.scrollIntoView({block:'center'})` 再取 `getBoundingClientRect()`。
   本次滚动前 `top=1102`（视口 993）→ 点了等于没点；滚动后 `top=578` ✓。
   `r.top < 0` = 滚过头了 → 先回顶部重取。
2. **左侧导航是层级树时坐标会漂**（antd `ant-tree`：一级节点下挂二级）：点开一级会展开二级，
   **后续所有节点的 y 全变** → **每次点击前重新取坐标**，绝不缓存。
3. **点完要等 + 校验读到的内容确实属于目标**：本次出现过 crumb 与 total 错位
   （点了「商品管理」，读到的还是上一个分类的数据）→ 交付前必须核对
   **面包屑 / 当前页码 / total** 三者与目标一致，否则只是在读残留。
4. **`history.back()` 对 SPA 路由无效**（Angular 下 URL 根本不变，实测停在上一个页面）
   → 要回列表就 `location.href = '<列表 URL>'`，别指望 back。

---

## 参考

- `references/tanyuai-consume.md`：探域「积分消耗明细」完整实战记录（接口、字段映射、实测数字）
- `references/pdd-help-center-harvest.md`：拼多多帮助中心逐条采集实战（§10 模式；已验证脚本骨架、选择器表、时序与耗时、踩坑顺序）
- `references/dewu-rule-center.md`：**得物规则中心完整实战**（✅ 已采完 340 条 → 79 篇 → IMA）。
  含：接口清单、**签名机制实测边界与合规绕法**（让页面自己发请求）、
  `next` 按钮翻页、`?courseId=` 直达取正文、正文锚点裁剪、**按字数装箱切分**、
  进程/端口溯源（回答「谁在控制我的浏览器」）
- `scripts/sniff_preload_payload.py`：**预注入式接口嗅探器**（加载前注入 fetch/XHR hook → reload → 回来 URL+请求体+响应体），
  用于「页面有数据但点不出请求」「不知道接口 body 长什么样」的场景（§3.4）
- **canvas 渲染 / 官方 API 被权限挡**的站（飞书多维表格）→ 跨到 `feishu-api` → `references/bitable-browser-session-read.md`
