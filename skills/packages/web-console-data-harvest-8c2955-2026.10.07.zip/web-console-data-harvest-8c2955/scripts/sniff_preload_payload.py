# -*- coding: utf-8 -*-
"""预注入式接口嗅探器 —— 找出「页面加载时就把数取回来了」的接口（含真实请求体）。

适用：「数据就在页面上，但点/切/筛都不发新请求」的场景。
此时在加载之后挂 hook 已经晚了（错过首屏请求），必须在文档创建前注入。

用法：改下面 CONFIG 两个值，然后跑
    python scripts/sniff_preload_payload.py

输出：每条命中请求的 方法/URL/请求体/响应体前 300 字。
拿到真实请求体后，就能用页面自己的 fetch 重放（见 SKILL.md §3.3）。

⚠️ 三个坑（都实踩过，别重犯）：
  · 千万别调 performance.clearResourceTimings()——清完后续探测全空，白跑
  · 读响应体必须 res.clone().text()，直接读会把 body 消费掉、页面自己就拿不到了
  · fetch 和 XHR 都要包（不同前端库不定走哪个）
"""
import json
import os
import subprocess
import sys

# ----------------------------- CONFIG -----------------------------
URL_HINT = 'your-page-url-fragment'      # 页面 URL 里的片段，用来认出那个标签页
KEEP_RE = 'api|list|query'               # 只保留命中的接口（正则，避免刷屏）
BU_NAME = 'pddstars'                     # browser-use 命名连接（要与专用浏览器一致）
BU_CDP_URL = 'http://127.0.0.1:9445'     # 专用浏览器调试端口
BROWSER_USE = r'E:\RuanJian\Hermes\bin\browser-use.EXE'
WAIT_S = 25                              # reload 后等它把首屏请求发完
MAX_BODY = 30000

INJECT = r"""
(function () {
  if (window.__NETLOG) return;
  window.__NETLOG = [];
  function push(o) { try { window.__NETLOG.push(o); } catch (e) {} }
  var of = window.fetch;
  window.fetch = function () {
    var a = arguments;
    var url = (typeof a[0] === 'string') ? a[0] : (a[0] && a[0].url);
    var body = (a[1] && a[1].body) ? String(a[1].body) : '';
    return of.apply(this, a).then(function (res) {
      try {
        var c = res.clone();
        c.text().then(function (t) { push({u: url, b: body.slice(0, 3000), r: t.slice(0, MAXBODY)}); });
      } catch (e) {}
      return res;
    });
  };
  var oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) {
    var self = this;
    self.addEventListener('load', function () {
      push({u: self.__u, b: b ? String(b).slice(0, 3000) : '', r: String(self.responseText || '').slice(0, MAXBODY)});
    });
    return os.apply(this, arguments);
  };
})();
""".replace('MAXBODY', str(MAX_BODY))

PAYLOAD = '''
import json, time

INJECT_JS = __INJECT__
HINT = __HINT__
KEEP = __KEEP__
WAIT = __WAIT__

targets = cdp('Target.getTargets')['targetInfos']
page = next((t for t in targets if t['type'] == 'page' and HINT in (t.get('url') or '')), None)
if page is None:
    print('__RESULT__' + json.dumps({'ok': False, 'error': 'NO_PAGE: 先用浏览器把这个页面打开'}, ensure_ascii=False))
    raise SystemExit(0)
sid = cdp('Target.attachToTarget', targetId=page['targetId'], flatten=True)['sessionId']


def jsv(expr):
    r = cdp('Runtime.evaluate', expression=expr, returnByValue=True, awaitPromise=True, session_id=sid)
    return r.get('result', {}).get('value')


cdp('Page.enable', session_id=sid)
cdp('Page.addScriptToEvaluateOnNewDocument', source=INJECT_JS, session_id=sid)
cdp('Page.reload', ignoreCache=False, session_id=sid)
time.sleep(WAIT)

JS = "(() => { const keep = (window.__NETLOG || []).filter(x => new RegExp(" + json.dumps(KEEP) + ").test(x.u || '')); return JSON.stringify(keep); })()"
log = json.loads(jsv(JS) or '[]')
print('__RESULT__' + json.dumps({'ok': True, 'n': len(log), 'log': log}, ensure_ascii=False))
'''


def main():
    payload = (PAYLOAD
               .replace('__INJECT__', json.dumps(INJECT))
               .replace('__HINT__', json.dumps(URL_HINT))
               .replace('__KEEP__', json.dumps(KEEP_RE))
               .replace('__WAIT__', str(WAIT_S)))
    env = dict(os.environ)
    env['BU_NAME'] = BU_NAME
    env['BU_CDP_URL'] = BU_CDP_URL
    for k in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
        env.pop(k, None)          # 让 browser-use 用自己的环境（否则 pydantic_core 报错）
    p = subprocess.run([BROWSER_USE], input=payload, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=600, env=env)
    out = (p.stdout or '') + '\n' + (p.stderr or '')
    for line in out.splitlines():
        if line.startswith('__RESULT__'):
            res = json.loads(line[len('__RESULT__'):])
            if not res.get('ok'):
                print('失败:', res.get('error'))
                return 1
            print('抓到 %d 条候选请求：\n' % res['n'])
            for x in res['log']:
                print('---', x['u'][:120])
                print('    请求体:', (x['b'] or '(空)')[:200])
                print('    响应体:', (x['r'] or '')[:300].replace('\n', ' '))
            return 0
    print('NO_RESULT；尾部输出：')
    print('\n'.join([x for x in out.splitlines() if x.strip()][-10:]))
    return 1


if __name__ == '__main__':
    sys.exit(main())
