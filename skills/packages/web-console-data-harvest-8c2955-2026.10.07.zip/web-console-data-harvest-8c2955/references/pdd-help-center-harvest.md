# 拼多多帮助中心 · 逐条采集实战记录（2026-10-03）

对应 SKILL.md §10「列表 → 详情 → 返回」模式。十一的原话：
「你打开一个浏览器，我登录拼多多，我需要你采集网页内的内容」→
「复制这个帮助中心的所有内容，到我的知识库：拼多多-电商学习中的拼多多帮助中心文件夹中」。

---

## 1. 环境

| 项 | 值 |
|---|---|
| 站点 | `https://mms.pinduoduo.com/other/helpcenter?listId=71`（商家后台帮助中心）|
| 浏览器 | 十一自己开的 Chrome 实例，`--remote-debugging-port=9555` |
| 独立 profile | `--user-data-dir=<工作区>\---日常沟通---\chrome-pdd`（不污染日常 Chrome）|
| 目标库 | `拼多多-电商学习📚` kb_id `MxOZ443nc9bRu7vPPaXwcCG6adRfPe61qKbM5P_DuCY=` |
| 目标文件夹 | `拼多多丨帮助中心` media_id `folder_7492456249585829`（**全角竖线**）|
| 父文件夹 | 库根 `folder_id = 7478318152575812` |

⚠️ **本机 9222 端口 LISTENING 但 `/json/version` 无响应**（被别的进程占住）——
`netstat` 看到端口在听 **不等于** CDP 能用，必须实际 curl 一次。

---

## 2. 规模（先算账再动手）

```
左侧分类：36 个（热门问题/最新动态/商品管理/商品发布与编辑/商品评价/…/官方ERP）
单个分类：302 条（＝16 页 × 20 条/页）
正文长度：最短 37 / 中位 160 / 最长 1152 字
全站估算：5,000 ~ 8,000 条
```

**给出这个估算让十一先拍板**（采集范围 / 存库形式）比默默跑一夜更对。
存库形式建议 **每 50 条 1 篇笔记**（302 条 → 7 篇）：
一篇塞 7 万字太长，逐条一篇又会把笔记列表淹没。

---

## 3. 验证过的脚本骨架

脚本：`D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\pdd_help_grab.py`
CDP 小工具：同目录 `cdp.py`（`--url` 列标签 / `--on <片段> "<js>"` 执行）
输出：`D:\Agent.GongZuoQu\Hermes.GZQ\数据--PDD帮助中心\`
      `cat_<listId>.json`（成品） + `.progress_<listId>.json`（断点）

```python
CDP_PORT = 9555

class CDP:
    async def connect(self):
        import websockets
        self.ws = await websockets.connect(self.ws_url, open_timeout=15, max_size=None)
        await self.send("Runtime.enable", {})
    async def js(self, expr):
        r = await self.send("Runtime.evaluate",
                {"expression": expr, "returnByValue": True, "awaitPromise": True})
        if "exceptionDetails" in r: return {"__error__": r["exceptionDetails"]["text"][:200]}
        return (r.get("result") or {}).get("value")
```

**关键 JS**：

```js
// 列表标题
[class*=TopicItem_topicItem]  →  [...document.querySelectorAll(SEL)].map(e=>e.innerText.trim())

// 点击第 i 条（必须带索引重新查，返回后 DOM 是新的一批）
(function(){ var it=document.querySelectorAll('[class*=TopicItem_topicItem]');
             it[%d].click(); return 'ok'; })()

// 读详情（一行同时拿到 id / 分类 / 标题 / 正文）
(function(){
  var c = document.querySelector('.rule-content');
  var lines = c.innerText.trim().split('\n').map(s=>s.trim()).filter(Boolean);
  var crumb = lines[0];                                   // 「分类 / 标题」
  var body  = lines.slice(1).join('\n')
                .replace(/这条知识对你有帮助吗？[\s\S]*$/, '').trim();
  var m = location.href.match(/[?&]id=(\d+)/);
  return JSON.stringify({id:m?m[1]:'', crumb:crumb, body:body});
})()

// 当前页 / 翻页
'[class*=PGT_pagerItemActive]'                       → 当前页码文本
'li[class*=PGT_pagerItem]' 中文本 == page 的 → .click()
```

---

## 4. 实测时间与踩坑顺序（照这个顺序复现最快）

```
1) 开浏览器 → 十一扫码登录（我不碰验证码）
2) 探 DOM：TopicItem_topicItem / rule-content / TopicItem_desc__2Mh4Y（CSS Modules 带 hash）
3) 猜接口 ✗  →  /latitude/api/help/topic/list … 全是 {"error_code":40010,"error_msg":"未知URL"}
   ⚠️ 猜错时返回的是 HTTP 200！不能靠状态码判成败，要看 body 的 error_code
4) hook fetch+XHR → 点分页 ✗  分页选择器写错，抓到 0 条 → 没继续纠缠接口
5) 单篇验证 ✓  →  5 条，id + 面包屑 + 正文全拿到
6) 跨页测试 ✓  →  第 1~2 页 40 条（这一步才暴露「返回重置页码」）
7) 全量跑 →  卡在第 2 页 → 发现 20 条全 [skip] → 定位为页码重置 bug
8) 修法：点之前校正页码 + 重取 titles → 跨页测 40 条零重复 → 全量重跑 ✓
```

**每次返回后的固定节奏**：`校正页码 → 重取 titles → 点击 → sleep 2.0s 读 → history.back() → sleep 1.5s`
≈ **13 秒/条**（302 条约 55 分钟）——**先把这个数报给十一**，别让他干等。

---

## 5. 交付纪律

- 采完先**把成品前 3 条完整内容贴给十一看**，确认格式/颗粒度没问题**再传知识库**
- 不直接往他库里写（看板/网页/软件类改动同样：**先本地、他拍板、再同步线上**）
- 交付前自检必报：`条数 == 唯一 id 数`（防静默重复）、实际采集范围、耗时

## 6. 待办（本次未走完）

全量 302 条跑完后仍是**单个分类**；剩余 35 个分类**尚未采集**。
换分类即换 `listId`（当前是 71），URL 形如 `helpcenter?listId=<N>` ——
左侧分类项的点击会改这个参数，可据此批量遍历。
