# 得物规则中心（stark.dewu.com/rule-center）—— 签名接口下的合规采集

> **状态：✅ 已完成（2026-10-04）**。340 条 → 79 篇 → IMA「得物平台-电商学习」。
> 从 12:00 开始探路，卡在 `sign` 一次，找到合规路径后采集 40 分钟。
>
> **教训（写给未来的自己）**：2026-10-03 曾把状态写成「采集未完成、卡在签名、等十一拍板」。
> 实际上第二天就找到了**完全合规**的路（让页面自己发请求），并且一次采完了。
> **接口要签名 ≠ 采不了** —— 先看完本节 §合规路径 再决定要不要报告卡点。

## 目标

把得物规则中心全站内容采进 IMA 知识库「得物平台-电商学习」。

- 库 ID：`uzErjPa0D7sQUnyp-xrgRQTwfM9U_PJ9JwGKPvHoIJI=`（根目录，无子文件夹）
- 页面：`https://stark.dewu.com/rule-center/detail?type=2&categoryId=0&where=list_details`
- **不需要登录**（右上角显示「登 录」但内容照样看）→ 因此可用 Browser Use 自带浏览器，不必连十一那个 9555 实例。

## 页面结构

- **纯客户端渲染**：原始 HTML 只有 ~2.6 KB 空壳（curl 拿不到内容），浏览器里 `outerHTML` ~59 KB 且含数据。
- 左侧是 **antd 层级树**：一级分类 12 个，下挂二级子分类，**点开一级会展开二级**。
- 「规则公示中心」= **340 条 / 35 页**（10 条/页）。
- 关键选择器：`[class*=ruleTitle___]`（标题）、`[class*=ruleTime___]`（日期）、
  `[class*=ruleTitleBox___]`（列表项）、`li[class*=ant-pagination-next]`（下一页）、
  `li[class*=ant-pagination-item-active]`（当前页）、`[class*=breadcrumb]`、
  `[class*=ruleCenterContainer]`（详情页最外层，**含大量导航噪音**）。
- ⚠️ 列表项**没有 href / `data-*` / id**，点击靠 Angular 事件绑定 → **要拿到 id 只能从接口响应里 hook**。

## 接口清单（grep 前端 JS 挖出来的）

实际前缀 `/api/v1/h5/merchant-study/`：

```
POST .../merchant/document/common/stark/getCategoryTree    分类树
POST .../merchant/document/common/stark/getDocumentPage    文档分页
POST .../merchant/document/common/stark/getDocumentDetail  正文详情
POST .../merchant/document/common/stark/documentSearch     搜索
POST .../merchant/rule/page                                规则分页
POST .../merchant/rule/votePage                            ★ 规则公示中心用这个
```

```jsonc
// 列表
POST .../merchant/rule/votePage
body: {"voteStatus":0,"keyword":"","pageNum":1,"pageSize":10,"sign":"…"}
resp: {"code":200,"data":{"pageNum":1,"pageSize":10,"total":340,"pages":35,
       "contents":[{"id":1017199344,"title":"关于变更《星桥平台服务协议》公开征求意见",
                    "publishTime":"2026-09-29 17:53:26",
                    "categoryInfos":[{…},{name:"规则公示中心"}],
                    "content":null}]}}          // ⚠️ 列表里 content 恒为 null，正文必须另取

// 正文
POST .../document/common/stark/getDocumentDetail
body: {"documentId":1017199344,"sign":"…"}      // documentId == 列表里的 id
```

## 🔴 签名机制（不復现，但要知道边界）

必需请求头（**静态**）：
```
SK: 9UBoNF9kkC1xfS4v7oDnXHS5WeJKc4DBY3jtNlzjDG43eQvcq1sqwiD9oVnrLp73hK5Y6INCFLtlAtbApkifr77aOg1v
clientId: stark | sysCode: DU_USER | channel: pc | appid: h5 | platform: h5
Content-Type: application/json;charset=UTF-8
passportToken: false          ← 未登录时是这个字面量；登录后变成真实 token（但签名要求不变）
```

**实测四种情况**（2026-10-04）：

| body | 结果 |
|---|---|
| 不带 sign | ❌ 401 签名认证失败 |
| `sign:""` | ❌ 401 |
| `sign:"000…0"`（假） | ❌ 401 |
| **复用页面刚发过的 sign** | ✅ **200** |

**关键事实**：`sign` 是**无状态的** —— 同一组参数永远是同一个 sign，**不带时间戳/nonce**
（`getCategoryTree` 的 `{channel:1,levelOneCode:'Stark_Rule_Center'}` 在 2026-08 就是 `3adf85421a5a3fdb155be8a24b12410e`，10 月仍是）。

> ⚠️ **“很容易推”恰恰是不要推的理由**。无状态 + 算法在前端（`md5`，源码已定位）= 技术上十分钟就能复现，
> 但那是**绕过平台接口防护**，与「不碰验证码」同类：算法一改脚本全废、高频重放拉风控。
> 技术可行 ≠ 应该做。**判据与话术见 SKILL.md §3.6。**

**登录不改变签名要求**：十一登录商家后台后重探，`passportToken` 变成真 token，但照样要 sign。
所以「让十一先登录」这条路**走不通**，不用再试。

## ✅ 合规路径：让页面自己发请求，我只读结果

核心思路：**不重放接口，而是驱动页面产生请求、截获响应，或直接 goto 让页面自己取数**。
签名由页面算，我只当读者。

### 第 1 步：翻页收集全部 id（hook + next 按钮）

**🔴 hook 必须挂 `fetch`（得物用 fetch，不是 XHR）**：
```js
window.__cap = [];
const oF = window.fetch;
window.fetch = function(u, o){
  const url = (typeof u === 'string') ? u : (u && u.url) || '';
  return oF.apply(this, arguments).then(res => {
    if (/merchant-study/.test(url)) { const c = res.clone();
      c.text().then(t => { try { window.__cap.push({api:url.split('/').pop(), body:o&&o.body, resp:t}); } catch(e){} }).catch(()=>{}); }
    return res; });
};
```
> 实践教训：第一版只挂了 `XMLHttpRequest` → 捕获数恒为 **0**，差点又误判成「页面不发请求」。
> **两个都挂**（SKILL.md §3.2 已有此条，这里是实锤）：挂错就什么都抓不到。

**🔴 翻页用 `next` 按钮，不要点页码数字**：
分页控件是 `1 2 3 4 5 ••• 35` + next —— 点数字到第 6 页就点不动了，
而 `li[class*=ant-pagination-next]` 可以一路点到底（`disabled` 即到底）。

```python
def click_next():
    r = js("""(() => {
      const wrap = document.querySelector('[class*=ant-pagination]');
      wrap.scrollIntoView({block:'center'});
      const nx = wrap.querySelector('li[class*=ant-pagination-next]');
      if (!nx || String(nx.className).indexOf('disabled')>=0) return 'disabled';
      const rr = nx.getBoundingClientRect();
      return JSON.stringify({x: Math.round(rr.left+rr.width/2), y: Math.round(rr.top+rr.height/2)});
    })()""")
    if not r.startswith('{'): return r
    p = json.loads(r); time.sleep(0.4); click_at_xy(p["x"], p["y"])
    return "clicked"
```

- 每页 10 条 → 340 条 = 34 次 next，约 3.2 秒/次 → **2 分钟拿全**
- **不能中途切分类**：切分类会导航 → **hook 丢失**。先把一个分类的 id 全收完，再动下一个。
- ⚠️ **第 1 页容易漏**：hook 注入时页面已加载完，第 1 页的响应早发过了。
  → **最后回第 1 页再点一次**补上（本次实测：330 → 补齐后 340）。
- 去重靠 id 字典（`{str(id): item}`），`len(set(ids)) == total` 即为完整。

### 第 2 步：逐条取正文（直接 goto，不要点标题再返回）

```python
goto_url(f"https://stark.dewu.com/rule-center/detail?type=2&categoryId=0&where=list_details&courseId={id}")
time.sleep(2.6)
body = js(READ_JS)
```

**为什么不用「点标题 → 读 → 返回」**：`history.back()` 对 SPA 无效（实测回到 `about:blank`），
而每轮都重新加载列表 + 定位页码会把单条耗时推到 6~8 秒。
**直接 goto 详情 URL**：页面自己带正确 sign 去请求详情，**单条约 2.6 秒**。

**正文裁剪**（`ruleCenterContainer` 含整块左侧导航 + 页脚）：
```js
let t = document.querySelector('[class*=ruleCenterContainer]').innerText || '';
const i = t.indexOf('历史协议规则');          // 左侧导航最后一项
if (i >= 0) t = t.slice(i + 6);
for (const stop of ['关于本次规则意见征集','关联平台','这条知识对你有帮助']) {
  const e = t.indexOf(stop); if (e > 0) { t = t.slice(0, e); break; }
}
t = t.replace(/\n{3,}/g, '\n\n').replace(/[ \t]+\n/g,'\n').trim();
```

> ⚠️ **锚点选错会静默失败**：第一版用正则 `/规则公示中心\s*\//` 匹配面包屑，
> 但实际文本里面包屑**没有斜杠**，匹配不上 → **不报错、直接不裁** →
> 340 条的 body 全带着「规则中心/返回首页/登 录/12 个分类名」的导航头。
> **好在不用重采**：清洗脚本扫一遍已采的 `dewu_docs.json` 就能修（本次修了 340 条）。
> **以后：裁剪后一定抽查 2 条的开头，别假设裁掉了。**

### 第 3 步：执行参数

- `browser_exec` 默认 **300 秒超时** → 批量采集必须显式传 `timeout_s`（最大 1800）
- 每批 ≤ 150 条（150 × 2.6s ≈ 390s，配 `timeout_s=1500` 安全）；中间每 40 条落一次盘
- 数据写在 browser-use 的 workspace（`$BH_AGENT_WORKSPACE`），用 id 去重字典累积 → 重跑即续采

## 实测数字（规则公示中心，2026-10-04）

```
条数        340/340（唯一 id 340，零重复，零失败）
正文字数    最短 207 / 中位 3,610 / 最长 25,241
合计        1,620,310 字（清洗导航头后 1,581,795）
耗时        列表 ~2 分钟 + 详情 ~30 分钟 ≈ 40 分钟
```

**⚠️ 得物正文比拼多多长一个量级**（拼多多的中位数只有 90 字）。
**直接后果：切分不能按条数**（见下）。

## 切分与上传

**❌ 每 10 条一篇**：中位 3,610 字/条 → 每篇 4.7 万字 ≈ **140 KB**，超 IMA 单篇上限。
**✅ 按字数装箱**：贪心累加到 ≤ **20,000 字**就开新篇，**单条正文不切断**。

```python
ds = sorted(docs, key=lambda x: -x["len"])      # 长的先放，减少碎片
bins = []
for it in ds:
    for b in bins:
        if b["chars"] + it["len"] <= 20000: b["items"].append(it); b["chars"] += it["len"]; break
    else: bins.append({"items":[it], "chars": it["len"]})
```

单条本身就超 2 万字的（如《商家服务协议》25,241 字）**单独成篇，不切正文**。

实测：340 条 → **79 篇**，体积 39~70 KB，**0 篇超 200 KB**。

上传：`import_doc`（标题写在 content 首行）→ `add_knowledge`（**不传 `folder_id` = 挂根目录**）→
`get_knowledge_list` 循环到 `is_end` 回读验证 → **79/79 在位、0 标题异常、0 重名**。

脚本：`脚本--PDD采集/dewu_build.py`（装箱切分）、`ima_upload_dewu.cjs`（断点续传上传）。

## 坑总结

| 坑 | 真相 |
|---|---|
| hook 只挂 XHR | 得物用 **fetch** → 捕获数恒为 0，挂两个 |
| 点分页数字翻页 | 控件只有 `1 2 3 4 5 ••• 35` → 用 **next 按钮** |
| 以为切分类不影响采集 | 切分类=导航 → **hook 丢失** → 先收完 id 再动 |
| 忘了第 1 页 | hook 注入时首屏响应已发过 → 最后回第 1 页补一次 |
| `history.back()` 回列表 | SPA 无效（回 `about:blank`）→ 用 `goto_url` |
| 点标题进详情再返回 | 每轮要重载列表+定位页码 → **直接 goto `?courseId=`** |
| 正文裁剪锚点没验证 | 正则不匹配时**静默不裁** → 抽查 2 条开头 |
| 按条数切分长正文 | 得物中位 3,610 字 → 按 **字数装箱** ≤2 万字/篇 |
| `browser_exec` 默认超时 | 300s → 批量任务传 `timeout_s=1500` |
| 想用「登录后就没签名了」 | 登录只换 `passportToken`，**签名照旧** → 此路不通 |
| 层级树坐标缓存 | 展开一级后全部下移 → 每次点击前重取 |

## 顺带：怎么回答「谁在控制我的浏览器」

十一会突然警觉地问这句（本次 2026-10-06）。**给进程级答案，别只说「是我」。**

```bash
# ① 找监听/连接的 PID
netstat -ano | grep LISTENING | grep -E ":(9222|9334|9337|9555)"

# ② 看那个 PID 在连谁
netstat -ano | grep ":9222"          # LISTENING + ESTABLISHED 两端都看

# ③ 拿 PID 的命令行 + 父进程
powershell -NoProfile -Command "\$p=Get-CimInstance Win32_Process -Filter 'ProcessId=<PID>'; \$p.CommandLine; \$p.ParentProcessId"
```

本次实测链条：`127.0.0.1:9222 ← PID 13280` →
命令行是 `...\uv\tools\browser-use\Scripts\python.exe -m browser_harness.daemon`
→ **是 Hermes 自己的 browser-use 守护进程**（Browser Use 用独立 Chrome 实例，走 9222，
与十一日常那个 Chrome 是两套配置目录，互不干扰）。

**回答时要说清三件事**：① 是哪个进程、什么命令行；② 它和用户自己的浏览器**不是同一个**；
③ 给可操作的选项（关掉它 / 用完自动关 / 不动），并说明关掉不影响数据和账号。
