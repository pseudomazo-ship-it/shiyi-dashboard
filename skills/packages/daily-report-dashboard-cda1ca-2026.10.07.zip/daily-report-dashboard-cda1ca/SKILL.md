---
name: daily-report-dashboard
description: Use when 十一要数据日报或改日报看板。含同步→推链接全流程与口径。
---

# 数据日报看板

## 🆕 V2 新排版（2026-10-06 十一给了新模板，**以后用这个**）

十一发的 `数据日报.html`（Executive 浅色蓝调风格、单文件、23 家店、5 时段）是**新排版**。
生成器：**`scripts/daily_dashboard_v2.py`**（复用 `daily_dashboard.py` 的取数与 `build()`，只换数据不动设计）

```bash
E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe E:/RuanJian/Hermes/scripts/daily_dashboard_v2.py
```

| 项 | 值 |
|---|---|
| 模板（**别改**） | `scripts/templates/daily_report_v2.html`（**已内含密码门**） |
| 产物（正式路径） | `cache/shiyi-dashboard-git/daily/index.html` ← 2026-10-06 已切 V2 |
| 本地副本 | `D:\Agent.GongZuoQu\Hermes.GZQ\数据--数据日报\数据日报.html` |
| 旧排版备份 | 同目录 `数据日报_旧版排版备份_2026.10.06.html` |
| 数据源 | 飞书「运营数据登记」`Q6PZbQRH3aZum0skE3Pc8WCVnPh` / `tbl9bX2VE4PXRRiM`（同旧版） |

### ✅ 已接的定时链路（2026-10-06 切换完成）
| 时间 | job_id | 脚本 | 说明 |
|---|---|---|---|
| 23:45 | `ee58ecb16feb` | **`daily_dashboard_v2.py`** | 已从旧生成器改指 V2 |
| 23:55 | `a56150a4e42f` | `daily_report_push.py` | 已兼容 V2（读 `meta.base_day`+`names`） |
| 7/10/13/16/19 | `502623247cea` | `daily_push_retry.py` | 不动（它调旧脚本的 `--push-only`，**只推不生成**，安全） |

### ⚠️ V2 必须保留的标记（删了校验就瞎）
看板 JS 里这两行是给推送/核对脚本读的，**不能删**：
```js
const meta={"gen":"YYYY-MM-DD HH:MM","base_day":"YYYY-MM-DD","v":2};
const names=[...23家店...];
```
`daily_report_push.py` / `daily_dashboard.git_push()` 都靠 `"gen":"..."` 正则回读；
`base_day_of()` 靠 `"base_day"` + `names` 长度。缺了 → 会误报「线上还是旧版」。

### 🔴 V2 三条铁律（踩过）
1. **`names` 与每一档 `rows` 必须严格同序** —— 模板里 `rows()` 是**按下标**取店名的
   （`function rows(raw){...map((s,i)=>{name:names[i]...})}`）。顺序错 → 全表店铺张冠李戴。
   现在统一用**全局唯一 order = 30天业绩降序**，5 个时段都按它出行。
   （模板原件的 names 顺序不是按业绩排的，但只要内部一致就正确 —— JS 渲染会自己重排。）
2. **23 家店 = 飞书全部 26 个名字 去掉 `?` / `MQ染发直售店` / `青丝堂`**（脚本里的 `SKIP`）。
3. **只换数据，别动 CSS/结构**；改了要同步回 `templates/daily_report_v2.html`。

### 🔴 两个图表坑（2026-10-06 十一报的，已修）
**① 店铺业绩排行柱子看不见长短** —— 根因：`.fill` 是行内 `<i>`，**行内元素上 `width`/`height` 不生效**，永远 0 宽。
修：`.fill{display:block}`。⚠️ CSS 里 `.fill` 有**两条**规则，两条都要带 `display:block`（后一条会覆盖前一条）。
**② 业绩走势** —— 十一要**折线图 + 鼠标悬停看数据**，不是柱状。已重写成 SVG：
网格 + 面积 + `polyline` 折线 + 数据点 + 最高/最低强调点 + **每日透明热区 `.thit`（带 `data-d`/`data-v`）** \
+ 固定定位 `#ttip` 提示框（`mouseover/mousemove/mouseout` + `touchstart/touchend`）。
- 改这两个图表的脚本：**`scripts/patch_v2_charts.py`**（已跑过，模板已含，重跑会重复注入 → 先还原备份再跑）
- 断点/缺数据：`trend.values` 里的 `null` 会**断开折线**、热区显示「未登记」
- ⚠️ tooltip 背景 `#fff` + 文字 `var(--ink)`，**别写成白底白字**（旧看板踩过）

### ✅ V2 无浏览器验证法（浏览器守护挂掉时用）
`browser_exec` 有时会卡死。可用 **Node + 迷你 DOM shim 跑整个 `<script>`**：
把 `<script>` 抽出来，用桩对象替掉 `document/window/sessionStorage/location`
（`style` 要带 `setProperty`），`new Function(...)()` 执行后读 `#ranking`/`#trend` 的 `innerHTML`，
断言：`rank-row`=10、`--w` 各不相同、`<polyline>`/`<polygon>`/`circle`/`thit` 数量、
热区 `data-d`/`data-v`。**能同时验证整页 JS 不报错**（比截图有用）。
另：`node --check` 先过一遍语法。node 路径：`C:/Users/Administrator/.workbuddy/binaries/node/versions/*/node.exe`。

### 验证方法（很有用）
拿**同基准日的旧产物**当基准：因为基准日规则一样（23:00 前报前天），
用同一份飞书数据重跑，生成的数字应与上次**逐位相同**。脚本：
比对 `kpis / totals / score / total / rows / monthly / 预警文案`。
⚠️ `rows` 的顺序会不同（模板原件的 names 非业绩序）——**只比集合不比顺序**，
但要另外验「names[i] ↔ rows[i] 同序」这条。

### V2 与旧版的口径差异
- 预警①「下滑最重」= 当日 vs **前3天该店日均**（不是前一日）
- 预警②「异常波动」= 当日 vs 前一日；门槛 业绩≥20% 且差≥800 元 / 数值≥8pt
- 小结里的「标准线」= **46%**（不是与上期比）
- 走势标签日期**补零**（`09/28`）
- `month` 走势若哪天没登记 → 置 `null`（前端显示「未标注」）

---

# 数据日报看板（V1 / 旧版，保留参考）

## 🔒 口径变更纪律（2026-09-27 十一要求，**读这份技能先看这条**）

**十一给口径时：照字面实现，不要自作聪明推导「他真正的意思」。**

反面案例（2026-09-26 实踩）：十一说「23:00 前报 9/24、23:00 后报 9/25」，
我嫌「早上会看到空数据」，擅自改成「永远报昨天」→ 结果第二天日报日期不对，挨批。

铁律：
1. **照字面写**。他说的时点/天数就是字面意思，不要替他「优化」。
2. **听不清就问一句**，别猜（猜错的代价 > 问一句的尴尬）。
3. 改完**跑自检表**：把「几个关键时点 → 算出的日期」逐行列出来贴给他确认。
4. **口径一旦锁定，除非他开口，不动**；要改先复述一遍新口径、等他确认。

## 🔒 总结文案纪律（2026-09-27 十一要求）

**所有总结/问题列表必须完整列出，不能用「等」「另有 X 家」「…」省略。**
- ❌ 反面：`⚠️ 15 家业绩下滑（A、B、C 等）`、`另有 7 家上升`
- ✅ 正确：`【下滑的店（全部 13 家）】` + 1~13 逐行列完（店名 + 前值→现值 + 涨跌%）
- 涉及位置：数据小结的「业绩下滑」、近30天的「店铺趋势小结」（上升/下滑/持平/无对比都列全）
- 判断：`grep -c "另有\|等）\|..."` 应为 0

## 触发场景

| 十一说 | 我做什么 |
|---|---|
| 「要日报」「日报链接」「发我日报」 | **① 先跑同步 → ② 再推链接**（见下方流程） |
| 「改日报看板样式/口径」 | 改 `daily_dashboard.py` → 重生成 → 推送 |
| 「日报怎么没更新」 | 查 cron 任务 + 看板文件 mtime |

## 标准流程（十一要日报时必走）

**只跑一条命令**（实测 **42 秒**）：

```bash
E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe E:/RuanJian/Hermes/scripts/run_daily_report.py
```

**它会自动完成：**
1. 飞书取数 → 生成看板 → `git pull --rebase` → push（6 次重试）
2. **回读线上 `meta.gen` 核对**（push 返回 0 不等于线上更新了，见下方专节）
3. 核实成功后 → 输出「✅ 已更新（时间）｜基准日 M/D（N 家）+ 链接」
4. 失败时明确报错，绝不静默

**然后把输出原样发给十一**（已含链接）。

**退出码**：`0`=成功 / `1`=同步失败 / `2`=本地已更新但推送失败

### 手动分步（排查时用）

```bash
VENV=E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe
# ① 取数+生成+推送
$VENV E:/RuanJian/Hermes/scripts/daily_dashboard.py
#   加 --no-push 则只生成不推送
# ② 核实+出链接
$VENV E:/RuanJian/Hermes/scripts/daily_report_push.py
```

⚠️ **顺序不能反**：先同步再推链接。**绝不能只发链接不更新** —— 那发的是旧数据。

### ⚠️ 夜里 git push 可能失败（2026-09-27/28 血泪坑）

**现象**：十一白天打开看板，说「和飞书表格内容不一样、差很多内容没推送」。
**真相**：看板数据**没错**（逐行拉飞书 6142 条比对，当天家数/业绩完全一致）——
是**线上网页停在旧版**（9/27 12:27 那版、基准日还写着 9/25），
而飞书已经有 9/26 的完整数据 → 差了一天。
**原因**：9/27 夜里 `git push` 失败 —— `Failed to connect to github.com port 443`
（国内网络常规；Pages 域名走 CDN 却正常，所以网页能开、却推不上去）。

**处理（已做，不要再重复踩）**：
1. `daily_report_push.py` 的告警文案要**点名原因**：本地版本 vs 线上版本 + 「多半是 github.com 连不上」
2. 新增 **`scripts/daily_push_retry.py` + cron `502623247cea`（7/10/13/16/19 点）**：
   一致=静默；落后=重推最多 3 轮；仍不行才告警。**这是防“夜里推失败、白天看旧版”的保险。**
3. 排查口诀：怀疑看板“数据不对”时，**先看线上 `meta.gen` 是不是最新**，再怀疑取数。
   线上 gen 一看就能分辨：“数据旧”还是“数据错”。

### 飞书表里没被用到的字段（共 8 个，十一 2026-09-28 问过“差很多内容”）

```
问卷编号 / 平台·店铺类型 / 负责人
净业绩 / 全店净投产 / 净客单 / 退款率 / 推广占比 / 数值占比（后 6 个是公式字段）
```
- 看板自己另算了一套（数值、退款占比、推广占比）→ **口径可能跟表内公式字段不完全一样**
- 若十一要求“跟表一致”，优先加 **净业绩**（可交叉验证）+ **负责人**
- 取数只用：日期 / 店铺名称（旗舰店|个人店）/ 当日总业绩 / 退款金额 / 推广花费 / 成团单量 / 退款单量

## 定时任务

| 时间 | job_id | 脚本 | deliver |
|---|---|---|---|
| **每天 23:45** | `ee58ecb16feb` | `daily_dashboard.py` | `local`（静默，只更新不推送）|
| **每天 23:55** | `a56150a4e42f` | `daily_report_push.py` | `qqbot`（推链接到 QQ）|
| **7/10/13/16/19 点** | `502623247cea` | `daily_push_retry.py` | `qqbot`（一致则静默）|

> ⚠️ `daily_push_retry.py`（2026-09-28 加）：夜里 push 失败时，白天自动补推；
> **一致就静默不打扰**，只有补不上才告警。不要删（删了又会出现“白天看旧版”）。

**周报/月报已停用**（十一 2026-09-25 定），不要再建。

## 数据源与产物

- **飞书 Base**：`Q6PZbQRH3aZum0skE3Pc8WCVnPh` / 表 `tbl9bX2VE4PXRRiM`（约 6,082 条 / 267 天 / 26 家店）
  - ⚠️ 店铺名带运营后缀（盼/博/涛/丽/熙/炜/珍），与其他源对齐须先去后缀
- **生成器**：`E:\RuanJian\Hermes\scripts\daily_dashboard.py`（默认生成 + 自动 push；`--no-push` 只生成）
- **产物**：`cache/shiyi-dashboard-git/daily/index.html` → 线上 `pseudomazo-ship-it.github.io/shiyi-dashboard/daily/`
- **本地副本**：`D:\Agent.GongZuoQu\Hermes.GZQ\数据--数据日报\日报看板.html`
- **访问密码**：`11`（前端门禁，密码存加盐哈希 `e818342`）

## 口径规则（十一 2026-09-25 拍板，不可自行改）

### 基准日（🔄 2026-09-26 十一明确，**2026-09-27 锁定，不要再改**）

| 生成/推送时间 | 报哪一天 |
|---|---|
| 当天 **23:00 之前** | **前天** |
| 当天 **23:00 之后**（含 23:45 定时、23:55 推链接） | **昨天** |

自检表（已跑过，完全对得上十一的说法）：
```
2026-09-26 10:35  →  基准日 09/24      ← 十一白天要，就是 9/24
2026-09-26 23:45  →  基准日 09/25      ← 定时同步
2026-09-26 23:55  →  基准日 09/25      ← 定时推链接（十一：必须推 9/25）
2026-09-27 08:34  →  基准日 09/25
2026-09-27 23:45  →  基准日 09/26
```

- ⚠️ **不按登记完整度回退**，也不因「当前这天填得少」而跳天 —— 定哪天就报哪天
- **漏登照报**：由看板「数据提示 → 登记漏登」块统计（**近30天**逐日列缺哪几家 + 当日 X/23 家）
  ⚠️ 2026-09-30 十一改：窗口从「近15天」→「当月」→ **「近30天」**（重复登记块同窗口）
  实现：`const _d30=new Date(last+'T00:00:00Z'); _d30.setUTCDate(_d30.getUTCDate()-29);
           const start30=_d30.toISOString().slice(0,10); const recent=days.filter(d=>d>=start30&&d<=last);`
- **看板头部副标题直接显示基准日**（`基准日 2026-09-25 | 统计 …`）—— 一眼看出是哪天
- **实现（2026-09-27 改，两处）**：
  1. **看板（JS）`resolveBaseDay()` 按打开页面的当前时间实时算** —— 不再用写死的 `meta.base_day`，
     否则 HTML 生成后跨了自然天就不对（列表放那里两天，第二天打开还是旧基准日）。
     东八区修正：`new Date(now.getTime() + (now.getTimezoneOffset() + 480) * 60000)`，
     然后 `getHours() >= 23 ? 退1天 : 退2天`。
  2. **Python `_now.hour >= 23 ? 昨天 : 前天`**（定时任务用），两者结果必须一致。
- **自检方法**：用 `browser_exec` + 覆盖 `window.Date` 模拟不同时刻，逐行列出「时刻 → 基准日」，
  对着十一的规则表逐条核（实测已过：9/27 14:35→9/25、1 9/27 23:45→9/26、9/30 10:00→9/28）

⚠️ **这条规则改过 3 版**（完整度回退 → 23:00 分界 → 固定昨天 → **回到 23:00 分界**）。
教训：十一说「23:00 前报 9/24、之后报 9/25」时别自作聪明改成「永远报昨天」——
**照字面实现**，有疑问先问，别自己推导他「真正的意思」。

### 店铺名显示全名（🔄 2026-09-26 十一改）

看板里**所有店铺名一律显示全名**（如「蒙倩美发护发官方旗舰店（盼）」），**不再去掉「蒙倩」**。
- 旧做法：JS 里 6 处 `${v.nm.replace('蒙倩','')}`；现已全改成 `${v.nm}`
- 自查：`t.count(".replace('蒙倩'") == 0`
- 涉及位置：店铺业绩条形图 / 明细表 / 业绩下滑 / 异常数据 / 登记漏登 / 数据小结
- （Python 侧 `short_name()` 已不再使用，留着不影响）

### 时间段与对比（严格等长对比）
| 时段 | 统计区间 | 对比区间 |
|---|---|---|
| 当日 | 基准日（1 天）| 前一日 |
| 近 3 天 | 基准日往前 3 天 | 前 3 天 |
| 近 7 天 | 基准日往前 7 天 | 前 7 天 |
| 当月 | 本月 1 号 ~ 基准日 | **上月同期**（上月 1 号 ~ 同号）|
| **近 30 天** | 基准日往前 30 天 | 前 30 天 |

**5 个时段**（十一 2026-09-27 从 4 个扩到 5 个）。数据里 `data-w` 分别是 `1/3/7/m/30`。
新增时段要同步的地方：`pickDays`/`pickPrev` 已通用、`sumTips` 标签、`cmpLabel`、`periodName`、`cmpName`、
总业绩趋势折线图的显示条件 `(w===7 || w===30 || w==='m')`、tabs 横向可滑（5 个按钮手机不挤）。

### 指标口径
- **数值** = (退款 + 推广费) / 业绩 × 100%
- **推广费占比** = 推广费 / 业绩
- **退款占比** = 退款 / 业绩
- **客单价** = 业绩 ÷ 成团单量
- **标准线**：46%（数值超过即标红）

### 颜色分档（必须全部用 46% 基准，别用 30/20）
看板里**所有**涉及数值判断的地方统一用：**≥46% 红 / 42~46% 橙 / <42% 绿**
包括：表格里「数值」pill、合计行 pill、各店铺业绩右侧百分号、数据小结里的 lvl 文案。
⚠️ 历史上这里曾残留 30%/20% 的旧分档，与仪表盘的标准线 46% 矛盾 —— 已修，改动时别改回去。
（例外：异常检测里的 `±20%` 业绩波动（且差≥800元）和 `±8pt` 数值突变，那两个是异常阈值，不是分档，不要动。）

### 语义色（关键，容易做错）
**业绩涨=绿、跌=红；但退款/推广费/数值「降才是绿」**（越低越好）。
实现：`delta(cur, prev, ptMode, goodDown)` 的第 4 个参数 `goodDown=true`。

### ⚠️ 同一店铺同一天只应登记 1 次（🔄 2026-09-30 十一新规则）

**规则**：一天一家店只登记一遍。**同一天同一店铺出现 ≥2 条记录 = 异常**，看板必须报出来。
**检测窗口：当月**（2026-09-30 十一定的，跟漏登一致；原来是"近15天"）。

**⚠️ 查重必须基于「全表记录」，不能用 rows（2026-09-30 踩过）**
本表有**两套字段**：
```
净业绩             6,185 条（全部）
当日总业绩         2,703 条（只有约 44%）
日期              部分记录是时间戳，部分是文本
```
`fetch_all()` 的 `rows` 只收「日期是时间戳」的记录 → 只按 rows 查重会**漏掉整月**（9 月一处都没查出来）。
所以 `fetch_all()` **同时收集 `pairs`**（全表所有 `(日期, 店铺, 业绩)`，日期兼容时间戳+文本），
`build(rows, pairs)` 用它算 `dup`：

```python
# fetch_all: 每个 item 都 append 到 pairs（不限字段齐不齐、不限日期格式）
pairs.append((day, nm, num(fs.get("当日总业绩") or fs.get("净业绩"))))
# build: 用 pairs 统计重复
for _d, _nm, _p in pairs: _cnt.setdefault((_d, _nm), []).append(_p)
if len(vals) > 1: dup[_d][_nm] = {"n": len(vals), "first": vals[0], "vals": vals[1:]}
```

**看板显示（JS「数据提示」区第 ④ 块）**
- 只列**近30天**重复项，格式 `日期　店铺　×N`
- 两次数值**一样** → `重复提交，删掉多余那条即可`
- 两次数值**不一样** → `⚠️ 数据对不上，必须核对该店当天数据`
- 近30天没有 → `✓ 近30天无重复登记`
- ⚠️ **2026-09-30 十一要求：重复登记不要标注「历史累计」** ——
  原来多一行灰字 `历史累计 N 处（当月外还有 M 处）`，**已删除**，不要再加回去。
- 标题右侧徽标写 `近30天　同一店铺同一天只应登 1 次`；尖括号里的计数用 `dupRows.length`（**不是 `dupAll.length`**，否则窗口外的一也算进去）
- 顶部「有需关注项」计数用 `dupAll.length`（保持全量判断）

**实测（2026-09-30）**：全表 6,185 条里 **67 处重复 / 涉及 44 天**；**9 月 0 处**（当月干净）。
⚠️ 注意：临时用别的字段口径查重容易**误报**（曾报"9/01 美容护肤重复"，实为脚本匹配错字段，表里只有 1 条）。

### 🔄 异常数据阈值（2026-09-30 十一改，别再用旧值）

```
① 业绩异常：涨跌幅 ≥20%  且  金额差 ≥800 元（两条同时满足）
② 数值异常：变化 ≥8 个百分点
```
（旧值 50%/300 元 + 20pt 已作废。）
判断方向没变：**"大波动"才报 —— 光看百分比会被小店害**。

## 看板板块

```
顶部时间段切换（分段控件）
KPI 6 张卡（不冻结，正常跟随滚动）★每张带 sparkline
核心指标：仪表盘（数值 vs 46% 标准线）+ 环形图（业绩构成）
总业绩趋势：折线图（仅近7天/当月显示）
各店铺业绩走势：**只在「近30天」显示**（一行一店，折线可悬停看每日数据）
各店铺业绩：横向条形 + 数值% + 右侧同周期涨跌
各店铺明细：表格（店铺·业绩·环比·数值·推广费占比·退款占比·客单价）
数据提示：下滑>5% / 异常数据 / 登记漏登（基准日口径，固定不随时段变）
数据小结：随时段动态生成【概况/走势/问题/建议】
```

### 各店铺业绩走势（2026-09-27 十一要的新板块）

**显隐规则（2026-09-27 十一定，重要）**：
- **当日 / 近3天 / 近7天 / 当月** → **不显示这个板块**
- **近30天** → **只显示这个板块**，其余板块（核心指标 / 总业绩趋势 / 各店铺业绩 / 各店铺明细 / 数据提示 / 数据小结）**全部隐藏**
- 顶部时段切换 + KPI 卡仍保留
- 实现：`render()` 末尾统一切 `#app > section` 的 display（板块 id：走势=`stSec`，趋势=`trendSec`），
  ⚠️ 必须放在 render 末尾，否则会被各板块自己的 display 覆盖。
  ⚠️ **2026-09-27 十一追加：近30天也不显示「各店铺明细」和「数据提示」**。
  这两个板块包在 `.twocol` 里 —— **它是 `<div>` 不是 `<section>`，`#app > section` 选不到**，
  必须单独处理：`document.querySelector('#app > .twocol').style.display = ONLY_TREND ? 'none' : ''`
  （同类坑：以后凡新增非 section 的直接子容器，都要同步加进显隐逻辑）
  走势渲染用 `if(w===30) renderStoreTrend(...)`，其它时段不白算。

- **一行一个店**：店铺名（全名）| 该时段每日业绩折线 | 区间合计 | **相对等长上一段的涨跌标签**
- **跟随所选时段**：`renderStoreTrend(w, cur, prv)` 接收 `sel`/`prevSel`（虽然只在近30天显示，
  但接口保留随时段走的能力，以后要放开只要改显隐那一行）
- 实现：JS `renderStoreTrend()`（用 `byDay[d].shops[nm].p` 逐店逐天取），
  折线用 `shopSpark(seq, dates, color, uid)`，排序 = 区间业绩降序，色 = 涨绿/跌红
- 板块 id：`stSec`/`stHead`/`stBody`（**默认展开**）、容器 `#sttrend`、说明 `#stTips`
- 样式：`.strow / .stname / .stspark / .stsvg / .stsum / .stpill`

### 走势图悬停提示（2026-09-27 十一要）

鼠标（或手指）放在折线上 → 显示**对应日期的业绩**。
- `shopSpark()` 里为**每一天生成一个透明热区** `<rect class="sthit" data-d="日期" data-v="数值">`，
  宽度铺满整列（好命中），不是只在数据点上放 circle
- 全局 tooltip 容器 `#sttip`（`position:fixed`），事件委托在 document 上：
  `mouseover` 显示 / `mouseout` 隐藏 / `touchstart` 显示 / `touchend` 隐藏 / `scroll` 隐藏
- ⚠️ 测试时若把 `mouseout` 派发到 `document` 上不会触发隐藏（`e.target.closest('.sthit')` 为空），
  要派发到热区元素本身上才算数
- 视觉：渐变面积（opacity .26→.02）+ 折线 stroke-width 2 + 首/末端点 + 最高点圆点

### 近30天 · 店铺趋势小结（2026-09-27 新增）

近30天模式下，走势板块下方多一个 **`stSumSec` / `trendSum`** 板块（同属近30天专属，折叠默认展开）。
结构：**【整体】→【上升的店（全部 N 家）】→【下滑的店（全部 N 家）】→【店铺结构】→【建议】**
- 实现：`renderTrendSummary(rows, cur, prv)`，在 `renderStoreTrend()` 末尾调用（`rows` 在作用域内）
- 排序：上升降序、下滑升序；持平（±0.5% 内）与「上一周期无数据」的店也**分别列全**
- 集中度 = 前3名业绩 / 总业绩，≥55% 算偏高
- ⚠️ **必须全量列出**（见上方「总结文案纪律」）

**顶部指标卡不冻结**（十一 2026-09-25 定）：`sticky` 会导致手机端卡片顶部圆角被视口裁切、左侧色条被截断、文字紧贴屏幕顶。**旧版曾用 sticky，现已废除，别改回去**。
（表格表头仍保持吸顶，基准 `top:0`。）

**同周期涨跌**：各店铺业绩 / 明细表都有「环比」列，基准跟着时段自动变（当日=较前一日 / 近3天 / 近7天 / 当月=较上月同期）。实现：先 `prevSel` 聚合出 `prevAgg[nm].p`，再算 `(b.p - pv)/pv*100`。

**全部 8 个板块均可折叠，且默认「全部收起」**（十一 2026-09-27 拍板）：
打开看板先看到「标题+基准日 / 5 个时段标签 / 6 张 KPI 卡 / 核心指标（仪表盘+环形图）」，
其余板块都是折叠标题行，想看哪块自己点开。
实现：`daily_dashboard.py` 里那张 `['xxHead','xxBody', true]` 配置表，8 项全部 `true`。
（历史：曾按「长板块收起 / 短板块展开」区分，已废除。）

## 设计规范

**当前风格：Corporate Clean（企业简洁风）** ← 2026-09-30 十一从 stylekit 选定
```
背景 #f8fafc (slate-50)   卡片 #ffffff + shadow-sm + 1px #e5e7eb (gray-200)
文字 #111827 (gray-900) / #4b5563 (gray-600) / #9ca3af (gray-400)
主色 #2563eb (blue-600)   hover #1d4ed8 (blue-700)   淡底 #eff6ff (blue-50)
成功 #22c55e (green-500)  警告 #f59e0b (amber-500)   危险 #ef4444 (red-500)
紫 #8b5cf6   青 #06b6d4
圆角 12px (rounded-xl)   动效 ≤200ms（卡片 200 / 按钮 150）
```
**交互层（Corporate Clean 必需，不能省）**：
- `.card` / `.kpi` hover → `translateY(-2px)` + 阴影升到 shadow-md + 边框变 `#d1d5db`
- `button` / `.tab` active → `scale(.98)`（按压反馈）
- 可聚焦元素 `:focus-visible` → `outline:2px solid #2563eb; outline-offset:2px`
- 表格行 hover → `background:#f9fafb`
- 数字 → `font-variant-numeric:tabular-nums`
- 必须有 `@media (prefers-reduced-motion:reduce)` 降级

**规格来源**：`skills/creative/stylekit` 的 `corporate-clean`；另一套参考 `data-dense`（更高密度）。
**改配色的脚本**：`scripts/apply_corporate_clean.py`（含交互层注入 + 禁止项自检）。

**🔴 换浅色主题必查（2026-09-30 踩过，重要）**：
1. **深色毛玻璃背景**：`rgba(18,18,18,0.90)` 这种写法的**小数位不一样**（`.90` vs `0.90`），
   按字符串 replace 很容易漏。**必须用正则扫**：
   `re.findall(r"rgba\(\s*(?:\d|[1-5]\d)\s*,\s*\d{1,2}\s*,\s*\d{1,2}\s*,\s*0\.[89]", t)` 应为空。
2. **白底上不可见的白色图形/文字**：
   - 图表是 SVG，原深色主题用 `stroke="#ffffff"` 画折线、`fill="#ffffff"` 画仪表盘数字
     —— **浅色主题下会完全隐形**。一律改成 `#2563eb`（线）/ `#111827`（数字）。
   - ⭐ **趋势图悬停提示（tooltip）的业绩数值**（2026-09-30 实踩）：
     `#sttip` 的 `color` 写的是 `#ffffff`，在白底提示框上**看不见**。
     另：**`#sttip` 在 CSS 里有 4 处定义**（基础 / 日期行 / 背景 / 日期行覆盖），
     **背景被后面的盖住了、`color` 没被盖住** → 只改背景不改 color 就会出现「白底白字」。
     ✅ 现在：数值 = `#2563eb`（蓝），日期行 = `#1d4ed8`（深蓝）
     ⚠️ **改 tooltip 配色时必须把 4 处一起看**，不能只改一处（同类坑也适用于其他重复定义的选择器）。
     自检：`getComputedStyle(#sttip).color` 不能是 `rgb(255,255,255)`。
3. **验证要用「扫所有可见元素的实际背景色」**，不能只看 `--bg` 变量：
   ```js
   document.querySelectorAll('body,.card,.kpi,header,.tabs,.tab,section,table,th,td').forEach(el=>{
     const bg = getComputedStyle(el).backgroundColor;   // 只统计 alpha>=0.3 的
     if(/* r,g,b 都 < 70 */) 报错;   // 深色背景应为 0 个
   });
   ```

**历史配色（已弃用，出现即为换色没做全）**：
- **Minimalist Flat（黑白极简）**：背景 `#ffffff` / 卡片 `#fafafa` / 主色 `#000000` —— 2026-09-27~09-30 用
- **Spotify 深色 / Fluent 深色**：背景 `#121212` / 卡面 `#181818` / 绿 `#1db954`
  ⚠️ **十一 2026-09-30 明确「整体色调都要浅色，不要存在暗色」→ 深色方案已否决，不要再做**
- **Fluent 微软风**：背景 `#f4f6f9` / 主色 `#2563eb` / 成功 `#0ea472`

**🔴 批量换色的正确姿势（2026-09-30 踩过大坑）**：
- ❌ **绝对不能逐个 key 循环 `t.replace(old, new)`** —— 会**链式替换**：
  `#000000→#ffffff` 之后，下一轮的 `#ffffff→#121212` 又把刚换成白的值变黑，
  结果 `--ink` 变成黑字黑底。
- ✅ **正确写法**：所有映射建成一张 dict，用**一次性 `re.sub` + 回调**完成，每个匹配只查一次表：
  ```python
  KEYS = sorted(MAP.keys(), key=len, reverse=True)     # 长 key 优先（8位hex/rgba）
  PAT = re.compile("|".join(re.escape(k) for k in KEYS))
  t = PAT.sub(lambda m: MAP.get(m.group(0), m.group(0)), t)
  ```
- ✅ 自检：`re.findall(r"#(?:[0-9a-fA-F]{7}|[0-9a-fA-F]{9,})(?![0-9a-fA-F])", t)` 应为空
  （**8 位 hex 是合法的**，不要误报 —— 正则要排除正好 6 位和 8 位）

**🔴 文件里可能有多个 `:root`**（2026-09-30 踩）：多个窗口并行改时，
后定义的 `:root` 会**覆盖**前面的。改完必查：`t.count(':root{')` 并**逐个数出来看谁生效**。
若重复定义，**只保留一处**（让真正生效的那处成为唯一）。

### 「各店铺明细」+「数据提示」并排两栏（2026-09-27 十一要求）

**要求原文**：「这两个指标放在同一行内（**不合并**）」—— 即并排但**各自独立折叠**。

实现：在 `#app` 里插一个 `<div class="twocol">` 包住这两个 `<section>`。
```css
.wrap>.twocol, #app>.twocol{grid-column:1/-1;min-width:0;margin-top:28px;
  display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px;align-items:start}
.twocol > section{margin-top:0 !important;min-width:0;grid-column:auto}
@media(max-width:1100px){ /* 手机变上下单栏 */ }
```
⚠️ **两个必须注意的点**（都踩过）：
1. `.twocol` 是 div，**`#app` 的 12 栏 grid 不会自动让它跨满** → 必须显式 `grid-column:1/-1`，
   否则它只占 1 栏（93px），两栏各 38px，完全塌掉。
2. 表格 7 列塞进 660px 栏会**截断店铺名** → 给 `.twocol table{min-width:700px}` +
   店名列 `min-width:170px;white-space:nowrap`，不够就横向滚动。
3. `.twocol .ni` 在窄栏里改成 **上下两行**（`flex-direction:column`），否则店名被挤断。

## ⚠️ 推送成功 ≠ 线上更新了（2026-09-26 实踩，重要）

**案例**：9/25 23:55 推给十一的链接，打开是**旧数据**（线上 9/24 只 15 家、业绩 21.7万；
本地其实已 21 家 / 28.7万）。比 `meta.gen`：本地 `09-25 23:45` / 线上 `09-25 16:06` ——
**23:45 那次 git push 压根没生效**。旧版 `daily_report_push.py` 只读**本地文件**的修改时间，
本地是新的就报「✅ 已更新」，把旧数据推了出去。

**已修的机制：**
1. 看板里写 `meta.gen`（生成时间）；`git_push()` 在 push 返回 0 后**回读线上 `meta.gen` 核对**
   （加 `?v=时间戳` 绕 CDN 缓存；Pages 构建 30~90 秒，给 12次×20秒 ≈ 4 分钟），对不上报 ⚠️ 不静默。
2. `daily_dashboard.py --push-only`：不取数不生成，只把本地已有看板推上线并核对（自愈用）。
3. `daily_report_push.py` 改成**核对线上**：线上 gen == 本地 → 发 ✅；
   ≠ → **自动重推一次**（调 `--push-only`）再核对；仍不一致 → ⚠️ 点名告警（两边 gen 都写出来）。
4. 推送文案**带上基准日**：`✅ 数据日报已更新（09/26 23:47）｜基准日 9/25（23 家）`。

**通用教训**：凡是「本地生成 → 推远端」的活，**核对必须打远端，不能看本地文件时间**。

## 坑（踩过的）

0. **生成器已有「结构自检」**（2026-09-27 加）：写盘前自动检查 `section`/`div` 标签配平，
   不配平就**中止写盘并报错**。新增板块时务必确保成对闭合 ——
   曾因 `stSumSec` 漏写 `</section>`，导致后面 5 个板块全被嵌套进去、页面布局全乱。
   手工排查：`html.count('<section') == html.count('</section>')`。
1. **改 CSS/JS 必须改 `daily_dashboard.py`**，不能直接改生成的 HTML —— 次日 23:45 定时任务会覆盖回去。
2. **文件可能被其他窗口的 agent 覆盖**：曾出现过生成的 HTML 被塞进 9 条额外 CSS 规则，其中一条把手机端 `.kpis` 改成 `position:static`，导致冻结失效。**发文件给十一前，先 grep 确认 `.kpis` 规则数 ≤ 2 且无 `position:static`。**
3. **JS 算 hash 必须用 `Math.imul`**，否则 `x * 0x01000193` 超出双精度导致哈希不匹配、密码永远进不去。
4. **`records/search` 分页会死循环**（page_token 重复）→ 用 `GET /records`。
5. **飞书全表 `sort` 会超时（>300s）** → 不要在取数时排序。
6. **GitHub 推送失败：真因几乎总是「远端有别人的提交」，不是网络**。
   这个仓库有**多个任务在推**：数据日报 23:45、评价星级 14:20、主体财务周一 9:00。
   症状：`hint: 'git pull' before pushing again. / Note about fast-forwards`
   **修法：先 `git pull --rebase origin main` 再 push**。生成器自带的 `git_push()` 已经是这个逻辑，定时任务不会出问题。
   ⚠️ **别再用「只 push 不 pull」的后台重试循环** —— 那会白白重试无数次（我因此误判过好几轮是网络问题）。
   判断网络是否真断：`curl -s -o /dev/null -w "%{http_code}" --max-time 20 https://github.com`，返回 `200` 就是通的。
7. **`renderDonut` 的 tag 必须用 `innerHTML`**（`fmtMoney` 返回含 `<small>` 的 HTML，用 `textContent` 会显示成字面标签）。
8. **Python 三引号里嵌 JS 模板字符串**（`${...}` + 反引号）很容易漏写闭合引号，用 `patch` 工具改比用 `execute_code` 拼字符串安全。
9. **🔴 批量换色时 `#fff` 必须加词边界**（2026-09-27 实踩）：
   `t.replace("#fff", newColor)` 会把 `#fff7e8`、`#fffbe6`、`#fff3d0` 的**前 4 位当成 `#fff`**，
   产生 `#fafafabe6`、`#fafafafff` 这种 **7~9 位非法 hex**（实测污染 13 处，CSS 静默失效）。
   ✅ 正确写法：`re.sub(r"#fff(?![0-9a-fA-F])", newColor, t)`
   ✅ 自检：`re.findall(r"#[0-9a-fA-F]{7,}\b", css)` 应为**空**。
10. **🔴 `#app`（=.wrap）本身是 12 栏 CSS Grid**（2026-09-27 实踩）：
   所有直接子元素靠 `.wrap>header/.tabs/.kpis/footer/section{grid-column:1/-1}` 跨满整行。
   **新增任何非 section 的直接子容器（如 `.twocol`）都必须自己写 `grid-column:1/-1`**，
   否则只占 1 栏（93px）—— 表现为「两栏各 38px，完全塌掉」。
11. **🔴🔴 定时任务推不上去的头号原因：cron 的 PATH 里没有 git**（2026-09-28 实踩，坑了三天）：
   **症状**：`❌ 推送异常：[WinError 2] 系统找不到指定的文件。`
   取数、生成、本地副本全部 ✅，**只有推送 ❌** —— 所以线上停在旧版。
   **根因**：原代码 `git = shutil.which("git") or r"C:\Program Files\Git\cmd\git.exe"`
     - cron 环境 PATH 干净 → `which("git")` 返回 `None`
     - fallback `C:\Program Files\Git\cmd\git.exe` **这台机器上不存在**（Hermes 自带 git 在 `E:\RuanJian\Hermes\git\`）
   **特征**：**我手动跑必成功、定时任务必挂** —— 因为我的 shell PATH 里有 git。
     千万别因为「我手动推成功了」就认为推送链路没问题（我就这么误判了三天）。
   **修法**：候选列表探测，Hermes 自带 git 排在前：
   ```python
   for c in (shutil.which("git"),
             r"E:\RuanJian\Hermes\git\cmd\git.exe",
             r"E:\RuanJian\Hermes\git\bin\git.exe",
             r"E:\RuanJian\Hermes\git\mingw64\bin\git.exe",
             r"C:\Program Files\Git\cmd\git.exe"):
       if c and os.path.exists(c): _GIT_BIN = c; break
   ```
   **同类**：`D:\Agent.GongZuoQu\Hermes.GZQ\项目：主体财务看板自动同步\weekly_sync.py`
     原来写 `cmd = ['git']`，同样依赖 PATH → 已改。**新增任何调 git 的脚本都要用绝对路径**。
12. **🔴 本机 git 直连 GitHub 常被 reset → 要加代理兜底**（2026-09-28）：
   评价星级的 `publish.py` 早就写了：「本机 git 直连 GitHub 常被重置（Empty reply / Connection reset），
   走本地代理才稳」。
   **正确姿势**：`_git(..., proxy=True)` 时给子进程加 `HTTPS_PROXY=HTTP_PROXY=http://127.0.0.1:7897`；
   `git_push` 里**先直连，失败自动改走代理重试**，两次都不行才报错。
   另外显式指定凭据管理器 + `GIT_TERMINAL_PROMPT=0`（免交互，防卡死）：
   ```python
   GCM = r"C:\Users\Administrator\.workbuddy\binaries\PortableGit\versions\1.2.0\mingw64\bin\git-credential-manager.exe"
   cmd = [GIT_BIN, "-c", "credential.helper=" + GCM] + args
   env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
   ```
13. **推送失败告警必须带真实错误**（2026-09-28 十一要求）：
   原告警只说「线上还是旧版，已自动重推仍未生效。**多半是 github.com 连不上**」
   → 十一以为是网络问题，实际是 `WinError 2`（代码问题）。**文案把排查方向带偏了**。
   修法：`daily_report_push.py` 重推时捕获 stdout，失败时把最后 3 行贴进告警的「失败原因」行。

## 验证清单（改完必跑）

**先看生成器自带的「结构自检」是否通过**（输出里应有 `✅ 结构自检通过（section/div 均配平）`）。

再用 `browser_exec` 打开本地副本，输密码 12511251，检查：
1. **顶层板块顺序**：`#app > section` 依次应为
   核心指标 / 总业绩趋势 / 各店铺业绩走势 / 店铺趋势小结 / 各店铺业绩 / 数据小结，
   外加一个 `#app > .twocol`（内含 各店铺明细 + 数据提示）
2. **打开即全部收起**：8 个板块的 head 都应有 `closed` 类 ✓
3. 6 张 KPI + 6 条 sparkline；KPI `position = static`（**不是 sticky**）
4. 仪表盘 SVG 有值、环形图 4 扇区
5. **5 个时段的板块显隐**逐一点过：
   - 当日/近3天/近7天/当月 → 无「走势」「趋势小结」，有 `.twocol`
   - **近30天** → 只剩「各店铺业绩走势 + 店铺趋势小结」，**`.twocol` 也必须隐藏**
6. **两栏并排**：`.twocol` 的 `gridTemplateColumns` 两值应各 ≈ 容器一半（如 `679.5px 679.5px`）；
   且两个 section 的 `left` 相差 > 100
7. 各店铺业绩 / 明细表都有「环比」列，且**合计环比 == KPI 业绩环比**（交叉验证）
8. **指标公式复算**：从 `byDay` 重新加总，与 KPI / 表格首行显示值完全一致
9. **颜色分档**逐行核对 pill 类名（≥46 r / 42~46 y / <42 g）
10. **语义色**：退款/推广/数值涨应为**红**
11. **总结完整性**：全文搜 `另有` / `等等` / `...` / ` 等` 应为 0
12. 近30天：23 家 × 30 天热区、悬停 tooltip 显示日期+数值、移出隐藏
13. **非法色值**：`re.findall(r"#[0-9a-fA-F]{7,}\b", html)` 应为空
14. **店铺名不截断**：取 `td.sh` 算 `scrollWidth <= clientWidth + 1` 应为 `true`

⚠️ `browser_exec` 的 `js()` 里**不要用 `[...spread]`**（harness 解析器会报 `Unexpected token ':'`），
用 `Array.from(...)` 或 `for` 循环代替。同理 f-string 里不能带反斜杠，正则要提前算好变量。

⚠️ `browser_exec` 的 `capture_screenshot` 在 500KB+ 页面上会超时（60s）。
**要看效果就用 `desktop_preview` 打开本地文件**（密码门可以直接 `drive_preview` 输入），或用 `js()` 取数据验证（不截图）。

## 相关文件

| 用途 | 路径 |
|---|---|
| **一键全流程** | `scripts/run_daily_report.py` ← **平时只用这个** |
| 看板生成器 | `scripts/daily_dashboard.py` |
| 链接推送 | `scripts/daily_report_push.py` |
| 旧版文本推送（已停用） | `scripts/yunying_daily.py` |
| 周报脚本（已停用） | `scripts/store_value_weekly.py` |
