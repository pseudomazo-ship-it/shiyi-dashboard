---
name: kuai-di-bi-jia-kan-ban
description: This skill should be used when the user asks to create or update a courier price comparison dashboard for 邮政/圆通/中通. Triggers include: "快递看板", "快递比价", "比价看板", "快递决策", "快递价格对比". The skill generates a self-contained HTML dashboard with Chart.js for comparing courier shipping prices across provinces and weight ranges.
agent_created: true
---

# 快递比价看板

## Purpose
Generate an interactive HTML dashboard that compares shipping prices from 邮政/圆通/中通 across multiple provinces and weight ranges (0-5000g). The dashboard provides real-time price calculation, visual trend charts, and a comprehensive summary matrix to help users choose the cheapest courier.

## When to Use
- User asks to create a new courier price comparison dashboard
- User asks to update, modify, or fix an existing courier dashboard
- User mentions "快递看板", "快递比价", "快递决策", "三家快递对比", "比价看板"
- User provides price tables from 邮政, 圆通, 中通 couriers

## How to Use

1. Read the template from `assets/快递决策看板模板.html` as the base
2. Extract price data from user-provided images or text tables
3. Update the three data structures in the `<script>` section:
   - `postalData` — 邮政快递 zone-based pricing data (7 weight ranges: 300/500/1000/2000/3000/4000/5000g)
   - `ytoData` — 圆通快递 province-based pricing (3 weight ranges: 0-1kg/1-2kg/2-3.2kg)
   - `ztoData` — 中通快递 province-based pricing (6 weight ranges: 0-500g/500-1kg/1-2kg/2-3kg/3-4kg/4-5kg + over5kg)
4. Update city surcharge rules:
   - `ztoData.cities` — cities that have special pricing per province
   - `citySurcharges` — surcharge rules by city name
   - `onProvinceChange` — add city selection for the province
5. Update the legend section (.legend-section) with all surcharge rules
6. Save the updated HTML to the workspace and preview it
7. Always update the title date (e.g. "2026.6.4") to match the data date

## Data Structure Reference

### postalData
```
zones layout:
  '一区': provinces: ['湖北'], prices: [0-300g, 300-500g, 500-1000g, 1000-2000g, 2000-3000g, 3000-4000g, 4000-5000g]
  '二区A': provinces: ['江苏','河北','福建','陕西','广东','山东','山西','浙江','重庆','上海']
  '二区B': provinces: ['湖南','江西','安徽','河南']
  '三区': provinces: ['贵州','天津','广西','四川','甘肃','宁夏','内蒙古','海南','云南']
  '四区': provinces: ['吉林','黑龙江']
  '单列-北京': provinces: ['北京']
  '单列-辽宁': provinces: ['辽宁']
```

### ytoData
```
provinces layout: { '湖北': { w0_1: 0-1kg, w1_2: 1-2kg, w2_3_2: 2-3.2kg } }
```

### ztoData
```
provinces layout: { '湖北省': { w0_0_5, w0_5_1, w1_2, w2_3, w3_4, w4_5, over5: {first, add} } }
surcharge types:
  - 'fixed': add fixed amount (上海/海南 +1元, 广州/深圳 +0.5元)
  - 'beijing': 3kg内+1元, 3kg以上+0.5元/kg
  - 'northeast': 黑吉辽青甘宁内超出8%部分+3元/kg
  - 'special_pricing': 西藏/新疆/四川(阿坝/甘孜/凉山州) 首重1kg*20.1+续重1kg*18.1
```

### City surcharge setup
```
ztoData.cities: { '广东省': ['广州','深圳','其他'], '四川省': ['阿坝州','甘孜州','凉山州','其他'] }
citySurcharges: { '广州': {type:'fixed',amount:0.5}, '阿坝州': {type:'special_pricing'} }

onProvinceChange(): must add city options for 广东 and 四川
```


## Bundled Resources

- `assets/快递决策看板模板.html` — Complete HTML dashboard template
- `assets/小程序源码/` — WeChat Mini Program source code (WXML/WXSS/JS)
  - Import into WeChat Developer Tools to run on mobile
  - Edit `project.config.json` → replace `appid` with your Mini Program AppID

### Adding a general surcharge (+0.3元/票 for postal & yto)
In `calcPostalPrice` and `calcYtoPrice`, change `return { price }` to `return { price: price + 0.3 }` and add `'+0.3元/票'` to surcharges.

### Adding city-based special pricing
1. Add city to `ztoData.cities[province]`
2. Add entry in `citySurcharges`
3. Add city options in `onProvinceChange()`
4. Add early-return check at top of `calcZtoPrice()` for 'special_pricing' type

### Updating the date in title
Change `<h1>📦 快递决策看板 {date}</h1>` to the new date.
