/**
 * 快递比价数据模型与计算函数
 * 邮政 / 圆通 / 中通 三网比价
 */

// ============ 邮政快递数据 ============
const postalData = {
  zones: {
    '一区': { provinces: ['湖北'], prices: [1.4, 1.6, 1.75, 2.5, 3.2, 5.5, 7.0] },
    '二区A': { provinces: ['江苏', '河北', '福建', '陕西', '广东', '山东', '山西', '浙江', '重庆', '上海'], prices: [1.4, 1.65, 1.8, 2.6, 3.2, 5.5, 7.0] },
    '二区B': { provinces: ['湖南', '江西', '安徽', '河南'], prices: [1.4, 1.6, 1.75, 2.5, 3.2, 5.5, 7.0] },
    '三区': { provinces: ['贵州', '天津', '广西', '四川', '甘肃', '宁夏', '内蒙古', '海南', '云南'], prices: [1.5, 1.75, 1.9, 2.9, 3.6, 5.5, 7.0] },
    '四区': { provinces: ['吉林', '黑龙江'], prices: [2.1, 2.2, 2.3, 3.1, 4.1, 5.5, 7.0] },
    '单列-北京': { provinces: ['北京'], prices: [2.0, 2.6, 3.1, 3.6, 4.6, 5.5, 7.0] },
    '单列-辽宁': { provinces: ['辽宁'], prices: [1.4, 1.8, 2.1, 3.1, 4.1, 5.5, 7.0] }
  },
  weightRanges: [300, 500, 1000, 2000, 3000, 4000, 5000]
}

// ============ 圆通快递数据 ============
const ytoData = {
  provinces: {
    '北京': { w0_1: 2.75, w1_2: 3.4, w2_3_2: 3.6 },
    '天津': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '河北': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '山西': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '内蒙古': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '辽宁': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '吉林': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '黑龙江': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '上海': { w0_1: 2.75, w1_2: 3.4, w2_3_2: 3.6 },
    '江苏': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '浙江': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '安徽': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '福建': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '江西': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '山东': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '河南': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '湖北': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '湖南': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '广东': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '广西': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '海南': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '重庆': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '四川': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '贵州': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '云南': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '陕西': { w0_1: 1.95, w1_2: 2.6, w2_3_2: 2.8 },
    '甘肃': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '青海': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 },
    '宁夏': { w0_1: 2.0, w1_2: 2.8, w2_3_2: 3.4 }
  }
}

// ============ 中通快递数据 ============
const ztoProvinces = {
  '江苏省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '浙江省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '安徽省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '江西省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '福建省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '海南省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 }, surcharge: { type: 'fixed', amount: 1.0, desc: '海南+1元/票' } },
  '广东省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '广西省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '湖北省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '湖南省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '河南省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '上海': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 }, surcharge: { type: 'fixed', amount: 1.0, desc: '上海+1元/票' } },
  '北京': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.10, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 }, surcharge: { type: 'beijing', desc: '北京3kg内+1元，3kg以上+0.5元/kg' } },
  '四川省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '重庆': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '贵州省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '云南省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '山东省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '河北省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '天津': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '山西省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '陕西省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 2.65, w2_3: 3.55, w3_4: 9.80, w4_5: 11.80, over5: { first: 3.6, add: 2.1 } },
  '辽宁省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 6.70, w2_3: 15.35, w3_4: 14.30, w4_5: 17.30, over5: { first: 5.1, add: 3.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '吉林省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 6.70, w2_3: 15.35, w3_4: 17.30, w4_5: 21.30, over5: { first: 5.1, add: 4.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '黑龙江省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 6.70, w2_3: 15.35, w3_4: 19.30, w4_5: 23.80, over5: { first: 5.6, add: 4.6 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '宁夏': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 7.70, w2_3: 15.35, w3_4: 21.80, w4_5: 26.80, over5: { first: 6.6, add: 5.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '甘肃省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 7.70, w2_3: 15.35, w3_4: 21.80, w4_5: 26.80, over5: { first: 6.6, add: 5.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '青海省': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 7.70, w2_3: 15.35, w3_4: 21.80, w4_5: 26.80, over5: { first: 6.6, add: 5.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '内蒙古': { w0_0_5: 1.35, w0_5_1: 1.60, w1_2: 7.70, w2_3: 15.35, w3_4: 21.80, w4_5: 26.80, over5: { first: 6.6, add: 5.1 }, surcharge: { type: 'northeast', desc: '黑吉辽青甘宁内超出8%部分+3元/kg' } },
  '西藏': { w0_0_5: null, w0_5_1: null, w1_2: null, w2_3: null, w3_4: null, w4_5: null, over5: { first: 20.1, add: 18.1 }, special: true },
  '新疆': { w0_0_5: null, w0_5_1: null, w1_2: null, w2_3: null, w3_4: null, w4_5: null, over5: { first: 20.1, add: 18.1 }, special: true }
}

// 中通城市加收规则
const ztoCities = ['广州', '深圳']
const citySurcharges = {
  '广州': { type: 'fixed', amount: 0.5, desc: '广州+0.5元/票' },
  '深圳': { type: 'fixed', amount: 0.5, desc: '深圳+0.5元/票' },
  '阿坝州': { type: 'special_pricing', desc: '阿坝州首重1kg*20.1+续重1kg*18.1' },
  '甘孜州': { type: 'special_pricing', desc: '甘孜州首重1kg*20.1+续重1kg*18.1' },
  '凉山州': { type: 'special_pricing', desc: '凉山州首重1kg*20.1+续重1kg*18.1' }
}

// 省份列表（完整）
const allProvinces = [
  '北京', '天津', '河北', '山西', '内蒙古',
  '辽宁', '吉林', '黑龙江',
  '上海', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南',
  '湖北', '湖南', '广东', '广西', '海南',
  '重庆', '四川', '贵州', '云南', '西藏',
  '陕西', '甘肃', '青海', '宁夏', '新疆'
]

// ============ 计算函数 ============

/** 获取邮政分区 */
function getPostalZone(province) {
  for (const [zone, data] of Object.entries(postalData.zones)) {
    if (data.provinces.includes(province)) return { zone, prices: data.prices }
  }
  return null
}

/** 计算邮政价格 */
function calcPostalPrice(province, weight) {
  const zd = getPostalZone(province)
  if (!zd) return null
  const { zone, prices } = zd
  let price
  if (weight <= 300) price = prices[0]
  else if (weight <= 500) price = prices[1]
  else if (weight <= 1000) price = prices[2]
  else if (weight <= 2000) price = prices[3]
  else if (weight <= 3000) price = prices[4]
  else if (weight <= 4000) price = prices[5]
  else if (weight <= 5000) price = prices[6]
  else return null
  return { price: price + 0.3, zone, surcharges: ['+0.3元/票'] }
}

/** 计算圆通价格 */
function calcYtoPrice(province, weight) {
  const d = ytoData.provinces[province]
  if (!d) return null
  let price
  if (weight <= 1000) price = d.w0_1
  else if (weight <= 2000) price = d.w1_2
  else if (weight <= 3200) price = d.w2_3_2
  else return null
  return { price: price + 0.3, surcharges: ['+0.3元/票'] }
}

/** 计算中通价格 */
function calcZtoPrice(province, city, weight) {
  // 特殊城市（阿坝/甘孜/凉山州）使用西藏同等待遇
  if (city && citySurcharges[city] && citySurcharges[city].type === 'special_pricing') {
    const kg = weight / 1000
    const price = 20.1 + Math.max(0, kg - 1) * 18.1
    return { price, surcharges: [citySurcharges[city].desc] }
  }

  const key = province + '省'
  const d = ztoProvinces[key] || ztoProvinces[province]
  if (!d) return null

  let price = 0
  const surcharges = []

  if (d.special) {
    const kg = weight / 1000
    price = d.over5.first + Math.max(0, kg - 1) * d.over5.add
    surcharges.push(province + '首重1kg*' + d.over5.first + '+续重1kg*' + d.over5.add)
  } else if (weight <= 500) {
    price = d.w0_0_5
  } else if (weight <= 1000) {
    price = d.w0_5_1
  } else if (weight <= 2000) {
    price = d.w1_2
  } else if (weight <= 3000) {
    price = d.w2_3
  } else if (weight <= 4000) {
    price = d.w3_4
  } else if (weight <= 5000) {
    price = d.w4_5
  } else {
    const kg = weight / 1000
    price = d.over5.first + (kg - 1) * d.over5.add
  }

  if (d.surcharge) {
    if (d.surcharge.type === 'fixed') {
      price += d.surcharge.amount
      surcharges.push(d.surcharge.desc)
    } else if (d.surcharge.type === 'beijing') {
      if (weight <= 3000) { price += 1; surcharges.push('北京3kg内+1元') }
      else { const e = (weight / 1000) * 0.5; price += e; surcharges.push('北京3kg以上+0.5元/kg(' + e.toFixed(2) + '元)') }
    } else if (d.surcharge.type === 'northeast') {
      surcharges.push(d.surcharge.desc)
    }
  }

  if (city && citySurcharges[city] && citySurcharges[city].type === 'fixed') {
    price += citySurcharges[city].amount
    surcharges.push(citySurcharges[city].desc)
  }

  return { price, surcharges }
}

/** 获取某省份的城市列表 */
function getCitiesForProvince(province) {
  if (province === '广东') return ['', '广州', '深圳']
  if (province === '四川') return ['', '阿坝州', '甘孜州', '凉山州']
  return ['']
}

module.exports = {
  postalData,
  ytoData,
  ztoProvinces,
  allProvinces,
  citySurcharges,
  getPostalZone,
  calcPostalPrice,
  calcYtoPrice,
  calcZtoPrice,
  getCitiesForProvince
}
