const prices = require('../../utils/prices')

// 汇总用的重量列表
const summaryWeights = [300, 500, 1000, 2000, 3000, 4000, 5000]
const weightLabels = ['300g', '500g', '1kg', '2kg', '3kg', '4kg', '5kg']

Page({
  data: {
    weightLabels: weightLabels,
    summaryData: []
  },

  onShow() {
    this.buildSummary()
  },

  buildSummary() {
    const zoneOrder = ['一区', '二区A', '二区B', '三区', '四区', '单列-北京', '单列-辽宁']
    const summaryData = []

    zoneOrder.forEach(zone => {
      const zoneInfo = prices.postalData.zones[zone]
      if (!zoneInfo) return

      const zoneClass = zone.includes('一区') ? 'zone-1' :
        zone.includes('二区A') ? 'zone-2a' :
        zone.includes('二区B') ? 'zone-2b' :
        zone.includes('三区') ? 'zone-3' : 'zone-4'

      const provinces = zoneInfo.provinces.map(province => {
        const data = summaryWeights.map(weight => {
          const p = prices.calcPostalPrice(province, weight)
          const y = prices.calcYtoPrice(province, weight)
          const z = prices.calcZtoPrice(province, '', weight)

          const all = []
          if (p) all.push({ name: '邮政', price: p.price, color: '#4C72B0' })
          if (y) all.push({ name: '圆通', price: y.price, color: '#DD8452' })
          if (z) all.push({ name: '中通', price: z.price, color: '#55A868' })

          const prices_ = all.map(x => x.price)
          const min = prices_.length ? Math.min(...prices_) : null
          const max = prices_.length ? Math.max(...prices_) : null

          const cells = all.map(x => ({
            ...x,
            isBest: x.price === min,
            cssClass: prices_.length >= 2 ?
              (x.price === min ? 'cell-best' :
               x.price === max && prices_.length >= 3 ? 'cell-worst' : 'cell-mid')
              : ''
          }))

          const best = cells.find(c => c.isBest) || cells[0]
          return {
            bestPrice: min,
            bestName: best ? best.name : '-',
            color: best ? best.color : '#999',
            cssClass: best ? best.cssClass : ''
          }
        })

        return { province, data }
      })

      summaryData.push({ zone, zoneClass, provinces })
    })

    this.setData({ summaryData })
  }
})
