const prices = require('../../utils/prices')

Page({
  data: {
    provinces: prices.allProvinces,
    provinceIndex: -1,
    provinceName: '',
    cities: [''],
    cityIndex: 0,
    cityName: '',
    weight: 500,
    showResult: false,
    postal: { price: null, zone: '', isBest: false, surcharges: [] },
    yto: { price: null, isBest: false, surcharges: [] },
    zto: { price: null, isBest: false, surcharges: [] },
    tableData: []
  },

  onProvinceChange(e) {
    const idx = e.detail.value
    const province = this.data.provinces[idx]
    const cities = prices.getCitiesForProvince(province)
    this.setData({
      provinceIndex: idx,
      provinceName: province,
      cities: cities,
      cityIndex: 0,
      cityName: cities[0] || ''
    }, () => this.calcAll())
  },

  onCityChange(e) {
    const idx = e.detail.value
    const city = this.data.cities[idx] || ''
    this.setData({ cityIndex: idx, cityName: city }, () => this.calcAll())
  },

  onWeightInput(e) {
    const w = parseInt(e.detail.value) || 0
    this.setData({ weight: w }, () => this.calcAll())
  },

  setWeight(e) {
    const w = e.currentTarget.dataset.weight
    this.setData({ weight: w }, () => this.calcAll())
  },

  calcAll() {
    const province = this.data.provinceName
    const city = this.data.cityName
    const weight = this.data.weight

    if (!province || weight <= 0) {
      this.setData({ showResult: false })
      return
    }

    const p = prices.calcPostalPrice(province, weight)
    const y = prices.calcYtoPrice(province, weight)
    const z = prices.calcZtoPrice(province, city, weight)

    const results = [
      { key: 'postal', price: p ? p.price : null },
      { key: 'yto', price: y ? y.price : null },
      { key: 'zto', price: z ? z.price : null }
    ]
    const validPrices = results.filter(r => r.price !== null).map(r => r.price)
    const minPrice = validPrices.length > 0 ? Math.min(...validPrices) : null

    this.setData({
      showResult: true,
      postal: {
        price: p ? p.price : null,
        zone: p ? p.zone : '',
        isBest: p ? p.price === minPrice : false,
        surcharges: p ? p.surcharges : []
      },
      yto: {
        price: y ? y.price : null,
        isBest: y ? y.price === minPrice : false,
        surcharges: y ? y.surcharges : []
      },
      zto: {
        price: z ? z.price : null,
        isBest: z ? z.price === minPrice : false,
        surcharges: z ? z.surcharges : []
      },
      tableData: this.buildTable(province, city)
    })
  },

  buildTable(province, city) {
    const weights = [300, 500, 1000, 2000, 3000, 4000, 5000]
    return weights.map(w => {
      const p = prices.calcPostalPrice(province, w)
      const y = prices.calcYtoPrice(province, w)
      const z = prices.calcZtoPrice(province, city, w)
      const all = [p ? p.price : null, y ? y.price : null, z ? z.price : null].filter(v => v !== null)
      const min = all.length ? Math.min(...all) : null
      const best = p && p.price === min ? '邮政' : y && y.price === min ? '圆通' : z && z.price === min ? '中通' : '-'
      return {
        weightLabel: w >= 1000 ? (w / 1000) + 'kg' : w + 'g',
        postal: p ? p.price : null,
        yto: y ? y.price : null,
        zto: z ? z.price : null,
        minPrice: min,
        best
      }
    })
  }
})
