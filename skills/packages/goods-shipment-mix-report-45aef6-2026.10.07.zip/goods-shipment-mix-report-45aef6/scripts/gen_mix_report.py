# -*- coding: utf-8 -*-
"""销售货品汇总账 → 品类/SKU 发货出库占比报表（每月一张 sheet）

用法：
    python gen_mix_report.py "7月=E:\path\销售货品汇总账(正式)7.1-7.31.xlsx" \
                             "8月=E:\path\销售货品汇总账(正式)8.1-8.31.xlsx"

    # 指定输出目录（默认写到工作区 数据--发货出库统计）
    python gen_mix_report.py "8月=...xlsx" --outdir "D:\...\数据--发货出库统计"

输出：<outdir>/<首月>-<末月>发货出库明细占比_<YYYY.MM.DD>.xlsx
每张 sheet：左块 品类汇总(A:D) + 右块 SKU明细(F:I)

注意：
  * 本表只有 1 个 sheet，名为 sheetTitle
  * 关键列(0-based)：1=货品名称  4=分类  5=数量  19=规格
  * 必须用 load_workbook(data_only=True)，read_only=True 会读到假的 max_row=1
  * 脚本会打印各月总量用于【量级校验】——环比差 >3 倍且结构一致 = 数据不全，交付时要点名
"""
import os
import re
import sys
import datetime
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from collections import defaultdict

SHEET_NAME = 'sheetTitle'
C_NAME, C_CLS, C_QTY, C_SKU = 1, 4, 5, 19      # 0-based
DEFAULT_OUTDIR = r'D:\Agent.GongZuoQu\Hermes.GZQ\数据--发货出库统计'

THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HDR_FILL = PatternFill('solid', fgColor='2F5597')
HDR_FONT = Font(bold=True, color='FFFFFF', size=10)
CAT_FILL = PatternFill('solid', fgColor='DDEBF7')
SUM_FILL = PatternFill('solid', fgColor='FFF2CC')


def extract_cat(sku, cls):
    """品类：优先规格里的【xxx】，取不到回退分类列"""
    if sku:
        m = re.search(r'【([^】]+)】', sku)
        if m:
            return '【%s】' % m.group(1)
    if cls:
        return cls
    return '【其他】'


def load(path):
    wb = openpyxl.load_workbook(path, data_only=True)     # 不要 read_only
    ws = wb[SHEET_NAME]
    rows = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if row[C_NAME] is None and row[C_CLS] is None and row[C_SKU] is None:
            continue
        name = str(row[C_NAME] or '').strip()
        cls = str(row[C_CLS] or '').strip()
        sku = str(row[C_SKU] or '').strip()
        try:
            qty = float(row[C_QTY]) if row[C_QTY] is not None else 0.0
        except Exception:
            qty = 0.0
        if name == '无效货品':            # 剔除，量很大
            continue
        if not sku:
            sku = cls or name
        rows.append({'sku': sku, 'cat': extract_cat(sku, cls), 'qty': qty})
    return rows


def tidy(v):
    return int(v) if v == int(v) else round(v, 2)


def main(argv):
    pairs = []
    outdir = DEFAULT_OUTDIR
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--outdir':
            i += 1
            outdir = argv[i]
        elif '=' in a:
            tag, path = a.split('=', 1)
            pairs.append((tag.strip(), path.strip()))
        i += 1
    if not pairs:
        print(__doc__)
        return 1

    data, order = {}, []
    for tag, path in pairs:
        if not os.path.exists(path):
            print('!! 文件不存在: %s' % path)
            return 1
        rows = load(path)
        cat_tot = defaultdict(float)
        sku_tot = defaultdict(lambda: defaultdict(float))
        for r in rows:
            cat_tot[r['cat']] += r['qty']
            sku_tot[r['cat']][r['sku']] += r['qty']
        data[tag] = {'cat': cat_tot, 'sku': sku_tot, 'rows': len(rows),
                     'total': sum(cat_tot.values())}
        order.append(tag)
        print('[%s] 有效行 %d | 品类 %d | 总发货 %s'
              % (tag, len(rows), len(cat_tot), format(int(sum(cat_tot.values())), ',')))

    # ---- 量级校验 ----
    totals = [data[t]['total'] for t in order]
    if len(totals) > 1:
        lo, hi = min(totals), max(totals)
        if lo > 0 and hi / lo > 3:
            print()
            print('!! 量级校验不通过：最大值/最小值 = %.1f 倍' % (hi / lo))
            print('!! 若各月结构占比又高度一致 => 数据不全（导出范围选错），交付时必须点名让十一重导')

    os.makedirs(outdir, exist_ok=True)
    stamp = datetime.date.today().strftime('%Y.%m.%d')
    out = os.path.join(outdir, '%s-%s发货出库明细占比_%s.xlsx'
                       % (order[0], order[-1], stamp))

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for tag in order:
        d = data[tag]
        ws = wb.create_sheet(tag)
        total = d['total']
        ws['A1'] = '%s 发货出库明细占比' % tag
        ws['A1'].font = Font(bold=True, size=13)
        ws.merge_cells('A1:D1')
        ws['F1'] = '来源：销售货品汇总账(正式) %s' % tag
        ws['F1'].font = Font(size=9, color='808080')

        # 左块：品类汇总
        r = 3
        for c, v in enumerate(['排名', '品类名称', '发货总量', '占比'], 1):
            cell = ws.cell(r, c, v)
            cell.font, cell.fill, cell.border = HDR_FONT, HDR_FILL, BORDER
            cell.alignment = Alignment(horizontal='center', vertical='center')
        cats = sorted(d['cat'].items(), key=lambda x: -x[1])
        r += 1
        for idx, (cat, q) in enumerate(cats, 1):
            ws.cell(r, 1, idx)
            ws.cell(r, 2, cat)
            ws.cell(r, 3, tidy(q)).number_format = '#,##0'
            ws.cell(r, 4, (q / total) if total else 0).number_format = '0.00%'
            for c in range(1, 5):
                ws.cell(r, c).border = BORDER
                if c in (1, 3, 4):
                    ws.cell(r, c).alignment = Alignment(horizontal='right')
            r += 1
        ws.cell(r, 2, '合计').font = Font(bold=True)
        ws.cell(r, 3, tidy(total)).font = Font(bold=True)
        ws.cell(r, 3).number_format = '#,##0'
        ws.cell(r, 4, 1.0).font = Font(bold=True)
        ws.cell(r, 4).number_format = '0.00%'
        for c in range(1, 5):
            ws.cell(r, c).border = BORDER
            ws.cell(r, c).fill = SUM_FILL

        # 右块：SKU明细
        r = 3
        for c, v in enumerate(['品类', 'SKU名称', '发货数量', '品类内占比'], 6):
            cell = ws.cell(r, c, v)
            cell.font, cell.fill, cell.border = HDR_FONT, HDR_FILL, BORDER
            cell.alignment = Alignment(horizontal='center', vertical='center')
        r += 1
        for cat, _q in cats:
            ctot = d['cat'][cat]
            for sku, q2 in sorted(d['sku'][cat].items(), key=lambda x: -x[1]):
                ws.cell(r, 6, cat).fill = CAT_FILL
                ws.cell(r, 6).font = Font(size=9)
                ws.cell(r, 7, sku)
                ws.cell(r, 8, tidy(q2)).number_format = '#,##0'
                ws.cell(r, 9, (q2 / ctot) if ctot else 0).number_format = '0.00%'
                for c in range(6, 10):
                    ws.cell(r, c).border = BORDER
                    if c in (8, 9):
                        ws.cell(r, c).alignment = Alignment(horizontal='right')
                r += 1

        for col, w in [('A', 6), ('B', 18), ('C', 12), ('D', 10), ('E', 3),
                       ('F', 18), ('G', 34), ('H', 12), ('I', 12)]:
            ws.column_dimensions[col].width = w
        ws.freeze_panes = 'A4'
        ws.sheet_view.showGridLines = False

    wb.save(out)
    print()
    print('OK 已生成:', out)
    print()
    for tag in order:
        d = data[tag]
        print('=== %s 品类TOP12 ===' % tag)
        for cat, q in sorted(d['cat'].items(), key=lambda x: -x[1])[:12]:
            print('   %-18s %10s  %7.2f%%' % (cat, format(int(q), ','), q / d['total'] * 100))
        print()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
