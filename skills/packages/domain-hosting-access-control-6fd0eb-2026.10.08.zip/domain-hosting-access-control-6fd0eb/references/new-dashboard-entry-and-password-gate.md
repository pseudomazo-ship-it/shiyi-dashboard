# 新增看板入口 + 前端密码门 —— 2026-10-07 实做案例（/skills/ Agent Skills 管理台）

## 一句话背景

十一在 Codex 窗口把技能管理台做好了（本地页面 + 一个未推送的 commit），
随后在桌面窗口对 Hermes 说：**「同步到我的域名，进入密码设置 11」**。
= 发上线 + 前端密码门。已全部落地并验证。

## 源文件在哪（别搞错）

| 角色 | 路径 |
|---|---|
| **源页面**（Codex 的工作区，只读不改） | `D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\skills.html`（约 451 KB，含 352 条内联数据） |
| Codex 的发布 clone（同一个远端） | `D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\网站发布_2026.10.07` |
| **我自己的 clone**（推送用） | `E:\RuanJian\Hermes\cache\shiyi-dashboard-git` |
| 线上 | `https://shiyi11.com.cn/skills/`（密码 **11**） |

## 发布的 commit 里有什么（a129a5c，355 files / 40 MB）

```
common/nav.js      NAV_GROUPS 里「Agent Skills 管理台」href:'' → '/skills/' + match:['/skills/']
index.html         nav.js 引用 v9→v10；「技能资源」cat-count 0→1；卡片去 disabled、文案「技能管理台 · 密码进入」
skills/index.html  453,133 字节，零 /common/ 引用，自带完整样式 + 密码门
skills/packages/   352 个 zip（共 40 MB），页面里用相对路径 packages/xxx.zip 引用
```

## 密码门实现（可整段复用）

- 结构：`.skill-gate` 覆盖全屏表单 + `#skill-content[hidden]`；CSS 里 `#skill-content[hidden]{display:none!important}`
- 校验：内联 IIFE，`crypto.subtle.digest('SHA-256')` 与常量比对；通过 → `gate.remove()`、`content.hidden=false`、`dispatchEvent(new Event('resize'))`
- 哈希：`4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8` = sha256('11')
- ⚠️ 密码就一个「11」，**手打时不能带空格/换行**；`sha256('11 ')` 完全不同
- ⚠️ `crypto.subtle` 需安全上下文（https / localhost）

## 真机验证记录（browser_exec，独立 session）

```
标题: 🐴 Agent Skills 管理台      门存在: True   内容隐藏: True
输 '12' → 提示「密码错误，请重试」  门仍在: True
输 '11' → 门已移除: True          内容可见: True
技能卡片数: 352
页面首屏: 全部352 | 11. 十一独创38 | 设计创作39 | 系统运维18 | 开发编程53 | 电商运营58 …
```

线上内容核对：`git show HEAD:skills/index.html | wc -c` = `curl …/skills/?t=… | wc -c` = **453,133**。
抽一个包 `zhongkui-skill-8a2e45-2026.10.07.zip` → 下载 **82,561** 字节 + `unzip -t` 无错。
首页核对：`技能资源 <span class="cat-count">1</span>`、`<a class="dashboard-link" href="/skills/">`。

## ⚠️ 必须主动告知十一的两件事

1. **前端门防君子不防技术**：仓库 `shiyi-dashboard` 是 **public**，哈希写在源码里、数据内联 →
   F12 能绕；**352 个技能 zip 还有公网直链**（`https://shiyi11.com.cn/skills/packages/<文件名>`，不需要密码）。
   真要锁住 = Cloudflare Access（见本技能「访问控制」一节）。
2. **更新不是自动的**：网站上是**那一天的快照**。源 `skill_manager\skills.html` 更新后要再走一次同步
   （重复本文的 fetch → merge → push 流程）。
   另外这个源文件当天已被两个窗口并发写过（一次被覆盖，见 Hermes 工作区 `数据--技能看板\技能看板同步记录_2026.10.07.md`），
   **建议只让一个窗口改它**。

## 发布时踩到的三件事（详版见 SKILL.md 坑 15/16/17）

1. 提交已经在 Codex 的 clone 里躺着了 → 用 `git fetch <他的路径> main` + `merge --ff-only` 取过来，**别动他的文件**。
2. 40 MB 包 → 走 7897 代理要加 `http.version=HTTP/1.1` + `postBuffer` + `lowSpeedLimit/Time`，并且**后台跑**。
3. 字节数比对要拿 `git show HEAD:<file>` 的 blob（CRLF 会让本地文件多 94 字节）。

---

## 第二轮（同一天）：详情页加「本机文件位置」+ 同步回源文件

十一的原话：
> **本机本地包，没有公网下载地址（附上：电脑名+本地文件的途径）。**
> **给其他 Agent 或另一台电脑安装时，把这个 ZIP 一并发过去即可。**

= 在详情页「安装包」区块、那句说明**之后**再补一行「包在哪台电脑的哪个路径」。

### 加的那一行（`showDetail()` 模板里）

```js
${pkg?`<p class="pkg-loc">本机文件位置：<b>办公室电脑-11</b>　｜　
<span class="path">D:\\Agent.GongZuoQu\\Codex.GZQ\\项目：Skill资源库\\skill_manager\\packages\\
${escapeHTML(pkg.split("/").pop())}</span></p>`:""}
```

- `pkg = safeURL(s.package_url)` → `packages/xxx.zip`；**用 `pkg.split("/").pop()` 取每条技能各自的包名**，
  绝不能写死一个文件名（352 条各不相同，抽 4 张卡验过各自指向自己的包）。
- JS 模板字面量里的 Windows 路径，**反斜杠要写 `\\`**。
- 位置：CSS 锚点 `.detail-frozen+.block{margin-top:12px}`，其后追加
  `.pkg-loc` / `.pkg-loc b` / `.pkg-loc .path`（浅蓝小块 + `overflow-wrap:anywhere` +
  `word-break:break-all`，长路径不撑破版面）。
- **电脑名 = 本机 hostname = `办公室电脑-11`**。⚠️ bash 里 `hostname` 直接打是 GBK 乱码，
  要用 Python `os.environ['COMPUTERNAME']` / `socket.gethostname()` 读才准。

### 源 / 发布版的关系（本次实测定论，已写进 SKILL.md）

逐块比对**只有两处差异、全是发布版多出来的**：密码门的 CSS + 密码门的 HTML/`<script>`。
→ **源文件是个裸页，门是发布时注入的。** 十一说「同步到源文件」= 把这次**文案/样式**改动也写进源文件，
两版内容随之一致（门本身仍只存在于发布版）。⚠️ 源文件里 `node --check` 也要跑一遍（本次 0）。

| commit | 内容 | 线上字节 |
|---|---|---|
| `a129a5c` | 首次上线（skills 页 + 352 包 + 首页入口 + nav.js v10） | 453,133 |
| `e01781d` | 详情页「本机文件位置」 | 453,683 |

改前备份都在我这边、**不在 Codex 工作区留文件**：
`E:\RuanJian\Hermes\cache\backup_skills源文件_改前_2026.10.07.html`（451,283 字节）、
`E:\RuanJian\Hermes\cache\backup_skills线上版_改前_2026.10.07.html`。

### 收尾纪律（十一会留意后台）

- 本地预览 server（`python -m http.server 8899`）验完就 kill；
- `browser_exec` 的调试 Chrome 用 `cdp('Browser.close')` 关掉，并**主动说一句「后台没留东西」**；
- `desktop_preview` 的面板切回**线上地址**，别留一个指向已关 server 的死标签页。

### 顺带记下的口径

- 十一听完「前端门可绕 + 包有公网直链」后明确说：**「不用了，我是内部人员使用」** →
  不配 Cloudflare Access。**这类安全建议说过一次即可，别再主动劝。**
