# 内容加密的静态页：解密 → 改文案 → 重新加密

适用：页面**内容本身被 AES 加密后内联**在 HTML 里（不是普通前端密码门）。
壳子是登录框 + `const ENVELOPE=[salt, iv, ciphertext]`，密码用来**派生解密密钥**，
解开才 `document.write` 出真正的看板。

真实案例：`https://shiyi11.com.cn/warehouse/guangxi/`（广西云仓月度对账，Codex 窗口生成，
`protect_dashboard.ps1` 加密）。2026-10-08 十一要求「顶部『11. 十一』改成蒙倩 + 密码别输两次」。

---

## 一、先判断是不是这种页面

```python
# 特征组合（不是普通密码门）
t = open(p, encoding='utf-8').read()
for kw in ['ENVELOPE', 'PBKDF2', 'AES-GCM', 'deriveKey', 'crypto.subtle.decrypt']:
    print(kw, t.count(kw))
# 命中 → 内容在密文里。此时页面源码里【搜不到任何业务文字】，
#   连店名/数字都搜不到 —— 别以为「页面是空的」，它在 ENVELOPE 里。
```

⚠️ **通用信号**：如果 `grep` 页面源码搜不到十一说的那段文字，但浏览器里看得到 ——
就是内容加密（或 canvas 渲染）。先解密再找，别去改错地方。

## 二、解密（Node WebCrypto，本机就够）

```js
const fs = require('fs');
const html = fs.readFileSync(P, 'utf8');
const E = JSON.parse(html.match(/const ENVELOPE=(\[[\s\S]*?\]);/)[1]);
const un  = s => Uint8Array.from(Buffer.from(s, 'base64'));

const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(PW),
                       'PBKDF2', false, ['deriveKey']);
const key = await crypto.subtle.deriveKey(
  { name: 'PBKDF2', salt: un(E[0]), iterations: 120000, hash: 'SHA-256' },
  material, { name: 'AES-GCM', length: 256 }, false, ['decrypt', 'encrypt']);
const plain = new TextDecoder().decode(
  await crypto.subtle.decrypt({ name: 'AES-GCM', iv: un(E[1]) }, key, un(E[2])));
```

盐/iv 长度可顺手体检：salt 16 字节、iv 12 字节、iterations 常见 120000。

## 三、改文案后必须重新加密（换新 salt/iv）

```js
const salt = crypto.getRandomValues(new Uint8Array(16));
const iv   = crypto.getRandomValues(new Uint8Array(12));
const key2 = await deriveKey(PW, salt);
const ct   = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key2,
                                          new TextEncoder().encode(plain2));
const b64 = b => Buffer.from(b).toString('base64');
html = html.replace(/const ENVELOPE=\[[\s\S]*?\];/,
                    'const ENVELOPE=' + JSON.stringify([b64(salt), b64(iv), b64(new Uint8Array(ct))]) + ';');
```

- **改明文用 `re.replace` 精确锚点**（如 `<div class="brand"><em>11.</em> 十一<small>` → `<em>蒙倩</em>`），
  改完**打印剩余命中数**（`(out.match(/十一/g)||[]).length` 应为 0）。
- ⚠️ **文案可能有两处**：登录壳里一个品牌位（`<div class="brand">11.</div>`）+ 加密内容里一个
  （`<aside><div class="brand"><em>11.</em> 十一<small>…`）。**两处都要改** ——
  只改密文里那处，用户打开时首先看到的是登录页的旧字样（本次实测第一轮就是这么漏的）。
- ⚠️ 改前**先把原文件另存一份**（`.bak_<ts>`），密文改坏等于页面全废。

## 四、🔴 血泪点：`document.write` 解锁**不可靠**

原实现在 submit 回调里：
```js
const content = new TextDecoder().decode(decoded);
document.open(); document.write(content); document.close();
```

**实测症状（2026-10-08）**：解锁后 `document.getElementById('login')` **仍然存在**，
而看板内容**也**渲染出来了 —— 两者叠在同一个文档里。用户视角 = 「好像没进去」→ **再输一次密码**，
这就是十一报的「密码怎么要输两次」。

**根因**：`document.open()` / `document.write()` 在**文档已解析完之后**（事件回调里）调用，
Chrome 可能不按预期清空文档（慢网络拦截、解析状态等原因），于是变成追加而不是替换。

### ✅ 正解：用 DOM 替换，不碰 `document.write`

```js
function reveal(html){
  const doc = new DOMParser().parseFromString(html, 'text/html');
  document.head.innerHTML = doc.head.innerHTML;
  document.body.innerHTML = doc.body.innerHTML;
  // ⚠️ innerHTML 插入的 <script> 不会自动执行 → 重新挂一遍
  Array.prototype.slice.call(document.querySelectorAll('script')).forEach(function(old){
    if(old.dataset.rebound==='1') return;
    const s = document.createElement('script');
    Array.prototype.slice.call(old.attributes).forEach(function(a){ s.setAttribute(a.name, a.value); });
    s.dataset.rebound = '1';
    s.textContent = old.textContent;
    old.parentNode.replaceChild(s, old);
  });
  document.title = doc.title || document.title;
}
```

### ✅ 再加一层「同一会话记住」（顺带解决刷新重输）

```js
const CACHE_KEY = 'gx_billing_unlocked_v1';       // 每个页面一个独立 key
function tryCache(){ let c=null; try{ c=sessionStorage.getItem(CACHE_KEY); }catch(e){ return false; }
                     if(!c) return false; reveal(c); return true; }
function boot(){ if(!tryCache()) bindForm(); }
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
```
解锁成功后 `sessionStorage.setItem(CACHE_KEY, content)`。

- 明文 ~106 KB，sessionStorage 5 MB 配额够用。
- 缓存路径也要在 **DOM 就绪后**执行（解析中途替换会被后续解析覆盖）。
- 换标签页/关掉重开仍需输一次 —— 这是期望行为（安全），别顺手改成 localStorage。

## 五、验证（必须真浏览器，读 DOM 状态）

```python
js('document.getElementById("password").value = "…"')
js('document.getElementById("login").requestSubmit()')      # ⚠️ 别用 fill_input()
time.sleep(4)
js('!!document.getElementById("login")')                     # 必须 False
js('document.querySelector("aside .brand").textContent')     # 字样已改
js('location.reload()'); time.sleep(6)
js('!!document.getElementById("login")')                     # 缓存生效 → False
```

本会话实测通过值：解锁前 `login:true` → 解锁后 `login:false` + 侧栏品牌「蒙倩…」→
刷新后 `login:false`（免重输）+ 全页「十一」0 次。

⚠️ **`new_tab()` 每次都是新标签页 → sessionStorage 不共享**。要验「刷新免重输」，
必须用**同一个标签页** `location.reload()`，否则会误判成「缓存没生效」。

## 六、改「别的 Agent 生成的加密页」的规矩

这类页常是别的窗口（Codex/WorkBuddy）连生成脚本一起产出的：

```
Codex 工作区的源： <项目目录>\dashboard_template.html   ← 品牌位
                  <项目目录>\protect_dashboard.ps1      ← 加密/门逻辑
我改的：          shiyi-dashboard 仓库里的 warehouse/guangxi/index.html（发布物）
```

- ✅ **只改发布仓库的产物**（线上立刻生效），**不动别人的工作区**。
- ⚠️ **必须提醒十一**：下次那个窗口重跑生成，会把改动覆盖回去 ——
  并把「要改哪两处文件」讲清楚（模板里的品牌位 + 加密脚本里的门逻辑），让他转告那个窗口。
- 备份留**自己工作区**，别在别人目录里丢 `.bak`。
