# 域名 → Cloudflare → GitHub Pages 全流程（实测可用）

2026-10 在 `shiyi11.com.cn` 上完整跑通一次。以下全部是**验证过的命令/代码**，不是设想。

---

## 0. 先定站点结构（多站点共用域名）

一个域名 + 路径区分，别拆仓库：

```
<域名>/             → 首页导航页（自动生成的入口卡片页）
<域名>/finance/     → 主体财务看板
<域名>/daily/       → 数据日报
<域名>/logistics/   → 快递决策速查表
```

⚠️ 把原来挂在根域的看板挪到子目录时，**根域要换成导航页** —— 旧链接（根域直指看板）会变，
要提前跟十一说一声。`github.io` 旧地址永远仍然可用，不会断。

### ⭐ 统一 UI 方案（2026-10-07 十一**自己给了规范**，以此为准）

我先前自作主张设计过一版导航页（`#f6f8fb` 底 / `#2563eb` 主色 / 单列居中）——
**十一直接发来一整套规范把我那版换掉了**。要点是：**首页要有统一规范，别每个入口页各写一套。**

⚠️⚠️ **但范围只到首页。** 同一天稍后十一又纠正了一次：
「**每一个看板网页都是独立的**……**每个看板都会对接不同的人，他们不能看到其他的看板数据**」。
所以 `common/` 这套**只服务首页**，**各看板一个引用都不要加**（详见 SKILL.md 坑 9）。

```
<域名>/
├── index.html              首页导航（dashboard-grid 卡片入口）
├── common/
│   ├── style.css           统一样式库（变量/导航/卡片/表格/按钮/响应式）
│   ├── nav.js              顶部导航组件（路径高亮 + 汉堡菜单）
│   └── inject_ui.py        注入工具（幂等，给存量看板补导航）
├── daily/index.html        各看板【完全独立】——不引 common 里任何东西
├── finance/index.html
└── logistics/index.html
```

**设计规范（十一指定，别再自己配色）**

| 项 | 值 |
|---|---|
| 主色（导航/标题） | `#1E3A5F` 深海军蓝 |
| 强调色（按钮/高亮） | `#3B82F6` 亮蓝 |
| 页面背景 | `#F5F7FA` |
| 卡片 | `#FFFFFF` + 圆角 `16px` + 柔和阴影 |
| 字体 | system-ui + 微软雅黑 |
| 导航 | 高 `64px`，移动端折叠为汉堡菜单 |

`style.css` 提供的 class：`container` / `page-header` / `card` / `stats-grid`+
`stat-card(.success/.warning/.danger)` / `table-wrap` / `tag-*` / `btn-*` /
`dashboard-grid`+`dashboard-link` / 间距与 flex 工具类。**新看板优先复用这些，别另起炉灶。**

**首页接入**（`<head>` 里引 CSS，`<body>` 最顶部放占位 div + 脚本）——⚠️ **已知末版是左侧竖导航**，
以 SKILL.md「首页（个人工作台）的结构规范」为准，别照早期顶部横导航写：
```html
<link rel="stylesheet" href="/common/style.css?v=6">
...
<div id="app-nav"></div>
<script src="/common/nav.js?v=6" data-sidebar="1" data-clock="1" data-search="1"></script>
```
（`data-sidebar="1"` → 渲染左侧竖导航；`data-clock="1"` → 启动逐秒时钟；
`data-search="1"` → 绑搜索框。子页面现在**什么都不引**，见坑 9。）

⚠️⚠️ **看板页面不要引这两行** —— 十一最后明确要求看板独立（拿链接的人不能看到别的看板）。
若日后确有需要引用，**路径必须以 `/` 开头**：十一给的示例写的是 `common/style.css`，
那个在 `/daily/` 这类子目录页面下会去找 `/daily/common/style.css` → **404，导航和样式全丢**
（静默失败：页面不报错、只是没样式没导航）。

**`nav.js` 的高亮用 `location.pathname` 匹配，不要用页面 title**（十一的描述里提了 title，
但 title 是浏览器标题、各看板格式不一，路径匹配才可靠）——留 title 作兜底即可。
菜单项集中在一份 **`NAV_GROUPS`（母分类数组，每项 = `title` + `items`）**里，
**加看板只改这一处**；`href: ''` 即表示「还没接入」→ 渲染成灰色不可点。
顶部横导航模式需要的扁平列表由 `NAV_GROUPS` 现推，**别维护第二份菜单**。

**存量看板批量接入**：别手工改大文件（看板 550KB+），用幂等注入脚本：
```bash
python common/inject_ui.py daily/index.html finance/index.html logistics/index.html
python common/inject_ui.py --check <文件>     # 只查不改
```
脚本在 `scripts/inject_ui.py`（可直接复制到仓库 `common/` 下用）。

### 首页 = 「个人工作台」布局（⚠️ 已迭代到【左侧竖导航】版，以 SKILL.md 为准）

我第一版做的是「纯入口网格」，十一改成**工作台**：**先不展示各看板的详细数据**，
只做「进入不同看板」的门。

⚠️ 当天又改了两轮，**只认最后一次**（完整规范在 SKILL.md，这里只留形状防止照旧版重建）：
```
① 左侧竖导航   宽 224px；品牌区【11】+「十一.11 / 个人工作台」；首页项
                + 【母分类 > 子分类】两级菜单（**末次：默认全部展开**、点击可收起）
                  ⚠️ 侧栏底部**不放页脚**（原来那两行已按要求删掉）
② 顶部栏       只放搜索框（placeholder 留空）+ 手机端 ☰
③ 【**右下角**悬浮状态卡】「欢迎回来。」/「所有入口都汇总在这里，点卡片直接打开」
                + 逐秒实时时间 + 绿色呼吸灯（position:fixed; right:22px; bottom:22px）
                ⚠️ 位置末次是**右下**（改过三轮：顶部 → 左下 → 右下）
④ 常用入口     3~4 个最常访问的，带更新频率
⑤ 全部看板     按四个母分类卡片网格（桌面每行 3 张，手机单列）
⑥ 页脚         只留维护说明（「内部使用·请勿外传」和域名两句末次已删）
```
⚠️ **不是**早期那版「顶部横导航 + 页面顶部欢迎区 + 右侧最近更新日期」——那个已被推翻。

**`nav.js` 靠脚本标签属性区分首页/子页面**（同一组件两副面孔，别写两份）：
```html
<!-- 首页（末版）：左侧竖导航 + 实时时钟 + 搜索框 -->
<script src="/common/nav.js?v=6" data-sidebar="1" data-clock="1" data-search="1"></script>

<!-- 子页面：现在什么都不引（它们必须完全独立，见坑 9） -->
```
`data-sidebar="1"` 渲染左侧竖导航，`data-clock="1"` 启动逐秒时钟，`data-search="1"` 绑搜索框；
遗留的 `data-nav="0"`（隐藏顶部菜单）只在旧的顶部横导航模式里还有意义。

**搜索框的完整行为**（逐项验证过，别只做一半）：
```
· 实时过滤：按 .dashboard-link 的 data-name + 文案匹配（要能跨分类命中）
· 空分类自动隐藏（一张卡都不剩的分类，别留个空标题）
· 分类计数跟着搜索结果变（搜「规则」→「知识资料 2」），不是写死总数
· 搜索时收起「常用入口」和分区标题，让结果更聚焦
· 无结果提示：命中 0 时显示「没有匹配的看板，换个关键词试试」
· 快捷键：按 / 聚焦搜索框；Esc 清空
· 移动端（≤768px）隐藏搜索框（空间不够），走汉堡菜单
```
⚠️ 每张卡要有 `data-name`，**把中英文别名都塞进去**（如「数据日报 … daily」），
否则搜英文/缩写/同义词搜不到。

**没接上的看板：放「占位卡片」，不要放死链。**
用 `.dashboard-link.disabled`（降透明度 + `pointer-events:none`），文案写「待接入」——
点不开但看得见规划，比点了 404 好。十一原话：「模板先用示例名称和链接，后续替换」。

### 版本号工作流（防浏览器缓存，详见 SKILL.md 坑 10）

```bash
# 注入 + 自动补 ?v=<VER>（VER 在 inject_ui.py 头部）
python common/inject_ui.py index.html daily/index.html finance/index.html logistics/index.html

# 只升版本号、不动结构 —— 改了 CSS/JS 之后跑这句，浏览器立刻拉新版
python common/inject_ui.py --bump 2 index.html daily/index.html finance/index.html logistics/index.html
```
⚠️ 版本号替换**只该动 `href=` / `src=` 属性**。早期用的宽松正则连页脚说明文字里写的
`/common/style.css` 也加了 `?v=1`（页脚文案变脏）；`scripts/inject_ui.py` 已收紧为
只匹配属性。手写正则时注意同样限定。

### 本地验收：先本地 → 他拍板 → 才推线上

```bash
cd <repo> && python -m http.server 8899 --bind 127.0.0.1
# desktop_preview 打开 http://127.0.0.1:8899/  ← 绝对路径链接能点，最接近线上
```
⚠️ **验证前端改动时先强制绕过缓存**（`cdp('Page.reload', ignoreCache=True)` + 等 2~3s），
否则你验的是旧版，会把缓存问题误判成「脚本没生效」（见 SKILL.md 坑 10）。

验收脚本要逐个页面打印：品牌文字 / 有无 logo 方块 / 有无搜索框 / 有无菜单 /
当前高亮项 / 导航整体文字 —— 一页一行，一眼看出哪页不对。

### ⚠️ 自动生成的看板：生成器要**兜底移除**导航

`daily/index.html` 和 `finance/index.html` 都是**脚本自动生成**的（数据日报每天 23:45、
主体财务周一），生成器整份重写 HTML。既然看板必须独立（坑 9），
**每个生成器都要在产出后跑一次 `--strip` 兜底**：

```python
import subprocess
subprocess.run([sys.executable, 'common/inject_ui.py', '--strip', 'daily/index.html'], cwd=repo)
```
（脚本幂等；本来就没有导航时输出「本来就无导航，无需处理」。）
⚠️ 这条是「生成器才是唯一事实源」的又一个实例——见 `gh-pages-dashboard-maintenance` 技能。

⚠️ 另一个生成器（主体财务周更）是**「读→替换 QDATA→写回」式**，只换数据不动结构，
不会破坏独立性 —— 但它把目标路径写死成了根域 `index.html`，
看板挪到 `finance/` 后必须同步改（连同 `git add` 和线上验证 URL），否则会更新到错的文件上。
详见 SKILL.md 坑 11。

### ⚠️ 以后挂更多看板 / 多来源自动推送

十一说这个域名是**他个人的**、以后还会往里挂别的看板。三条约定（已写进仓库 `common/README.md`）：
1. **加看板 3 步**：建 `/新名/index.html`（**什么都不引，保持独立**）→ 首页加张卡（带 `data-name`）→
   （可选）`NAV_ITEMS` 加一项。加完跑 `python common/inject_ui.py --check <新页面>` 确认零 common 引用。
2. **多个来源自动 push 时各推各的目录** —— 整仓库覆盖式 push 会**连别的看板和导航一起冲掉**。
3. **导航已经分组了**（不是待办）：`NAV_ITEMS` 已升级为 **`NAV_GROUPS`（母分类 > 子分类）**，
   母分类**末次改为默认全部展开**（先要收缩、当天又改），点击可收起，箭头用 `▸`/`▾` 文字切换（别用 CSS rotate）；
   母分类字号 13.5px/700、子分类 12.5px/400（**母必须明显大于子**，否则两级分不出层级）。
4. ✅ **看板独立（已按十一要求落地）**：导航页列了**所有入口**，所以**首页链接只给需要总览的人**；
   每个看板单独发对应的人，看板自身零 common 引用 → 拿链接的人看不到还有别的看板。
   再叠一层：`daily` / `finance` 自带密码门（`id="gate"` / `login-overlay`）。
   要更强防护（防 F12 抠数据）仍然只有「Cloudflare 代理 + Access」一条路。

GitHub Pages 侧结构：
```
<repo>/
  CNAME            ← 填自定义域（GitHub 在设置自定义域时自动创建，别手动改）
  .nojekyll        ← 必须有，否则下划线开头文件被 Jekyll 吞掉
  index.html       ← 导航页
  common/          ← 统一样式库 + 导航组件 + 注入脚本（见下「统一 UI 方案」）
  finance/index.html
  daily/index.html
  logistics/index.html
```
部署后 URL 就是 `<域名>/finance/`（目录 → 默认找 index.html）。
⚠️ 绑了自定义域后，`<域名>/<repo名>/` 这种路径会 404 —— 那只是 github.io 的路径形态，
自定义域下不存在，别当成配置错误。

---

## 1. Cloudflare 添加站点 → 拿 NS

后台：`dash.cloudflare.com/<accountID>/add-site?type=onboard`
入口按钮：侧边栏「连接域名」→ 输入框填裸域名（`example.com`，无 http/无 www）。

流程：填域名 → 选 **Free** 计划（三个「选择计划」按钮里最左那个）→
「继续」→ 确认扫描到的 DNS 记录（新域名扫出来是空的，正常）→ **「继续前往激活」**。

⚠️ 坑：
- 「继续前往激活」按钮常在**视口外**（`y` 超出 window 高度）→ 要先 `scrollIntoView({block:'center'})`
  **再重新取坐标**，别用滚动前的坐标点（会点空）。
- 下面这几个页面上的按钮对 CDP 合成点击**没反应**，别浪费轮次 —— 直接走第 3 节的 API 通道。

拿到的 NS 是**每个 zone 独立的**（形如 `<名>.ns.cloudflare.com`），**必须现读，不要硬编码**。
读完去域名概览页确认状态：先是「正在等待注册机构传播新的名称服务器」，
NS 生效后变 `active`。**实测 NS 改完几分钟内就 active，不用等它说的 24 小时。**

---

## 2. 在注册商改 NS（阿里云）

⚠️ **改 NS 不在「云解析 DNS」（`dns.console.aliyun.com`），在「域名控制台」**（`dc.console.aliyun.com`）。

路径：域名列表 → 该域名的「管理」→ 左栏竖排菜单里的 **「DNS修改」**。

**⚠️ 坑（卡了很久）**：左栏那个「DNS修改」链接的 href 是
```
#/domain/details/dns-modify?saleId=undefined&domain=<域名>
                              ^^^^^^^^^^^^^^^^^ 点击无反应
```
`saleId` 是 `undefined`，所以点它什么都不发生。

**解法：直接用真实 saleId 拼 URL 导航** —— saleId 从域名详情页 URL 里拿：
```
https://dc.console.aliyun.com/#/domain/details/info?saleId=<Sxxx...>&domain=<域名>
                                                      ^^^^^^^^^^^^ 抄这个
↓ 换成
https://dc.console.aliyun.com/#/domain/details/dns-modify?saleId=<Sxxx...>&domain=<域名>
```

到了之后：**「修改DNS服务器」**按钮 → 弹窗（提示「错误修改DNS可能导致网站无法访问」）→
填 2~6 个 NS（**国内域名最多 6 个**；国际域名 2~13 个）→ 确定。
⚠️ 别在结尾打点号（`example.com.` 是错的，要 `example.com`）。

填输入框用 CDP：点击 → `Ctrl+A` → `Backspace` ×3 → 逐字符 `dispatchKeyEvent`，
或者更省事用 `Input.insertText`（不受键盘布局影响）。

改完立刻验：
```bash
nslookup -type=NS <域名>
# 返回的 *.ns.cloudflare.com + 它们的 IP ⇒ 注册局已更新（往往几分钟内，不是 24h）
```
**域名实名/续费/过户仍在阿里云**，只有解析挪到了 Cloudflare —— 跟他说明白这点。

---

## 3. 配 DNS 记录（核心：用 A 记录，不用 CNAME）

**为什么不用 CNAME 指向 github.io**（详见 SKILL.md 坑 5）：
CNAME 会把目标的 A + AAAA 一起返回，GitHub Pages 的 AAAA 在国内不通
→ 浏览器先试 IPv6、干等 ~15s 超时 → 才回退 IPv4。症状是**间歇性**的（0.4s 和 15s 交替）。

**正确配置：**
```
A      <域名>      185.199.108.153   proxied=false（灰云）
A      <域名>      185.199.109.153   proxied=false
A      <域名>      185.199.110.153   proxied=false
A      <域名>      185.199.111.153   proxied=false
CNAME  www.<域名>  <域名>            proxied=false   ← 指向根域，不是 github.io
```
（这 4 个是 GitHub Pages 官方 IP。）

**灰云 vs 橙云**：
```
灰云 proxied=false → 解析直出 GitHub IP，快（实测 0.4~1.6s），但
                     Cloudflare Access / CDN 防护**全部失效**
橙云 proxied=true  → 有 Access、有 CDN，但延迟高（实测走 AMS 节点 ~183ms）
                     ⚠️ 且橙云下 GitHub 的 DNS check 和 Let's Encrypt 证书签发容易失败
```
十一明确要「直连」时选灰云，**但必须把「没有访问控制了、数据裸奔」讲清楚**，
并给他三选一：保持现状 / 给看板加密码门 / 改回橙云+Access。

### Cloudflare API 通道（不用 API Token，绕开点不动的 UI）

在**已登录 Cloudflare 的页面**里执行（CDP `Runtime.evaluate`，`awaitPromise`）：
浏览器自动带 cookie，**不需要 API Token、不需要 CSRF header**。

```js
// 拿 zoneId + 状态
(async function(){
  var r = await fetch('/api/v4/zones?name=<域名>', {credentials:'include'});
  var j = await r.json();
  var z = j.result[0];
  return JSON.stringify({zoneId: z.id, status: z.status});   // status: active
})()

// 列记录
(async function(){
  var j = await (await fetch('/api/v4/zones/'+Z+'/dns_records?per_page=100',
            {credentials:'include'})).json();
  return JSON.stringify(j.result.map(x => x.type+' '+x.name+' → '+x.content+' proxied='+x.proxied));
})()

// 改记录（PUT 要带全 type/name/content/proxied/ttl）
fetch('/api/v4/zones/'+Z+'/dns_records/'+ID, {
  method:'PUT', credentials:'include',
  headers:{'Content-Type':'application/json'},
  body: JSON.stringify({type:'A', name:'<域名>', content:'185.199.108.153', proxied:false, ttl:1})
})

// 新建 POST /api/v4/zones/<Z>/dns_records     删除 DELETE /api/v4/zones/<Z>/dns_records/<ID>
```

⚠️ **A 和 CNAME 不能同名共存** —— 改 A 之前必须先删掉同名 CNAME，否则 POST 报错。
顺序：**先删 CNAME → 再加 A**（中间有几秒空窗，可接受；GitHub 侧域名绑定有缓存，不会掉）。

---

## 4. GitHub Pages 填自定义域（走 API，不用他手点）

本机 git 凭据管理器里存着 GitHub token（形如 `gho_...`），取出来直接调 REST API：

```bash
# 取凭据（注意：不要把 token 明文打印到日志/文件）
git credential fill <<< $'protocol=https\nhost=github.com\n\n'
# → username / password(=token)
```

```python
# PUT /repos/<owner>/<repo>/pages   body: {"cname": "<域名>"}
# 返回 204 = 成功；随后 GET 回读：status/cname/https_enforced
# 证书签好后：PUT 同一端点  body: {"https_enforced": True}
```

⚠️ 子进程里调 curl/subprocess 前要 `env.pop('PYTHONPATH')`（否则 uv 工具链报 pydantic_core 缺失）。
⚠️ 走 `shell=False` + 列表参数（`shell=True` + 多行参数会被 cmd 在第一个换行处截断）。

设置成功后 GitHub 会自动：
- 在仓库里创建 `CNAME` 文件
- 签 Let's Encrypt 证书（**必须在灰云下**，橙云会挡住 HTTP-01 挑战）
- 约 1 分钟内 `status: built`

---

## 5. 验收

```bash
# ① 解析：应只有 A，无 AAAA
nslookup -type=A    <域名> 1.1.1.1
nslookup -type=AAAA <域名> 1.1.1.1     # 应无应答

# ② 逐站点验内容 + 状态码
for p in "" daily/ finance/ logistics/; do
  curl -s -m 25 -o /dev/null -w "<域名>/$p -> %{http_code}\n" "https://<域名>/$p"
done

# ③ 只看 title 确认挂对了页
curl -s -L "https://<域名>/finance/" | grep -oE '<title>[^<]*</title>'

# ④ IPv4/IPv6 分别测速（防 IPv6 拖慢）
curl -4 -s -o /dev/null -w "v4: %{time_connect}s / %{time_total}s\n" "https://<域名>/"
curl -6 -s -o /dev/null -w "v6: %{time_connect}s / %{time_total}s\n" "https://<域名>/"

# ⑤ 强制指 IP 测「不含解析问题」的真实速度
curl -s --resolve <域名>:443:185.199.110.153 -o /dev/null \
     -w "%{time_connect}s / %{time_total}s\n" "https://<域名>/"
```

**⚠️ `curl` 在 git-bash 里偶尔返回 `exit_code 23`（write error）**，但输出是完整的 ——
不要把 23 当命令失败。同理 `nslookup` 中文乱码属正常，只读 IP/NS。

---

## 6. 本地预览再上线（十一的硬性要求）

看板/网页类改动：**先本地改好 → 给他预览确认 → 他拍板才推线上**。

```bash
cd <repo> && python -m http.server 8899 --bind 127.0.0.1
# 然后 desktop_preview 打开 http://127.0.0.1:8899/  ← 链接能点，最接近线上效果
```
直接 `file://` 预览的话，绝对路径链接（`/daily/`）点不动，只能用来看样式。

push 前必须 `git pull --rebase`（GitHub 那边会被自动同步脚本改）。
改目录结构用 `git mv` 保留历史。

---

## 7. 遗留待办（2026-10-07 当时的）

- 灰云无访问控制 → 已给十一三个选项，等他拍板
- 快递决策速查表挂的是 2026.09.21 版，已问他是否有更新
- 是否给子页面加「← 返回导航」链接 —— 已否（看板必须完全独立，见坑 9）
- **7 张占位卡片的真实名称/地址**（待办清单 / 退款处理工作台 / 商品上架控制台 /
  Agent Skills 管理台 / 客服话术库 / 平台规则库 / 快递物流规则汇总）—— 已多次问他，尚未回复

> ⚠️ 这两项（快递决策表版本、占位卡片）**每次都提一句就行，别反复催**；
> 他很可能就是暂时没想好。催太密会烦（他会直接不回）。
