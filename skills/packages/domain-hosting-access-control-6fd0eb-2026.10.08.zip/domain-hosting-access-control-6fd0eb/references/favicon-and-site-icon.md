# 站点图标（favicon）· 从需求到上线

## 触发

十一发一张图 + 问「**能不能给我域名做个图标**」—— 这里的「图标」= **favicon**
（浏览器标签页那个小图），**不是**首页上的装饰大图。

2026-10-07 实例：他发了一张「戴耳机背书包喝咖啡的水獭」梗图后问这句 → 想拿这个形象当站点图标。

---

## 一、先讲清技术现实（不讲他会选错，选完会失望）

```
浏览器标签页里的图标只有 16 × 16 像素。

带细节的插画（照片 / 梗图 / 动漫形象）缩到 16px ⇒ 必然糊成一团，
只剩一团色块，认不出是什么。

行业惯例：
  favicon     → 极简符号（单字 / 字母 / 简单几何图形）
  大图 / logo → 留在首页当装饰或 banner
```

**光用嘴解释没用，做对比给他看。** 2026-10-07 做了 7 版候选，其中两版直接裁他的原图：

| 版本 | 内容 | 结局 |
|---|---|---|
| A | 「十一」深蓝底 | — |
| **B** | **「11.」深蓝底（对应域名里的 11）** | ✅ **他选了这个** |
| C | 「十」亮蓝底（最简） | — |
| D | 咖啡杯简笔（把他的图元素提炼出来） | — |
| E | 「十一」白底 + 深蓝底条 | — |
| **F** | **水獭原图裁圆** | ❌ 16px 下只剩一团棕色 |
| **G** | **水獭 + 深蓝圆底** | ❌ 稍好，但仍不是可辨符号 |

**F / G 的 16px 效果一出，他立刻就懂为什么要用极简版** —— 比讲道理有效得多。
他看完直接回了一个字母「B」，没有再纠结原图。

**推荐的折中组合**（既保个人形象又保清晰）：
```
标签页图标 → 极简版（单字 / 字母）
首页欢迎区 → 放那张大图（有味道，且不糊）
```

---

## 二、一套 favicon 要产出哪些文件

全部放**站点根目录**（不是 `common/` —— 浏览器和爬虫默认只找根目录）。

| 文件 | 尺寸 | 用途 |
|---|---|---|
| `favicon.ico` | 16/32/48 多帧 | 传统浏览器、Windows 快捷方式 |
| `favicon-16x16.png` | 16 | 标签页 |
| `favicon-32x32.png` | 32 | 标签页（高分屏）、书签栏 |
| `favicon-48x48.png` | 48 | 部分浏览器的标签页 / 任务栏 |
| `apple-touch-icon.png` | 180 | iOS 加到主屏幕 |
| `icon-192.png` | 192 | Android 主屏幕 / PWA |
| `icon-512.png` | 512 | PWA 启动画面 |
| `site.webmanifest` | — | PWA 配置（可「添加到主屏幕」） |

> 2026-10-07 实际就产出了这 8 个。不追求 SVG 也行 —— **ICO + PNG 全套已覆盖所有主流场景**，
> 且 PIL 直接就能出，不用装 cairosvg（本机没有）。

`<head>` 里这样加：
```html
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">      <!-- 只有首页加 -->
<meta name="theme-color" content="#1E3A5F">          <!-- 手机地址栏配色，呼应图标主色 -->
```

`site.webmanifest`（PWA，手机可「添加到主屏幕」，图标 + 名称都正常）：
```json
{
  "name": "十一.11个人工作台",
  "short_name": "工作台",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#F5F7FA",
  "theme_color": "#1E3A5F",
  "icons": [
    {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
    {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}
  ]
}
```

---

## 三、用 PIL 生成（本机没有 cairosvg 也能做）

**超采样再缩小是清晰的关键**（画 8 倍大，最后 LANCZOS 缩回）：
```python
SS = 8                       # 超采样倍数（小图标建议 8，比 4 更干净）
s = size * SS
im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
ImageDraw.Draw(im).rounded_rectangle(
    [0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=PRIMARY)
# ... 画内容 / 写字 ...
return im.resize((size, size), Image.LANCZOS)    # 缩回目标尺寸
```

**⚠️ 小尺寸要单独补偿细节，不能等比例缩。** 装饰性小元素（圆点、细线）在 16px 下会
直接消失或被背景吃掉。按尺寸给一个放大系数 + 微调位置：
```python
k = 1.0 if size >= 48 else (1.35 if size >= 32 else 1.7)   # 越小越放大
dr = s * 0.045 * k
cx, cy = (s * 0.755, s * 0.765) if size >= 48 else (s * 0.770, s * 0.775)
d.ellipse([cx - dr, cy - dr, cx + dr, cy + dr], fill=ACCENT)
```

**ICO 直接由 PIL 打包多帧**（不需要外部工具）：
```python
imgs[48].save("favicon.ico", format="ICO", sizes=[(16, 16), (32, 32), (48, 48)])
```

**踩过的细节**：
- **中文字体**：`C:\Windows\Fonts\msyhbd.ttc`（微软雅黑 Bold）；`simhei.ttf` 兜底
- **文字居中**：用 `d.textbbox((0,0), txt, font=f)` 算实际包围盒再偏移。
  直接 `anchor="mm"` 对 CJK 不一定准（字形上下留白不对称）
- **字距**：PIL 的 `text()` **没有 spacing 参数**。要字距就逐字 `textbbox` +
  累加宽度自己排（本会话的「十一」就是逐字排的）
- **圆形蒙版**：`ImageDraw.Draw(mask).ellipse(...)` 建 L 通道 mask，再 `paste(im2, (0,0), mask)`
- **从照片/梗图裁圆**：主体不一定在正中。先按视觉中心裁正方形
  （本例水獭偏左，取 `w * 0.42` 为基准 `max(0, cx - side//2)` 再夹住右边界），再套圆形 mask

---

## 四、关键验证：必须看 16px 真实效果，而且要看图

**只看 256px 大图就下结论是错的。** 真实缩到 16px 再放大回来看：
```python
im.resize((16, 16), Image.LANCZOS).resize((64, 64), Image.NEAREST).save("check_16x4.png")
#                                       ↑ 必须 NEAREST（最近邻）
#                                         用 LANCZOS 放大会把糊掉的像素又平滑回去，看不出真相
```

**然后真的去「看」它** —— 用 `vision_analyze` 问三个具体问题：
```
① 主体字符（如「11」）能清晰辨认吗？
② 那个装饰小点/小元素还能看到吗？
③ 整体有无糊边、错位？（像素风的锯齿是正常的，不算问题）
```
2026-10-07 就是这么确认 B 版可用的（结论：字形可辨、蓝点可见、无糊边）。
**别跳过这一步** —— 「生成成功」不等于「小尺寸可用」。

---

## 五、让他挑：做一页预览，含「模拟浏览器标签页」

看图标大图他判断不了。预览页必须有三样：

1. **256px 大图**
2. **16px 真实效果（放大 4 倍，NEAREST）** ← 最关键的一格
3. **模拟标签页**：**浅色 + 深色各一排**（他可能用深色主题），图标和标题一起排进去

再加一段说明：图标会做全套尺寸、会加 `theme-color`、不满意可以换方向。

> 预览页用 `desktop_preview` 打开本地 HTML。**中文路径要 URL 编码**：
> `file:///D:/.../%E6%95%B0%E6%8D%AE--%E5%9B%BE%E6%A0%87/preview.html`
> 生成脚本、各候选图、预览页统一放 `数据--图标\`（工作区，不进仓库）。

---

## 六、上线

### ① favicon 会被所有页面共享 —— 但这【不】违反坑 9

```
判断标准是「它有没有在说话」，不是「它在几个页面上出现」：

  导航    = 站点名 + 其他看板的菜单项 → 枚举出「你还有哪些看板」= 泄露，必须删（坑 9）
  favicon = 一个不含文字的符号标记   → 不枚举任何东西，全站共用【没问题】
```

2026-10-07 的落地：选「11.」这种中性符号标，**注入到了全部 4 个页面（含 3 个独立看板）**，
十一没有异议 —— 因为它没暴露任何「还有哪些看板」。

**只有当图标里塞了公司名 / 看板清单 / 会说话的字时**，才需要按页分开放
（每页 `<link rel="icon" href="/daily/favicon.ico">`），或用纯色块等无信息图形。

### ② 注入用脚本，别手改

页面里有的是脚本整份生成的（`daily/`、`finance/`），手改会被覆盖。
用幂等脚本按 `</head>` 前插入，（首页额外加 manifest + theme-color）：
```python
BASE = ('<link rel="icon" href="/favicon.ico" sizes="any">\n'
        '<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">\n'
        '<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">\n'
        '<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">')
m = re.search(r'</head>', html, re.I)
html = html[:m.start()] + BASE + '\n' + html[m.start():]
# 已有 favicon.ico 就跳过 → 幂等
```

### ③ 上线后看不到新图标 = 正常现象，别当成失败

**favicon 的缓存比普通页面顽固得多**，普通 `Ctrl+F5` 经常也不管用，可能几小时不更新。
告诉他：**开无痕窗口**、或**把所有标签页全关掉再重新打开**再看。
（这和坑 10 是同一个病根：先把「是不是缓存」排除掉，再去怀疑代码。）

### ④ 线上校验要比字节数，不能只看 HTTP 200

```bash
curl -s -o f.ico  "https://<域名>/favicon.ico"
curl -s -o f32.png "https://<域名>/favicon-32x32.png"
# 和本地原件逐字节数比对（一致才算真的传上去了）
ls -la <本地 icons>/favicon.ico <本地 icons>/favicon-32x32.png
```
2026-10-07 核对：线上 3341B / 1158B = 本地一致。
⚠️ `curl -o /dev/null -w '%{size_download}'` 在部分 shell 里会显示 0B（统计被吞），
**别据此以为文件是空的** —— 落到临时文件再 `wc -c` 才可靠。

---

## 七、2026-10-07 交付记录（可当作模板复用）

```
设计       B 版：「11」深蓝圆角方（#1E3A5F）+ 右下亮蓝点（#3B82F6）
生成       PIL 超采样 8× 渲染 → LANCZOS 缩回；小尺寸对蓝点做 1.35× / 1.7× 补偿
验证       check_16x4.png（NEAREST 放大）→ vision_analyze 判定：字形可辨、蓝点可见、无糊边
预览       7 版候选 + 模拟标签页（浅色/深色）→ 他回「B」
产出       favicon.ico / 16 / 32 / 48 / 180 / 192 / 512 / site.webmanifest → 仓库根目录
注入       4 个页面（首页含 manifest + theme-color；看板只加 icon 引用）
上线       git push → 等 90s → 逐文件 curl 比对字节数
```

工件位置：`D:\Agent.GongZuoQu\Hermes.GZQ\数据--图标\`
（`make_favicon.py` 生成脚本、`b\` 成品、`preview.html` 预览页）
