#!/usr/bin/env bash
# dns-layer-diagnose.sh
# 判断某条 DNS 记录被缓存在哪一层；也用于排查「网站慢 / 打不开」是不是 IPv6 拖后腿。
#
# 用法:
#   bash dns-layer-diagnose.sh <域名>            # 查 A + AAAA，并附 IPv4/IPv6 测速
#   bash dns-layer-diagnose.sh <域名> AAAA       # 只查一种类型
#
# 用法背景：改完 DNS 记录后「本机还解析到旧 IP」时，别急着怀疑配置 ——
# 往往只是路由器/运营商还缓存着旧记录，权威早已更新。此脚本一次看清是哪一层。
#
# 实测案例：CNAME→github.io 改成 4 条 A 记录后，1.1.1.1/8.8.8.8/223.5.5.5/114
# 全部只返回 IPv4，唯独本机路由器还吐 2606:50c0::153（旧 AAAA）
# ⇒ 浏览器仍然间歇性卡 15 秒。定位到这里才知道不是配置问题。

set -u
DOMAIN="${1:-}"
if [ -z "$DOMAIN" ]; then
  echo "用法: bash dns-layer-diagnose.sh <域名> [A|AAAA]"
  exit 1
fi

# 只抓 IP，避开 nslookup 在 git-bash 里的中文乱码
probe () {
  local d="$1" t="$2" s="$3" out
  if [ -z "$s" ]; then out=$(nslookup -type="$t" "$d" 2>&1)
  else                   out=$(nslookup -type="$t" "$d" "$s" 2>&1); fi
  echo "$out" \
    | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}|([0-9a-fA-F]{0,4}:){2,}[0-9a-fA-F]{0,4}' \
    | grep -vE '^(1\.1\.1\.1|8\.8\.8\.8|223\.5\.5\.5|114\.114\.114\.114|192\.168\.|127\.|10\.)' \
    | sort -u | tr '\n' ' '
}

TYPES=("A" "AAAA")
FULL=1
if [ $# -ge 2 ]; then TYPES=("$2"); FULL=0; fi

for T in "${TYPES[@]}"; do
  echo "=============================================="
  echo "  记录类型: $T   ($DOMAIN)"
  echo "=============================================="
  printf '  %-20s %s\n' "权威 1.1.1.1:"    "$(probe "$DOMAIN" "$T" 1.1.1.1)"
  printf '  %-20s %s\n' "8.8.8.8:"         "$(probe "$DOMAIN" "$T" 8.8.8.8)"
  printf '  %-20s %s\n' "223.5.5.5阿里:"   "$(probe "$DOMAIN" "$T" 223.5.5.5)"
  printf '  %-20s %s\n' "114:"             "$(probe "$DOMAIN" "$T" 114.114.114.114)"
  printf '  %-20s %s\n' "本机默认(路由器):" "$(probe "$DOMAIN" "$T" "")"
  echo
done

if [ "$FULL" -eq 1 ]; then
  echo "=============================================="
  echo "  本机 IPv4 / IPv6 连接对比"
  echo "=============================================="
  for fam in 4 6; do
    curl -"$fam" -s -m 25 -o /dev/null \
      -w "  IPv$fam → HTTP %{http_code} | 连接 %{time_connect}s | 总 %{time_total}s\n" \
      "https://$DOMAIN/" 2>/dev/null \
      || echo "  IPv$fam → 不可用（常见：本机没有 IPv6 出口）"
  done
  echo
fi

cat <<'EOF'
读法:
  · 权威无 AAAA、但路由器还有 ⇒ 旧记录卡在路由器/运营商
    → 等 TTL 过期，或把本机 DNS 改成 223.5.5.5 绕开。
    → 只有「改记录前就解析过该域名」的机器会中招，全新访问者不受影响，
      所以「同事能开、就我卡」是正常现象。
    → ❌ 不要动路由器设置（那是十一的网络设备，需他同意）

  · IPv4 快、IPv6 不通或极慢 ⇒ IPv6 拖后腿（15 秒超时的典型成因）
    → 去 Cloudflare 把 CNAME 换成 A 记录（见 SKILL.md 坑 5）

  · 先清本机缓存再判断（否则看到的仍是旧值）:
    powershell -NoProfile -Command "Clear-DnsClientCache"
    （git-bash 里 `ipconfig //flushdns` 无效，MSYS 会把 /flushdns 当路径转译）

  · curl 返回 exit_code 23(write error) 但输出完整 = 不是失败，别当命令挂了
EOF
