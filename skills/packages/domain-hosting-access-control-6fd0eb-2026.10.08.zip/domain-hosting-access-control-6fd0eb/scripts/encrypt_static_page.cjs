// 把一版明文 HTML 页面「生成」成加密页（内容 AES-256-GCM 内联）
// 与 /docs/ 、/warehouse/guangxi/ 同机制：壳里只有登录框 + const ENVELOPE=[salt,iv,ct]
// 用法: node encrypt_static_page.cjs <明文html> <输出html> <密码> [标题]
const fs = require('fs');
const crypto = require('crypto');

const [src, out, pw, titleArg] = process.argv.slice(2);
if (!src || !out || !pw) {
  console.error('用法: node encrypt_static_page.cjs <明文html> <输出html> <密码> [标题]');
  process.exit(1);
}
const TITLE = titleArg || '文档库';

const plain = fs.readFileSync(src);            // Buffer（UTF-8 字节）
const salt = crypto.randomBytes(16);
const iv = crypto.randomBytes(12);             // AES-GCM 推荐 12 字节
const key = crypto.pbkdf2Sync(pw, salt, 120000, 32, 'sha256');
const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
const ct = Buffer.concat([cipher.update(plain), cipher.final()]);
const tag = cipher.getAuthTag();               // 16 字节
const envelope = [salt.toString('base64'), iv.toString('base64'),
                  Buffer.concat([ct, tag]).toString('base64')];

const page = `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${TITLE}</title>
<style>
  :root{--blue:#2563eb}
  *{box-sizing:border-box}
  body{margin:0;background:#f8fafc;color:#0f172a;
    font:15px/1.7 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif;
    display:flex;align-items:center;justify-content:center;min-height:100vh}
  .box{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:36px 42px;
    text-align:center;box-shadow:0 18px 50px rgba(15,23,42,.13);width:340px;max-width:90vw}
  .gl{font-size:30px;margin-bottom:8px}
  h1{font-size:19px;margin:0 0 6px}
  p{color:#64748b;font-size:13.5px;margin:0 0 18px}
  input{width:100%;padding:11px 14px;border:1px solid #e2e8f0;border-radius:10px;
    font-size:16px;text-align:center;letter-spacing:4px;outline:none;font-family:inherit}
  input:focus{border-color:var(--blue)}
  button{width:100%;margin-top:12px;padding:11px;border:none;border-radius:10px;background:var(--blue);
    color:#fff;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit}
  button:hover{background:#1d4ed8}
  button:disabled{opacity:.6;cursor:default}
  #error{color:#dc2626;font-size:12.5px;height:18px;margin-top:9px}
</style></head>
<body>
<div class="box">
  <div class="gl">🔒</div>
  <h1>${TITLE}</h1>
  <p>请输入访问密码</p>
  <form id="login"><input id="password" type="password" inputmode="numeric" autocomplete="off" placeholder="····">
  <button id="enter" type="submit">进入</button></form>
  <div id="error"></div>
</div>
<script>
const ENVELOPE=${JSON.stringify(envelope)};
const unbase64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
document.getElementById('login').addEventListener('submit',async event=>{
  event.preventDefault();
  const button=document.getElementById('enter'),input=document.getElementById('password'),error=document.getElementById('error');
  button.disabled=true;button.textContent='正在解锁…';error.textContent='';
  if(!globalThis.crypto?.subtle){error.textContent='浏览器不支持安全解锁，请使用 Chrome 或 Edge 访问 HTTPS 页面。';button.disabled=false;button.textContent='进入';return}
  try{
    const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(input.value),'PBKDF2',false,['deriveKey']);
    const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:unbase64(ENVELOPE[0]),iterations:120000,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['decrypt']);
    const decoded=await crypto.subtle.decrypt({name:'AES-GCM',iv:unbase64(ENVELOPE[1])},key,unbase64(ENVELOPE[2]));
    input.value='';
    const content=new TextDecoder().decode(decoded);
    document.open();document.write(content);document.close();
  }catch(e){error.textContent='密码错误，请重试。';input.value='';input.focus();button.disabled=false;button.textContent='进入'}
});
</script></body></html>`;

fs.writeFileSync(out, page, 'utf8');
console.log('加密完成 → ' + out);
console.log('  明文 ' + (plain.length / 1048576).toFixed(2) + ' MB → 页面 ' + (Buffer.byteLength(page) / 1048576).toFixed(2) + ' MB（base64 膨胀约 33%）');
console.log('  salt 16 ｜ iv 12 ｜ tag 16 ｜ PBKDF2-SHA256 120000 次');
console.log('⚠️ 推完必须实测「正确密码 → 内容真的出现」，别只看本脚本没报错。');
