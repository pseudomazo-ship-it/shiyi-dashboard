#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""验证某个子站/页面是否已部署到线上：仓库 blob 字节数 == 线上字节数。

用法:
  python verify_subsite_live.py <仓库路径> <仓库内相对文件> <线上URL> [--retries 10] [--wait 20]

例:
  python verify_subsite_live.py E:/RuanJian/Hermes/cache/shiyi-dashboard-git \
      skills/index.html https://shiyi11.com.cn/skills/

为什么这么比（都是实踩出来的）:
  · 本地工作区文件可能带 CRLF，比仓库 blob 多几十字节（2026-10-07 实测差 94）
    → 基准必须是 git 对象，不是磁盘上的文件。
  · GitHub Pages 返回 Cache-Control: max-age=600 → URL 必须带 ?t= 时间戳，否则验的是旧版。
  · Pages 部署要 30~120s，第一轮经常还是旧版 → 脚本自己重试，别急着重推。
  · 注意：本脚本只验「部署到位」，不验页面里的 JS 行为（密码门等要用真实浏览器验，
    且必须强制绕过缓存：cdp('Page.reload', ignoreCache=True)）。
"""
import os
import subprocess
import sys
import time
import urllib.request


def main():
    pos = [a for a in sys.argv[1:] if not a.startswith('--')]
    if len(pos) < 3:
        print(__doc__)
        return 2
    repo, rel, url = pos[0], pos[1], pos[2]
    retries, wait = 10, 20
    for i, a in enumerate(sys.argv):
        if a == '--retries' and i + 1 < len(sys.argv):
            retries = int(sys.argv[i + 1])
        if a == '--wait' and i + 1 < len(sys.argv):
            wait = int(sys.argv[i + 1])

    git = os.environ.get('GIT_EXE', 'git')
    blob = subprocess.run([git, 'show', 'HEAD:%s' % rel], cwd=repo,
                          capture_output=True).stdout
    if not blob:
        print('取不到仓库内容: %s  HEAD:%s' % (repo, rel))
        return 1
    print('仓库 blob 字节数: %d   (%s HEAD:%s)' % (len(blob), repo, rel))

    sep = '&' if '?' in url else '?'
    for i in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                '%s%st=%d' % (url, sep, int(time.time())),
                headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'})
            with urllib.request.urlopen(req, timeout=30) as r:
                body = r.read()
            if len(body) == len(blob):
                print('[%d] HTTP %s  %d bytes  OK 与仓库一致，部署到位'
                      % (i, r.status, len(body)))
                return 0
            print('[%d] HTTP %s  %d bytes  != %d'
                  % (i, r.status, len(body), len(blob)))
        except Exception as e:
            print('[%d] 拉取失败: %s' % (i, e))
        if i < retries:
            time.sleep(wait)

    print('%d 轮后仍不一致。若 push 已成功，多半只是 Pages 还在构建 —— '
          '别急着重推，过一两分钟再跑一次。' % retries)
    return 1


if __name__ == '__main__':
    sys.exit(main())
