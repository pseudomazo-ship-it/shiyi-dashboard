# -*- coding: utf-8 -*-
"""看板 HTML：公共导航的注入 / 移除，以及公共资源版本号管理

用途：
    ① 给【首页】注入 common/style.css + common/nav.js（或给存量入口页补上）
    ② 把【看板】上的导航彻底移除 —— 看板必须独立（见下）
    ③ 升版本号，防浏览器缓存
大文件（550KB+）手工改容易出错，统一用这个脚本。

用法:
    python inject_ui.py <html...>                 # 注入导航（已存在则同步版本号）
    python inject_ui.py --strip <html...>         # 移除导航+common 引用（看板独立化）
    python inject_ui.py --check <html...>         # 只检查，不改；看板应显示「独立页面」
    python inject_ui.py --bump <版本> <html...>   # 只升版本号，不改结构

⚠️⚠️ 最重要的一条：**看板必须完全独立、一个 common 引用都不加。**
    十一原话：「每个看板都会对接不同的人，他们不能看到其他的看板数据」。
    · 首页 /          → 有导航（只给需要总览的人）
    · 看板 /daily/ …  → 零 common 引用（无导航、无品牌、无别的看板入口）
    违反就是泄露：带导航的看板链接被转发出去，对方能顺着看到你还有哪些看板。
    误加了导航 → 一句 `--strip` 还原。

为什么需要版本号:
    浏览器会缓存 /common/style.css 和 /common/nav.js。改了它们之后，
    用户（包括十一自己）打开的仍是旧版 —— 看起来像「改动没生效」。
    跑一次 `--bump <新号>`，所有页面立刻拉新版。
    验证前端改动时也要绕过缓存（Page.reload ignoreCache=true），否则验的是旧版。

⚠️ 注入用【绝对路径】/common/... ——
   写成相对路径 common/... 的话，在 /daily/ 这类子目录页面下会 404（静默失败、页面不报错）。
    十一给的示例写的就是相对路径，照抄必踩。
⚠️ 自动生成的看板（daily/ finance/）整份重写 HTML，
   必须让生成器在产出后自己调一次 `--strip` 兜底，否则导航会被带回来。
⚠️ 版本号替换【只匹配 href/src 属性】，不会误伤正文/页脚里写的路径文案。
⚠️ style.css 的 `padding-top: 64px` 必须挂在 `body.has-nav` 上，不能写在 `body` 上
   —— 否则独立看板会凭空多出 64px 顶白（不引导航却留着导航的留白）。
"""
import sys
import os
import re
import io

VER = '1'   # 改了 common/ 下的资源就 +1（或用 --bump 指定）

CSS_HREF = '/common/style.css'
JS_SRC = '/common/nav.js'

MARK_CSS = '/common/style.css'
MARK_JS = '/common/nav.js'
MARK_NAV = 'id="app-nav"'

RE_HEAD = re.compile(r'</head>', re.I)
RE_BODY = re.compile(r'<body[^>]*>', re.I)

# ⚠️ 只匹配 href="..." / src="..." 属性里的 /common 路径，正文文案不动
RE_VER = re.compile(
    r'((?:href|src)\s*=\s*["\'])(/common/(?:style\.css|nav\.js))(\?v=[^"\']*)?'
)

# --strip 用：整块移除（含前面缩进的空白，避免留空行）
RE_NAV_DIV = re.compile(r'\s*<div\s+id="app-nav"\s*>\s*</div>[ \t]*\n?', re.I)
RE_NAV_SCRIPT = re.compile(
    r'\s*<script[^>]*src="/common/nav\.js[^"]*"[^>]*>\s*</script>[ \t]*\n?', re.I)
RE_CSS_LINK = re.compile(
    r'\s*<link[^>]*href="/common/style\.css[^"]*"[^>]*>[ \t]*\n?', re.I)


def css_tag(ver=VER):
    return '<link rel="stylesheet" href="%s?v=%s">' % (CSS_HREF, ver)


def nav_block(ver=VER):
    return ('<div id="app-nav"></div>\n'
            '<script src="%s?v=%s"></script>' % (JS_SRC, ver))


def bump_versions(html, ver):
    """把 href/src 属性里已有的 ?v= 全改成新版本；没带版本号的补上。
    返回 (新html, 处理处数)。"""
    n = [0]

    def rep(m):
        n[0] += 1
        return '%s%s?v=%s' % (m.group(1), m.group(2), ver)

    return RE_VER.sub(rep, html), n[0]


def is_independent(html):
    """看板是否已经独立（无导航容器 / 无 common 引用）"""
    return (MARK_NAV not in html) and (MARK_CSS not in html) and (MARK_JS not in html)


def inject(html, ver=VER):
    """返回 (新html, 改动说明列表)"""
    notes = []

    # ① 注入 CSS（放 </head> 前）
    if MARK_CSS in html:
        notes.append('CSS  已存在')
    else:
        m = RE_HEAD.search(html)
        if m:
            html = html[:m.start()] + css_tag(ver) + '\n' + html[m.start():]
            notes.append('CSS  已注入')
        else:
            notes.append('!! 没找到 </head>，CSS 未注入')

    # ② 注入导航占位（放 <body> 后）
    if MARK_NAV in html:
        notes.append('导航 已存在')
    else:
        m = RE_BODY.search(html)
        if m:
            i = m.end()
            html = html[:i] + '\n' + nav_block(ver) + '\n' + html[i:]
            notes.append('导航 已注入')
        else:
            notes.append('!! 没找到 <body>，导航未注入')

    # ③ 统一版本号
    html, cnt = bump_versions(html, ver)
    notes.append('版本号 -> v%s (%d 处)' % (ver, cnt))

    return html, notes


def strip(html):
    """移除导航容器 / nav.js / style.css 引用，让看板彻底独立。
    返回 (新html, 改动说明列表)。"""
    notes = []
    total = 0
    for rx, name in ((RE_NAV_DIV, '导航容器'),
                     (RE_NAV_SCRIPT, 'nav.js 引用'),
                     (RE_CSS_LINK, 'style.css 引用')):
        html, k = rx.subn('\n', html)
        total += k
        if k:
            notes.append('%s 已移除 (%d)' % (name, k))
    html = re.sub(r'\n{3,}', '\n\n', html)   # 别留一排空行
    if total == 0:
        notes.append('本来就无导航/公共引用，无需处理')
    notes.append('合计移除 %d 项' % total)
    return html, notes


def main():
    args = sys.argv[1:]
    mode = 'inject'
    ver = VER

    if args and args[0] == '--check':
        mode = 'check'
        args = args[1:]
    elif args and args[0] == '--strip':
        mode = 'strip'
        args = args[1:]
    elif args and args[0] == '--bump':
        mode = 'bump'
        args = args[1:]
        if not args:
            print('用法: inject_ui.py --bump <版本> <html...>')
            return 1
        ver = args[0]
        args = args[1:]

    if not args:
        print('用法: python inject_ui.py [--check | --strip | --bump <版本>] <html...>')
        return 1

    rc = 0
    for path in args:
        if not os.path.isfile(path):
            print('X 不存在: %s' % path)
            rc = 1
            continue
        with io.open(path, 'r', encoding='utf-8', errors='replace') as f:
            html = f.read()
        before = html

        if mode == 'bump':
            new, cnt = bump_versions(html, ver)
            notes = ['版本号 -> v%s (%d 处)' % (ver, cnt)]
        elif mode == 'strip':
            new, notes = strip(html)
        elif mode == 'check':
            new = html
            notes = ['独立页面 OK（零 common 引用）' if is_independent(html)
                     else '含导航/公共引用 -- 看板的话要 --strip 掉']
        else:
            new, notes = inject(html, ver)

        title = ''
        mt = re.search(r'<title>([^<]*)</title>', html, re.I)
        if mt:
            title = mt.group(1).strip()[:50]

        label = {'inject': '注入', 'check': '检查', 'bump': '升版本', 'strip': '移除'}[mode]
        print('-- %s: %s' % (label, path))
        print('   title: %s' % title)
        for n in notes:
            print('   * %s' % n)
        if any(n.startswith('!!') for n in notes):
            rc = 1

        if mode == 'check':
            print('   (未修改)')
        elif new != before:
            with io.open(path, 'w', encoding='utf-8', newline='') as f:
                f.write(new)
            print('   OK 已写回')
        else:
            print('   o 无变化')
        print('')

    return rc


if __name__ == '__main__':
    sys.exit(main())
