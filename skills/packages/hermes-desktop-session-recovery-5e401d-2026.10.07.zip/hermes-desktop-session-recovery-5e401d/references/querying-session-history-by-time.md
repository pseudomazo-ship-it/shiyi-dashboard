# Querying session history by date (cross-window recall)

Use when the user asks what changed **on a specific date** rather than
"find the session about X" — e.g. 「今天改了哪几个？」「昨天 X 改了吗？」.

## Why `session_search` is not enough

`session_search` is FTS5 relevance with a `sort` bias (`newest` / `oldest`).
It has **no date filter**, so it cannot answer "everything touched today".
It is also biased toward the current conversation.

This matters more than usual for this user: he runs **several windows at
once** (main + h-2…h-5). The work being asked about frequently happened in a
*different* window, and the asking window has no memory of it.

## The query

Query the message store directly, bounded by timestamp.

```python
import sqlite3, datetime

CN  = datetime.timezone(datetime.timedelta(hours=8))
DB  = r"E:\RuanJian\Hermes\state.db"          # = $HERMES_HOME/state.db
KW  = "触发器"                                  # the topic keyword

now  = datetime.datetime.now(CN)
ts0  = int(now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp())

con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)   # READ-ONLY
cur = con.cursor()

rows = cur.execute("""
    SELECT id, session_id, role, substr(content,1,200), timestamp
    FROM messages
    WHERE timestamp >= ? AND content LIKE ?
    ORDER BY timestamp
""", (ts0, f"%{KW}%")).fetchall()

for mid, sid, role, snippet, ts in rows:
    t = datetime.datetime.fromtimestamp(ts, CN).strftime("%H:%M")
    print(f"[{t}] {role:9} {sid}  #{mid}")
    print(f"       {snippet}")
con.close()
```

## Column reference

`messages` columns that matter here (the table has ~24; these are the ones you want):

| Column | Notes |
|---|---|
| `id` | integer PK — feed to `session_search(around_message_id=...)` |
| `session_id` | **which window** the hit came from |
| `role` | `user` / `assistant` / `tool` |
| `content` | message body |
| `timestamp` | **unix seconds** — convert with `datetime.fromtimestamp(ts, CN)` |
| `tool_name` | populated on `role='tool'` rows |

## Practical rules

- **Always open read-only**: `sqlite3.connect(f"file:{DB}?mode=ro", uri=True)`.
  This is the live store — never take a write lock on it.
- **`substr(content,1,200)` in the SELECT**, not in Python. It keeps a
  thousands-of-rows scan cheap. Widen the slice only for hits you care about.
- **Filter by role to cut noise**:
  - `role='user'` → the raw instruction (what was actually asked)
  - `role='assistant'` → conclusions and summary tables ← usually the answer
  - `role='tool'` → raw API/command output
- **Search a second keyword.** The term the user uses may not be the term in
  the record. In the 2026-09-25 探域 case, `'触发器'` alone missed context that
  `'探域'` surfaced (and vice-versa) — run both and merge.
- **The answer is usually the assistant message right after the tool calls.**
  Once you have a hit id, either pull the neighbouring rows with the same
  query, or use `session_search(session_id=..., around_message_id=<id>)` to get
  the hydrated window.
- **Report the window.** For this user, naming the `session_id` answers the
  unspoken half of the question — 「谁改的」.

## Worked example (2026-09-25)

十一 asked: 「探域机器人 触发器，今天改了哪几个？」

1. `session_search(query='探域 触发器')` → surfaced the *topic* but the top hits
   were old sessions; nothing pinned to today.
2. Direct time-bounded query above → **32 hits**, all from
   `20260830_212544_6149cd`, clustered 08:15–08:43 — i.e. a **different window**,
   earlier the same morning. (`20260830_224937_35fb9e17` matched `'触发器'`
   only incidentally — the scan makes that obvious instead of hiding it.)
3. Reading the two `role='assistant'` summary rows there gave the full answer:
   a table of the 5 changed triggers, plus the field-level 原值 → 改为 detail
   and one open question the earlier session had left unresolved.

Without the date bound, step 1 alone would have answered "有触发器这回事" —
not "今天改了哪几个".

## Scope note

This is a **read** technique. It does not mutate the store, and it is not a
substitute for `session_search` — use FTS for relevance discovery, this for
time-bounded sweeps. Combine them: sweep by date, then hydrate by id.
