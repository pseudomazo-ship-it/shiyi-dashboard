# Return-to-Chat Plugin (verified working)

Problem class: user reports the Hermes desktop chat window "keeps disappearing"
("聊天窗口老是不见"). Root cause: a **full-page route** (e.g. the 配置档案 / profile
editor, 产物, 定时任务) rendered into the workspace pane covers the chat view.
This is NOT a layout-preset problem — `apply_layout(default)`/`focus_pane('chat')`
do NOT clear a route; they only arrange panes.

Best fix: a desktop plugin that gives the user a one-click "return to chat"
control. The app has **no built-in global keyboard shortcut** that switches
layout or forces the chat route, so a plugin is the only reliable path.

## Authoring checklist

- Location: `$HERMES_HOME/desktop-plugins/<id>/plugin.js` — the folder name MUST
  equal the plugin `id`. (On this box `$HERMES_HOME=E:\软件\Hermes`.)
- Hot-reload: the app watches `desktop-plugins/`; the plugin loads within a few
  seconds of the file landing, no restart. Fallback: ⌘K → **Reload desktop
  plugins**.
- Imports allowed (ALL from `@hermes/plugin-sdk` or `react/jsx-runtime`): `cn`,
  `host`, `Tip`, `usePluginI18n`, `useValue`; `jsx`/`jsxs`. Use `jsx(...)` calls,
  NOT JSX syntax — the file is loaded uncompiled.
- Chip: `ctx.register({ id, area: 'statusBar.right', order, render })`.
  Register a `PALETTE_AREA` command for the keyboard path (⌘K command center).
- To actually go back to chat: `host.navigate('/')`.
- **Never hardcode colors**; style with theme vars
  (`text-(--ui-text-tertiary)`, `hover:bg-(--chrome-action-hover)`, `hover:text-foreground`)
  and the `cn(...)` helper.

## Verified plugin.js (show-chat)

```js
import { cn, host, Tip, usePluginI18n } from '@hermes/plugin-sdk'
import { jsx } from 'react/jsx-runtime'

const ID = 'show-chat'  // folder name must match

function backToChat() {
  host.navigate('/')
}

function ShowChatChip() {
  const t = usePluginI18n(ID)
  return jsx(Tip, {
    label: t('chipTip'),
    children: jsx('button', {
      className: cn(
        'inline-flex h-full items-center gap-1 px-1.5 text-[0.6875rem] transition-colors',
        'text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover) hover:text-foreground'
      ),
      type: 'button',
      onClick: () => backToChat(),
      children: t('chip')
    })
  })
}

export default {
  id: ID,
  name: '回到全部显示',
  register(ctx) {
    ctx.i18n.register({
      en: { chip: '全部显示', chipTip: '回到 聊天 + 全部面板 视图', commandTitle: '回到全部显示(聊天视图)' },
      zh: { chip: '全部显示', chipTip: '回到 聊天 + 全部面板 视图', commandTitle: '回到全部显示(聊天视图)' }
    })
    ctx.register({
      id: 'chip',
      area: 'statusBar.right',
      order: 150,
      render: () => jsx(ShowChatChip, {})
    })
    ctx.register({
      id: 'command',
      area: 'PALETTE_AREA',
      title: '回到全部显示(聊天视图)',
      run: () => backToChat()
    })
  }
}
```

This exact file was saved to `E:\软件\Hermes\desktop-plugins\show-chat\plugin.js`
and confirmed loaded (a `Button '全部显示'` appeared at the bottom status bar,
beside the native `v0.20.6 <branch>` item).

## Verify the plugin actually loaded (do NOT trust the file write)

A successful `write_file` does not prove the plugin is running. Confirm against a
**runtime element**, not your own conversation text:

1. `computer_use action='capture'` (mode `som`) on the Hermes window.
2. The capture result prints a path to a saved elements JSON
   (`cache/computer_use/elements_*.json`) — grep that file for the chip label
   (`全部显示`) / new command title. If there is a `Button` with that label at a
   bottom status-bar y-coordinate (near the window bottom, y≈1002 on this box),
   the chip is live.
3. Why grep the JSON, not the screenshot text: the conversation transcript
   repeats the plugin source, so searching your own message stream will always
   "match." The elements tree only contains what actually rendered in the app.

## Related facts (v0.20.6, verified in the bundle)

- Active layout preset state is persisted in the renderer's `localStorage` key
  `hermes.desktop.layoutPreset.active` (default `default`); the preset registry
  lives under `hermes.desktop.layoutPresets.v2`.
- The `apply_layout` tool emits a `layout.apply` bridge event; the renderer
  resolves the preset id against its layouts registry (core + plugin + user
  presets are one list).
- `KEYBINDS_AREA` exists for registering rebindable actions, but there is **no
  built-in global keybind for layout switching** in this version — the ⌘K
  `PALETTE_AREA` command is the keyboard path to use.
