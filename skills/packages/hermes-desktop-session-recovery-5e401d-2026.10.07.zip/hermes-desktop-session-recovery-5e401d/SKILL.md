---
name: hermes-desktop-session-recovery
description: "Use when a Hermes chat is missing, hidden, keeps disappearing, or needs a project group."
version: 1.1.0
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Sessions, Desktop, Projects, Recovery, Productivity]
    category: productivity
    related_skills: [session-librarian, hermes-agent]
---

# Hermes Desktop: Session Recovery & Project Groups

Recover conversations that a user reports as "gone" / "entry missing" from the
Hermes desktop app, and group sessions into project workspaces. The bar is:
**almost always a visibility problem, never data loss** — confirm before
grabbing anything as lost.

## When to Use

- "Why can't I find that conversation / the chat entry is gone / where did it go?"
- "This window doesn't show my sessions about X."
- "Group these into a project / make a project group."
- "Switch me back to my other workspace."

## Root Cause (the one-line answer)

**The desktop left sidebar groups sessions by project/workspace.** A session
opened under project A is NOT listed in a window anchored to project B — even
though it is still in the DB. So "the entry is missing" usually means "it
belongs to a different project group than the one this window is showing." The
session is never deleted by this.

**A second, distinct root cause — the chat WINDOW is there but covered.** If
the user says "聊天窗口老是不见 / the chat pane keeps disappearing / I can't see
the conversation anymore" (as opposed to "a specific session's entry is
missing"), the cause is usually a **full-page route that took over the
workspace pane** — e.g. the 配置档案/profile editor, 产物, 定时任务, or any page
rendered into the main (workspace) pane. That page replaces the chat view, so
the transcript looks "gone." It is NOT a layout-preset problem and NOT data
loss.

**Critical trap — `apply_layout` does NOT fix this.** Layout presets
(`default` / `focus` / `terminal-deck` / `quad`) only change which *panes* are
shown and their arrangement. They are unaware of *route* takeover: if 配置档案
is the active route, applying `default` still leaves that route covering the
workspace pane. Diagnose BEFORE reaching for `apply_layout`: if the chat is
"missing," first distinguish **(a) session entry absent from the sidebar** →
session search / project group (below), versus **(b) workspace pane showing a
non-chat page** → route problem, fix is `host.navigate('/')` (see the pane/
route recovery section below).

## Chat Pane Covered by a Route (chat window "keeps disappearing")

Use when the user reports the chat window being hidden/covered (often replayed
as "老是/老是老是不见"), not a specific missing entry.

1. **Confirm it's a route, not a layout.** `computer_use action='capture'`
   and look at the workspace pane: if it renders a chrome-less full-page editor
   (配置档案 + an editable box, 产物, a form), it's a route takeover.
2. **Best fix: give the user a one-click "return to chat" control** via a
   desktop plugin. The app has **no built-in global keyboard shortcut** that
   switches layout or forces the chat route back. Ship
   `$HERMES_HOME/desktop-plugins/<id>/plugin.js` that calls `host.navigate('/')`
   from a statusBar-right chip and a `PALETTE_AREA` ⌘K command. Reusable
   recipe + full verified `plugin.js` in
   [`references/return-to-chat-plugin.md`](references/return-to-chat-plugin.md).
   Hot-reload: file lands → app loads it in a few seconds (no restart); fallback
   ⌘K → **Reload desktop plugins**.
3. **Ad-hoc recovery** (no plugin): `focus_pane('chat')` re-focuses the chat
   pane, and `apply_layout(default)` restores the standard pane grouping — but
   only after the route is cleared. For a quick, manual return, tell the user
   to click the session in the sidebar or the "打开 主页 / 打开 <会话>"
   button.

## Verify a desktop plugin actually loaded (don't trust "I wrote it")

A written `plugin.js` is NOT proven by a successful file write. Confirm it is
live in the app:
- `computer_use action='capture'` (mode `som`), then grep the saved elements
  JSON (path shown in the capture output) for the chip label / new button text.
  If it appears as a `Button` near the bottom status bar, it's loaded. (Nearest
  neighbor `v0.20.6 <branch>` is a native statusbar item — the new chip landing
  beside it is a good sign.)
- A `PALETTE_AREA` command shows up in the ⌘K command center.
- Do NOT confirm "loaded" from your own conversation text — the transcript
  repeats the plugin source, which matches any string you grep. Match against a
  **runtime element** the plugin renders, at its real bounds.

## Recover a "Disappeared" Session (in order)

1. **`session_search(query=<topic>, limit=5)`** — finds the session regardless
   of which project it lives in (search covers the whole message store, not
the current project). Hand back the verbatim `@session:<profile>/<id>` link
   from the result so the user can jump straight in.
2. **Sidebar search box** — the "搜索会话" field above the session list
   (selector `input[aria-label="搜索会话"]`) searches across projects, not
   just the current view. Tell the user to type a keyword there and press
   Enter.
3. **Point at it in the GUI** — `tour(action='targets', surface='app')` to
discover the selector (it is stable), then
`tip(selector="input[aria-label=\"搜索会话\"]", text="<instruction>")` to
put an arrow on the box. Prefer the tip route over prose when the user says
"point to it."

## Time-scoped recall: 「今天改了哪几个 X？」

A related-but-distinct job: the user asks what changed **on a date**, not
"find the session about X". `session_search` has **no date filter**, and this
user runs several windows at once, so the work often happened in a window that
knows nothing about the question being asked.

→ Full recipe (SQL, column reference, worked example):
[`references/querying-session-history-by-time.md`](references/querying-session-history-by-time.md)

Short version: open `$HERMES_HOME/state.db` **read-only**, select from
`messages` where `timestamp >= <midnight unix>` and `content LIKE '%kw%'`,
`ORDER BY timestamp`. `messages.timestamp` is **unix seconds**; `session_id`
tells you **which window** the hit came from (report it — it answers the
unspoken 「谁改的」). Read the `role='assistant'` row that follows the tool
calls; that's usually the answer table.

## Project Groups (desktop_project)

- `desktop_project list` — shows existing projects and which is **active**.
  Use this FIRST to understand the current grouping before changing anything.
- `desktop_project create name=... path=<folder>` — makes a project AND
  **switches the current chat into it**, anchoring the session's working
directory to that folder. The sidebar then shows a new group for it.
- `desktop_project switch name|slug|id` — move the current chat to an existing
  project (the intentional way to return to a workspace, not `cd`).

Confirm the anchor folder exists before creating (the current working dir may
differ from the target project's folder); `desktop_project create` does not
validate the path for you.

## Pitfalls

- **A historical session cannot be auto-moved between projects.** It stays in
the project it was created under. To make an old conversation live in a
project's sidebar, branch it there: open a new session in that project and
continue it (or fork the old one), then tell the user the branch now belongs
to that project group.
- **Creating a project switches the current chat into it.** If the user is
working in one workspace and you create a project for a different topic, the
current window now lives in the new project — say so explicitly, and offer
`desktop_project switch` back if they didn't intend to leave.
- **Don't trust the visible list as evidence of absence.** A target "not
present in the DOM" can still be one scroll/filter/expand away; search before
concluding it's really missing.
- **GUI search-box selector can go stale across app versions; re-run
`tour('targets')` if the tip selector stops matching.**
- **Route vs layout confusion is the top time-waster.** If you're reaching for
  `apply_layout` on a "chat disappeared" report, stop and check what's actually
  on the workspace pane first (see the route section above).
- **Match the fix to the right root cause of the two.** Don't `apply_layout`
  for a route problem; don't `session_search` for a pane/route problem.

## Verification

After helping the user, re-run `session_search` on the same topic and confirm
the session returns with its link; if they chose a project group, confirm
`desktop_project list` shows it (and is active if that was the intent).
