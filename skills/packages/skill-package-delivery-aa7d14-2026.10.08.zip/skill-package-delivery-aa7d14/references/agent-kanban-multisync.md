# 多 Agent 共用的技能看板（syncing into someone else's kanban）

2026-10-07 实战。十一给了一份 8 节规格，要求「自查你当前环境的全部技能，整理安装包，
并同步到现有网页看板」，适用范围是 **WorkBuddy / Claude / Codex / Hermes 及以后新增的桌面 Agent**。

⚠️ 这份和 `SKILL.md` 里那个「Hermes 单机版清单页」**不是同一个东西**，路径、数据文件、生成器都不同。

## 1. 位置与归属（别写错地方）

```
D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\
├─ skills.html       ← 看板（单文件、纯本地、双击可开）
├─ skills_data.json  ← 数据（HTML 内联同一份）
└─ packages\         ← 所有 Agent 的安装包混在一起
```

- 这是 **Codex 的工作区**。十一**点名**授权写入 → 可以写，但必须遵守
  「多 Agent 不得同时覆盖同一文件；写入前重新读取最新版，合并别人新增的技能」。
- **同步 = 只更新本地网页 + 安装包。未经授权不发布网站、不改域名配置。**
- 现有条目按 `agent` 字段区分（本次实测：Codex 58 + WorkBuddy 119 + Hermes 177 = 354）。

### 别人的生成脚本会冲掉你的数据

`build_catalog.py`（Codex 侧生成器）原本的逻辑是：
扫自己的目录 → `html.replace(const skills=[...], 自己的数据)` → **整体替换**。
它跑一次，WorkBuddy + Hermes 的条目全没。

**改法（规则明确要求「如果有生成脚本，同步修改生成逻辑」）**：
```python
# 只从本 Agent 的历史条目继承描述，避免同名技能串文案
previous = {e['name']: e for e in existing if e.get('agent') == 'Codex'}
...
# 合并保护：保留其他 Agent 的条目
mine = {e['name'] for e in data}
others = [e for e in existing
          if e.get('agent') not in (None, 'Codex') and e.get('name') not in mine]
data = data + others
for i, e in enumerate(data):     # ID 全局唯一
    e['id'] = 'skill-' + str(i)
```

## 2. 包命名规则（必须和现有一致）

```
{slug}-{sha256(name)[:6]}-{YYYY.MM.DD}.zip
slug = re.sub(r'[^a-zA-Z0-9_-]', '-', name).strip('-')[:65]
```
实测与现有包 100% 吻合（`anthropic-frontend-design-f5b49d-2026.10.07.zip` 等）。
迁移前**先拿 3 个现有包名反推验证规则**，别自己发明命名。

## 3. 五个必踩的坑（每个都真的踩了）

### ① 同名包会被你没经意覆盖 —— 破坏别人成果

同名技能（`pdf` / `xlsx` / `humanizer` / `github` / `cocoloop` / `ima-skill` /
`stylekit` / `zhongkui-skill` / `agent-browser` / `self-improvement` /
`anthropic-frontend-design` / `computer-use`）在不同 Agent 下**内容差异很大**
（例：`github` 别人 375 B、我这版 35 KB；`xlsx` 别人 158 KB、我这版 31 KB）。
按同名规则打包 → **直接覆盖了别人 12 个包**。

**正确做法**：
1. 自己的同名版本包名加后缀（本次用 `-h`），让出原文件名；
2. 从各 Agent 的**源技能目录**重新打包、填回原包名（源路径写在条目的 `source_note` 里）；
3. 用**现有包大小反推**源目录选对没（本次 10/12 大小与原版完全一致 = 选对了；
   另外 2 个差异是源目录版本不同，要在报告里如实标注）；
4. 同名但内容不同的，**分别展示、在 `notes` 里说明**，不强行合并（规格明写这条）。

### ② `re.sub` 的替换串会把 `\n` 还原成真换行 —— JSON 被写坏

```python
# ❌ 翻车写法：replacement 里的 \n 被当转义处理
src = re.sub(r'const skills=\[.*?\];\n', 'const skills=' + inline + ';\n', src, flags=re.S)
# → 内联 JSON 里的所有 \n 变成真实换行 → json.loads 报 "Invalid control character"，
#   JS 字符串字面量被截断 → 页面整个白屏/报错

# ✅ 用 lambda
src = re.sub(r'const skills=\[.*?\];\n', lambda m: 'const skills=' + inline + ';\n', src, count=1, flags=re.S)
```
`str.replace()` 没有这个问题，只有 `re.sub` 有。**写完必跑一次 `json.loads(内联数据)` 自检。**

### ③ ID 重复 → 点 A 卡、详情显示 B

新条目若从 `skill-0` 开始编号，会和原有条目**撞号**；页面用
`skills.find(s => s.id === selected)` 取值 → 永远命中先出现的那条旧条目。
症状极其迷惑：**卡片标题是对的，详情面板却是另一个技能**（我一度怀疑是 DOM 顺序、
缓存、点击没生效，绕了好几轮）。

**改法**：合并后统一重编号 + 断言唯一：
```python
for i, e in enumerate(merged): e['id'] = f'skill-{i}'
assert len({e['id'] for e in merged}) == len(merged)
```
**排查口诀：出现「点 A 显示 B」先查 `id` 是否唯一，别先怀疑前端。**

### ④ `sha256` / `package_size` 会过期

包被重新打包过（哪怕只是重打一次、字节数相同）→ zip 的 mtime 变了 → hash 变。
本次 12 条「大小相同、hash 不同」。
**做法**：合并最后一步统一**以磁盘实际文件为准**重算所有条目的 `package_size` + `sha256`，
并同步替换 `install_command` 里内嵌的那个 SHA 值：
```python
e['install_command'] = re.sub(r'核对 SHA-256：[0-9a-f]{64}', '核对 SHA-256：' + sha, e['install_command'])
```

### ⑤ 小写：备份目录会被当成技能收进来

`ima-skill.bak_1.1.8/`（以及 `.archive/`）里的 `SKILL.md` 会被扫到。
本次实测**跳过**存档 1 个 + 备份 2 个 + 重复目录 1 个 → 181 扫到 / 177 打包。
跳过规则要写进打包脚本，并在报告里点明跳了哪些、为什么。

**后续（2026-10-07 十一要求「名称有歧的修改一下」）**：`ima-skill.bak_1.1.8` 已移出
技能加载目录 → `D:\Agent.GongZuoQu\Hermes.GZQ\软件--技能旧版备份\ima-skill.bak_1.1.8\`
（含 `_为什么在这里.md` 记录原路径与恢复方法）。

> **坑的本质**：旧版备份目录里的 `SKILL.md` 仍写着 `name: ima-skill`，
> 而**技能名取自 frontmatter、不是目录名** → 只改文件夹名无效，必须移出加载目录
> 或改 frontmatter 的 name。症状是 `skill_view('ima-skill')` 报
> 「Ambiguous skill name: 2 skills match」。移出后再扫是 179 / 打包 177。

## 4. 页面结构（改之前先摸清，别重做页面）

`skills.html` 是单文件、内联数据，关键锚点：

| 锚点 | 内容 |
|---|---|
| `<line>const skills=[...];` | 内联数据（唯一权威副本在 `skills_data.json`） |
| `function sceneInfo(s){const lookup={...};const templates={...}` | **按技能名的场景口令查表** → `["场景口令", "😀"]`，缺省 `["整理资料 · 辅助工作","📝"]` |
| `function compatibility(s){const exclusive={...};return exclusive[s.name]||null}` | 按技能名的 **Agent 专用**标签表 |
| 分类按钮 | 由 `['', ...new Set(skills.map(s=>s.category))]` **自动生成** |
| `function render()` | 卡片渲染 + 过滤（`s.category===$('category').value`） |
| `function showDetail()` | 详情面板 |

**给新技能加场景口令/图标 → 往 `lookup` 里插键值对**，锚 `};const templates={`（唯一）。
**分类是自动生成的** → 新增分类只要给条目 `category` 赋值就会自动出按钮。

### 「11. 十一独创」独立分类的落地方式（2026-10-07 十一追加要求）

要求：**用户独创技能单独加橙色醒目「11.」标签，并单独做一个分类。**

- 条目加字段 `original: true`（**分类仍保留功能分类，不要拿功能分类去换**）；
- 分类按钮列表前插一个哨兵项 `['__original__','11. 十一独创']`，按钮加 class `origin-button`；
- **过滤条件必须同时改**，否则点进去是空的：
  ```js
  (!$('category').value || ($('category').value==='__original__' ? s.original : s.category===$('category').value))
  ```
- 样式（橙色 `#FF6A00`）：`.origin-badge`（卡片上的「11.」）/ `.origin-button` / `.origin-button.active` / `.origin-note`（详情页「11. 十一独创技能」）。
- ⚠️ **原创归属必须由十一确认**（规格原话：「不能把安装、改名或简单修改当作原创」）。
  做法：**按业务规则归属列出候选清单交给十一核**，报告里写明「按我判断标的，不算你确认」。

### Agent 专用标签

只标**明确只能某 Agent 用**的（如 `hermes-config-and-moa` / `hermes-cron-script-jobs` → `Hermes专用`）。
工具依赖、运行依赖、插件依赖、跨 Agent 协作 **≠ 单 Agent 专用**，写进 `notes` 而不是打标签。
macOS-only 的技能（`apple-*` / `findmy` / `imessage`）也走 `notes` 说明，不打 Agent 标签。
兼容性没验证过的**不得判定「其他 Agent 不能用」**，也不得承诺全通用。

## 5. 验收配方（规格第八节要求「分别报告验证范围」）

### 静态
```python
inline = json.loads(re.search(r'const skills=(\[.*?\]);\n', src, re.S).group(1))
assert json.dumps(inline, sort_keys=True) == json.dumps(disk, sort_keys=True)   # 内联 == JSON 文件
assert len({e['id'] for e in disk}) == len(disk)                                 # ID 唯一
# 每个包存在 且 size/sha 与记录一致
```

### 运行时（必须真开浏览器，链接能开 ≠ 功能可用）
```bash
cd "<kanban dir>" && python -m http.server 8912 --bind 127.0.0.1
```
- **⚠️ 自动化点击会被「防误触」逻辑吃掉**：卡片 `onclick` 第一行是
  `if(window.getSelection()?.toString().trim())return;`（这是十一明确要求的：选中文字不切卡片）。
  所以脚本点击前必须在**同一个 js 表达式里**先 `window.getSelection().removeAllRanges();`，
  否则表现是「点了没反应 / 详情还是上一条」——**这是设计行为，不是 bug，别去改页面**。
- **判「点击是否真的生效」要比对卡片名与详情标题**：
  `card.querySelector('h3').textContent` vs `.detail-frozen h2`，相等才算过。
- **移动端**：`cdp('Emulation.setDeviceMetricsOverride', width=390, height=844, deviceScaleFactor=3, mobile=True)`；
  详情是全屏浮层，且是 `location.hash` 变化后**异步**才加 `mobile-open` 类 → 断言前要 `await`。
- **真实下载**：起 http 服务后 `fetch(package_url)` 比对 `byteLength` 与条目 `package_size`
  （本次抽 3 个包全部 200 + 字节数一致）。**只检查「链接非空 + 文件存在」不算下载验证。**
- **`file://` 单独验一次**（十一要「双击即可打开」）；本机中文路径可用 URL 编码访问。
- 收尾**关掉 http 服务**（十一会留意后台残留进程）。

## 6. 交付报告口径（规格第八节第 7 条）
必须给：**扫描数量 / 去重后数量 / 新增·更新数量 / 安装包数量 / 清理项及恢复位置 / 未验证项**。
未验证项要如实（本次：未做安全审计、未做跨 Agent 真实安装、
复制按钮在自动化环境被拒剪贴板权限走了手动兜底、移动端是模拟非真机）。

**清理/覆盖前一定先备份到技能加载目录之外并记录恢复方法**（本次：
`…\Hermes.GZQ\数据--技能看板\_backup_2026.10.07\skills.html.bak` + `skills_data.json.bak`，
报告里写明「按原名盖回即还原」）。

## 7. 相关脚本（本次产物，留作下次复用）

都在 `D:\Agent.GongZuoQu\Hermes.GZQ\数据--技能看板\`：
- `pack_hermes.py` — 扫盘 + 打包（排除缓存/敏感命名/含凭据特征的文件）
- `fix_overlap.py` — 同名包：自己改名 `-h` + 从源目录恢复别人的
- `desc_1~5_*.py` — 177 条中文简介 + 场景口令字典（按类分批写，别指望自动翻译）
- `merge_kanban.py` — 合并进 `skills_data.json` + 改 HTML（内联数据/查表/11. 独创/样式）
- `ima_upload_record.cjs` / `ima_link_record.cjs` — 把同步记录写入 IMA
</br>
**注意**：`desc_*.py` 那一步是本任务最慢的环节（177 个技能要中文简介 + 场景口令，
其中 114 个原描述是纯英文）。要**分批写字典文件**，不要试图一次写完。

## 8. 本地包 → 不显示安装口令（2026-10-07 十一指示「做实事求是」）

看板上的包**全部是本地相对路径**（`packages/xxx.zip`），看板目录没有 git、也没发布，
域名下 `/skills/`、`/packages/` 都是 404。**口令里那条相对路径在任何其他电脑/Agent 上都解析不到**，
`cocoloop` 也装不了本地相对路径 → 整段口令是空头支票。

**十一的原话：「既然是本地技能包，没有口令，就不需要口令内容。做实事求是。」**

已做的改动（`skills.html`）：
1. 详情页删掉 `<button id="copy">复制安装口令</button>`；
2. 删掉整个 `<section><h3>通用安装口令 · Cocoloop</h3><code>…` 段落；
3. 删掉 `$('copy').onclick=…` 绑定；
4. 删掉已无人调用的 `function installPrompt(s){…}` 本体（约 364 字符）；
5. 「安装包」区块改成说实话：
   > 本机本地包，没有公网下载地址，也没有可复制的安装口令。
   > 给其他 Agent 或另一台电脑安装时，把这个 ZIP 一并发过去即可。
6. **保留**「场景口令」（`讲人话 · 去AI味` 那种）—— 那是给十一认用途的，不是安装口令。

⚠️ **`install_command` 已彻底清除（2026-10-07 十一说「清」）**：
- `skills_data.json` 352 条字段全删，**699 KB → 411 KB**；
- `build_catalog.py` 删掉 `command = f"…"`、`install_command=command,`、`entry['install_command'] = f"…"` 三处，**不再重新生成**；
- 本任务自己的 `merge_kanban.py` 同步删掉 `cmd = (…)` 整块 + 字段 + SHA 回填那行；
- 全仓复扫：**无任何文件再含 `install_command`**。
- `skills.html`（440 KB）内联数据与 JSON 一致，页面上「安装口令」相关零残留。

### 顺带修掉的页面 bug

`showDetail()` 里「来源」的兜底分支写成了**单引号字符串**，导致 `${...}` 被当字面量渲染：

```js
// ❌ 页面直接显示 ${escapeHTML(s.source_note)}。上游官方来源未核实…
${source?`<a …>${escapeHTML(source)} ↗</a>`:'<p>${escapeHTML(s.source_note)}。上游…</p>'}
// ✅ 换成反引号
${source?`<a …>${escapeHTML(source)} ↗</a>`: `<p>${escapeHTML(s.source_note)}。上游…</p>`}
```

> **口诀**：模板里只要要插值，就用反引号；**单引号里的 `${}` 是死的**。

## 9. ⚠️ 多窗口并发写同一个看板 —— 实测被覆盖两次

2026-10-07 这一天里，**十一同时在多个窗口下同一批指令**，同一个 `skills.html` /
`skills_data.json` 被反复覆盖，实测两次事故：

1. **卡片版本号 / 简介行数**：我准备改时发现**已经被另一个窗口改好了**
   （`.card .version{display:none}` + `.card .description{-webkit-line-clamp:4}`）→ 差点重复劳动。
2. **175 条详细简介被整个覆盖**：我用 `detail_A/B/C_*.py` 写完并校验通过，
   17:42 另一个窗口写入 `skills_data.json`，**175 条我的版本 0 条存活**，
   全被换成更短更笼统的版本（如 `computer-use` 只剩「操作 Windows 应用程序」）。

**做法**：
- 写之前**必须重新读最新版**（本次是写时现读），写完立刻**逐条比对校验**
  （`sum(1 for e in disk if e['description']==D.get(e['name']))` → 期望 175/175）；
- 发现被覆盖 → 把字典（`detail_*.py`）留着，**再写一次**即可恢复；
- **向十一说明「这个文件建议只让一个窗口改」**，别自己硬扛 ping-pong；
- 页面/数据的**结构类改动**（去掉口令、加标签）风险较低；
  **内容类改动**（简介、文案）最容易被覆盖，写完一定复核。

## 10. 如果以后要「恢复口令」——先把这三个方案摆给十一（2026-10-07 已分析，他未选）

他问「**我能不能通过口令下载到这个技能？**」时，先回答：
**可以，而且改动很小** —— 页面 `installPrompt()` 的逻辑是「只要 `package_url` 是 `https://` 完整地址，
复制出来的口令就自动带全 URL」。所以本质不是改口令，是**把包放到能被访问的地方**。

现状（别搞错）：看板目录**没有 git、没发布**，域名下 `/skills/`、`/packages/` 都是 **404**。

| 方案 | 做法 | 代价 / 风险 |
|---|---|---|
| **A 挂自己域名** | 推到 `shiyi-dashboard` 仓库的子目录 → `https://shiyi11.com.cn/skills/` | ⚠️ **GitHub Pages 免费版只对公开仓库生效** → 谁拿到地址都能下。业务技能包里有店铺口径、字段名、脚本逻辑；看板本身还会暴露「你有哪些技能、业务怎么跑」。**ZIP 设不了密码**；随机目录名只是「地址不外传」，F12 一扒就穿 |
| **B 私有对象存储 + 签名链接** | 腾讯云 COS / 阿里云 OSS 私有桶，生成有时效的下载链接 | 不公开、可撤销、可统计；但**链接会过期**（1 小时~7 天）→ 不适合当长期口令贴在看板上，适合「临时发给某人」。要开通配置，38 MB 按量计费几毛钱 |
| **C 维持发文件** | 把 ZIP 随消息附给接收 Agent | 零风险；但每次都得发文件，不能「一句话装好」 |

**规模参考**（省得再算）：packages 共 **352 个包 / 38.8 MB**（单包中位 10 KB，最大 7 MB），
`skills.html` 440 KB。**十一自己的业务技能只有 38 个、合计 0.67 MB** ——
所以「只挂业务包」是可行的折中（通用工具技能本来网上就有，不必上公网）。

**推荐口径**：
- 他要的是「**我在别的电脑 / 别的 AI 窗口一句话装好我的业务技能**」→ 推 **B**（业务包才 0.67 MB，最合适）；
- 「**发给同事用**」→ 维持 **C**（附文件最稳）；
- 想省事且**能接受公开** → **A，但只挂 38 个业务包**，并明确告诉他风险。

⚠️ **别默认选 A。** 十一之前就关心过「仓库是 public」这件事，
直接把业务技能包挂上公开 Pages = 一键泄露经营结构，**必须先讲清风险再动手**。

## 11. `merge_kanban.py` 的三个真实缺陷（2026-10-07 修）

### ① 它不去重 —— 跑一次多一份，而且会把你自己的 JSON 写脏

合并逻辑是「读现有 → 追加自己那 177 条 → 写回」，**从不按 name 合并**。同一天连跑两次的实测：
```
第 1 次：现有 351 → 合并后 528（新增 177）
第 2 次：现有 528 → 合并后 705（新增 177）   ← 177 个名字重复，最高一名 4 条
```

正确去重口径（**别按 name 全局去重**）：
- 只对 **`agent == 'Hermes'`** 的条目按 `name` 去重（保留最后一条 = 最新写入、带最新简介的）；
- `agent != 'Hermes'` 的（本次实为 `Codex` 58 条 + `WorkBuddy` 119~120 条）**一条不动**；
- 收工应回到 **354 上下**（58 + 119 + 177）。

⚠️ **实测过的错误做法**：按 `(name, agent)` 全局去重 → Codex 从 178 掉到 58，
把别人同名不同内容的技能整批删了。**改数据前先把自己那份整份备份出去**
（本次全靠 `cache/backup_skills_data_脏_2026.10.07.json` 才回滚成功）。

现成脚本：`scripts/dedupe_kanban_json.py`（**默认 dry-run，`--apply` 才写，写前自动备份**）。

### ② `full_description` 一直被写成和卡片简介同一个值

```python
# 原样（错的）
d, scene = DESC.get(name, ...)
return {... "description": d, "full_description": d, ...}
```
→ `detail_*.py` 那份长简介**从来没被读过**，详情面板和卡片长得一模一样（他给这套数据时
本来就是想说「卡片短、详情长」）。

修法：把 DETAIL 字典也加载进来，两个字段分开取
```python
DETAIL = {}
for fn, vn in [("detail_A_ecommerce.py", "DETAIL_A"),
               ("detail_B_office.py", "DETAIL_B"),
               ("detail_C_dev.py", "DETAIL_C")]:
    DETAIL.update(load_mod(fn, vn))
...
"description": d,
"full_description": DETAIL.get(name, d),
```
`load_mod` 是 `importlib.util.spec_from_file_location` 按文件加载 —— 改完 `desc_*.py` /
`detail_*.py` 后**先 `rm -rf __pycache__` 再重跑**，别去赌缓存；重跑时看开头的
「详细简介条数: N」确认字典真的加载进来了。

### ③ 最后一步会断，而 JSON 已经写进去了

`merge_kanban.py` 末尾对 `skills.html` 做几处 `assert src.count(锚点) == 1` 的字符串替换。
只要**别的窗口动过 HTML 的结构**（本次是分类按钮那段被改过），就会在最后一步抛
`AssertionError: 分类按钮锚点异常` —— **此时 `skills_data.json` 已经写完了，HTML 一点没动**。

所以看到这个报错：**不要当成整轮失败、更不要重跑**（重跑 = 再追加 177 条）。正确动作：
1. 承认 JSON 已更新（`skills_data.json` 是数据源，HTML 才是交付物）；
2. HTML 侧改用**聚焦替换**，只替换自己那几个技能的字段，不碰别人的锚点/结构 →
   现成脚本 `scripts/fix_kanban_entry_text.py`；
3. 用「HTML 条目数 + 重复名数量」跟备份对比，确认没被自己搞坏
   （本次 HTML 仍是 351 条 = 干净；原始备份里的 12 个重复名是 Codex/WorkBuddy 侧本来就有的，
   **不是我造成的，别顺手"修"掉**）。

### HTML 聚焦替换的两个坑

**坑一：键不相邻 → 正则静默 0 匹配。** 记录的字段顺序是
`name → description → full_description → version …`，所以：
```python
r'("name": "X", "full_description": ")[^"]*(")'        # ❌ 一条都匹配不到
r'("name": "X".{0,900}?"full_description": ")[^"]*(")'  # ✅ 带窗口 + re.S
```
本次第一条正则没报错、只是「未匹配」—— 中间隔着 `description`，很容易看漏。

**坑二：回读断言会假通过。** 用「name 之后 1200 字符里包含新值」做校验：
`description` 已经改过、正落在窗口内 → 6 个字段全报 ✅，其实 `full_description` 还是旧的。
**回读必须定位到具体字段再比值**，不要用「窗口内包含」判断。

---

## 12. 卡片简介 vs 详情简介：他说「详细一些」时加到哪一处

2026-10-07：十一给了 `shiyi11.com.cn/skills/`（密码 12511251）+ 三个技能名，说
「**卡片简介，中文简介内容详细一些**」。

页面上这两个字段各有预算，别混：

| 字段 | 显示位置 | 约束 |
|---|---|---|
| `description` | 卡片网格 | `-webkit-line-clamp:4` + `max-height:72px` ≈ **4 行 / 78 字**，超了截断 |
| `full_description` | 右侧详情面板 | 无截断，可以放开写 |

→ **「详细一些」要加在 `full_description`**；`description` 仍守 78 字上限。
本次我把 130~170 字的长文本也写进了 `description`，卡片必然被截。
下次按「卡片 ≤78 字讲清『是什么 + 什么时候用』，详情放开写口径 / 范围 / 产出 / 坑」来分。

顺带一条口径：这类改动**只改 Eleven 自己那批技能**，Codex/WorkBuddy 的条目一个字都不动 ——
即使发现他们的同名条目有问题，也只报告、不顺手改。


