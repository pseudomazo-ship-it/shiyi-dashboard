#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""技能加载目录体检 —— 只读，不改任何文件。

扫出三类毛病（2026-10-07 十一说「名称有歧的修改一下」时实修出来的）：
  ① 重名      frontmatter `name:` 相同的多个 SKILL.md → skill_view 报 Ambiguous skill name
  ② 备份残留  路径含 .bak / .archive / _bak 的目录 → 会被当成技能扫进来、重复计数
  ③ 子模块    没有 `name:` 字段的 SKILL.md → 是别人的子章节，不该算独立技能

用法：
    python find_skill_name_collisions.py [skills_root]
    # 默认 root = E:/RuanJian/Hermes/skills

退出码：0 = 干净；1 = 有毛病（便于接 CI / 脚本判断）。

⚠️ 判别原则：**技能名取自 frontmatter，不是目录名** —— 所以修重名必须把旧版目录
   移出加载目录，改文件夹名没有任何用。移出前先 cp 再逐文件校验，别直接 mv/rm。
"""
import os
import re
import sys
import collections

DEFAULT_ROOT = r"E:/RuanJian/Hermes/skills"
NAME_RE = re.compile(r'^name:\s*(.+?)\s*$', re.M)
BACKUP_RE = re.compile(r'(\.bak|\.archive|_bak|backup|\.old)', re.I)


def scan(root):
    """返回 [(name or None, rel_dir)]，按目录排序稳定输出。"""
    rows = []
    for dirpath, _dirnames, filenames in os.walk(root):
        if "SKILL.md" not in filenames:
            continue
        try:
            text = open(os.path.join(dirpath, "SKILL.md"),
                        encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        m = NAME_RE.search(text)
        name = m.group(1).strip().strip("\"'") if m else None
        rows.append((name, os.path.relpath(dirpath, root)))
    return sorted(rows, key=lambda r: r[1])


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_ROOT
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        print("目录不存在: %s" % root)
        return 2

    rows = scan(root)
    print("技能加载目录: %s" % root)
    print("SKILL.md 总数: %d" % len(rows))
    print()

    problems = 0

    # ① 重名（只报真有 name 的；None 归到第 ③ 类）
    by_name = collections.defaultdict(list)
    for name, rel in rows:
        if name:
            by_name[name].append(rel)
    dups = {n: v for n, v in by_name.items() if len(v) > 1}
    print("① 重名（%d）" % len(dups))
    if dups:
        problems += len(dups)
        for name, rels in sorted(dups.items()):
            print("   ⚠️ name = %s" % name)
            for rel in rels:
                print("        %s" % rel)
        print("   → 修法：把旧版目录**移出**技能加载目录（改名无效）")
    else:
        print("   ✅ 无")
    print()

    # ② 备份 / 存档残留
    leftovers = [rel for _n, rel in rows if BACKUP_RE.search(rel)]
    print("② 备份/存档残留（%d）" % len(leftovers))
    if leftovers:
        problems += len(leftovers)
        for rel in leftovers:
            print("   ⚠️ %s" % rel)
        print("   → 修法：整体移出到工作区（cp → 校验 → rm）")
    else:
        print("   ✅ 无")
    print()

    # ③ 无 name 字段（多为子模块）
    noname = [rel for n, rel in rows if not n]
    print("③ 无 name: 字段（%d）" % len(noname))
    if noname:
        for rel in noname:
            print("   · %s   ← 子章节/子模块，入库时必须排除，不算独立技能" % rel)
    else:
        print("   ✅ 无")
    print()

    print("结论: %s" % ("✅ 干净" if problems == 0 else "⚠️ 发现 %d 处问题，见上" % problems))
    return 0 if problems == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
