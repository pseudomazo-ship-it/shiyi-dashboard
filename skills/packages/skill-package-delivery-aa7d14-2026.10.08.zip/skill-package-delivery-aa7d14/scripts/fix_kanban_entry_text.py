# -*- coding: utf-8 -*-
"""技能看板 skills.html 「聚焦替换」指定技能的简介字段。

什么时候用：merge_kanban.py 末尾对 HTML 的 `assert src.count(锚点) == 1` 挂掉
（别的窗口改过页面结构，例如分类按钮那段），此时 skills_data.json 已更新、HTML 没动。
**别重跑 merge**（它会再把自己那一整批追加进 JSON）—— 用本脚本把数据灌进 HTML。

关键实现（两个踩过的坑都在这）：
  ① 字段顺序是 name → description → full_description → version，键不相邻
     → 匹配 full_description 必须带 `.{0,900}?` 窗口 + re.S（否则静默 0 匹配）
  ② 校验必须定位到具体字段再比，不能用「name 之后 N 字符里包含新值」
     （description 已改过会落在窗口里，导致假通过）
  ③ 同名技能可能属于不同 agent → 逐个出现位置先看信封里的 `agent` 再决定改不改

用法：
  python fix_kanban_entry_text.py skills.html --json skills_data.json \
         --names linghangyuan-overtime,hermes-cron-script-jobs [--agent Hermes] [--apply]
默认 dry-run；`--apply` 才写，写前自动备份到 <Hermes>\\cache\\。
"""
import argparse
import datetime
import json
import os
import re
import shutil
import sys

BACKUP_DIR = r"E:\RuanJian\Hermes\cache"
FIELDS = ("description", "full_description")
WINDOW = 1500   # 一条记录的大致长度上限


def record_span(html, idx):
    """从 name 字段位置往后切一个窗口，作为「这条记录」的近似范围。"""
    return html[idx: idx + WINDOW]


def field_value(seg, field):
    m = re.search(r'"%s":\s*"([^"]*)"' % field, seg)
    return m.group(1) if m else None


def replace_field(html, start, field, newval):
    """只替换 [start, start+WINDOW) 范围内的某个字段。返回 (新html, 命中数)"""
    end = start + WINDOW
    seg = html[start:end]
    if field == "description":
        pat = re.compile(r'("description":\s*")[^"]*(")')
    else:
        pat = re.compile(r'("description":\s*"[^"]*".{0,900}?"full_description":\s*")[^"]*(")', re.S)
    seg2, n = pat.subn(lambda m: m.group(1) + newval.replace("\\", "\\\\") + m.group(2),
                       seg, count=1)
    return html[:start] + seg2 + html[end:], n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("--json", required=True)
    ap.add_argument("--names", required=True, help="逗号分隔的技能名")
    ap.add_argument("--agent", default=None, help="只改这个 agent 的条目（默认不限制）")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()

    with open(a.json, encoding="utf-8") as f:
        data = json.load(f)
    items = data if isinstance(data, list) else (data.get("skills") or data.get("items") or [])

    names = [x.strip() for x in a.names.split(",") if x.strip()]
    want = {}
    for it in items:
        if it.get("name") in names:
            want[it["name"]] = {k: it.get(k, "") for k in FIELDS}
    for n in names:
        print("  %-38s %s" % (n, "OK" if n in want else "★ JSON 里没有"))

    html = open(a.html, encoding="utf-8").read()
    orig_len = len(html)
    hits = 0

    for name, vals in want.items():
        pat = re.compile(r'"name":\s*"%s"' % re.escape(name))
        starts = [m.start() for m in pat.finditer(html)]
        print("\n%s —— HTML 里出现 %d 次" % (name, len(starts)))
        # 从后往前改，避免前面的替换使后面偏移失效
        for start in reversed(starts):
            seg = record_span(html, start)
            if a.agent and field_value(seg, "agent") != a.agent:
                print("   跳过：agent=%s" % field_value(seg, "agent"))
                continue
            for field in FIELDS:
                if not vals[field]:
                    continue
                cur = field_value(record_span(html, start), field)
                if cur == vals[field]:
                    print("   %-17s 已是目标值" % field)
                    continue
                html, n = replace_field(html, start, field, vals[field])
                hits += n
                print("   %-17s 替换 %d 处" % (field, n))

    print("\nHTML: %d → %d 字符｜共替换 %d 处" % (orig_len, len(html), hits))

    if a.apply:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        bak = os.path.join(BACKUP_DIR, "backup_kanban_html_%s.html" % stamp)
        shutil.copy(a.html, bak)
        open(a.html, "w", encoding="utf-8").write(html)
        print("已写回｜备份:", bak)
    else:
        print("（dry-run，未写回。加 --apply 才写）")

    # 校验：定位到字段再比，不用「窗口内包含」
    print("\n=== 回读校验（按字段精确比对）===")
    check = open(a.html, encoding="utf-8").read() if a.apply else html
    bad = 0
    for name, vals in want.items():
        pat = re.compile(r'"name":\s*"%s"' % re.escape(name))
        for m in pat.finditer(check):
            seg = record_span(check, m.start())
            if a.agent and field_value(seg, "agent") != a.agent:
                continue
            for field in FIELDS:
                ok = field_value(seg, field) == vals[field]
                bad += 0 if ok else 1
                print("  %-38s %-17s %s" % (name, field, "✅" if ok else "❌"))
    if bad:
        print("⚠️ 有 %d 个字段没对上" % bad)
        return 1
    print("全部对上。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
