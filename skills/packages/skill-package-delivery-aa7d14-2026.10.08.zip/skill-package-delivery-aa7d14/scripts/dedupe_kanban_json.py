# -*- coding: utf-8 -*-
"""技能看板 skills_data.json 去重 —— 只在【同一个 agent 内】按 name 收敛。

背景：merge_kanban.py 的合并逻辑是「读现有 → 追加自己那一批 → 写回」，从不按 name 合并。
同一天跑两次的实测：351 → 528 → 705，177 个名字重复、最高一名 4 条。

⚠️ 不要按 name 全局去重！Codex / WorkBuddy / Hermes 会有同名技能且内容差异很大
   （github 别人 375B vs 我这版 35KB；xlsx 别人 158KB vs 31KB）。
   2026-10-07 按 (name, agent) 全局去重过一次，Codex 从 178 掉到 58 —— 把别人的条目删了。
   正确口径：只收敛 Hermes 那一批，其他 agent 的条目一条不动。

用法：
  python dedupe_kanban_json.py <skills_data.json>                 # dry-run，只报告
  python dedupe_kanban_json.py <skills_data.json> --apply         # 写回（写前自动备份）
  python dedupe_kanban_json.py <src.json> --apply --agent Hermes  # 指定只收敛哪个 agent
"""
import argparse
import collections
import datetime
import json
import os
import shutil
import sys

BACKUP_DIR = r"E:\RuanJian\Hermes\cache"


def load(path):
    with open(path, encoding="utf-8") as f:
        raw = f.read()
    data = json.loads(raw)
    if isinstance(data, list):
        return data, None, "list"
    for key in ("skills", "items"):
        if isinstance(data.get(key), list):
            return data[key], data, key
    sys.exit("❌ 找不到条目数组（既不是 list，也没有 skills/items 键）")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json_path")
    ap.add_argument("--apply", action="store_true", help="真正写回（默认 dry-run）")
    ap.add_argument("--agent", default="Hermes",
                    help="只收敛这个 agent 的条目（默认 Hermes）；其他 agent 一律不动")
    a = ap.parse_args()

    items, wrapper, key = load(a.json_path)
    before = len(items)
    by_agent = collections.Counter(x.get("agent") for x in items)
    print("文件:", a.json_path)
    print("去重前:", before, "|", dict(by_agent))

    mine = [x for x in items if x.get("agent") == a.agent]
    others = [x for x in items if x.get("agent") != a.agent]
    c = collections.Counter(x.get("name") for x in mine)
    dups = {k: v for k, v in c.items() if v > 1}
    print("  待收敛 %s: %d 条，其中重名 %d 个" % (a.agent, len(mine), len(dups)))
    for k, v in list(dups.items())[:6]:
        print("     %-40s x%d" % (k, v))
    if not dups:
        print("✅ 没有重名，不用动。")
        return 0

    seen = {}
    for x in mine:                     # 保留最后出现的那条 = 最新写入的
        seen[x.get("name")] = x
    merged = others + list(seen.values())
    print("去重后:", len(merged), "（%s %d + 其他 %d）"
          % (a.agent, len(seen), len(others)))

    after = collections.Counter((x.get("name"), x.get("agent")) for x in merged)
    left = [k for k, n in after.items() if n > 1]
    print("残留重复 (name, agent):", len(left))

    if not a.apply:
        print("\n（dry-run，未改动。加 --apply 才写回）")
        return 0

    os.makedirs(BACKUP_DIR, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    bak = os.path.join(BACKUP_DIR, "backup_skills_data_%s.json" % stamp)
    shutil.copy(a.json_path, bak)
    print("\n已备份:", bak)

    if key == "list":
        payload = merged
    else:
        wrapper[key] = merged
        payload = wrapper
    with open(a.json_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)

    chk, _, _ = load(a.json_path)
    print("写回验证:", len(chk), "条（改动前 %d）" % before)
    return 0


if __name__ == "__main__":
    sys.exit(main())
