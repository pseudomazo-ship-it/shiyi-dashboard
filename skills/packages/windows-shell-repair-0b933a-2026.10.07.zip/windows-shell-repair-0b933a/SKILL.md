---
name: windows-shell-repair
description: "Use when broken desktop icons or garbled labels."
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows]
metadata:
  hermes:
    tags: [windows, shell, explorer, icon-cache, desktop, ui-repair]
    category: productivity
---

# Windows Shell / Desktop UI Repair

Repair corrupted Windows explorer/shell/desktop UI. The classic symptom (user
says "开机后很多软件的图片不正常") is a **corrupted icon cache**: app icons
draw as blue generic rectangles or blank white pages, the labels overlap/mojibake,
and the desktop grid looks chaotic. This is shell icon-cache corruption, NOT broken
apps — the software itself is fine.

## When to use
- Desktop app icons show as blue generic documents / blank white pages.
- Icon labels overlap, get truncated, or render as floating stray text.
- Desktop icon layout is misaligned/chaotic after a reboot.
- Explorer or the taskbar renders oddly (window chrome, thumbnails).

## Root cause
Windows caches app icons in `IconCache.db` (user profile) and per-size
`iconcache_*.db` / `thumbcache_*.db` (under `%LOCALAPPDATA%\Microsoft\Windows\Explorer\`).
If that cache is stale/corrupted, the shell draws placeholder/blank icons and the
label it caches is garbled → the overlapping-text look. Fix = clear the cache and
let Windows rebuild it.

## The reliable fix (stop explorer → delete cache → restart explorer)

```powershell
# fix_icons.ps1  (write to a NON-Temp dir, see below)
$ErrorActionPreference = "SilentlyContinue"
Stop-Process -Name explorer -Force
Start-Sleep -Seconds 2
Remove-Item "$env:LOCALAPPDATA\IconCache.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\iconcache_*.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_idx.db" -Force
Start-Process explorer
Start-Sleep -Seconds 3
$p = Get-Process explorer -ErrorAction SilentlyContinue
if ($p) { Write-Output "explorer restarted, PID=" + $p.Id } else { Start-Process explorer }
```

Run it, then confirm explorer is back (`Get-Process explorer` shows a fresh PID).
Windows rebuilds the cache **progressively** — right after restart some icons may
still look stale; a desktop refresh (F5 / right-click→Refresh) helps. Don't conclude
failure immediately.

## Pitfalls (learned this machine)

1. **Write the .ps1 to a non-Temp directory.** If you park it in `%LOCALAPPDATA%\Temp`
   and the disk-cleanup skill runs, it deletes `Temp` wholesale — a repair script
   there gets deleted mid-session. Use a dedicated scripts dir.
2. **PowerShell .ps1 must be ASCII-only / no mojibake.** A `.ps1` containing Chinese
   characters (e.g. `Write-Output "..."` with emoji) fails to parse on this machine
   with `parsererror: missing terminator` — the file is read as ANSI/GBK and the UTF-8
   Chinese mangles the quote. Write the script with **pure ASCII** strings (English
   labels, no Chinese, no emoji) and it parses fine.
3. **Don't inline PowerShell with `$` vars from git-bash.** `powershell -Command "... $env:... "`
   loses the `$` to bash expansion (tested repeatedly). Always `-File` the script.
4. **A script that fails to PARSE leaves explorer untouched** — it errors at parse
   time before `Stop-Process` runs. Safe: if you see the parsererror, nothing was
   deleted, explorer is still running. Re-check `Get-Process explorer` before retrying.

## Icon-cache rebuild FAILED → it's shortcut TARGET PATHS (the real culprit)

When the user reports icons broken **after a reboot** AND says something like
"我把 E:\软件 改成了 E:\RuanJian" / "这些软件之前都在这个文件夹内", the icon cache
is fine — the **shortcut targets point to a renamed/moved folder** (e.g. `E:\软件\...`
no longer exists; the real folder is now `E:\RuanJian\...`). Windows can't find the
target so it draws the generic blue/blank placeholder.

Note: the cache wipe above is still worth one attempt first (cheap, and clears
stale cached placeholders), but the durable fix is rewriting each `.lnk` target.

### The working recipe (validated: fixed 20/21 shortcuts on this machine)

1. **Enumerate .lnk targets** (desktop + public desktop + start menu) without the
   PowerShell-encoding trap: have PowerShell write results to a UTF-8 file, read it
   back with Python (`io.open(..., encoding='utf-8', errors='ignore')`):
   ```powershell
   $sh = New-Object -ComObject WScript.Shell
   Get-ChildItem "$env:USERPROFILE\Desktop\*.lnk" -ErrorAction SilentlyContinue |
     ForEach-Object { $lnk = $sh.CreateShortcut($_.FullName)
       $out += ("{0}|{1}" -f $_.FullName, $lnk.TargetPath) }
   $out | Out-File "C:\Users\Administrator\AppData\Local\Temp\lnk_full.txt" -Encoding UTF8
   ```
2. **Filter + validate the new path exists BEFORE changing anything.** For each
   target starting with the OLD prefix (`E:\软件\`), build the new path by
   replacing the prefix (`E:\RuanJian\`), and only keep it if
   `os.path.exists(newpath)`. This is what makes the fix safe — never write a live
   shortcut to a path you haven't verified exists.
3. **Back up every .lnk** to a temp dir first (`shutil.copy2`) so the batch is
   reversible.
4. **Batch-rewrite with a single UTF-8-BOM .ps1 file** (all mappings hard-coded
   inside the file, via WScript.Shell CreateShortcut → set TargetPath → Save).
   Run it with `powershell -File`, capture ONLY the exit code (`r.returncode`),
   not stdout — see encoding pitfall below.

### ⚠️ THE #1 PITFALL: rewriting TargetPath is NOT enough — also rewrite IconLocation
This is the mistake that costs a whole extra round-trip. Setting `$lnk.TargetPath`
and saving leaves `$lnk.IconLocation` still pointing at the OLD path, and the shell
draws a shortcut's icon from **IconLocation**, not from TargetPath. Symptom: user
says "**还是没恢复 / 没恢复**" even though every target is correct and every exe
exists. Diagnose by dumping both fields:
```powershell
$out += ("{0}|{1}|{2}" -f $_.FullName, $lnk.TargetPath, $lnk.IconLocation)
```
`E:\RuanJian\x\x.exe` + `E:\软件\x\x.exe,0` → the icon field is stale.
Fix: rewrite BOTH, preserving the icon index (`...exe,1` for the 2nd icon —
`豆包浏览器` legitimately uses `,1`, don't flatten every entry to `,0`):
```powershell
$lnk.TargetPath   = '<new exe>'
$lnk.IconLocation = '<new exe>,<same index>'
$lnk.Save()
# then read back and record it — proof, not hope:
$chk = $sh.CreateShortcut($f); $res += ('OK|' + $chk.IconLocation)
$res | Out-File '<...>\icon_res.txt' -Encoding UTF8
```
Always do the read-back into a results file and print it — a Save that silently
no-ops looks identical to success otherwise.

### Pitfall: Public Desktop `.lnk` need ADMIN to rewrite
`C:\Users\Public\Desktop\*.lnk` (and some Start-Menu entries) **refuse Save**
to a non-elevated process — you get `无法保存快捷方式 ...` even though the file
is writable and not read-only. Detect: rerun the rewrite with a result file
(`$res += ('OK|'+name+'|'+$chk.TargetPath)`), see `ERR|...|无法保存`. The fix is
to run the .ps1 **elevated**:
```python
subprocess.run(["powershell","-NoProfile","-Command",
  "Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','<script>' -Verb RunAs -Wait"],
  timeout=90)   # pops one UAC prompt; user clicks Yes
```
That elevated run DOES succeed (it's a permission issue, not a bug).

### Verify & scope
- After restart, cap verification as "explorer running fresh PID + cache cleared".
  Rebuilding is incremental; icons recover within a minute or two.
- If SOME icons stay broken after a clean cache rebuild, that's a per-shortcut
  problem (target moved/deleted) — **run the shortcut-target rewrite above**, not
  another cache wipe.
- One leftover that can't be fixed = the target folder genuinely doesn't exist
  under the new name (e.g. the app was never moved / never installed). Report it
  as "software missing" and offer to delete the dead .lnk or reinstall — don't
  invent a mapping.
- If the whole taskbar/window chrome also glitches, that's broader shell state;
  a restart or sign-out usually resolves it. This skill covers the icon-cache case.

## Cross-cutting pitfall: PowerShell-from-Python UTF-8 output decode crash
Calling `powershell -Command` that emits **Chinese/stdout** from Python via
`capture_output=True, text=True` throws `UnicodeDecodeError: utf-8 codec can't
decode byte 0xbc` (one per _readerthread) and `r.stdout` becomes `None` — a
recurring waster of tool calls. Two reliable fixes, in order of preference:
1. **Don't parse stdout at all** — `subprocess.run(..., capture_output=True)`
   then read only `r.returncode`; write any result to a UTF-8 file (via PowerShell
   `Out-File -Encoding UTF8`) and read it back with Python `errors='ignore'`.
2. Write a full UTF-8-**BOM** `.ps1` and `-File` it → the script file's own
   encoding is respected; inline `-Command` is what mangles non-ASCII.
