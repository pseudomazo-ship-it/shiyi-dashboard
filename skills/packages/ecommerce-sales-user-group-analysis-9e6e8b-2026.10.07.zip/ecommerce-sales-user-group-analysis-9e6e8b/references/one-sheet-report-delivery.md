# 单页 Excel 报表交付（十一 2026-09-19 定的形态）

## 什么时候用

十一说「**再生成一个表格文件，表格中把所有数据在一个页面内**」时 —— 除 HTML 看板外再给一份 **单工作表** 的 Excel，不要多 sheet。任何「把多张表汇总成一份可交付表格」的场合都适用这套骨架。

## 核心思路：数据只算一次，两个成品都读它

```
build_dashboard.py  →  HTML 看板 + 脚本/_computed.json
                              ↓
build_one_sheet_xlsx.py  →  单页 Excel（读 _computed.json，不重算）
```

看板脚本收尾：

```python
DUMP = {'MONS': MONS, 'EV': EV, 'S1': S1, 'S2': S2, 'S3': S3, 'S4': S4, 'S5': S5,
        'DSR_EXACT': DSR_EXACT, 'T_DSR': T_DSR, 'T_EV': T_EV, 'T_S1': T_S1, 'T_S2': T_S2,
        'T_S3': T_S3, 'T_S4': T_S4, 'T_S5': T_S5, 'STAR_TOTAL': STAR_TOTAL,
        'STAR_OLD': STAR_OLD, 'STAR_YNG': STAR_YNG, 'STAR_OLD_FULL': STAR_OLD_FULL,
        'STAR_EST': sorted(STAR_EST),          # set 不能直接 json dump
        'GAP6': GAP6, 'GAP6_OLD': GAP6_OLD, 'GAP6_YNG': GAP6_YNG,
        'ORD_T': ORD_T, 'ORD_O': ORD_O, 'ORD_Y': ORD_Y, 'T_ORD': T_ORD, 'QTY': QTY, 'BUY_T': BUY_T}
json.dump(DUMP, open(os.path.join(BASE, '脚本', '_computed.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
```

Excel 脚本头部只做 `D = json.load(open(..., encoding='utf-8'))`，之后一律 `D['S1'][i]`，**不重写任何算式**。

## 排版骨架（openpyxl）

```python
N, P2, P1, D4 = '#,##0', '0.00%', '0.0%', '0.0000'
PD = '+0.0000;-0.0000;0.0000'      # 平均分之差：分数差，不是百分比！
MUL = '0.00"×"'                    # 倍差（年轻率 ÷ 中老年率），别留成裸数字
F_EST = Font(name='微软雅黑', size=10, color='2F5597')   # 蓝＝估算/补录/平台提供

wb = Workbook(); ws = wb.active; ws.title = '全部数据'

# 三件套：title() / section() / head() / row()，全局 r 游标逐行落
# row(vals, fmts, est=set(), summary=False)：fmts 逐列 number_format，est 里的列号涂蓝底蓝字

def section(text):                      # 板块标题：合并整行 + 深蓝底白字
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, text); c.font = F_SEC; c.fill = FILL_SEC

def row(vals, fmts=None, est=None, summary=False):
    for i, v in enumerate(vals, 1):
        c = ws.cell(r, i, v); c.border = BOX
        if fmts and i <= len(fmts) and fmts[i-1]: c.number_format = fmts[i-1]
        c.font = F_SUM if summary else (F_EST if i in (est or set()) else F_TXT)
```

收尾：

```python
ws.freeze_panes = 'A2'
ws.sheet_view.showGridLines = False
ws.page_setup.orientation = 'landscape'
ws.page_setup.fitToWidth = 1
ws.page_setup.fitToHeight = 0
ws.sheet_properties.pageSetUpPr.fitToPage = True
```

## 板块顺序（实测可用，**86 行 × 14 列 / 8 个板块**）

| 板块 | 列 |
|---|---|
| 标题 + 一行口径/补录说明 | 合并整行 |
| 【一】总览 | 指标｜数值｜说明 |
| 【二】星级结构（1-5星） | 星级｜条数｜占总评价｜出评率(÷订单)｜中老年｜年轻｜中老年占比｜月度峰值｜数据口径 |
| **【二·2】各星级出评率（整体/中老年/年轻）** | 星级｜全店出评率｜中老年出评率｜年轻出评率｜差(pp)｜**倍差**｜条数(中老年/年轻) |
| 【三】月度评价 × 星级 | 月份｜评价数｜1星..5星｜5星占比｜自算平均分｜差评率 |
| 【四】月度订单与出评（不含金额） | 月份｜成交订单｜成交件数｜买家数｜评价数｜出评率｜自算平均分 |
| 【五】购买人群·月度 | 月份｜中老年订单｜年轻订单｜中老年占比｜年轻占比｜两组评价*｜两组出评率｜两组平均分｜分差 |
| 【六】人群 × 星级 | 星级｜中老年%｜年轻%｜差 |
| 【七】口径说明与数据来源 | 编号条目，合并整行、灰色小字 |

每个板块最后一行 `summary=True` 走黄底加粗合计行（`FILL_SUM = 'FFF2CC'`）。

## 坑

1. **差值别套百分比格式**：DSR 差 0.0608 用 `0.00%` 会显示成 `6.08%`，读者会当成 6.08 个百分点。用 `+0.0000;-0.0000`。
   （相反，「各星占该人群的比例」之**差** 5.07% 用 `0.00%` 是对的 —— 那是两个百分比之差。）
2. `set` 不能直接 `json.dump` → 导出前 `sorted()`。
3. 列宽按最长内容设（`[22,12,11,...]`），否则合并说明行会挤成一坨；`NCOLS` 要和合并范围一致。
4. 免责文字（「本报表不含金额字段」）里会出现「金额」二字 → 机器断言前先排除说明行，否则误报残留。
5. **回读校验**：生成后用 `openpyxl.load_workbook(data_only=True)` 把每行打印出来核对一次，并断言 `len(wb.sheetnames) == 1`（十一要的就是单页）。
   - ⚠️ 回读脚本里的「百分比自动格式化」会骗你：自己去把 ≤1.5 的浮点当百分比打印，会把倍差 1.20 显示成 `120.45%`、把 1.79 显示成裸数 `1.7939`，看着像格式坏了，其实单元格没错。**要验格式就读 `cell.number_format`**（实测确认 5星倍差 = `0.00"×"`、出评率 = `0.00%`），别靠打印值判断。
6. **衍生列要和来源列一起标蓝**：5星整行是由估算链推出来的，除了「中老年/年轻」两格，「差」「倍差」同样间接依赖估算 —— 曾只标了来源两格，回读时自己发现不自洽。原则：`est` 集合覆盖「该格的值直接**或间接**依赖估算/补录」的所有列号。

## 运行环境

本机 `execute_code` 沙箱和系统 `python` 都没有 openpyxl → 用隔离环境跑：

```bash
cd "$LOCALAPPDATA/Temp"
uv run --quiet --with openpyxl python "D:/.../脚本/build_one_sheet_xlsx.py"
```

脚本传**原生正斜杠路径**（`D:/...`），别传 MSYS 风格 `/d/...`（本机禁用了路径转换，原生 python 会报 `can't open file`）。
