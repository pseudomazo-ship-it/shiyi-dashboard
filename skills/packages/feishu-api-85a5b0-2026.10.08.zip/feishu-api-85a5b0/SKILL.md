---
name: feishu-api
description: "Use when building/modifying Feishu 多维表格 via OpenAPI."
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [Feishu, Lark, OpenAPI, Bitable, 多维表格, IM, API, automation]
    related_skills: [feishu]
---

# Feishu OpenAPI 自动化

Use when the user (十一) wants to **create / modify / read** a Feishu 多维表格 (Base), put data into Feishu, or pull Feishu 消息历史 (@消息 / 待办) via the API. This is the *write/automate* sibling of the `feishu` skill, which only covers reading links.

> Distinction: `feishu` = read a shared URL; `feishu-api` = programmatically create/write/read via credentials. Reach for `feishu-api` the moment the user says "建一张表" / "帮我做飞书表" / "自动拉飞书消息".

## Preconditions (check before writing code)

The app must have the Bitable/document scopes **granted AND a version published**. Without this you get `Access denied ... 应用尚未开通所需的应用身份权限：[drive:drive, drive:drive:readonly, space:document:retrieve]`. If that happens, the fix is NOT in code — have the user open `https://open.feishu.cn/app/<APP_ID>/auth`, add the scopes, then **发布版本** (otherwise it stays disabled).

Credentials live in `E:\软件\Hermes\.env` as `FEISHU_APP_ID` / `FEISHU_APP_SECRET` (added when `hermes gateway setup` configured Feishu).

## Auth — get tenant_access_token

```python
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
{"app_id": FEISHU_APP_ID, "app_secret": FEISHU_APP_SECRET}
→ {"code": 0, "tenant_access_token": "t-...", "expire": 7200}
```

Use `Authorization: Bearer <token>` on all subsequent calls.

## ⚠️ 本机代理软件会挡掉飞书接口（2026-09-28 实踩，所有飞书脚本都要防）

**症状**（两种形态，同一个根因）：
- 脚本里报 `Cannot connect to host 127.0.0.1:7897 ssl:default [远程计算机拒绝网络连接]`
- 或者被脚本自己的容错吃掉，只留一句「**飞书取 token 失败，今天没算出来**」
  （2026-09-28 16:05 的「加班通知」就是这么整条没出结果的）

**根因**：这台机器上常驻一个代理软件（`com.vortex.helper.exe`，监听 `127.0.0.1:7897`）。
Python 的 `urllib` 在 Windows 上**默认会读系统代理** → 飞书是国内接口，走代理只会被挡 / 抖动。

**修法**：任何调飞书的脚本，开头显式装一个「不用代理」的 opener（一行）：

```python
import urllib.request
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
```

已加在：`scripts/daily_dashboard.py`、`项目：领航员加班判定/overtime_daily.py`。
**新增任何飞书取数脚本都补这一行。**

⚠️ **反方向别搞反**：同一台机器上，**git 推 GitHub 反而需要走这个代理**
（直连常被 reset，见 `daily-report-dashboard` 坑 12）。
一句话记法：**国内接口（飞书/QQ/微信）绕开代理；境外接口（GitHub）走代理。**

## Bitable 多维表格 endpoints (all verified working)

| Action | Method + Path | Body / notes |
|---|---|---|
| **Create Base** (app) | `POST /bitable/v1/apps` | `{"name": "售后补发表"}` → returns `app_token`, `default_table_id`. ⚠️ Do NOT pass an empty `folder_token` (caused `code:9499 Bad Request`); just `name` alone works and lands in default space. |
| **Rename table** | `PUT /bitable/v1/apps/{app_token}/tables/{table_id}` | `{"name": "新名"}` |
| **Add field** | `POST /bitable/v1/apps/{app_token}/tables/{table_id}/fields` | `{"field_name": "收件人姓名", "type": 1}` |
| **Create table**（⚠️ 必须一次带齐字段） | `POST /bitable/v1/apps/{app_token}/tables` | `{"table": {"name":"评价有礼·每日登记", "fields":[{"field_name":"日期","type":5}, {"field_name":"店铺","type":3}, {"field_name":"金额","type":2,"property":{"formatter":"0.00"}}]}}` → `data.table_id`。**`fields` 传空会被拒**：`{"code":99992402,"msg":"field validation failed","error":{"field_violations":[{"field":"table.fields","description":"the min len is 1"}]}}`。 |
| **Update field / 给已有单选字段加选项** | `PUT /bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}` | `{"field_name":"运营","type":3,"property":{"options":[{"name":"丽丽"},{"name":"玉珍"}]}}`。**⚠️ 必须 `PUT`；`PATCH` 同路径返回 `None`（无响应体）且不生效**（本次在这里白跑一轮）。先建空单选字段、再 PUT 灌 options 是可行路径。 |
| **Batch create records** | `POST /bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_create` | `{"records":[{"fields":{...}}, ...]}`，**每次 ≤500 条**。实测 7,231 + 7,320 条分 30 批全部 `code:0`。 |
| **Batch delete records** | `POST /bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_delete` | `{"records":["recXXX", ...]}`。用来清掉新表自带的空行。 |
| **Batch update records**（改已写入的值，**别删表重建**） | `POST /bitable/v1/apps/{app_token}/tables/{table_id}/records/batch_update` | `{"records":[{"record_id":"rec…", "fields":{列名: 新值}}, ...]}`，**每次 ≤500 条**。自己把某列写错时的正解：先 `GET .../records` 拉全表拿 `record_id`，用业务键（如 `(日期,店铺)`）匹配，再分批回写。实测 3,242 条 / 7 批 / 0 失败。⚠️ 表里可能已有用户自己补的新行 —— 源数据取不到值的就 `continue` **原样留着**，并在报告里写清「未动 N 条」，否则他会以为你覆盖了他的录入。 |
| **List / create views** | `GET` / `POST /bitable/v1/apps/{app_token}/tables/{table_id}/views` | 建：`{"view_name":"按运营分组","view_type":"grid"}` → `data.view.view_id`。 |
| **List fields** | `GET /bitable/v1/apps/{app_token}/tables/{table_id}/fields?page_size=50` | returns `data.items[].field_id / field_name / type / is_primary / ui_type` |
| **Delete field** | `DELETE /bitable/v1/apps/{app_token}/tables/{table_id}/fields/{field_id}` | |
| **List tables in a Base** | `GET /bitable/v1/apps/{app_token}/tables` | returns `data.items[]` with `table_id` + `name`, plus `data.total`. THE key diagnostic: a Base has N tables. |
| **Read records** | `GET /bitable/v1/apps/{app_token}/tables/{table_id}/records?page_size=100` | returns `data.items[]` (each with `fields`), `data.has_more`, `data.page_token`. Paginate by appending `&page_token=`. |
| **加协作者 / 转让所有权** | `POST /drive/v1/permissions/{app_token}/members?type=bitable` ／ `POST .../members/transfer_owner?type=bitable` | `{"member_type":"openid","member_id":"ou_...","perm":"full_access"}`。用户说「把权限给我 / 我要所有者权限」时用。**转完必须 `POST /drive/v1/metas/batch_query` 读回 `owner_id` 自证**，别凭 `code:0` 宣布成功。详见 `references/bitable-api-pitfalls.md`。 |
| **按名字搜应用能访问的文档** | `POST /suite/docs-api/search/object` | `{"search_key":"运营数据","count":20,"offset":0}` → `data.docs_entities[].docs_token`（= app_token）。用户只给了分享链接、拿不到 app_token 时用这个自己查。 |

## Reading a Base from a URL (wiki / base / ?table=)
User 十一 often pastes a Feishu link and says "看看/你以后都能看到吗/登记了多少" — this is the READ-by-API path (the `feishu` skill's read-by-link can't extract Base rows). URL → app_token:
- `my.feishu.cn/base/<app_token>` → app_token is the path segment right after `/base/`. The `?table=<table_id>` / `?view=` params name the table it was opened on.
- `my.feishu.cn/wiki/<wiki_token>` → NOT the app_token. Resolve it: `GET /open-apis/wiki/v2/spaces/get_node?token=<wiki_token>` → `data.node.obj_token` (the Base app_token), `obj_type` (`bitable`).
- **⚠️ `131006` = 这个知识库节点根本没分享给应用（不是缺 scope，也不是链接错）。**
  用户问"这张表你能看到吗"时，先跑这两个探针再回答：
  1. `GET /drive/v1/files?page_size=100` → 列应用云空间**能看到的文件**（本次就只有 1 个）。目标表不在列表里 + 下面报 131006 ⇒ 结论是"没授权"，**不要再重试、更不要改代码**。
  2. `GET /wiki/v2/spaces/get_node?token=<wiki_token>` → `{"code":131006,"msg":"permission denied: node permission denied, tenant needs read permission."}`；同时 `GET /wiki/v2/spaces` 返回 `99991672`（连知识库列表都读不到）。
- **131006（节点级）和 "Preconditions" 里的 scope 报错（应用级）是两种不同失败，修法不同，别混：**
  - 节点级 131006 → 用户把**这份文档/知识库**加应用为协作者（表格页右上角「分享」→ 加协作者搜应用名；或「···」→「添加文档应用」；知识库最好走「成员管理」加成员）。
  - 应用级 scope 报错 → 去 `open.feishu.cn/app/<APP_ID>/auth` 勾 scope 并**发布版本**。
  - 两个都得满足：加了协作者仍 131006 ⇒ 就是后台 `wiki:wiki:readonly` 没勾。
  - ⚠️ 飞书有时**不回 `code:0` 而直接抛 HTTP 400**，`code`/`msg` 在响应体里 → `urllib` 会 raise `HTTPError`，**必须 catch 后 `e.read()` 解析 body**，否则只看到 "HTTP Error 400: Bad Request"，错过 131006（本次白跑一轮）。
- **⚠️ `1254302 RolePermNotAllow` = 表**存在**，但开了「表级/高级权限」，文档级授权管不到它（第三种失败，别和 131006、scope 报错混）。**
  2026-09-21 实测：同一多维表格文档下浏览器里看得见 7 张表，但 `GET /bitable/v1/apps/{app}/tables` 只返回 **1 张**（`data.total: 1`），读另一张表报 `{"code":1254302,"msg":"RolePermNotAllow"}`（`fields`、`records`、`records/search` 三个接口全一样）。
  - **症状辨析**：`1254302` ≠ `table not found`；表确实在同一个 base 里，能识别到，只是**这张表自己设了权限**。
  - **别被 `tables` 的 `total` 骗了**：开了高级权限后，接口**只列应用有权限的表**。`total:1` 不代表这个文档只有一张表 —— 用浏览器打开文档看左侧表清单，才是真实的表数量。
  - **⚠️ 修法不是「加协作者」—— 加协作者在高级权限下完全无效（2026-09-21 实测走通）。** 真正生效的是改「**角色 × 数据表**」权限矩阵，且**只能在飞书 UI 里点**（API 改不了）：
    1. 打开 Base → 右上角「**分享**」→ 面板底部找 `高级权限已开启，用户的权限同时受到角色设定限制` → 点后面的「**查看**」
    2. 左侧选**应用所属的角色**（系统角色：所有者/管理员/编辑者/**阅读者**；或自定义角色）
    3. 右侧「**数据权限 → 数据表权限**」列表里，把目标表从「无权限」改成「**仅可阅读**」
    4. 点「**保存**」（旁边还有个「保存并预览」，**别点错**）
    5. **立刻重测** `records?page_size=3` —— 生效是秒级的，不用等
  - **已证伪、别再让用户走的两条路**：①「分享 → 文档应用 → 把应用加为协作者（可阅读）」—— 面板明明显示“已添加 `爱马仕.Hermes` / 可阅读”，API 照旧 `1254302`（用户为此白试两轮）；②「管理协作者」面板顶部那句 `协作者的实际权限以高级权限为准` 就是明示，**看到它就别再走协作者路线**，直接去高级权限。
  - **诊断表数量不要靠问用户**：开了高级权限后 `GET .../tables` 只返回**有权限的那些表**（实测 `total:1`，而文档里实际有 7 张）。用浏览器打开文档页扫 DOM 拿全量 table_id：
    `(document.documentElement.innerHTML.match(/tbl[A-Za-z0-9]{10,}/g))` → 去重后逐个 `GET .../tables/{id}/records?page_size=3`，`code:0` 的就是已授权的。
    区分三种码：`1254302`=表存在但无权限；`1254041 TableIdNotFound`=不是这个 base 的表（视图 id 或别的 base）；`0`=通。
  - **完整操作术（含飞书自绘面板的点击方法）见 `references/advanced-permission-table-grant.md`。**
  - **🔓 兜底路线：应用读不到 ≠ 读不到 —— 用十一自己的浏览器登录态走飞书的「页内接口」（2026-10-07 实测走通）。**
    高级权限挡的是**应用身份**；他自己的账号在浏览器里看得见全部表。**别退回「截图 + 肉眼读」**
    （飞书表格是 canvas 渲染，44 行 × 15 列要滚好几屏、还容易读串列），直接抓页面自己调的那个 GET 接口：

    | 用途 | 页面内接口（须在页面上下文 `fetch`，自动带 cookie） |
    |---|---|
    | **schema + 全量记录一次拿全（首选）** | `/space/api/v1/bitable/{app}/clientvars?tableID={tbl}&recordLimit=2000&ondemandLimit=2000` |
    | 只取记录（⚠️ `offset=0` 才是全量） | `/space/api/v1/bitable/{app}/records?tableId={tbl}&viewId={v}&viewLazyLoad=true&offset=0&limit=3000` |
    | 表清单（⚠️ 只回权限内的表，与 `GET .../tables` 的 `total` 同病） | `/space/api/bitable/{app}/tablesv3/` |

    - 响应体是 **gzip 压完再 base64**（标志：`data.encoding == 0`）：
      `json.loads(gzip.decompress(base64.b64decode(resp['data']['records'])).decode('utf-8'))`；
      `clientvars` 的载荷在 `data.table`。
    - `tablesv3` / `/fields` / `/datasource/list` 是 **POST**，用 GET 打只报 `Failed to fetch` —— **别据此判定「没这个接口」**。
    - 🔴 **取值器不能照抄 OpenAPI 那套**：这里**记录的键是字段 ID**（`fldXXXXXXXX`）不是字段名，
      **单选（type 3）回的是选项 ID**（`opt2i7blkf`）不是选项名 → 两者都要用**同一次 `clientvars` 的 `fieldMap`** 翻
      （`fieldMap[fid].name` / `fieldMap[fid].property.options[].{id,name}`）。OpenAPI 那边回的是选项名，写法不通用。
    - 完整 recipe（CDP 预注入钩子写法 + 解码脚本 + 本次实测数字 + 数据质量坑）见 `references/bitable-browser-session-read.md`。
- **数字字段（type 2）经 API 读出来是 STRING，不是 number。** 实测 `业绩: type=str value='1094090.92'`。写进 Excel 就是文本单元格 → pandas 读到 object 列，`.sum()` 会**把字符串首尾相接**，报 `ValueError: could not convert string to float: '1094090.92938846.92...'`（一串数字糊在一起）。**落 Excel 前对数字列强制 `float()`**：
  ```python
  def num(v):
      if v is None: return None
      if isinstance(v, (int, float)): return v
      s = str(v).strip().replace(',', '')
      if s in ('', '-', '—', 'None'): return None
      try: return float(s)
      except Exception: return v
  ```
  ⚠️ **由此派生的两个静默杀手（2026-10-01 都实踩了）：**
  1. **别用 `isinstance(v, (int, float))` 当读值的闸门。** 数字列返回的是 `str`，这个判断会把**整列读成空的** ——
     症状是「脚本跑完 0 家/0 行、又不报错」，看着像字段名写错或表是空的。**必须显式走 `num()`/`float()` 兜一层。**
     （本次为这一条白跑一轮 debug，最后靠打印一条原始 record 才看到 `花费金额: "0"`。）
  2. **数值列永远 `float()`，不要 `int()`。** 表里的小数列（如「近90天用户评价得分排名」= `0.2837`）
     被 `int()` 截断后**全部变成 0**，写进线上表**不报错、只是静默错值**（本次污染了 3,173 行，事后靠 `batch_update` 回写修复）。
     写线上表前**先打该列的分布**：`len / min / p50 / max`（量纲不对一眼就能看出来）。
- **`web_extract` returns empty for `base/wiki` links** (dynamic Base component; only the pre-loading HTML comes back) — do NOT trust a no-content result as "can't read". Go straight to the API.
- **⚠️ Field `日期` values are epoch MILLISECONDS — convert in CHINA time (UTC+8), NEVER `utcfromtimestamp`.** `utcfromtimestamp(ts/1000)` shifts every Beijing date back one day (a row entered 2026-09-05 reads as `2026-09-04`) and silently produces a wrong answer to "昨天/前天登记了多少". Use:
  `CN = timezone(timedelta(hours=8))` → `datetime.datetime.fromtimestamp(ts/1000, tz=CN).strftime("%Y-%m-%d")`
- **Share links (`my.feishu.cn/share/base/view/shr...`) require a logged-in Feishu session.** An unauthenticated fetch returns the Feishu LOGIN PAGE even when the doc is set 组织外可访问 — so do not burn turns on it or conclude the data is unreadable. Ask for the normal `my.feishu.cn/base/<app_token>?table=<table_id>` URL instead; that one resolves with app credentials.

## Reading the NEWEST records: `records/search` (POST) — the list endpoint's `sort` is REJECTED

Answering "最新一天 / 最近7天 / 本月累计" needs the newest rows, but records are stored
oldest→newest, so `GET .../records?page_size=100` starts in the distant past and paginating to
the end is slow (a full pull of ~5.9k rows timed out at 120 s in `terminal`).

- ❌ `GET .../records?page_size=100&sort=[{"field_name":"日期","desc":true}]` →
  `{"code":1254016,"msg":"InvalidSort"}` **and `data.items` comes back EMPTY** — so it presents
  as "no data" rather than as a bad parameter. Always print `code`/`msg`, never just the row count.
- ⚠️ **更阴的一种：把 `sort` 挂在 `records/search` 的 URL 查询串上 → `code:0`、有数据、但排序被静默忽略**（2026-09-26 实测：想取「最近日期」，返回的却是 2025-09 最旧的行）。**`records/search` 的 `sort` 只能放 POST body**；放 URL 不报错、只是不生效 —— 会静默地给你一个"看着有数据其实排反了"的结果。
- ✅ `POST /open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records/search` with the sort in
  the BODY: `{"sort":[{"field_name":"日期","desc":True}],"page_size":500}` → `code:0`,
  newest-first, **up to 500 rows in ONE call** (no pagination needed for a 3-week window).
- ⚠️ A `日期` filter with `{"operator":"isGreater","value":["ExactDate","<ms>"]}` returned
  `code:0` but **0 items** on a day that demonstrably had 22 rows. Sort-desc + slice in Python is the
  dependable "latest N days" path; don't burn turns tuning the date filter.
- **Debug rule when the item count is 0**: print the raw response first. `success` + 0 items = wrong
  param or a genuinely empty window; non-zero `code` = the param is wrong. This session's "0 条"
  cost two extra round trips before printing the body exposed `InvalidSort`.

### ⚠️⚠️ 拉**全表**时：`records/search` 的 `page_token` 会「假分页」→ 死循环卡死（2026-09-25 实测）

`records/search`（POST）**只能用来取"最新 N 条"，绝不能拿来翻页拉全表**：

```
第1页 500条  page_token=cGFnZVRva2VuOjUwMA==   ← 解码 = "pageToken:500"
第2页 500条  page_token=cGFnZVRva2VuOjUwMA==   ← 一模一样
第3页 500条  page_token=cGFnZVRva2VuOjUwMA==   ← 永远同一个
```

它**每次返回同一个 `page_token`、`has_more` 永远 true** → `while has_more: page_token = ...` 变成
**无限拉第一页**。症状极隐蔽：**不报错、不返回空、就是一直跑**（本次脚本在 `terminal` 里
分别卡满 **240s / 300s** 两轮，脚本内零输出，看着像"网络慢"或"venv python 坏了"——实际是死循环）。

**✅ 正解 — 拉全表用 `GET /records`（page_token 走 URL 查询参数）：**

```python
def fetch_all(token):
    rows, page_token, seen = [], None, set()
    while True:
        url = f"/bitable/v1/apps/{APP}/tables/{TABLE}/records?page_size=500"
        if page_token:
            url += f"&page_token={page_token}"
        d = req_get(url, token).get("data", {})
        rows.extend(d.get("items", []))
        if not d.get("has_more"): break
        pt = d.get("page_token")
        if not pt or pt in seen: break   # ← 防死循环的保险，必加
        seen.add(pt); page_token = pt
    return rows
```

实测：**6,083 条 / 13 页 / 45 秒**跑完，`page_token` 每页都不同（`reciytlAPy` → `recTbqmp23` → …）。

**两条规矩：**
1. **拉全表 → `GET /records`；取最新 N 天 → `records/search` + sort（单次，不翻页）。** 别混用。
2. **任何翻页循环都加 `seen` 集合兜底** —— 飞书返回重复 token 时不报错，只有这个保险能让你退出。
3. **`records/search` 带 `sort` 时不要 `page_size=500` 硬拉**：对全表排序本身就慢，配合上面的死循环会叠成"看起来永远跑不完"。

See `references/feishu-records-search-and-daily-digest.md` for the working fetch plus the
recurring-digest / cron pattern (baseline-missing-store detection, text trend lines, threshold backtesting).

## Re-read the token every run; never cache it across calls
`tenant_access_token` is short-lived (`expire` ~55–120 min) and can be rejected as `code:99991663 Invalid access token` mid-session. ALWAYS re-fetch the token in the same process that does the read — do not store a token in memory/session and reuse it on a later call. Token-fetch (in Python, from `.env`): see "Auth" above.

## 每个 `req()` 都要内置重试（SSL 抖动会整轮断掉）

### ⚠️ 容错/告警函数必须定义在「使用之前」（2026-09-28 实踩，误导了一轮排查）

定时脚本常写一个 `bail(code, msg)` 用来打印失败原因并退出。若把它定义在**页面/接口调用之后**，
一旦前面就走不通，抛的是 `NameError: name 'bail' is not defined` ——
**真正的错误（比如 NO_PAGE、取数失败）被盖掉**，日志里只剩一个看不懂的 NameError。
- 规矩：**先定义 `bail` / `jsv` / `req` 这类工具函数，再写主体逻辑**。
- 排查时的信号：日志尾部是 `NameError` 而不是业务错误 ⇒ 先找“是不是容错函数没定义/拼错”，
  不要先去改业务逻辑。
长跑/定时脚本（cron 每日日报那种）会遇到 `urlopen error [SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol` —— 本次一条日报就因此整轮无内容（推送直接没有数据）。加完重试立刻复跑就成功 ⇒ 是网络抖动，不是配置问题。模板：

```python
def req(path, payload=None, token=None, tries=3):
    last = None
    for i in range(tries):
        try:
            ... # 正常 urlopen
            return json.loads(...)
        except Exception as e:
            last = e
            if i < tries - 1: time.sleep(2 * (i + 1))
    raise last
```

## Reliable execution pattern: write a .py, run via terminal python
For multi-page Base pulls, **write the script to `cache/*.py` and run `python cache/script.py` in `terminal`** rather than `execute_code` or a `curl | python -c` pipeline. This session the `curl | python` pipe returned empty/exit 49 (MSYS pipe/UTF-8) and the `execute_code` persistent kernel intermittently dropped its socket (`Connection refused` / `Remote closed`). A script run in terminal is the dependable path and survives pagination cleanly. See `references/feishu-base-read-recipe.md` for the full working fetch script.

### field `type` codes
- `1` = Text, `2` = Number, `3` = SingleSelect, `5` = DateTime, `17` = Attachment, **`20` = Formula**（另有 `ui_type: "Formula"`）。
- **⚠️ `type:20` 公式列：既**不可写**、也**读不到计算结果**（2026-09-28 实测更正）。**
  **写**：`评价总数 = sum(1星..5星)`、`DSR = 加权平均` 这类列，导入时**不要写它们**，只写底层数值列（1星~5星），让飞书自己算。
  OpenAPI 也改不了公式表达式（`PUT .../fields/{id}` 改不了）—— 结构要动必须请用户在 UI 里改。
  **读**：**⚠️ 2026-10-01 实测更正 —— 公式列读得到，只是不同接口的返回形态不同**：
  - `GET /records` 给**计算后的数值**（实测 `评价总数=3182`、`DSR=4.73538654934004`）
  - `POST /records/search` 给**包装体** `{"type":2,"value":[0]}`

  ⇒ 取值器**两种形态都要兼容**，否则会把有值的公式列解成 `None`：
  ```python
  def g(v):
      while isinstance(v, (list, tuple)) and v: v = v[0]
      if isinstance(v, dict): v = (v.get("value") or [None])[0]
      return v
  ```
  （2026-09-28 那条「读出来都是 None」是**取值器没解包装体**造成的误判，不是接口不返回 —— 别据此放弃用公式列反验导入结果。）
  2026-09-28 实测「领航员·每日登记」表：字段列表里能看到 `DSR` / `评价总数`（`type=20, ui_type=Formula`），
  但每条记录的 `fields` 里这两个键**根本不存在**，自己的取值器一律解成 `None`。
  ⇒ **要统计就用底层列自己算**，不要指望公式列：
  ```python
  dsr = (1*f1 + 2*f2 + 3*f3 + 4*f4 + 5*f5) / (f1+f2+f3+f4+f5)   # f = 各星级
  ```
  ⚠️ **别把“读到 None”当成“这列是空的/数据没填”** —— 是 API 拿不到公式结果，飞书 UI 里那个格子是有值的。
  （旧笔记说“公式会把源表的错值自动纠正”——那是**在飞书 UI 里**看到的，不是 API 读到的，别混淆。）
- ⚠️ `type:2` 的字段返回值是**字符串**（见上面「数字字段」那条），落 Excel/算术前必须转 float。单选（type 3）返回的是**选项名字符串**，文本（type 1）返回 `[{"text":...}]` 数组 —— 三种类型取值方式不同，写统一的 `val()` 取值器。
- SingleSelect needs property: `{"field_name":"状态","type":3,"property":{"options":[{"name":"待组长核实"},{"name":"已完成"}]}}`.

## 把 Excel 登记表迁进飞书多维表格（2026-09-25 实测走通）

用户给一个"运营每天自己开 Excel 填"的表 + 问「要不要转成飞书表格」→ **答案是该转，但绝不能照搬宽表**。

**宽表必须拆成长表**，一条记录 = 一个业务实体的一次取值：

| 原 Excel（宽表） | 飞书表（长表） |
|---|---|
| 一行一天 × 20 列店铺 | 一行 = 日期 × 店铺 |
| 运营要横向数第几列才填得对 | 运营是独立字段 → 建视图按人筛 |
| 插一列 → 历史数据全错位 | 店铺是单选选项，加店不动结构 |
| 手机 20 列根本没法填 | 一屏填完 |
| 汇总列混在明细列里（如 X 列「汇总花费」） | 归到对应的记录上，不再混 |

**说给用户听的理由**（他要的是「填得方便 + 自动统计」，两者都只有长表能给）：
1. 9 人共用一个 Excel 会冲突/覆盖；
2. 宽表插列会让历史数据错位；
3. 长表才能按 **运营 / 店铺 / 日期 / 指标** 任意切统计。

**完整 recipe（含 openpyxl 读不了时的手工 xlsx 解析）见 `references/excel-to-bitable-migration.md`。**

**⚠️ 目标表是用户手改过的 —— 每次都先 `GET .../tables` + `fields` 重新探一遍，别照旧笔记的字段名写。**
本次（2026-09-26）那张表已经被改过：**表名变了**（`tbl4h3Q7tsHljiwS` 从「运营数据·每日登记（合并）」改成「领航员·每日登记-4.8⭐」）、**表内清空过**、`评价总数`/`DSR` 从 Number 改成了公式列、还多了两个排名字段。
- **按名字找表会找不到；`table_id` 才是不变的锚。**
- **导入前先 `GET .../fields`**，拿真实字段名 + `type`，**公式列（type 20）不要写**。
- 本次重导 7,380 条（15 批 / 0 失败），**读回后拿公式反验**：`评价总数 == sum(1星..5星)` 且 `DSR == 加权平均` —— 这一步能直接抓出块行偏移导致的数据错位。

**⚠️ 迁移前先把维度对齐，并当场向用户确认：**
- 本次 Excel 表头的运营（`玉珍姐`/`丽丽姐`/`博怡`/`国熙`）与另一张「店铺&运营对应分配表」**对不上**（分配表缺 2 人、写法带"姐"）。我以**实际填表人（表头）为准**并明确告知用户"若不对告诉我改"—— 而不是默默选一个、也不是猜。
- 同一家店在不同 sheet 里写**全名** vs **简称**（评价有礼表头写「美发官方」、DSR 表写「蒙倩美发官方旗舰店」），要先建一张 全名↔简称↔运营 的映射表；映射不到的（如汇总行 `/` 未识别店铺）**单独计数并报告跳过了多少条**，不要静默丢。
- **异常行不要静默跳过**：本次 DSR 表里混了一个叫「汇总」的伪店铺（其"运营"字段解出来是一个 DSR 数值）、以及一个 `DSR=1.07` 的离谱值。前者要排除并计数，后者要**点名报告给用户**（原表就错，不自行修）。

## 拿登记表做「月度评比 / 比赛结算」（2026-10-01 实测）

十一 会拿同一张登记表办月度比赛（如「近90天用户评价得分：9月均值 vs 8月均值」）。
完整 recipe 见 `references/monthly-metric-contest.md`。三条最贵的教训：

1. **规则里出现没定义的百分比（如「未达标30%」）时，不要停下来连问多题。**
   本次连问 5 题 → 十一回「**不用你拿给我拿给你 / 停下 / 你先拿给我**」。
   正解：**先按最合理口径出一版成品**，把每条假设写进 xlsx 的「口径与假设」sheet，
   把待确认项**放在成品后面**简短列出。他要的是成品，不是问卷。
2. **缺关键数据（本次缺「总业绩」，判不了大店/小店）→ 不要卡住，把两套口径并排列。**
   「大店金额」和「小店金额」各占一列，业绩一到手直接选列就能用 —— 比追问一轮快得多。
3. **动手前先跑 `date`。** 本次注入上下文写「今天 9/27」，实际系统日期 **2026-10-01** ——
   9 月早已结束，而源文件只到 9/26（缺 9/27–9/30 共 4 天）。差点把「残缺的 9 月」当完整月结算。
   **月均值/评比类任务，先确认当月是否真的过完，再决定用哪段数据。**

## ⚠️ 同一张表可能藏着「两套字段」（2026-09-30 实测，跨改版表必查）

十一的「运营数据登记」表（`Q6PZbQRH3aZum0skE3Pc8WCVnPh` / `tbl9bX2VE4PXRRiM`）全表 6,185 条，
按字段出现次数统计结果很反直觉：

```
净业绩             6,185 条   ← 全部记录都有
当日总业绩         2,703 条   ← 只有约 44% 的记录有
退款金额/推广花费/成团单量/退款单量/…   均 2,703 条
平台/店铺类型      6,184 条
日期               6,184 条   ← 一部分是时间戳(毫秒)，一部分是文本 "YYYY-MM-DD"
店铺名称（拼多多旗舰店） 5,825 条 ／ 店铺名称（拼多多个人店） 358 条
```

**含义**：这张表**跨过一次结构调整** —— 早期记录只填「净业绩」，改版后才有「当日总业绩」那一套。
不只这一张：**任何“用了很久、改过版”的登记表都可能有这个形态**。

**三条取数纪律（不遵守就会静默丢一半数据）**：

1. **取值要写兼容链路**，不能只认新字段名：
   ```python
   p = num(fs.get("当日总业绩") or fs.get("净业绩"))
   ```
2. **日期要兼容两种格式**（时间戳毫秒 + 文本），且文本可能是 `list-of-dict`：
   ```python
   if isinstance(ts, (int,float)) and ts > 1e10:
       day = datetime.fromtimestamp(ts/1000, tz=CN).strftime("%Y-%m-%d")
   else:
       s = "".join(x.get("text","") for x in ts) if isinstance(ts, list) else str(ts or "")
       m = re.match(r"\s*(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", s)
       day = "%s-%02d-%02d" % (m.group(1), int(m.group(2)), int(m.group(3))) if m else ""
   ```
   ⚠️ 旧写法 `if not isinstance(ts, (int,float)): continue` 会把文本日期那批**静默跳掉**。
3. **任何「按（日期,店铺）去重/查重」的统计，必须基于全表原始记录**，不能用「已按字段过滤后的 rows」。
   实例：查「同一天同一店铺重复登记」时只拿 rows → **9 月一处都查不出来**；
   改成 `fetch_all()` 同时返回 `rows`（算数值用）和 `pairs`（全表 `(日期,店铺,业绩)`，查重用）→ 
   全表 67 处 / 44 天一目了然。

**规矩：拿到一张不熟的表，先跑一次字段出现次数统计，再写取值逻辑。**

```python
from collections import Counter
fld = Counter()
for it in items:
    for k, v in it.get("fields", {}).items():
        if v or isinstance(v, (int, float)): fld[k] += 1
print(len(items)); print(fld.most_common(20))
```
条数明显分层的字段（全部 vs 一半）就是**跨版结构**的信号。

## ⚠️ 按「字段名关键字」取列 → 必须用精确名，别用 `in` 子串匹配（2026-09-30 实踩）

十一的表**列名是复合长名**（`平台/店铺类型`、`店铺名称（拼多多旗舰店）`）。写
`if "店铺" in k: shop = ...` 会**先命中 `平台/店铺类型`** → 按它分组 → 全表只剩
「拼多多/旗舰店」一个组 → 一次跑出 **363 组“重复”**（真实只有 **71 组**）。

**规矩**：
1. **先用一条记录打印全部字段名**，看清真实列名再写取值逻辑：
   ```python
   print(list(items[0]["fields"].keys()))
   # → ['净业绩','平台/店铺类型','店铺名称（拼多多旗舰店）','日期','负责人','问卷编号']
   ```
2. 取值按**优先级列表**匹配，并**显式排除**近义兄弟列：
   ```python
   def pick(f, cands, exclude=()):
       for k in f:
           if any(c in k for c in cands) and not any(x in k for x in exclude):
               return txt(f[k]).strip()
       return ""
   shop = pick(f, ["店铺名称"], exclude=["类型"])           # 精确名优先
   shop = shop or pick(f, ["店铺"], exclude=["类型", "平台"])  # 兜底
   ```
3. **异常数大得离谱（几百家 / 占比 >5%）时，先怀疑自己的匹配逻辑，不要先报给用户。**
   本次 363 → 71 就是这条救的。

**同类探针纪律（用户说「X 算异常」时照这个顺序）**：
① 写一次性探针脚本打真实数据源 → ② 打印**真实条数 + 最近几例（带区分性字段）** →
③ 数字看着荒谬**先自查匹配** → ④ 才把规则写进生产脚本。
**先量、再改、后报**；别把没量过的判断说成结论。

⚠️ **「小数字误报」同样危险，甚至更危险**（2026-09-30 实踩，已向用户口头报错）：
临时探针报出「2 处重复登记」，数字看着很合理，我直接报给了用户；
后来用生产脚本（看板）复核发现**当月 0 处** —— 是探针自己的店铺字段匹配错，飞书表里那些店只名只有 1 条。
- **规矩：探针数出的异常，先跟生产脚本/看板交叉对一次再开口。**
- 两个口径不一致时，**先查哪个错了**（打印两边实际算到的记录数最直接），别忙着让用户去改表。
- 反过来说：**大的异常先怀疑自己（363→71），小的异常也要交叉验证（2→0）**。
  两种都不是“对自己结果的信心问题”，而是“上报前多一道对账”。

**检测「重复登记」这类规则时的分类法**（十一 2026-09-30 定义，已写进 `daily-report-dashboard`）：
- 同一天同一店铺 **≥2 条 = 异常**（一天一店只应登一遍）
- 两次数值**完全一样** → **重复提交**，删一条即可
- 两次数值**不一样** → **数据冲突**，必须核对该店当天真值（当天汇总会算错，最危险）
- 探针脚本可直接抄：`references/field-matching-and-data-quality-probes.md`

### 🔴 真正动手删重复时的四条硬规矩（2026-10-08 实做：全表 6,399 条 → 70 组重复 → 删 67 条）

十一 说「**把飞书表格内数据重复的删除一下**」时，按这个顺序做：

**① 先把全表 dump 成本地 JSON，再做所有分析。**
**别在翻页循环里逐条做字段解析/归一化** —— 那样每页都要跑一遍重逻辑，实测 **>420s 超时**
（前台 terminal 超时一次；换后台跑 6 分钟仍无输出，只能 kill）。拆成两步快得离谱：

```python
# dump_daily_raw.py —— 只存 rec + 原始 fields，循环里不做任何解析
rows.append({"rec": it["record_id"], "fields": it.get("fields", {})})
# 实测：6,399 条 / 13 页 / 26 秒
```

落地后所有查重/统计都读本地 JSON，**秒级**，还能反复换判定规则试算而不用再拉一次网络。

**② 判定「重复」要比【业务值】，不能比【整条记录签名】。**
第一版把整条 record 序列化成 JSON 当签名 → **70 组全被判成「值冲突」、可删 0 组**，
因为 `问卷编号`、创建时间这类**元数据每条都不同**，签名必然不等。
✅ 正解 —— **只用业务值当比较键**（本表 = `当日总业绩 or 净业绩`）：

```python
vals = {(x["p"] or 0) for x in items}
if len(vals) == 1:      # 业绩一致 → 重复录入，保留先提交的那条（问卷编号小），删其余
    ...
else:                   # 业绩不同 → 数据冲突，一律不动
    conflict.append(...)
```

本次结果：**66 组可删（共 67 条）/ 4 组冲突**。
⚠️ 70 组里有 **60 组是早期（1~3 月）用问卷重复提交、业绩为 0 的空记录** —— 一并清掉，
「近30天重复登记」随之从 3 处变 0 处（4 组冲突都在 6~8 月，已出 30 天窗口）。
⚠️ 日报/看板只统计**近30天**，所以它显示「3 处」而全表其实有 70 组 —— 别被小数字骗到，**先跑全表**。

**③ 值冲突的组【不要自动删】，先给判断依据再让他拍板。**
删哪条会直接改历史数据，猜不得。做法：**打「争议日 ±4 天、同店、逐日业绩」**，量纲一眼可判：

```
蒙倩美发旗舰店（炜） ｜ 争议日 2026-07-29   15116.34 / 3154.97
   07-25  1057.90     07-30  3449.69
   07-26  2627.88     07-31  1177.83
   07-27  2446.96     08-01  1341.17
   07-28  2994.69     08-02   956.12
→ 日常 1000~3500 ⇒ 3154.97 合理；15116 是平时的 5 倍
```

报告要给**建议留哪条 + 理由**；两个都合理的单独列出让他定（本次 4 组：2 组可判、2 组需他定）。

**④ 删前备份全字段，删后逐条复核。**
- 先按 `record_id` 逐条 `GET .../records/{id}` 把**完整字段**存 JSON（本次 67 条 → `daily_dups_backup.json`），误删可回写。
- `batch_delete` 之后**再逐条 GET 一遍确认取不到**（本次「仍存在 0 条」）；
  只信 `{"deleted": true}` 不算完成 —— 用 `data.total` 前后对比（6,399 → 6,335）更直观。
- 报告里主动交代备份路径 +「要回滚随时说」。

## 把 Excel 里的历史数据**回填**进线上登记表（2026-10-01）

场景：十一说「**这张表里的 X 列是空的，你把附件里的数据填到对应店铺**」。
完整 recipe（解出分块 xlsx + 写前确认清单）：`references/backfill-history-into-live-table.md`。

### ⚠️⚠️ 写线上表 ≠ 出成品：这一步**必须先确认再写**

先把两类活分清，否则会拿错态度：

| 他要的东西 | 正确做法 |
|---|---|
| **一个成品文件**（xlsx / 看板 / 名单） | **别问，先出成品**（口径差异写进「口径与假设」sheet）—— 见 `references/monthly-metric-contest.md` 教训 1 |
| **写进线上表 / 改线上数据** | ⛔ **先确认再写**。不可逆（API 能写但没撤销）、运营正在用、写歪了要人工一行行擦 |

- 界线：**做错了重做成本低 → 直接做；做错了要人工善后 → 先问。**
- 确认要**一次问完（≤ 5 条），别分批问**，也别为了不问而自己猜。
- 本次正确做法：先把数据全解出来（能报出每店的值），再列 5 条待确认（填哪天 / 缺的 2 个店名 / 个人店要不要 / 范围 / 用 API 还是给他文件），**明确写“你回这几条我就开干”**。

### ⚠️ 分块式 xlsx 的两个坑（源表是「每店一块横着排日期」的宽表时）

1. **列名和它的数据可能隔了上百列。** 本次表里 D 列写着「近90天用户评价得分排名」，
   而**值在 IF~NU 列（第 240~385 列）** —— 只扫标签右边几列会得到「**全是空的**」的错误结论。
   **正确动作：先扫「这一行的全部非空列」（打印列号+值），再判断有没有数据。**
   同理：先 `maxcol = max(所有单元格的列号)` 摸清表到底多宽（本次到 NY = 第 389 列）。
2. **表头是 Excel 日期序列号**（`45909` 这种），不是日期。换算：
   `datetime.date(1899,12,30) + timedelta(days=n)` → `45909`=2025-09-09。
   **横向定日期、纵向定店铺，两边都要先对齐才能算“最新一天”。**
3. **块内店名单元格可能是空的**（合并单元格 / 只填了简称）—— 本次 22 个块里 2 个没店名。
   ⛔ **不要按位置猜它是哪家店**；把缺的那几个点名问十一（猜错就是往错的店写数）。

### ⚠️ 写数值列之前，先拉 5 条**已有行**对齐量纲（2026-10-04 实踩，白写了一轮）

同一列「近90天用户评价得分排名」：我先按**百分比数值**（`0.2694` → `26.94`）写入 3,179 条，
十一随即要求改回**小数**（`0.2694`）→ 只能**全量重写第二遍**。

**根因**：我只看了 Excel 源表（同一列里混着 `0.2847` 和 `26.54` 两种形态，以为要统一成百分比），
**没看飞书目标表这一列已有什么值**。表里另有一列「领航员综合分行业排名」是 `0.23` ——
那才是这张表的量纲约定，**拉 5 行看一眼就能定下来**。

**规矩**：
1. **写数值列前先 `GET .../records?page_size=5`**，打印该列已有值 + 相邻同类列的值
   → 量纲（0~1 小数 / 百分数 / 元 / 万元）一眼看清，比开口问更快也更准。
2. **口径一旦定了就写进交付说明**（哪怕用户没问），下次同一个字段才能直接对齐。
3. **改口径 = 全量覆写**，没有「只改格式」的捷径；且必须**从原始源值重新转换**，
   **不能在已写入的值上二次换算**（`0.2694 → 26.94 → 再 ÷100` 就乱了）。
   ⇒ 所以**回填前把源值备份成 JSON**（含业务键），改口径时才有干净的输入。
4. 这类返工不挨骂，但**烧的是他自己的时间窗口** —— 一次确认好过两轮写入。

## Pitfalls (each cost a retry this session)

1. **主字段可以「改名」，但不能「删」——旧版本这条写错了，2026-09-25 已实测更正。** 新 Base 会自动创建一个名为 `文本` 的 primary Text 字段（`is_primary: true`）。
   - ❌ `DELETE .../fields/{primary_id}` → `code:1254046` —— **删是真的删不掉**。
   - ✅ `PUT .../fields/{primary_id}` body `{"field_name":"日期文本","type":1}` → **`code:0 success`，改名成功**（本次实测）。旧文写"PUT 改名也失败 99992402"，**是被 `PATCH` 误导的**：`PATCH` 同路径返回 `None`（无响应体）且不生效，看到 `None` 别当成"飞书拒绝"，换 `PUT` 再试。
   - **实操建议**：主字段当 `日期文本`（或`编号`）用，另建一个真正带类型的 `日期`（type 5）——一列给人看，一列给筛选/排序用。改名后记得计算记录 dict 时都用新名字。
2. **New Base ships sample fields** (文本/单选/日期/附件/数字/复选框). Delete the noise ones (they pollute the table) — but NEVER delete the `is_primary: true` one. Deleting other sample fields works via `DELETE .../fields/{id}`.
3. **Field-name collisions are silent.** Adding `收件人姓名` twice succeeds (code 0) and you end up with a duplicated field. Always `List fields` first and check names before adding.
4. **`config.yaml` is write-protected for the agent** — `patch` on it is refused (“Refusing to write to Hermes config file”). Use `hermes config set <key> <value>` instead (works, incl. nested like `moa.aggregator.provider`), or have the user edit it by hand. For nested array values `hermes config set` may warn “not a recognized config key” — verify with a read-back after.
5. **Windows paths: native tools don't get MSYS translation.** Use forward-slash Windows paths (`E:/软件/...`) for Python/curl file args; `/tmp` is not readable by a Windows Python. Pass the token via file or re-read `.env` inside the script rather than relying on a shell export.
6. **Create a FRESH Base when the goal is a clean table** — cheaper than deleting 5 sample fields + repurposing an immutable primary.
7. **Column-name / table-name mismatch does NOT prove you're on the wrong Base — verify by RECORD VALUE instead.** Different *views* of the SAME Base can render renamed columns (a view showing `业绩` / `全店净资产` / `成交单量` for raw fields `当日总业绩` / `全店净投产` / `成团单量`), and a screenshot's bottom record count is usually the *filtered view* count, not the table total — so name and count mismatches are expected and are NOT evidence of a wrong link. This session I wrongly concluded "wrong table" from exactly that and spent several turns asking for links the user had already given correctly. **The decisive test: cross-check ONE record's identifying value** (e.g. 问卷编号 + 净业绩) between your API pull and the user's screenshot. Values match → same data; the discrepancy is elsewhere (check dates/timezone first). No match → only then ask for the correct link. Still do `GET .../tables` to confirm the real table inventory, and never report counts for a table you haven't confirmed.
8. **Date-based questions ("昨天/前天登记了多少") need BOTH a calendar anchor AND the right timezone.** Confirm today's date from the system before computing 昨天/前天, and state both the date AND the count. Then convert timestamps in UTC+8 (see the `日期` bullet above) — this session a UTC conversion is what manufactured the false "昨天 0 间" answer. Note the newest data row landing on the *previous* calendar day is normal for a same-day 登记 form; do not read that as "nobody filled it in". **If the user pushes back on a date/count answer ("我怎么看昨天是23个呢"), treat it as a signal to RE-DERIVE, not to re-explain or apologise-then-repeat.** Re-check the conversion, match one 问卷编号+值 against their screenshot, and only then answer again.

9. **`batch_create` 里只要有一个字段名不存在 → 整批 500 条全部被 reject。** 报 `{"code":1254045,"msg":"FieldNameNotFound","error":{"message":"Invalid request parameter: 'records[0].fields.日期文本'. Correct format : field_name not found."}}` —— 文案只点名 `records[0]`，看着像"第 0 条的问题"，**实际是一条都没进去**。
   - **所以批量导入前先 `List fields` 拿真实字段名，记录 dict 的 key 严格按它来。** 本次同一个导入函数套两张表，表1 有 `日期文本` 主字段、表2 没有（表2 的主字段就叫 `日期`），于是**表1 进 7,231 条、表2 白跑 15 批全失败**。
   - 两张表字段不同时，**不要把主字段列硬写进两份记录**；按各表实际字段分别构造。
10. **新 Base 的默认表自带空行，会让 `total` 比你导入的条数多。** 本次导完 7,231 条后 `total` 显示 7,241（多 10 行）。核对时不要把这 10 行当成"重复导入"—— 用 `GET .../records?page_size=100` 找出 `fields` 全空的 `record_id`，再 `batch_delete` 清掉。
11. **报数前先把「导入成功条数」和「表内 total」分别打印出来对账。** 本次两表最终 `7,231 / 7,320`，与源数据完全一致；这类"导入"任务如果只看 `code:0` 就宣布成功，漏批是看不出来的（表2 当时报了 15 个 `code` 但全是 1254045，只有把失败数计出来才看得到）。
12. **视图的筛选/分组/排序**和**表单视图的配置**，飞书 OpenAPI **都不支持**：`PATCH /views/{vid}` 带 `filter`/`filter_info`/`group_info` 均返回 `code:0` 却**不生效**，`GET /views/{vid}` 的 `property` 恒为 `null`；表单视图建出来后 `GET`/`PATCH` 直接报 `{"code":1254019,"msg":"The view type is invalid"}`（报文里点明 `modifications to the form view is not supported`）。**API 只能「建一个空视图」。**
    - **判定视图是否真生效看 `GET .../records?view_id={vid}` 的 `data.total`**（等于全表条数 = 没生效），别信 `code:0`。
    - 这件事只能交给用户在 UI 里点 ⇒ **要主动说明限制，不要承诺「我帮你把视图配好」**（本次照着旧笔记的错说法试了 5 种参数，白跑好几轮）。
13. **用户说「把表格管理权限给我 / 我要所有者权限」** → 走 `drive/v1/permissions` 系列（见上表）。应用自建的 Base，owner 是应用；`transfer_owner` 可以真转走，**转完用 `metas/batch_query` 读 `owner_id` 自证**。拿用户 open_id 用 `GET /contact/v3/users`，不用问他。
14. **删表不可逆，且用户会改主意。** 本次用户先说「合并在一个表格」，我建了合并表后他选 A 删掉两张原始表 —— **本地 JSON 备份先落盘再删**（`D:\Agent.GongZuoQu\Hermes.GZQ\数据--运营登记\`），这样删错了还能重跑。删除前用 `GET .../records?page_size=1` 的 `total` 分别打印「导入成功条数 / 表内 total / 源数据条数」三方对账。

## IM message history (read @消息 / 待办)

- `GET /im/v1/messages?container_id_type=chat&container_id=<chat_id>` reads message history — **but requires a real `chat_id`**; a fake id returns `code:230001 invalid container_id` (the endpoint EXISTS, so confirm permission/context, not existence).
- `GET /im/v1/chats` returns `code:0` but an **empty list** with a *tenant* token (the app doesn't see all chats). The bot must actually be pulled into a group / have a chat and someone must @ it; otherwise there is no history to fetch.
- In gateway logs: **inbound** = messages sent TO the bot (someone else→you); **outbound** = the bot's replies. `inbound message: platform=...` is what the user sent.

## Working evidence
十一's Feishu app (`cli_aa1fb172da38dbce`) is wired with Bitable scope. A “售后补发表” Base was created this session: `app_token=Q864b8hXBaB9cNsxMRVcU40sntb`, default table `tblvjnUSy9p0Ab7O`. See `references/feishu-bitable-notes.md` for the reproduce trace.

### 应用名查询（叫十一授权时必用）
`GET /open-apis/application/v6/applications/{app_id}?lang=zh_cn` → `data.app.app_name`。

**⚠️ 应用名会被十一改，告诉他要搜什么之前必须先跑这个接口拿当前名字。** 实测：`cli_aa1fb172da38dbce` 2026-09-17 叫 **`Hermes`**，2026-09-21 已改成 **`爱马仕.Hermes`**。搜错名字他会白等一轮（这个坑已经发生过两次）。

### 已确认可读的 Base 清单（2026-09-17 实测）
| 表 | 标识 | 备注 |
|---|---|---|
| 运营数据登记（运营日报/周报数据源） | base `Q6PZbQRH3aZum0skE3Pc8WCVnPh` / table `tbl9bX2VE4PXRRiM` | 日志字段见 `feishu-yunying-daily-report` 技能 |
| 售后补发表 | base `Q864b8hXBaB9cNsxMRVcU40sntb`：`tblvjnUSy9p0Ab7O` 数据表 / `tblCTmcVTYrv9RKE` 组合货品表 | 应用自建 |
| **店铺主体公司业绩登记-情况** | wiki `QFIPwzVtuixfRik0P1scPmDynAf` → app_token `Uoz1b1LSGaHGbDsL3vDc4lGcnag` / table `tblrdREDnYFr0Si6` | 首个靠“加协作者”开成功的 wiki 表（**该表没开高级权限**，所以协作者路线管用） |
| 同上·**主体&店铺绑定记录** | 同 base / table `tblDyrr0HiSeQzhw` | **2026-09-21 开通**，走的是「高级权限→角色→数据表权限」；字段=`平台/店铺名/承接主体/当前（新/旧）承接店铺`（+起止日期、备注），86 条 |
| 同上·**【主体&法人】信息登记表** | 同 base / table `tblGAhZkE4UojTlb` | ⛔ **应用读不到**（`1254302`，2026-10-07 复测仍挡）→ 只能走上面的浏览器页内接口。**21 字段 / 44 条**（43 家有公司名 + 1 条空行）。字段=主体公司名/是否绑定店铺/执照属地/状态/统一社会信用代码/注册日期/法人/股东1/股东2/财务办税人/法人手机号/法人身份证号/对公账户信息/税务局密码/身份证正反面/主体执照/公章/相关合同/备注。🟡 **含身份证号、手机号、税务局密码、身份证照片** → **绝不落工作区文件/记忆/IMA**。（十一 2026-10-07 明确：**只排除**「税务局密码 / 身份证正面 / 身份证反面」3 列，其余照统计）。⚠️ **`是否绑定店铺` 这个列名是错的** —— 它装的是**备注文本**（`否，需注销` 14 家 / `天猫,换主体` / `先计入10业绩，淘宝转主体` / `申请工厂撤资中`，其余 27 家为空），**真正的店铺绑定在 `tblDyrr0HiSeQzhw`**【店铺&主体】承接表**。→ 别按列名直接回答「这家主体绑了哪几个店铺」，也别把它当作绑定关系的数据源。（2026-10-07 实踩：先按列名报了一版「绑定店铺」，回头才发现列里全是注销备注）|
| 同上·**人员信息登记表** | 同 base / table `tbljtTdiHsU9fIYD` | 7 字段：姓名/身份证号/联系方式/身份证正反面/备注等 |

**店铺主体公司业绩登记-情况**：21 字段、754 条、2025Q3~2026Q3；主体公司去重 **43 家**、店铺 40 家；字段=平台/店铺名/年份/季度/月份/业绩/转账推广费/技术服务费/主体公司/【支出·收票】项目/仓储快递(支出)/货款转账(支出)/其他花费(支出)/【收款方·开票方】主体公司/【进项票】开票金额/开票编号/凭证附件/提交人/备注。它是**业绩端 + 支出端混在一张表**：⚠️ 约 **336 条没有店铺名/平台**（支出端挂账行）、6 条缺年份、202 条缺提交人——统计前先过滤，否则会把空行算进去。

### 131006 修复闭环（本次走通的完整链路）
用户说“看不到” → 探针报 131006 → 告诉他要 **① 把文档/表加应用为协作者（文档应用里搜 `Hermes`）+ ② 后台勾 `wiki:wiki:readonly` 并发布版本** → 用户弄完后重跑 get_node，`code:0`，立刻就能读。两件缺一不可。

## Related
- `feishu` (read links) — the read-only sibling.
- `productivity/xlsx` for the Excel-side conventions.
