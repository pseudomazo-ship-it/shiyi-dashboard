# 飞书多维表格 OpenAPI 实操坑（2026-09-25 建成「蒙倩·运营数据登记」实测）

## 建 Base / 建表
- 新建 Base：`POST https://open.feishu.cn/open-apis/bitable/v1/apps` body `{"name":"..."}`；
  返回 `data.app.app_token` + `data.default_table_id`（**注意 default_table_id 在 data 层，不在 app 里**）。
- **新建的 Base 归「应用」名下**，用户可能要另加协作者才能看到——建完先把链接发用户确认能打开。
- **建表必须带 fields**：`{"table":{"name":"x","fields":[...]}}`；fields 传空数组报 `99992402 field validation failed (the min len is 1)`。

## 字段
- **主字段（第一个字段）删不掉**：DELETE 返回 `1254046`。只能：改名 / 保持 / 后续用它存“日期文本”之类的键值。
- **改名用 PUT，不要用 PATCH**：`PUT /tables/{tid}/fields/{fid}` body `{field_name,type,property}`。PATCH 返回空（无 code/msg），看不出报错。
- **单选项先建再写记录**：`PUT` 字段带 `property.options:[{name:"蒙倩旗舰店"},...]`。
- 类型码：`1` 文本｜`2` 数字(`property.formatter` 用 `"0"`/`"0.00"`/`"0.0000"`)｜`3` 单选｜`5` 日期｜`17` 附件｜`1001` 创建时间。
- 日期字段可以是主字段；同时想要“可读日期”可另加一个文本字段存 `YYYY-MM-DD`。

## 写记录
- 批量：`POST /tables/{tid}/records/batch_create`，**每批上限 500 条**。
  实测 1.4 万条 ≈ 30 批、1~2 分钟；批间 `sleep 0.25s` 稳。
- **日期字段传毫秒时间戳**，按 UTC+8 折算。
- **数字字段读回来是字符串**（`"74.5"`），别直接当 float 用。
- 字段名写错 → `1254045 FieldNameNotFound`（records[].fields 的 key 必须是**已存在**的字段名，多传一个不存在的字段名会让整批失败）。
- **表内 `total` 会含新建时自带的空行**：导完先 `GET records?page_size=100` 找出 fields 全空的、`batch_delete` 掉。

## 视图 ⚠️ 只能「建」，不能「配」（2026-09-25 实测，在这上面白跑好几轮）
- 建视图：`POST /tables/{tid}/views` body `{"view_name":"按运营分组","view_type":"grid"}` → `data.view.view_id`。**这个接口只有 view_name / view_type 生效，仅此而已。**
- **筛选 / 分组 / 排序无法通过 OpenAPI 设置** —— 以下五条路**全部失败，别再试**：
  1. `PATCH /views/{vid}` body `{"property":{"filter":{...}}}` → `code:0 success` **但没生效**（记录数仍是全表 7,476）
  2. 同上换 `filter_info` → 无响应体；换 `group_info` → `code:0 success` 但同样不生效
  3. `POST /views` 时就带上 `property` → `code:0`，照样不生效
  4. `PATCH /views/{vid}/filter` → `404 page not found`
  5. `GET /views/{vid}` → `{"view":{...,"property":null,...}}` ← **看这个字段判生效，它永远是 null**
- **判定视图是否真生效的唯一硬指标**：`GET .../records?view_id={vid}&page_size=1` 看 `data.total`。等于全表条数 = 没生效。**别信 `code:0`。**
- **`view_type:"form"`（表单视图）能建，但建完就不能通过 API 动**：
  - `POST /views` 带 `{"view_type":"form"}` → `code:0`，能拿到 view_id；
  - 之后 `GET /views/{vid}` 与 `PATCH` 都报 `{"code":1254019,"msg":"The view type is invalid"}`，报文里点破原因：`"modifications to the form view is not supported"`。
  - ⇒ **表单的字段顺序 / 必填 / 说明 / 分享链接，只能让用户在飞书 UI 里配**（Base → 点该表单视图 → 右上角「表单配置」→ 配完在面板里点「分享」拿真正的 `share/base/form/shrcn...` 链接）。
  - ⚠️ **你给用户的 `?view=<form_vid>` 是内部视图链接，不能直接发给运营填** —— 要说清「对外表单链接只能在表单配置面板里拿」。
- **权限按版本分**：高级权限（按人限制只能改自己的行）需企业版；普通版只能靠视图筛选让人「看见」自己的，**挡不住改别人的**。而视图筛选又只能用户在 UI 里加 ⇒ **这块要明确交给用户手动做，不要承诺 API 能搞定。**

## 协作者 / 所有权（2026-09-25 实测走通）
用户说「把表格管理权限给我」「我要所有者权限」时走这条：

| 动作 | 接口 | body |
|---|---|---|
| 加协作者 | `POST /drive/v1/permissions/{app_token}/members?type=bitable&need_notification=true` | `{"member_type":"openid","member_id":"ou_...","perm":"full_access"}` |
| 查当前协作者 | `GET /drive/v1/permissions/{app_token}/members?type=bitable` | —（`data.items[].member_type/member_id/perm`）|
| **转移所有权** | `POST /drive/v1/permissions/{app_token}/members/transfer_owner?type=bitable&need_notification=true` | `{"member_type":"openid","member_id":"ou_..."}` |
| 放开链接分享 | `PATCH /drive/v1/permissions/{app_token}/public?type=bitable` | `{"link_share_entity":"tenant_editable"}` |
| 查文档归属 | `POST /drive/v1/metas/batch_query` | `{"request_docs":[{"doc_token":"<app_token>","doc_type":"bitable"}],"with_url":true}` → `data.metas[].owner_id` |

- `perm` 取值：`view` / `edit` / `full_access`。用户要「管理权限」就给 `full_access`。
- **应用自建的 Base，owner 是应用**；`transfer_owner` 一次 `code:0` 就真转过去了 —— **必须用 `metas/batch_query` 读回 `owner_id` 验证**（本次读回 = 十一的 open_id，才算数），**不要凭 `code:0` 宣布成功**。
- **拿用户 open_id 不用问他**：`GET /contact/v3/users?page_size=20` → `data.items[].open_id`（本租户就 1 个用户，直接就是十一）。
- **找不到用户那个 Base 的 app_token 时**：`POST /suite/docs-api/search/object` body `{"search_key":"运营数据","count":20,"offset":0}` → `data.docs_entities[]` 带 `docs_token`（就是 app_token）/ `docs_type` / `title` / `owner_id`。**比问用户要链接快**（本次就是这样一步找到 `Q6PZbQRH3aZum0skE3Pc8WCVnPh`）。
  ⚠️ 分享链接 `share/base/query/shrcn...` 里的 `shrcn...` 是**分享 ID，不是 app_token**，取不到 —— 要么让用户给 `my.feishu.cn/base/<app_token>` 形式的链接，要么用这个搜索接口自己查。

## 读飞书 Base 原始 Excel（附带坑）
- openpyxl 报 `TypeError: Fill() takes no arguments` / `expected <class 'openpyxl.styles.fills.Fill'>`
  = 该 xlsx 的 `xl/styles.xml` 非法（WPS/第三方导出常见），**`read_only=True` 也救不了**。
- 兜底：zipfile 手工解析 —— `xl/sharedStrings.xml`（串池）+ `xl/worksheets/sheetN.xml`（单元格）。
  `t="s"` 的值是**串池下标**；日期是 Excel 序列号，`1899-12-30 + days` 还原；`t="inlineStr"` 走 `is/t`。

## 宽表 → 多维表格长表（转表通用套路）
- Excel 里「一行=一天，多列=各店铺」的宽表，**必须拆成长表**（一行一条：日期/主体/指标/值），否则运营填表要横向数列、插列就错位。
- 长表落飞书时：用**单选字段**存主体（店铺/人员），**独立字段**存指标 → 加人加店不动结构。
- 表头里的“简称+人名”（如 `美发官方\n丽丽姐`）要先跟主数据表建映射，**统一成全名 + 规范人名**，否则同店多写法会把统计拆碎。
- 汇总行（“汇总”“合计”“2月汇总”）**必须排除**，否则会污染成“店铺名=汇总”的记录。
