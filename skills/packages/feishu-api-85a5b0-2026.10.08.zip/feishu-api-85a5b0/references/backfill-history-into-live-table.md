# 把历史数据回填进线上登记表（含分块 xlsx 解码）

来源：2026-10-01。十一给一个附件 `店铺数据（每日登记）-2.xlsx`，
说「飞书表（`S3r3bHOeXaEJzXsNTfUcpC2Mncd` / `tbl4h3Q7tsHljiwS`）里的
**近90天用户评价得分排名**是空的，你把文件里的数据填到对应店铺」。

---

## 一、第一步不是写，是「先确认再写」

写线上表**不可逆**。把待确认项**一次问完**，并明确告诉他「你回这几条我就开干」。
本次问的 5 条（可当模板）：

1. **填哪一天的值？** A 只填最新一天 / B 按日期逐日回填 / C 其他
   （他的表里这列是**逐日历史值**，只填一天和逐日回填是完全不同的工作量）
2. **块里店名是空的那几个是哪个店？**（不要猜）
3. **个人店填还是跳过？**
4. **两边店铺范围不一致时怎么办？**（只填交集 / 其余留空）
5. **我用 API 批量写，还是生成一份 Excel 给你手动贴？**

> 边界：**产出成品文件 → 别问先做**（见 `monthly-metric-contest.md` 教训 1）；
> **写线上数据 → 先问**。区分标准 = 做错了要不要人工善后。

---

## 二、openpyxl 打不开时：直接解 xlsx 的 XML

**症状**：`load_workbook()` 直接抛
```
TypeError: Fill() takes no arguments
expected <class 'openpyxl.styles.fills.Fill'>
```
（WPS / 某些国产表格软件导出的文件，`styles.xml` 不合 openpyxl 的口味）

**不要去修样式表 —— 绕过去。** xlsx 就是个 zip，只需要 3 个部件：

```python
import zipfile, re
from xml.etree import ElementTree as ET

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
z = zipfile.ZipFile(PATH)

# ① 工作表名
wbx = ET.fromstring(z.read("xl/workbook.xml"))
sheets = [s.get("name") for s in wbx.iter(NS + "sheet")]

# ② 共享字符串表（单元格 t="s" 时，v 里存的是它的下标）
root = ET.fromstring(z.read("xl/sharedStrings.xml"))
sst = ["".join(t.text or "" for t in si.iter(NS + "t"))
       for si in root.iter(NS + "si")]

# ③ 单元格：列字母 → 列号
def ci(ref):
    m = re.match(r"([A-Z]+)", ref); c = 0
    for ch in m.group(1): c = c * 26 + (ord(ch) - 64)
    return c

# ④ 读成 {行号: {列号: 值}}
sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
rows = {}
for row in sheet.iter(NS + "row"):
    r = int(row.get("r")); cells = {}
    for c in row.iter(NS + "c"):
        t = c.get("t"); v = c.find(NS + "v"); isel = c.find(NS + "is")
        if t == "s" and v is not None:            val = sst[int(v.text)]          # 共享字符串
        elif t == "inlineStr" and isel is not None: val = "".join(x.text or "" for x in isel.iter(NS + "t"))
        elif v is not None:                        val = v.text                  # 数字/日期序列号
        else:                                      val = ""
        cells[ci(c.get("r"))] = val
    rows[r] = cells
```

**三种单元格形态必须都兼容**（`t="s"` / `t="inlineStr"` / 纯数字），
只写一种会把大量单元格解成空。

> 另一条保底：如果只是要 openpyxl 能读，可先用 LibreOffice 中转
> `soffice --headless --convert-to xlsx in.xlsx --outdir out/` 重写一遍样式表。
> 但要**逐单元格保留原数据**时，直接解 XML 更可控。

---

## 三、分块式宽表的实际布局（本次结构，同类表通用）

```
r1      : 日期行（E 列起，值为 Excel 序列号 45909 → 2025-09-09）
r2~r8   : 汇总块（1星/2星/3星/4星/5星/评价总数/DSR）
r{N}    : 说明行      ← D 列 = 「近90天用户评价得分排名」
r{N+1}  : 店名行      ← D 列 = 店铺简称（可能是空！）
r{N+2}~ : 1星 / 2星 / 3星 / 4星 / 5星 / 评价总数 / dsr
...      : 每 9 行重复下一个店（本次共 22 块 / 219 行）
```

### 🔴 最大的坑：列名和数据隔了上百列

```
D 列（标签）      = 「近90天用户评价得分排名」
IF ~ NU 列        = 真正的值（第 240 ~ 385 列，0.13~0.63 的小数）
E ~ IE 列         = 别的东西
```

**只扫标签右边几列（E~L）→ 得到「全是空的」的错误结论。**
本次差点就这么报给十一了。

**正确探针**：
```python
# 先摸清表有多宽
maxcol = max(max(cells) for cells in rows.values())

# 再扫「这一行的全部非空列」，打印 列号 + 值
for r in sorted(rows):
    if "近90天" in (rows[r].get(4) or ""):
        print(r, {cn(k): v for k, v in sorted(rows[r].items()) if v and k >= 5})
```

### 日期换算（表头是序列号）

```python
import datetime
def xd(n):
    return (datetime.date(1899, 12, 30) + datetime.timedelta(days=int(float(n)))).isoformat()
# 45909 → 2025-09-09
```

**横向定日期 + 纵向定店铺，两边都对齐了才能算「最新一天的值」。**
本次：数据覆盖 `2026-05-01 ~ 2026-09-23`（146 天），最新一列 = NU = 2026-09-23。

### 块内店名可能是空的

本次 22 块里有 2 块（r161 / r215）D 列没店名（合并单元格或只填简称）。
⛔ **不要按位置猜是哪家店** —— 按上下文猜很容易差一家，而错位就是「把 A 店的排名写到 B 店头上」。
**点名问他，或者拿他给的截图对。**

---

## 四、写回飞书时的通用纪律

- **先 `GET .../fields` 拿真实字段名 + type**（他会改表结构）；
- **公式列（type 20）不写**（写不进去，让飞书自己算）；
- **`batch_create` 每次 ≤ 500 条**；一个字段名不对会**整批 500 条全 reject**（报 `1254045`）；
- **写前把「要写多少条 / 涉及哪些记录」报给他，写后 `GET .../records` 回读核对**，
  别拿 `code:0` 当成功。

---

## 五、🔴 写数值前先对齐**目标列的量纲**（2026-10-04 实踩，白写一轮）

本次后续：3,179 条按**百分比**（`0.2694` → `26.94`）写完后，十一要求改回**小数**（`0.2694`）
→ **全量重写第二遍**。

**为什么错**：只看了源表（Excel 同一列混着 `0.2847` / `26.54` 两种形态，便自行定为百分比），
**没看目标表这一列已有什么行**。表里另一列「领航员综合分行业排名」是 `0.23` ——
这才是这张表的量纲约定，**写之前拉 5 行就能定案**。

```python
# 写之前必做：看目标列已有值 + 相邻同类列
d = req_get(f"/bitable/v1/apps/{APP}/tables/{TABLE}/records?page_size=5", tok)
for it in d["data"]["items"]:
    f = it["fields"]
    print(f.get("日期文本"), "|", f.get("近90天用户评价得分排名"), "|", f.get("领航员综合分行业排名"))
```

**两条纪律**：
1. **量纲以目标列为准，不以源表为准。** 源表脏（混口径）不代表目标列没有既定约定；
   源表内部不一致时，**按目标表已用的量纲归一**（本次：`v >= 1` 则 ÷100 成小数）。
2. **改口径 = 全量 `batch_update` 覆写**，且**必须从原始源值重算**，
   **不能在已写入的值上二次换算**。⇒ 回填前先把源值（含业务键）存成 JSON 备份，
   不然改口径时没有干净输入。本次备份：`cache/rank_final.json`。

**报告话术**：口径定了就写进交付说明（「本列统一为 0~1 小数，与「领航员综合分行业排名」同口径」），
下次同一字段直接对齐，不用再问。
