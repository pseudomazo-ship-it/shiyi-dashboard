# 飞书多维表格：OpenAPI 被高级权限挡住时，走「浏览器登录态 + 页内接口」读全表

**实测日期**：2026-10-07　**场景**：十一给了一个 wiki 表链接问「表里每个主体的状态/法人/绑定店铺都看得见吗」。

## 为什么需要这条路

| 身份 | 能读到什么 |
|---|---|
| 应用身份（OpenAPI，`tenant_access_token`） | `tblGAhZkE4UojTlb` 报 `{"code":1254302,"msg":"RolePermNotAllow"}`；`GET .../tables` 的 `total` 只列得出权限内的表 |
| **十一自己的浏览器登录态** | **全部表 + 全部字段** |

高级权限挡的是**应用**，不是**他**。所以「应用读不到」的正确下一步是**换身份**，不是放弃。

⛔ **不要退回「截图 + 肉眼/OCR」**：飞书多维表格的网格是 **canvas 渲染**，`document.body.innerText` 里一个单元格文字都没有；
44 行 × 15 列要滚好几屏，还会把列读串（本次第一版就把「是否绑定店铺」和相邻列的值对错了位）。
**截图只适合「确认表名/列名长什么样」，取数必须走接口。**

## 第 1 步：预注入 fetch/XHR 钩子，重载页面拿接口 URL

页面数据是**加载时一次性取回的**，加载后再挂钩子已经错过 —— 必须用 CDP 在**文档创建前**注入，再 reload：

```python
hook = """
(function(){
  window.__resp = {};
  var of = window.fetch;
  window.fetch = function(){
    var u = arguments[0]; u = (typeof u === 'string') ? u : ((u && u.url) || '');
    var p = of.apply(this, arguments);
    try {
      if (/tablesv3|bitable/i.test(u)) {
        p.then(function(res){ try { var c = res.clone();          // ★ 必须 clone，否则消费掉原始 body
              c.text().then(function(t){ window.__resp[u] = t; }); } catch(e){} });
      }
    } catch(e){}
    return p;
  };
  var oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m,u){ this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(){
    var self = this;
    this.addEventListener('load', function(){
      try { if (/tablesv3|bitable/i.test(self.__u||'')) window.__resp[self.__u] = self.responseText; } catch(e){}
    });
    return os.apply(this, arguments);
  };
})();
"""
cdp('Page.addScriptToEvaluateOnNewDocument', source=hook)
js("location.reload()")
time.sleep(15)                                   # 等它把首屏请求发完
```

本次只关心**接口 URL**的话，用 `window.__cap` 记 URL 就够；要**响应体**才需要上面这版。

## 第 2 步：三个接口

```
# ① 首选：一次拿 schema + 全量记录（fieldMap + recordMap 都在里面）
GET /space/api/v1/bitable/{app_token}/clientvars
      ?tableID={table_id}&recordLimit=2000&ondemandLimit=2000

# ② 只取记录
GET /space/api/v1/bitable/{app_token}/records
      ?tableId={t}&viewId={v}&viewLazyLoad=true&offset=0&limit=3000

# ③ 表清单
GET /space/api/bitable/{app_token}/tablesv3/
```

**在页面上下文里 `fetch(u, {credentials:'include'})`** —— cookie/鉴权自动带上，不要在 Python 里重放。

### 坑

| 坑 | 真相 |
|---|---|
| `tablesv3` / `/fields` / `/datasource/list` 用 GET → `Failed to fetch` | 它们是 **POST** 接口。**别据此判定「接口不存在」** |
| `records?offset=43` 只回来 1 条 | `offset` 是**记录偏移**，页面懒加载时就是这么发的 → **全量要 `offset=0`** |
| `tablesv3` 只回了 4 张表里的 3 张 | 和 `GET .../tables` 是**同一个病**：只列权限内的表。**真实表数量要问登录态**（客户端变量/侧栏） |

## 第 3 步：解码（gzip + base64）

**标志**：`data.encoding == 0`，载荷是一串 `H4sIAAA...`（base64 的 gzip magic `\x1f\x8b`）。

```python
import json, base64, gzip, io

# ① clientvars：schema + 记录都在 data.table
tbl = json.loads(gzip.decompress(base64.b64decode(cv['data']['table'])).decode('utf-8'))
fieldMap  = tbl['fieldMap']      # 字段 ID → {name, type, property.options}
recordMap = tbl['recordMap']     # 记录 ID → {字段ID: {value: ...}}

# ② records：记录在 data.records（只有记录，没有 schema）
obj = json.loads(gzip.decompress(base64.b64decode(r['data']['records'])).decode('utf-8'))
recordMap = obj['recordMap']
```

**自检**：`obj['tableRecordNum']` 应等于你拿到的记录数（本次 `44 == 44` ✓）。

## 第 4 步：取值（🔴 和 OpenAPI 不一样）

两个关键差异，照抄 OpenAPI 的取值器会全错：

1. **记录的键是字段 ID**（`fldWlb68SD`），不是字段名 → 用同一次 `fieldMap` 翻名字。
2. **单选（type 3）回的是选项 ID**（`opt2i7blkf`），不是选项名 → 用 `fieldMap[fid]['property']['options']` 建 `{id→name}` 映射。

```python
def gv(fid, rec, fm, opts):
    cell = rec.get(fid) or {}
    v = cell.get('value')
    if v is None: return ''
    t = fm.get(fid, {}).get('type')
    if t == 3:                                   # 单选 → 选项 ID 要映射
        return opts.get(fid, {}).get(v, '')
    if t == 5:                                   # 日期 → 时间戳（>1e12 是毫秒）
        import datetime
        ts = int(v); ts = ts // 1000 if ts > 10**12 else ts
        return datetime.datetime.fromtimestamp(ts).strftime('%Y/%m/%d')   # 飞书日期列按中国时区想
    if t == 17:                                  # 附件 → 只取名字/数量
        return '有(%d) %s' % (len(v), '; '.join(a.get('name','') for a in v[:3])) if isinstance(v, list) else '有'
    if isinstance(v, list):                      # 文本(type 1) → [{text: ...}]
        return ''.join(x.get('text','') for x in v if isinstance(x, dict))
    return str(v)
```

字段类型码与 OpenAPI 一致：`1`Text / `2`Number / `3`SingleSelect / `5`DateTime / `17`Attachment / `20`Formula。

## 本次实测数字（2026-10-07）

base `Uoz1b1LSGaHGbDsL3vDc4lGcnag`（wiki `QFIPwzVtuixfRik0P1scPmDynAf`）

| 表 | table_id | 字段 | 记录 |
|---|---|---|---|
| 【主体&法人】信息登记表 | `tblGAhZkE4UojTlb` | 21 | 44（43 家有公司名 + 1 空行）|
| 店铺主体公司业绩登记-情况 | `tblrdREDnYFr0Si6` | 21 | 754 |
| 【店铺&主体】承接日期登记 | `tblDyrr0HiSeQzhw` | 8 | 86 |
| 人员信息登记表 | `tbljtTdiHsU9fIYD` | 7 | — |

**一次 `clientvars` 调用（239 KB 解压后）就拿到 schema + 全量 44 条**，比截图快两个数量级。

## 数据质量坑（本次实际发现，交付时要报告）

1. **列名装的不是那回事**：`tblGAhZkE4UojTlb` 的「**是否绑定店铺**」列实际装的是**备注文本**
   （`否，需注销` ×14、`天猫,换主体`、`先计入10业绩，淘宝转主体`、`申请工厂撤资中`，其余 27 家为空）
   —— **真正的店铺绑定在另一张表**（`tblDyrr0HiSeQzhw` 的 `承接主体`↔`店铺名`）。
   **列名与内容对不上时要主动告诉十一，别照列名解读。**
2. **两表主体集合不等**：资料表 43 家 vs 承接表 48 家 → **5 家有店铺但资料表无登记**
   （同人彩商贸襄阳市/徐州市珍髟商贸/徐州市耋饕商贸/襄阳市铃铛百货/银灰商贸襄阳市）→ 单独出一个 sheet。
3. **「当前承接」的判据**：承接表里 `承接店铺日期【尾】` 为空 = 仍在承接（本次 40 条新主体 / 46 条旧主体）。
   按这个数：**15 家资料表主体当前没有任何店铺** —— 要**点名让他确认**（可能是承接表没维护到位，也可能是真空的），不要默认为空。

## 合规边界（写下来免得下次踩）

- 走这条路的正当性 = **读的是十一自己账号可见的数据**，不是绕过权限去够别人的东西。**别越界。**
- 这张表含**身份证号 / 手机号 / 税务局密码 / 身份证正反面照片**。
  ⇒ **只在本地产出他要的成品，绝不写进记忆 / IMA / 公开看板**；
  ⇒ 十一明确「只排除那 3 列，其余照统计」时**照字面做**，但成品里仍只需他点名的字段，别顺手多带。
