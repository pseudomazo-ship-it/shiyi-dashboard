# Feishu Bitable create + field-setup reproduce trace (2026-09-04)

Ground truth for the working sequence used to build 十一's 售后补发表 Base. Every step returned `code:0` unless noted.

## 1. Permission prerequisite
App `cli_aa1fb172da38dbce` initially LACKED document scopes → `Access denied. ... [drive:drive, drive:drive:readonly, space:document:retrieve]` on `GET /drive/v1/files`. User granted the scopes in Open Platform and **published a version**; after that the same call returned `{"code":0,"data":{"files":[]}}`.

So: before blaming code, verify the app has the scope AND published. The reliable check is `GET /drive/v1/files?page_size=5` → code 0.

## 2. Create Base
```
POST https://open.feishu.cn/open-apis/bitable/v1/apps
-H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"
-d '{"name":"售后补发表"}'
```
Returns `app_token=Q864b8hXBaB9cNsxMRVcU40sntb`, `default_table_id=tblvjnUSy9p0Ab7O`; `name` may render mojibake in a bash echo but is correct.

Dropping a trailing `,"folder_token":""` (empty) triggered `code:9499 Bad Request` — omit it entirely.

## 3. Read the default table's fields
New Base ships `文本 (type1, primary)` + `单选 (type3)` + `日期 (type5)` + `附件 (type17)` + 数字/复选框. Primary `is_primary=true` and is named `文本`.

## 4. Add fields (type 1=text, 2=num, 3=select, 5=date)
```
POST /bitable/v1/apps/{app}/tables/{tbl}/fields
{"field_name":"收件人姓名","type":1}
{"field_name":"状态","type":3,"property":{"options":[{"name":"待组长核实"},{"name":"已完成"}]}}
```

## 5. Delete samples
`DELETE .../fields/{field_id}` for 单选/日期/附件 etc. Each returns `{"code":0,"deleted":true}`. Never delete the `is_primary:true` one.

## 6. Rename primary — DOES NOT WORK
```
PUT /bitable/v1/apps/{app}/tables/{tbl}/fields/{primary_field_id}
{"field_name":"补发单号"}
```
→ `code:99992402 field validation failed`. The primary Text field name is fixed. Keep it as column 1 (序号/备注) and add your own named fields.

## 7. Generated table (final, for reference)
fields = 文本(primary) / 收件人姓名 / 联系电话 / 收货地址 / 补发SKU / 补发数量(Number) / 原始订单号 / 补发原因 / 状态(SingleSelect) / ERP单号 / 核实人 / 创建时间(DateTime).

## 8. Cross-platform token handing
`hermes config` / `curl` run fine from bash, but a Windows-targeted Python (execute_code) can't read `/tmp/ftk.txt`. Read the token by parsing `E:/软件/Hermes/.env` inside the script, or curl the token endpoint fresh each time.
