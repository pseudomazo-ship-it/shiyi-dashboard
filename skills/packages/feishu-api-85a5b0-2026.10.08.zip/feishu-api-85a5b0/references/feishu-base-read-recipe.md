# Feishu Base read-by-API recipe (verified working recipe)

Goal: read all records of a Feishu 多维表格 (Base) table, e.g. to answer "date X registered N stores" or to pull a full table for analysis. Web extraction of Base/wiki links returns EMPTY (dynamic Base component) — always use the API.

## Working script (write to `cache/fetch_<x>.py`, run `python cache/fetch_<x>.py`)

```python
# -*- coding: utf-8 -*-
import json, time, datetime, urllib.request
from collections import Counter
from datetime import timezone, timedelta

CN = timezone(timedelta(hours=8))   # ⚠️ MANDATORY for 日期 fields — UTC gives off-by-one DAY

# Hermes home .env. Canonical = E:\RuanJian\Hermes\.env;
# the legacy E:\软件\Hermes\.env also still resolves — if one path is
# missing, read the other rather than declaring credentials unavailable.
ENV = r"E:\RuanJian\Hermes\.env"
BASE = "<app_token>"          # from my.feishu.cn/base/<app_token>
TABLE = "<table_id>"          # from ?table=<table_id> or GET /tables
OUT = r"E:\RuanJian\Hermes\cache\<x>.json"

app_id = app_secret = None
for line in open(ENV, encoding="utf-8"):
    if line.startswith("FEISHU_APP_ID="):    app_id = line.split("=",1)[1].strip().strip('"')
    if line.startswith("FEISHU_APP_SECRET="): app_secret = line.split("=",1)[1].strip().strip('"')

def request(path, payload=None):
    data = json.dumps(payload).encode() if payload else None
    headers = {"Content-Type": "application/json"}
    if payload is None and path.startswith("/bitable"): headers["Authorization"] = "Bearer " + TOKEN
    req = urllib.request.Request("https://open.feishu.cn/open-apis"+path, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())

# 1) per-run token (short-lived; never cache across calls)
tokd = request("/auth/v3/tenant_access_token/internal", {"app_id":app_id,"app_secret":app_secret})
TOKEN = tokd["tenant_access_token"]

# 2) resolve a wiki token -> base app_token (wiki links are NOT the app_token)
#    GET /wiki/v2/spaces/get_node?token=<wiki_token>  ->  data.node.obj_token, obj_type

# 3) list tables (confirm the real inventory before answering anything)
d = request(f"/bitable/v1/apps/{BASE}/tables")
print("tables:", [(t["name"], t["table_id"]) for t in d.get("data",{}).get("items",[])])

# 4) paginate all records
all_items, page_token = [], None
while True:
    p = f"/bitable/v1/apps/{BASE}/tables/{TABLE}/records?page_size=100"
    if page_token: p += "&page_token=" + page_token
    d = request(p)
    data = d.get("data",{})
    all_items += data.get("items",[])
    if data.get("has_more"): page_token = data.get("page_token"); time.sleep(0.2)
    else: break
print("TOTAL:", len(all_items))
with open(OUT,"w",encoding="utf-8") as f: json.dump(all_items, f, ensure_ascii=False)

# 5) aggregate by date — MILLISECONDS, converted in UTC+8 (NOT utcfromtimestamp)
day = Counter()
for it in all_items:
    ts = it.get("fields",{}).get("日期")
    if isinstance(ts,(int,float)):
        day[datetime.datetime.fromtimestamp(ts/1000, tz=CN).strftime("%Y-%m-%d")] += 1
for k in sorted(day): print(k, ":", day[k], "间")
```

## Key gotchas
- **`日期` = epoch ms, convert with `timezone(timedelta(hours=8))`.** `utcfromtimestamp` reads every Beijing date one day early (2026-09-05 → 2026-09-04) and silently produces wrong "昨天/前天" answers. This is the single highest-cost bug in this recipe — it already shipped one wrong answer to the user.
- **Verify identity by record VALUE, not column names.** Views rename columns and show filtered counts, so a table-name / field-name / record-count mismatch is NOT proof of a wrong link. Cross-check one 问卷编号 + value against the user's screenshot; if they match, debug the dates instead of asking for another link.
- **Share links (`/share/base/view/shr...`) return a login page to unauthenticated fetchers** even with 组织外可访问 on. Ask for the plain `my.feishu.cn/base/<app_token>?table=<table_id>` URL.
- `data.total` on `GET /tables` = how many tables the base holds — read the names, but don't over-trust a name mismatch (see above).
- Re-fetch the token every run: it expires (~55–120 min) and a stale one returns `code:99991663 Invalid access token`.
- Prefer running this as a `.py` file via `terminal python` for multi-page pulls; a `curl | python -c` pipeline can come back empty on Windows/MSYS. Re-run rather than concluding failure on a transient socket error.
