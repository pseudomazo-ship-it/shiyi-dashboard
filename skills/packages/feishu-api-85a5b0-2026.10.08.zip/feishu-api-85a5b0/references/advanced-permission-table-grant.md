# 飞书高级权限：给应用开「某张表」的读取权（2026-09-21 实战走通）

用户说“我给了你智能体的阅读权限”但 API 照旧 `1254302 RolePermNotAllow` 时，照本文做。
**结论：加协作者无效，必须改「角色 × 数据表」权限矩阵。**

---

## 0. 先分清三种权限失败（修法完全不同）

| 码 | 含义 | 修法 |
|---|---|---|
| `99991672` + “应用尚未开通所需的应用身份权限：[...]” | **应用级 scope** 没勾/没发版 | 后台 `open.feishu.cn/app/<APP_ID>/auth` 勾 scope → **发布版本** |
| `131006` permission denied: node | **知识库节点**没分享给应用 | 把文档/知识库**加应用为协作者**（走「文档应用」或「成员管理」） |
| `1254302 RolePermNotAllow` | **表级/高级权限**，文档级授权管不到 | **改角色×数据表权限矩阵（本文）** |
| `1254041 TableIdNotFound` | 不是这个 base 的表 | 链接/table_id 给错了 |

⚠️ 同一个 base 里可以**有的表能读、有的表报 1254302** —— 这本身就说明开了高级权限（按表分权）。
⚠️ 反过来：**如果这个 base 没开高级权限，加协作者路线是好使的**（`tblrdREDnYFr0Si6` 就是这么开的）。所以先判断有没有开，再选修法。

### 判断有没有开高级权限
浏览器打开该 Base 页 → 右上角「分享」→ 面板里找这句：
> `高级权限已开启，用户的权限同时受到角色设定限制 查看`

有这句 = 开了，走本文；没有 = 没开，加协作者即可。

---

## 1. 操作路径（让用户点，或授权后我代点）

1. Base 页 → 右上角「**分享**」
2. 面板底部那行提示 → 点「**查看**」（进高级权限面板）
3. 面板左侧 = 角色列表：
   ```
   系统角色：所有者 / 管理员 / 编辑者 / 阅读者
   自定义角色：<业务自定义角色名>
   ```
   选**应用所属的那个角色**。应用是「可阅读」权限 ⇒ 通常是**阅读者**；拿不准就挨个点开看右侧表权限。
4. 右侧「**数据权限 → 数据表权限**」= 表清单，每张后面跟当前权限：
   ```
   主体&店铺数据信息登记     仅可阅读
   【主体&法人】信息登记表     无权限
   【店铺&主体】承接日期登记    无权限      ← 目标
   人员信息登记表           无权限
   ```
5. 点中目标表行 → 下方出现**单选**：`仅可阅读` / `无权限` → 选「**仅可阅读**」
6. 点「**保存**」。⚠️ 页脚有两个按钮：`保存并预览` 和 `保存` —— **点「保存」**。
7. **立刻复验**：`GET /bitable/v1/apps/{app}/tables/{table_id}/records?page_size=3` → `code:0` 才算通。秒级生效，不用等。

### 只开需要的表
客户/人事类表（法人手机号、统一社会信用代码、人员信息）**不要顺手一起开**。只开业务需要的那张。

---

## 2. ⚠️ 飞书权限面板是自绘控件：`click_at_xy` 常常无效

实测：同一个坐标用 CDP 真点击点了 4 次，radio 状态纹丝不动；改用 **JS 点内部原生元素**，一次就中。
（CDP 也踩过坑：`cdp('Input.dispatchMouseEvent', ...)` 在长会话里会 `timed out after 5s waiting for the daemon`。）

### 找控件（先定位，再点）
```js
// 找 radio 的位置和当前状态
JSON.stringify(Array.from(document.querySelectorAll('.ud__radio__wrapper'))
  .filter(e => e.offsetParent)
  .map(e => ({t: e.innerText.trim().slice(0,8), ck: e.className.includes('checked'),
              x: Math.round(e.getBoundingClientRect().left+12),
              y: Math.round(e.getBoundingClientRect().top+e.getBoundingClientRect().height/2)})))
```

### 点它（React 监听冒泡；原生 `.click()` 能穿透自绘外壳）
```js
const w = Array.from(document.querySelectorAll('.ud__radio__wrapper'))
  .find(e => e.offsetParent && e.innerText.trim().startsWith('仅可阅读'));
(w.querySelector('input,input[type=radio],.ud__radio') || w).click();   // 先点内部 input
const lab = w.closest('label'); if (lab) lab.click();                   // 再补一发 label
```

### 选中左侧表行（列表项也是自绘的）
真点击点不动时，用 JS 派发完整事件序列到该行容器：
```js
const el = Array.from(document.querySelectorAll('[class*="block-menu-item"]'))
  .find(e => e.offsetParent && e.innerText.includes('承接日期登记') && e.innerText.includes('无权限'));
const rc = el.getBoundingClientRect();
['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t =>
  el.dispatchEvent(new MouseEvent(t, {bubbles:true, cancelable:true,
    clientX: rc.left+60, clientY: rc.top+rc.height/2, view: window})));
```

### 点保存
```js
Array.from(document.querySelectorAll('button,[role="button"],.ud__button'))
  .find(e => e.innerText.trim() === '保存' && e.offsetParent && !/预览/.test(e.innerText)).click();
```

**通用规律**：飞书/字节系（ud__* 前缀）的弹窗、权限面板、自绘下拉，`click_at_xy` 可能一直点不中，
但 `el.querySelector('input,.ud__radio,.ud__button') || el).click()` 往往一击即中。先试 JS click，别在坐标上反复调。

---

## 3. 不开权限也能摸清“到底有几张表、哪张能读”

`GET /bitable/v1/apps/{app}/tables` 在高级权限下**只列已授权的表**（实测 `total:1`，文档实际 7 张）。
别拿这个 `total` 当“文档只有一张表”去回复用户。

正确做法 —— 浏览器打开文档页，从 DOM 里扫全部 table_id：
```js
Array.from(new Set(document.documentElement.innerHTML.match(/tbl[A-Za-z0-9]{10,}/g)))
```
然后逐个探：
```python
for t in tids:
    r = req('/open-apis/bitable/v1/apps/%s/tables/%s/records?page_size=3' % (APP, t), token=TOKEN)
    print(t, r.get('code'), r.get('msg'))   # 0=可读 / 1254302=无权限 / 1254041=不属于本base
```
这一步能在**不打扰用户**的情况下把问题定位到“就是这一张表没授权”，回复用户时也更有说服力。

---

## 4. 授权后：拉数常量

```python
APP   = 'Uoz1b1LSGaHGbDsL3vDc4lGcnag'   # 店铺主体公司业绩登记
TBL   = 'tblrdREDnYFr0Si6'              # 收集结果
TBL_BIND = 'tblDyrr0HiSeQzhw'           # 主体&店铺绑定记录
```
绑定表字段 = `平台 / 店铺名 / 承接主体 / 当前（新/旧）承接店铺`（另有 `【起】承接店铺日期` / `承接店铺日期【尾】` / `备注`）。
落地时**只取前 4 列**写成 `主体绑定店铺情况【模版】.xlsx.xlsx`，列名必须完全一致（生成器会 `assert` 表头）。

⚠️ 即便飞书读通了，`records` 里 **type=2 数字字段仍是字符串**（见 SKILL.md「数字字段」条）——写 Excel 前统一转 float，否则下游 pandas `.sum()` 会把字符串首尾相接。

---

## 5. 沟通要点（十一这边）

- 他会说“**已经给了/保存了**”——**不要照单全收**，每次都在 API 上复验 `code`，并在回复里明确写“还是同一个错误码”。本轮他在协作者路线上白试了两轮。
- 一旦确认是高级权限，**一次把话说全**：给出三个选项（①改角色表权限 ②关掉高级权限 ③直接导出 Excel 兜底），并说明①②的副作用，让他挑，而不是挤牙膏式来回。
- 他说“**你直接远程我的浏览器操作**” = 授权我代点（但仍不碰表格数据）。改完把**结果截图/文本证据**回给他。
- 从截图判断他已点到哪一层：面板里若出现 `系统角色/自定义角色 + 数据表权限 + 保存并预览/保存`，说明已经站在正确面板里，直接给“点哪个角色、点哪张表”的坐标级指引即可。
