# 字段名匹配 + 数据质量探针（2026-09-30 实测）

## 为什么要有这份文档

十一说「**每个店铺每天只需要登记一遍，如果店铺名在一天中出现两次数据，这个也属于异常**」——
要把它做成看板里的告警块。**直接写规则 → 差点报出 5 倍虚高的数字**。
这份记录正确的顺序和两个真踩到的坑。

## 坑 1：字段名子串匹配命中错列（363 vs 71）

数据源：飞书 Base `Q6PZbQRH3aZum0skE3Pc8WCVnPh` / table `tbl9bX2VE4PXRRiM`（运营数据登记），6,187 条。

**真实字段名**（一定要先打印出来看）：
```python
print(list(items[0]["fields"].keys()))
# ['净业绩', '平台/店铺类型', '店铺名称（拼多多旗舰店）', '日期', '负责人', '问卷编号']
```

**错的写法**：
```python
for k in f:
    if "店铺" in k:          # ❌ 先命中 '平台/店铺类型'
        s = txt(f[k]); break
```
→ 所有行的 `s` 都变成 `拼多多/旗舰店`／`拼多多/个人店` → 每组都“重复” →
**报出 363 组，最近几天每天显示 ×21**（看着像全公司天天重复登记）。

**对的写法**（精确名优先 + 排除兄弟列）：
```python
def txt(v):
    if isinstance(v, list):
        return "".join(x.get("text", "") for x in v if isinstance(x, dict))
    return str(v or "")

def pick(f, cands, exclude=()):
    for k in f:
        if any(c in k for c in cands) and not any(x in k for x in exclude):
            return txt(f[k]).strip()
    return ""

shop = pick(f, ["店铺名称"], exclude=["类型"]) or pick(f, ["店铺"], exclude=["类型", "平台"])
```
→ **71 组**（真实值）。

## 坑 2：日期字段是 epoch 毫秒，必须按 UTC+8 转

```python
import datetime
tz = datetime.timezone(datetime.timedelta(hours=8))
def d2s(v):
    if isinstance(v, (int, float)) and v > 1e10:
        return datetime.datetime.fromtimestamp(v / 1000, tz).strftime("%Y-%m-%d")
    return txt(v)[:10]
```
（用 `utcfromtimestamp` 会把每天整体挪前一天。）

## 探针脚本（照抄改字段名即可）

```python
# -*- coding: utf-8 -*-
"""查「同一天同一店铺登记 ≥2 条」的重复记录 —— 只读探针，不动任何数据"""
import json, urllib.request, time, datetime
from collections import defaultdict

ENV   = r"E:\RuanJian\Hermes\.env"
BASE  = "Q6PZbQRH3aZum0skE3Pc8WCVnPh"
TABLE = "tbl9bX2VE4PXRRiM"

# ⚠️ 飞书是国内接口：必须先绕开本机代理（否则 127.0.0.1:7897 拒绝连接）
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))

aid = asec = None
for line in open(ENV, encoding="utf-8"):
    if line.startswith("FEISHU_APP_ID="):     aid  = line.split("=", 1)[1].strip().strip('"')
    if line.startswith("FEISHU_APP_SECRET="): asec = line.split("=", 1)[1].strip().strip('"')

def req(path, payload=None, token=None, tries=3):
    last = None
    for i in range(tries):
        try:
            data = json.dumps(payload).encode() if payload else None
            h = {"Content-Type": "application/json"}
            if token: h["Authorization"] = "Bearer " + token
            r = urllib.request.Request("https://open.feishu.cn/open-apis" + path,
                                       data=data, headers=h)
            return json.loads(urllib.request.urlopen(r, timeout=30).read().decode())
        except Exception as e:
            last = e
            if i < tries - 1: time.sleep(2 * (i + 1))
    raise last

def txt(v):
    if isinstance(v, list): return "".join(x.get("text", "") for x in v if isinstance(x, dict))
    return str(v or "")

def pick(f, cands, exclude=()):
    for k in f:
        if any(c in k for c in cands) and not any(x in k for x in exclude):
            return txt(f[k]).strip()
    return ""

tz = datetime.timezone(datetime.timedelta(hours=8))
def d2s(v):
    if isinstance(v, (int, float)) and v > 1e10:
        return datetime.datetime.fromtimestamp(v / 1000, tz).strftime("%Y-%m-%d")
    return txt(v)[:10]

tok = req("/auth/v3/tenant_access_token/internal",
          {"app_id": aid, "app_secret": asec})["tenant_access_token"]

# 拉全表必须用 GET /records（records/search 的 page_token 会假分页死循环）
items, pt, seen = [], None, set()
while True:
    p = f"/bitable/v1/apps/{BASE}/tables/{TABLE}/records?page_size=500"
    if pt: p += "&page_token=" + pt
    d = req(p, token=tok).get("data", {})
    items += d.get("items", [])
    if not d.get("has_more"): break
    pt = d.get("page_token")
    if not pt or pt in seen: break          # ← 防死循环保险，必加
    seen.add(pt)

print("总记录:", len(items))
print("字段名:", list(items[0]["fields"].keys()))   # ← 先看真实列名！

seen_key = defaultdict(list)
for it in items:
    f = it.get("fields", {})
    d = shop = ""
    for k in f:
        if "日期" in k: d = d2s(f[k]); break
    shop = pick(f, ["店铺名称"], exclude=["类型"]) or pick(f, ["店铺"], exclude=["类型", "平台"])
    if d and shop:
        seen_key[(d, shop)].append(f)

dups = {k: v for k, v in seen_key.items() if len(v) > 1}
print(f"\n重复（同一天同一店铺≥2条）共 {len(dups)} 组\n")
for (d, s), v in sorted(dups.items(), reverse=True)[:25]:
    print(f"  {d}  {s}  ×{len(v)}")
```

## 实测结果（2026-09-30）

- 全表 **6,187 条** → 重复 **71 组 / 涉及 47 天**
- 近 15 天内 4 处：
  - `09/24 蒙倩精油官方旗舰店 ×2` —— 数值完全一样（**重复提交**）
  - `09/02 蒙倩药妆官方旗舰店 ×2` —— **数值不同**（2532.63 vs 1784.82，**数据冲突**）
  - `09/01 蒙倩美容护肤官方旗舰店 ×2` —— **数值不同**（8375.18 vs 8113.74）
  - `09/01 蒙倩个人护理官方旗舰店 ×2` —— 数值一样（重复提交）

## 把这套接进看板时的落点（`daily_dashboard.py`）

- **Python 端 `build()`**：去重仍只取第一条（原来是 `seen[k] = 1`，要改成 `seen[k] = r["p"]` 才能比较），
  并把重复收进 `dup[日期][店铺] = {"n": 条数, "first": 第一条净业绩, "vals": [后续各条净业绩]}`，
  payload 里加 `"dup": dup`。
- **JS 端「数据提示」区**：在「③ 登记漏登」后加「④ 重复登记」块；只列近 15 天，
  按 `vals` 是否都等于 `first` 分「重复提交 / ⚠️ 必须核对」两种文案；
  顶部「有需关注项」计数要把 `dupAll.length` 算进去。
- 完整规则已写进用户自有技能 `daily-report-dashboard`。
