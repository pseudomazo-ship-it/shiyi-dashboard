# Excel 登记表 → 飞书多维表格：完整迁移 recipe

来源：2026-09-25 实操（十一的《店铺数据（每日登记）.xlsx》，7 sheet → 2 张飞书表，14,551 条）。全程走通，最终两表条数与源数据完全一致。

---

## Step 0 · 先决定结构：宽表必须拆成长表

判断依据与话术见 SKILL.md「把 Excel 登记表迁进飞书多维表格」一节。核心：

```
宽表  一行 = 一天，B~W 列 = 22 家店铺
  ↓
长表  一行 = 日期 × 店铺（+运营 +取值）
```

**飞书侧字段**（两张表都用了同一套骨架）：

```python
# 表1：评价有礼·每日登记
[{"field_name":"日期","type":5},
 {"field_name":"运营","type":3},          # 单选，选项后补
 {"field_name":"店铺","type":3},
 {"field_name":"花费金额","type":2,"property":{"formatter":"0.00"}}]

# 表2：DSR·每日登记
[{"field_name":"日期","type":5},
 {"field_name":"运营","type":3},
 {"field_name":"店铺","type":3},
 {"field_name":"1星","type":2,"property":{"formatter":"0"}},
 ... 2星/3星/4星/5星/评价总数 ...
 {"field_name":"DSR","type":2,"property":{"formatter":"0.0000"}}]
```

> 同一指标族的数值列（1星~5星）**分开建字段**，不要做成「指标名+值」两列——后者没法直接算 DSR，也没法按星级筛选。

---

## Step 1 · 读源 Excel（`openpyxl` 读不了时的手工解析）

### 症状

```
TypeError: Fill() takes no arguments
...
File ".../openpyxl/styles/stylesheet.py", line 76, in __init__
    self.fills = fills
```

连 `read_only=True` 也照样崩——**崩在 stylesheet 解析阶段，跟读数据无关**。常见于 WPS 另存 / 别的工具导出的 xlsx，`xl/styles.xml` 里有非法 `<fill>` 节点。

### 解法：手工解析 xlsx（xlsx 就是 zip + XML）

```python
import zipfile, re
from xml.etree import ElementTree as ET
from datetime import datetime, timedelta

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"

def xl2date(n):
    """Excel 序列号 → 日期字符串（45901 → 2025-09-01）"""
    try: return (datetime(1899,12,30) + timedelta(days=int(float(n)))).strftime("%Y-%m-%d")
    except: return None

with zipfile.ZipFile(path) as z:
    # 1) 字符串池
    shared = []
    root = ET.fromstring(z.read("xl/sharedStrings.xml"))
    for si in root.findall(f"{NS}si"):
        shared.append("".join(t.text or "" for t in si.iter(f"{NS}t")))

    # 2) 工作表名（顺序=sheet1.xml, sheet2.xml, ...）
    wbroot = ET.fromstring(z.read("xl/workbook.xml"))
    sheets = [s.get("name") for s in wbroot.iter(f"{NS}sheet")]

    # 3) 逐表读成 [{列名: 值}, ...]
    def read(idx):
        sx = ET.fromstring(z.read(f"xl/worksheets/sheet{idx}.xml"))
        rows = []
        for row in sx.iter(f"{NS}row"):
            cells = {}
            for c in row.findall(f"{NS}c"):
                ref, t = c.get("r"), c.get("t")
                v, isel = c.find(f"{NS}v"), c.find(f"{NS}is")
                if   t == "s" and v is not None:                    val = shared[int(v.text)]   # 共享字符串
                elif t == "inlineStr" and isel is not None:         val = "".join(x.text or "" for x in isel.iter(f"{NS}t"))
                elif v is not None:                                 val = v.text               # 数字/日期序列号
                else:                                               val = None
                if val not in (None, ""):
                    cells[re.match(r"([A-Z]+)", ref).group(1)] = val   # 列字母
            if cells: rows.append(cells)
        return rows
```

**关键点**：
- 单元格 key 用**列字母**（`A`/`B`/`AA`），比较时按 `(len(s), s)` 排序才是 B,C,…,Z,AA 的正确顺序（否则 `AA` 会排在 `B` 前面）。
- `t="s"` 是共享字符串索引；`inlineStr` 是内联；其余是字面值（**日期在这里是序列号，要 `xl2date` 转**）。
- 这一招对「文件本身格式坏」和「openpyxl 版本不兼容」都管用，不依赖任何第三方库。

---

## Step 2 · 宽表 → 长表（两个真实形状）

### 形状 A：列头就是店铺（评价有礼表）

```
行1:  A="店铺/平均有礼"  B="蒙倩旗舰店\n\n玉珍姐"  C="造型官方\n\n玉珍姐" ... X="汇总花费"
行2:  A=45901(日期)      B=74.5                    C=0                    ... X=980.9
```

```python
hdr = r1[0]
shop_cols = [c for c in hdr if len(c)==1 and "B" <= c <= "W"]
col_map = {}
for c in shop_cols:
    raw = str(hdr[c]).split("\n")
    col_map[c] = (raw[0].strip(), raw[-1].strip())   # (店铺, 运营)

recs = []
for r in r1[1:]:
    d = xl2date(r.get("A"))
    if not d: continue                    # 跳过「2月汇总」「合计」这类文字行
    for c in shop_cols:
        v = r.get(c)
        if v in (None, ""): continue      # 空格不产生记录
        shop, op = col_map[c]
        recs.append({"日期": d, "运营": op, "店铺": shop, "花费金额": float(v)})
```

### 形状 B：行是一组指标、列是日期（DSR 表）

```
行1:  A="汇总\n4.69731"  D="拼多多"  E=45909  F=45910 ...   ← 日期在第一行的 E 之后
行2:  D="1星"    E=1308  F=1243 ...
...
行8:  D="DSR"    E=4.66198 ...
行9:  A="蒙倩官方旗舰店\n\n朝玲"   ← 下一组的组头（A 列存店铺+运营）
行10: D="1星" ...
```

**⚠️ 块的精确形状（2026-09-26 复核）：每店 **9 行**一块** —— 组头行 + 8 个指标行（`1星 2星 3星 4星 5星 评价总数 dsr 近90天用户评价得分排名`）。取值靠**行偏移**：`组头行号 +1..+5` = 1~5星、`+6` = 评价总数、`+7` = dsr、`+8` = 近90天排名；下一块 = `+9`。实测组头在 `r9 → r18 → r27 …`，**间距恒为 9**。旧笔记写的「行8=DSR、行9=下一组组头」是漏算了新增的排名行 —— **一律用 `+9` 递推定位下一块，别按固定行号硬写**。

**解析规则**：`A 列非日期 ⇒ 是新一组（店铺）的开始**；`D 列`是指标名。先解成长表（店铺/日期/指标/值），再按 `(日期, 店铺)` 聚合回宽表去匹配飞书字段：

```python
from collections import defaultdict
agg = defaultdict(dict)
for r in recs_long:                      # [{日期,店铺,指标,值}, ...]
    agg[(r["日期"], r["店铺"])][r["指标"]] = r["值"]

wide = []
for (d, shop), m in agg.items():
    rec = {"日期": d, "店铺": shop, "运营": SHOP_MAP[shop][1]}
    for k in ["1星","2星","3星","4星","5星","评价总数","DSR"]:
        if k in m: rec[k] = m[k]
    wide.append(rec)
```

> 这一步把 52,781 条长表压回 7,320 条宽表（≈ 22 店 × 333 天）。**先长后宽**是解析这种「指标×日期」矩阵最简单的写法，不要直接两重循环硬拼。

---

## Step 3 · 维度对齐（最容易出错的一步）

同一个业务实体在多个 sheet 里写法不一致，**必须先建映射，不能模糊匹配**：

```python
SHOP_MAP = {
 "蒙倩美发官方旗舰店":   ("美发官方", "丽丽"),   # 全名 → (表头简称, 运营)
 "蒙倩美发护发官方旗舰店": ("美发护发官方", "袁盼盼"),
 ...   # 本次 22 家
}
```

**四个真实坑**：
1. **运营名字带"姐"**：表头写 `玉珍姐`/`丽丽姐`，分配表写 `玉珍`/`丽丽` → 统一成分配表写法。
2. **表头里出现了分配表没有的人**（`博怡`/`国熙` 不在「店铺&运营对应分配表」里）→ **以实际填表人为准，并当场告知用户"若不对告诉我改"**，不要默默选一边。
3. **伪分组行**：DSR 表第一组叫「汇总」（整体数据，不是店），其"运营"解出来是 `4.69731` 这种数值 → **排除并计数**，不要让它进表：
   ```python
   if shop == "汇总" or shop not in SHOP_MAP:
       skipped += 1; continue
   ```
   最后报告里写明「跳过 X 条（汇总/未映射）」，不要静默丢数据。
4. **无名空占位块**（本次在 `r162`）：**有日期表头行、但组头 A 列没有店名，且 8 个指标行全空** —— 原表删店后残留的空壳。
   - **块检测不能只认「A 列有店铺名」**，否则这 8 行会被并进上一家店，或让后续行号整体错位。
   - 判据：① 块头 A 列非空且含「旗舰店」；② 块间距恒为 9 行；③ 指标全空 → 跳过并计数。
   - 这**不算数据问题**，报告里说一句「跳过 1 个空占位块」即可，别当异常去追问用户。

---

## Step 4 · 建表 + 字段 + 选项

```python
# 建表必须一次带齐 fields（空 fields → 99992402）
r = req("POST", f"{BASE}/tables", {"table": {"name": "评价有礼·每日登记", "fields": fields}})
T1 = r["data"]["table_id"]

# 给已有单选字段补选项（必须 PUT）
def set_options(tid, fname, opts):
    for f in req("GET", f"{BASE}/tables/{tid}/fields?page_size=30")["data"]["items"]:
        if f["field_name"] == fname and f["type"] == 3:
            req("PUT", f"{BASE}/tables/{tid}/fields/{f['field_id']}",
                {"field_name": fname, "type": 3,
                 "property": {"options": [{"name": o} for o in opts]}})
```

---

## Step 5 · 批量导入

```python
TZ = datetime.timezone(datetime.timedelta(hours=8))
def ts(d):    # "2025-09-01" → 毫秒时间戳（东八区）
    return int(datetime.datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=TZ).timestamp() * 1000)

# ⚠️ 各表的字段名不同，分别构造（表1 主字段叫 日期文本，表2 主字段就叫 日期）
recs = [{"fields": {"日期文本": r["日期"], "日期": ts(r["日期"]),
                    "运营": r["运营"], "店铺": r["店铺"], "花费金额": r["花费金额"]}}
        for r in rows]

ok = fail = 0
for i in range(0, len(recs), 500):           # ≤500 条/批
    r = req("POST", f"{BASE}/tables/{Tid}/records/batch_create", {"records": recs[i:i+500]})
    if r.get("code") == 0: ok += len(recs[i:i+500])
    else:
        fail += len(recs[i:i+500])
        print("❌", json.dumps(r, ensure_ascii=False)[:250])   # 一定要打出原文
    time.sleep(0.25)                          # 轻限速
print(f"成功 {ok:,} / 失败 {fail:,}")
```

---

## Step 6 · 收尾与自检

1. **清空行**：新 Base 默认表自带空行（导 7,231 条后 `total` = 7,241）→ 找 `fields` 全空的 `record_id`，`batch_delete`。
2. **建视图**：`POST .../views` `{"view_name":"按运营分组","view_type":"grid"}`。
   ⚠️ **这只是建了个空视图，里面没有任何筛选/分组** —— 飞书 OpenAPI **不支持设置视图的筛选/分组/排序**（5 种参数写法全不生效，`GET /views/{vid}` 的 `property` 恒为 `null`；详见 `references/bitable-api-pitfalls.md` 的「视图」一节）。
   所以「让每个运营只看自己的店」**做不到自动化**：要么请用户在 UI 里手动加一次分组/筛选，要么老实说明这个限制。**别承诺 API 能把视图配好。**
3. **对账**：分别打印「导入成功条数」和「表内 total」，与源数据条数三方对齐。
4. **抽样验证**：取一条源数据（如 `2025-09-01 蒙倩旗舰店 74.5`）与 API 读回的值比对，**不一致才算真出问题**。
5. **⚠️ 公式列（`type: 20` / `ui_type: "Formula"`）绝对不能写。** 本次目标表的 `评价总数` 和 `DSR` 已改成公式列（`评价总数 = sum(1星..5星)`、`DSR = 加权平均`）——**只写 1~5星，让它自己算**。OpenAPI 也改不了公式表达式，结构要动必须请用户在 UI 里改。
6. **读回时顺手验一次公式 —— 这是抓「块行偏移/错位」最有效的一招：**
   ```python
   t = sum(r[k] for k in ["1星","2星","3星","4星","5星"])
   w = sum(r[k] * i for i, k in enumerate(["1星","2星","3星","4星","5星"], 1))
   assert t == r["评价总数"] and abs(w / t - r["DSR"]) < 1e-9
   ```
   实测 `38,25,137,341,2641` → 总数 3,182 ✓ / DSR 4.7354 ✓；`88,44,222,638,4256` → 5,248 ✓ / 4.7016 ✓。
   **附带好处：公式会自动纠正源表的错值** —— 源表 `蒙倩官方旗舰店 2025-09-09` 的 dsr 单元格写的是 `1.07`，飞书表算出来是 `4.7016`（对的）。报告里要主动说明这一点，别让用户以为「导错了」。

---

## 本次实测结果（可当基准）

| | 源 Excel | 飞书表 |
|---|---|---|
| 评价有礼 | 404 天 × 22 店铺列 | **7,231 条** |
| DSR | 23 组 × 388 日期列（52,781 长表） | **7,320 条**（宽表） |
| 合计 | — | **14,551 条 / 30 批 / 0 失败** |

**Base**：`app_token = S3r3bHOeXaEJzXsNTfUcpC2Mncd`（蒙倩 · 运营数据登记）
表1 `tblcbN6LK4iywDIc`（评价有礼）／表2 `tblOciaRaegOoQxy`（DSR）

> ⚠️ **这两张原始表后来按用户要求删掉了**（用户接着要「把评价有礼 / DSR 合并在一个表格」）。
> **最终 Base 里只剩一张合并表** `tbl4h3Q7tsHljiwS`，字段骨架 = `日期 ｜ 运营 ｜ 店铺 ｜ 花费金额 ｜ 1星 ｜ 2星 ｜ 3星 ｜ 4星 ｜ 5星 ｜ 评价总数 ｜ DSR`；
>
> **⚠️ 2026-09-26 复核：这张表已被用户改过，别再照旧笔记操作。**
> - 表名已从「运营数据·每日登记（合并）」改为 **「领航员·每日登记-4.8⭐」**（`table_id` 没变，仍是 `tbl4h3Q7tsHljiwS`）。**按名字找表会找不到。**
> - **表内被清空过**（本次开工时 `total = 0`）—— 旧笔记里的「7,476 条」已过时。
> - **`评价总数` / `DSR` 已从 Number 改成 Formula（`type: 20`）** → 结构上就不能写，见 Step 6 第 5 条。
> - **新增两个字段**：`近90天用户评价得分排名`（Number）、`领航员综合分行业排名`（Number）。
> - 单选选项现为 **运营 10 人**（朝玲/袁盼盼/小魏/玉珍/丽丽/轩轩/齐钰/国熙/修炜/博怡）、**店铺 22 家**（全名）。
> - 2026-09-26 按这份 recipe 重导 **7,380 条**（15 批 / 0 失败 / 58.8s），读回 `total = 7,380` 一致。
> 表内还有一个 `view_type:"form"` 的空表单视图 `vewfdPlEu3`（等用户在 UI 里配）。
> **Base 所有权已转给用户**（`owner_id` = 十一的 open_id，已用 `metas/batch_query` 读回验证）。
> 本地 JSON 备份在 `D:\Agent.GongZuoQu\Hermes.GZQ\数据--运营登记\`（`_t1_final.json` / `_t2_final.json` / `_merged.json`）。
> **下次接着干别去找那两张已删的表。**
>
> **合并口径**：按 **(日期, 店铺)** 做 outer join。本次 7,075 条两边都有、156 条只有评价有礼、245 条只有 DSR、**运营归属冲突 0 条**。
> **顺序是「先合并、再删原表」**，且删表前务必确认本地 JSON 备份已落盘 —— 飞书删表不可逆。

**本次踩到并已解决的 API 报错**：`99992402`（建表 fields 为空）｜`1254046`（删主字段）｜`1254045`（字段名不存在，整批失败）｜`PATCH` 返回 `None`（换 PUT）

---

## 交付时要顺手报给用户的「源数据问题」

迁移会把原表的毛病暴露出来，**这些问题要单独列出来，但不要自行修改源数据**：

- **异常值**：`蒙倩官方旗舰店 2025-09-09` 的 `DSR = 1.07`（前后几天都是 4.70）—— 明显是原表录入/公式错。
- **占位 `0`**：`近90天用户评价得分排名` 列 4,139 行空 + **3,173 行是 `0`** + 只有 **68 行**是真实排名（15~84）。`0` 看着就是登记时随手填的占位。**原样写入、点名报告、再问用户要不要清空** —— 不要自行清、也不要自行丢（这是「照字面实现」的场景）。
- **漏登要点名到人**：本次 9/26 有 5 家店没登记星级，且**集中在 2 个人身上**（小魏 3 家：护发旗舰 / 护发官方 / 染发旗舰；修炜 2 家：美发旗舰 / 美容护肤官方）—— 报漏登要出「日期 × 店铺」的 ✓/✗ 矩阵，别只说「有 5 家没填」。
  ```python
  by = defaultdict(set)
  for r in rows:
      if r["1星"] is not None: by[r["日期"]].add(r["店铺"])
  for d in sorted(by)[-7:]:        # 最近 7 天 × 22 家的 ✓/✗ 矩阵
      print(d, "".join("✓" if s in by[d] else "✗" for s in STORES))
  ```
- **只写了一部分的行**：172 行只有 `花费金额`、没有星级（源表 2025/9/1–9/8 与 2026/3 部分日期本来就没填）。
- **汇总块没同步**：源表的「汇总」伪店铺，飞书表没有这个选项 → **不硬塞**，但报告里说明「要的话我给你加一个『汇总』选项再补 N 行」。
- **未来日期**：表里有到 2026-10-09 的日期行（提前拉好的空行）。
- **人员/店铺名单不一致**：见 Step 3。

报告格式：先给结果（链接 + 条数），再给「发现的数据问题」，最后给「接下来要你定的」（权限、运营怎么填）。
