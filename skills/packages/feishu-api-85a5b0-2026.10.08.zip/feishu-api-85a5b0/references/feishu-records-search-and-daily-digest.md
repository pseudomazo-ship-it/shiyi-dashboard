# Feishu Base: newest-record reads + a nightly digest push (verified 2026-09-16)

Context: 十一's **运营数据登记** Base. Every 运营负责人 files one row per store per day
(业绩/退款/推广/单量). The ask became a nightly WeChat digest: 业绩总数、整体数值、本月累计、
业绩下滑(近3天均值)、疑似数据异常、近7天漏填、近7天总业绩趋势. He revised the layout five times
in one sitting — build it so a revision is a script edit, not a rebuild.

## 1. The table
- Base `app_token = Q6PZbQRH3aZum0skE3Pc8WCVnPh`, table `tbl9bX2VE4PXRRiM` (数据登记, ~5.9k rows,
  and it GROWS daily — never hard-code a total).
- Fields (17): `日期`(5 DateTime) · `负责人`(3) · `平台/店铺类型`(3) · `店铺名称（拼多多个人店）`(3) ·
  `问卷编号`(1005) · `店铺名称（拼多多旗舰店）`(3) · `当日总业绩`(2) · `退款金额`(2) · `净业绩`(20) ·
  `全店净投产`(20) · `数值占比`(20) · `成团单量`(2) · `退款单量`(2) · `推广花费`(2) · `净客单`(20) ·
  `退款率`(20) · `推广占比`(20).
- ⚠️ `退款率` / `推广占比` are formula columns that came back as **0 for every row**. Do NOT read
  them as the store's rate — compute `退款÷业绩`, `推广÷业绩` yourself, and say so in the reply.
- Store key = `店铺名称（拼多多旗舰店）`, falling back to `店铺名称（拼多多个人店）`.
- `日期` is epoch ms → convert with **UTC+8** (see the SKILL.md bullet); UTC shifts every date back a day.

## 2. Fetch the newest N days in ONE call
```python
sort_payload = {"sort": [{"field_name": "日期", "desc": True}], "page_size": 500}
items = req(f"/bitable/v1/apps/{BASE}/tables/{TABLE}/records/search", sort_payload, token=tok)["data"]["items"]
```
- 500 rows ≈ 21–23 days at 22–23 stores/day — covers "近7天" and "本月累计" at once.
- List-endpoint `sort` in the query string → `1254016 InvalidSort` + empty items.
- A `日期` `isGreater`+`ExactDate` filter returned `code:0` / 0 items on a day with 22 rows.
- Full-table pagination (~59 pages) is the slow path; it timed out at 120 s in `terminal`.

## 3. Digest blocks and their exact rules
| Block | Rule |
|---|---|
| 业绩总数 / 整体数值 | day totals; 整体数值 = (总退款 + 总推广) ÷ 总业绩 |
| 本月累计 | sum the current month's days → 业绩 + (退款+推广)÷业绩, print the day span (e.g. 9/1~9/15，15天) |
| 业绩下滑>5% | each store's day 业绩 vs **its own mean over the previous 3 days** — require ≥2 of those 3 days to have data, else skip (thin data would manufacture a fake swing) |
| 疑似数据异常 | vs previous day: 业绩 涨跌≥50% **且** 绝对变化≥300元, OR 店铺数值((退款+推广)÷业绩) 变化≥20pt |
| 近7天漏填 | §4 |
| 近7天趋势 | §5 |

Note 十一 replaced the original "vs 前一天" rule with "vs 近3天均值" because per-day comparison flagged
stores that were *steadily* declining rather than suddenly breaking (4 stores → 2 real ones).

## 4. "漏填" detection — anchor on a per-store baseline, never a raw count
- Daily store counts drift 19–23, so a bare count cannot tell you *who* is missing.
- Baseline = stores appearing in **≥15 of the last 21 days** → currently **23 stores** ("应登 23 家").
- Per day: `sorted(base - set(byd[d]))` names the missing stores. Real output: 蒙倩个护官方旗舰店（熙）
  missing on 9/10, 9/13, 9/15 — a systemic filing gap the raw daily count had hidden completely.
- Keep printing `登记 N 家 / 应登 M 家` next to it so a shrinking baseline stays visible.

## 5. Rendering a trend line in plain text (WeChat has no charts)
- Normalize over the **window's own min–max**, not 0–max: `"▇" * (2 + round((v-min)/(max-min)*10))`.
- With 0-max, seven days sitting in 262k–311k all rendered as near-identical bars — the trend was
  invisible. Min–max normalization made the 9/13 jump obvious.
- Append the day-over-day % per row and label the window's newest date so the reader anchors it.

## 6. Alert thresholds MUST be backtested before shipping
A rule that never fires is as useless as one that fires daily. Before wiring a threshold, replay it
over recent history and count hits per day, then tell the user the measured hit rate:
- `±50% & ≥300元` / `±20pt` → **0–4 hits/day (mostly 1–2)** across 14 days → real anomalies
  (蒙倩染发官方旗舰店（珍） 业绩 +154%; 蒙倩美发旗舰店（炜） 数值 -56pt). ✅ shipped
- `±30% & ≥200元` / `±12pt` → up to **7 hits/day**, ~1/3 of 23 stores flagged → noise. ❌ rejected

## 7. Wiring the nightly push (Hermes cron)
- `cronjob action=create` → `no_agent=true` + `script="yunying_daily.py"` (resolves under
  `E:\RuanJian\Hermes/scripts/`) + `schedule="0 23 * * *"` + `deliver="origin"`.
  Job `ee58ecb16feb`; script `E:\RuanJian\Hermes\scripts\yunying_daily.py`.
- `no_agent` delivers stdout **verbatim** → the script IS the message. Make its print output exactly
  what the user should read, and wrap `main()` so an exception prints one honest failure line
  instead of dying silently (empty stdout sends nothing at all).
- Iterating on layout = editing the script only; no cron or prompt change between revisions. That is
  why `no_agent`+`script` beats a prompt-driven agent job for a fixed-format digest.
- **Channel choice**: 十一 first asked for 微信+QQ as mutual backup (`deliver="origin,qqbot"`), then
  settled on **微信 only** — he lives in WeChat, so "推送的价值不在发出去，而在你会看". Both WeChat
  and QQ *proactive* sends need a live 互动窗口; an expired one fails with `ret=-2 prepare failed`,
  and the user sending any message to the bot re-opens it. Say that when a push silently stops.
- Verify by running the script once in `terminal` and pasting the REAL output — never describe a
  digest you haven't executed.

## 8. `sort` in the query string vs the request body
The identical JSON URL-encoded into the list endpoint's query string is rejected (`InvalidSort`).
Put sort (and filter) in the POST **body** of `records/search`. Same trap applies to both.
