---
name: skill-package-delivery
description: Use when 十一要「把技能打包发我」。打 zip 交付并处理占用锁。
metadata:
  hermes:
    tags: [skills, delivery, zip, packaging, 技能包]
    category: productivity
---

# 技能包交付（把技能打包发给十一）

十一会把一轮工作沉淀成技能，过一阵回来说「**把最新的这个技能打包发我**」。
他要的不是源码归档，是**解压即用、换台机器 / 换个人接手也能跑**的一个 zip。
本技能只管「更新 → 打包 → 交付 → 收尾」这一段；技能内容本身怎么维护，看被包的那个技能。

## 触发

| 十一说 | 我做什么 |
|---|---|
| 「把技能打包发我」「把最新的技能 skill 打包发我」 | 打包 → `MEDIA:` 发他 |
| 「**更新 skill 技能**并打包发我」 | ⚠️ 这半句是**先更新再打包**，别跳过更新 |
| 「打包一份技能包」 | 同上 |
| 「把**所有** skill 的名称和简介、安装包和安装指令汇总**放在一个网页**」 | **打总览页**，见下节（不是打 zip） |
| 「更新一下技能清单网页」 | 重跑生成器 —— **先分辨是哪一版（见下）** |

### ⚠️ 有两种页面形态，别拿错生成器（2026-10-07）

| 形态 | 生成器 | 产物 |
|---|---|---|
| **简化版（chips 页）** | `scripts/build_skills_page.py --root <skills> --out <html>` | `Hermes技能清单.html` + `skills_index.json` |
| **管理台版（他给了完整规格的）** ← 现行 | `gen_skills_data.py` → `gen_skills_html.py`（**两个要依次跑**） | `skill_manager/skills.html` + `skills_data.json` |

管理台版的脚本本机位置（**暂寄在 `脚本--PDD采集\` 下，属误放**；已问过十一要不要挪，未定）：
```
D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\gen_skills_data.py
D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\gen_skills_html.py
产物：D:\Agent.GongZuoQu\Hermes.GZQ\文档--Hermes工作规则\skill_manager\
```
**他再说「更新技能清单网页」时，默认按管理台版更新**（重跑那两个脚本），
不要退回简化版 —— 他看过简化版之后才给出的完整规格，两者不是同一件东西。

## 铁律

1. **先更新 SKILL.md，再打包。** 本次会话学到的东西要**当场写进技能**，
   否则包出去的是旧知识。打包脚本不负责更新 —— 更新是 `skill_manage(action='patch')` 的活。
2. **文件锁不是失败。** 十一常把上一版 zip 开着（预览中 / 解压中），`os.remove` 抛
   `PermissionError`（Windows 上表现为「另一个程序正在使用此文件」）。
   **不要重试到死，也不要干脆跳过清理** —— 改名叫 `_v2` 继续打，
   并在交付里写一句「旧包被占用删不掉，你关掉后我清」。
3. **只发一份。** 不要同时把 `_v1` 和 `_v2` 都发出去（违反「同信息只留最新版」）。
4. **交付前必跑校验**：`zipfile.testzip()` + 列出包内文件与各自字节数。
   「打包完成」这句话要有 `testzip()` 和文件清单撑着。

## 包内结构（十一验收过的形状）

```
<label>-技能包_<YYYY.MM.DD>_v<N>.zip
├─ <skill-name>/
│   └─ SKILL.md                  ← 技能主文件（已含本次更新）
├─ scripts/
│   ├─ <主流程脚本>.py            ← 平时只跑这个的那个
│   ├─ <生成器>.py
│   └─ <辅助>.py
├─ 参考-<文档名>_<YYYY.MM.DD>.md  ← 本次改动的说明/核查报告，可选但很有用
└─ README.txt                    ← 上手说明，见下节
```

- 保留技能自己的相对路径（`scripts/`、`references/` 相对技能目录），换机器解压后链接不断。
- **`scripts/` 放的是 Hermes 侧的运行脚本**（`E:\RuanJian\Hermes\scripts\`），
  跟技能目录里的 `scripts/` 不是一回事 —— 都要收进去，放同一层 `scripts/`。

## README.txt 骨架（9 节，照抄结构换内容）

固定顺序，标题用全角【】：**是什么 → 结构 → 怎么用 → 纪律 → 口径 → 现状 → 数据源/产物 → 坑 → 验证清单**。
完整骨架见 `templates/pack_readme_skeleton.txt`，直接复制改内容。

要点：
- 「怎么用」必须给出**一条能直接粘贴运行的完整命令**（含解释器绝对路径），别写成「运行 xx 脚本」。
- 「纪律」把该技能最容易犯的 2 条放最前面（如一「照字面实现别自作聪明」、二「总结必须全量列出」）。
- 「坑」段直接用 SKILL.md 里的编号清单，不要另写一套。
- 有密码 / 凭证的：写「访问密码 11」这类**用户已知的**，**不要把 token、secret、哈希写进 README**。

## 另一种交付形式：技能清单网页（全库总览）

十一 2026-10-07 要的：「**把你所有的 skill 的名称和简介，对应的安装包和安装指令都汇总放在一个网页，创建一个网页**」。
他要的不是某一个技能包，是 **整个技能库的一页目录** —— 看自己有什么能力、并知道怎么搬到别的机器。

```bash
"E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" \
  "E:/RuanJian/Hermes/skills/productivity/skill-package-delivery/scripts/build_skills_page.py" \
  --root "E:/RuanJian/Hermes/skills" \
  --out  "D:/Agent.GongZuoQu/Hermes.GZQ/文档--Hermes工作规则/Hermes技能清单.html"
```

页面形态（他验收过）：顶部 5 个统计卡 → 搜索框 + 分类 chips（全部 / 专属定制 / 各分类）→
每技能一张卡（名称 + 类型/分类/体积标签 + 简介 + 磁盘路径 + **两条可一键复制的命令**）。
两条命令就是他要的「安装包 / 安装指令」：
```
安装/迁移  cp -r "<skill 路径>" "<目标机>/skills/<分类>/"
打包发送  cd "<skill 目录>/.." && zip -r "<skill>.zip" "<skill>"
```
**技能本身就是文件夹 —— 所以「安装包」= 那个文件夹，「安装指令」= 复制它。** 页面底部再补一段
「整包迁移：把 skills 根目录整个拷过去」，并提醒**脚本里的绝对路径换机器要改**。

交付：`desktop_preview(action='open', url=<html 路径>)` 当场给他看 + `MEDIA:` 给一份文件。

### ⚠️ 两个分不清的分类维度（本次踩了，别再宣称精确）

页面上「自建 vs 内置」这类标签，**做不到准**，两种判法都试过：

| 判法 | 结果 |
|---|---|
| 按名字关键词白名单（`pdd-`/`feishu-`/`xlsx`…） | ❌ 误判 5 个：`docx`/`xlsx`/`hermes-agent-skill-authoring`/`windows-desktop-maintenance`/`windows-electron-app-verify` 都是自带的 |
| 按「简介含中文」判**专属定制** | 🟡 好用但约 10% 偏：`baoyu-infographic`/`cocoloop`/`zhongkui-skill`/`feishu`/`feishu-api` 是市场/自带的 |

**做法**：用第二种，但①标签文字写成「专属定制 / 通用工具」（描述性，不是断言）；
②**主动告诉十一这个标签是近似的**，并说「要精确区分得我逐个手工核，你要的话我去核」——
本次直接这么坦白，他没追问。**别把猜出来的分类当成事实汇报。**

另外两个小坑：
- `skills_list` 报的条数（166）与扫盘 `SKILL.md` 数（180）**不等**，因为有 `.bak`/未启用副本。
  重名要去重（优先留非 `bak` 的那份），否则页面上出现重名卡。
- 扫盘要把 **plugins / `.bak_*` / `@clawhub_*` / `@user_*`** 目录一并列上（能看出哪些是外部装进来的），
  但这些是**只读展示**，不要写回。

### 升级版形态：Agent Skills 管理台（十一 2026-10-07 给的完整规格）

看过第一版 chips 页面后，他**直接给了一份完整产品规格**，要的形态重得多。
遇到他贴规格，就按这个做，**别再用简化版**。

**布局**
```
顶部导航（fixed, 64px）：图标 + 站名 | 技能总数 | 更新时间（可加 专属定制/分类）
筛选栏（sticky top:64px）：搜索框 + 分类▾ + 适用Agent▾ + 安装方式▾ + 重置 + 计数
主体：卡片网格（3列） + 右侧 sticky 详情面板
页脚：维护说明 / 技能怎么用 / 安装到别的机器 / 反馈 + 更新时间
```

**响应式**：桌面 3 列 / <1400px 2 列 / <1100px 单列。窄屏时点卡片改为**全屏详情页**（带返回键 + ESC）。
**用 `window.matchMedia('(max-width:1100px)')` 在 JS 里判断**，不要只靠 CSS 隐藏 —— 桌面版和移动版的详情渲染路径不同。

**设计规范（他逐字给的，照做）**
```
主色 #2B6CB0 ｜ 背景 #F7F9FC ｜ 卡片 #FFFFFF + 阴影
字体 system-ui + 微软雅黑
卡片间距 24px ｜ 内边距 24px ｜ 圆角 12px
顶部导航固定，筛选栏 sticky top:64px
```

**详情面板 7 个板块**：简介 / 基本信息（版本·适用Agent·体积·安装方式）/ 安装指令（可复制）/
安装包位置（可复制路径）/ 来源 / 注意事项 / 更新时间。

**数据字段（11 个，他要的）**
```
name / description / version / category / agent / install_method /
install_command / package_url / source_url / notes / updated_at
```

**⚠️ 数据必须内联进 HTML**
`file://` 协议下 `fetch` 读本地 JSON 会被浏览器拦（CORS），**双击打不开**。
做法：数据同时写 `skills_data.json`（供别的程序用）+ 内联成 `skills.html` 里的 `const DATA = [...]`。
**JSON 是副产品，HTML 才是交付物** —— 他说「双击即可打开」就是指这个。

**`notes` 字段怎么来**：从 SKILL.md 正文抽「坑 / 注意 / ⚠️」章节的头两条，
去 Markdown 标记、截 160 字。抽不到就写「无特殊注意事项」。

**⚠️ 两个下拉实际只有 1 个值 —— 要主动说明，别装作是筛选**

| 下拉 | 实际值 | 原因 |
|---|---|---|
| 适用Agent | 全是 `Hermes（通用）` | 技能都是 Hermes 的，没有 Codex/Claude/GPT |
| 安装方式 | 全是 `手动（文件夹复制）` | 技能 = 文件夹，不存在 npm/pip/git 安装 |

他规格里写了多值，但实际没有 → **直接告诉他「这俩现在是摆设」**，
并建议把「安装方式」换成**「来源筛选」**（专属定制 / Hermes 内置 / 市场安装 / 外部技能），
那个真有区分度。**猜一个假的分类维度比说"没有"更糟。**

**来源判定（比名字关键词准）**：`@clawhub_*` / `@user_*` 前缀 → 市场安装；
`ima-skill*` → 外部技能；`ecommerce` 分类 → 自建；其余 → Hermes 内置。

本次实测数据：**176 个技能 / 20 个分类 / 自建 39 / 内置 132 / 市场 3 / 外部 2**。

## 打包

```bash
# 通用打包器（自动找技能目录、收脚本、清理旧包、处理占用锁）
"E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" \
  "E:/RuanJian/Hermes/skills/productivity/skill-package-delivery/scripts/pack_skill.py" \
  --skill daily-report-dashboard \
  --label 数据日报看板 \
  --out "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报" \
  --scripts run_daily_report.py daily_dashboard.py daily_report_push.py \
  --ref-md "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报/数据日报看板改版说明_2026.09.27.md" \
  --readme "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报/_pack_readme.txt"
```

输出：zip 绝对路径 + 逐文件字节数 + `testzip()` 结果。

## 交付

```
MEDIA:<zip 绝对路径>
```

报告里给全四样：**包内结构树（带字节数）/ README 写了哪几节 / 本次 skill 改了哪几处 / 校验结果**。
⚠️ 如果这一轮同时有旧包被占用删不掉，**单独点出来**并说「关掉后我清」。

## 收尾

- 打包用的临时 README（`_pack_readme.txt`）留在产出目录即可，下次覆盖写，不算交付物。
- **旧包清理**：正常情况同目录只留最新一个；被占用就先留着，**下次碰这个目录时先扫一遍再删**，
  `glob("<label>-技能包_*.zip")` 排序后除最新全删。

## 相关文件

- `scripts/pack_skill.py` — 通用打包器（打单个技能包 → zip）
- `scripts/build_skills_page.py` — **简化版（chips）清单页生成器**（`--root` / `--out`，无第三方依赖；
  输出 HTML + `skills_index.json`）。只在没给规格时用
- `gen_skills_data.py` / `gen_skills_html.py` — **管理台版生成器（现行）**：前者扫盘出
  `skills_data.json`（含 `meta` + `skills`），后者把数据内联进单文件 `skills.html`。
  ⚠️ 两者分两步跑，改完扫描逻辑要先跑 data 再跑 html，否则页面还是旧数据
- 重生成时的两个细节：① `category` 要把目录名（`ecommerce`/`productivity`…）映射成中文，
  并特判 `@clawhub_*` / `@user_*` → 「市场安装」（否则页面上挂着裸目录名）；
  ② 去重时优先留非 `.bak` 目录的那份，否则页面上出现重名卡

## 坑

1. **`os.remove` 抛 `PermissionError` ≠ 打包失败。** 那是十一开着旧包。换名（`_v2`）继续，
   别为了删旧包卡住整个交付。实测一轮里撞过两次。
2. **别用 `write_file` 直接写 zip 同名文件**：同上锁。命名带 `_v<N>` 是唯一的解。
3. **f-string 里不能带反斜杠**（`f"{re.findall(r'<div[\s>]', t)}"` → `SyntaxError`，
   整个 cell 一行都不执行，表现为「文件没生成」）。正则结果先算成变量。
4. **不要给通用打包器写死某个技能的路径** —— 参数化 `--skill/--scripts/--out`，
   否则第二个技能要复制一份脚本。

## 验证

- [ ] `zipfile.testzip()` 返回 `None`
- [ ] 包内文件数与预期一致，逐项列出字节数
- [ ] `SKILL.md` 是**更新后**的版本（含本轮新加的条目）
- [ ] README 里的运行命令**粘出来能跑**（解释器绝对路径正确）
- [ ] 没有把凭证 / token / 哈希写进包内任何文件
- [ ] 交付用 `MEDIA:` 绝对路径
- [ ] 旧包清理状态已说明（已删 / 被占用待删）
