# -*- coding: utf-8 -*-
"""扫 Hermes 全部 skill → 生成可检索的 HTML 清单页（技能目录总览）

用法:
  python build_skills_page.py
  python build_skills_page.py --root "E:/RuanJian/Hermes/skills" \
      --out "D:/Agent.GongZuoQu/Hermes.GZQ/文档--Hermes工作规则/Hermes技能清单.html"

产物:
  <out>                    可检索 HTML（搜索 / 分类筛选 / 一键复制安装命令）
  同目录 skills_index.json 原始数据（下次重生成直接覆盖）

为什么值得存脚本：十一会反复要「把技能汇总成一个网页」，且每次技能都在变，
手写一遗。这个脚本无第三方依赖。
"""
import os, re, json, argparse, datetime, collections

DEFAULT_ROOT = r"E:\RuanJian\Hermes\skills"
DEFAULT_OUT = r"D:\Agent.GongZuoQu\Hermes.GZQ\文档--Hermes工作规则\Hermes技能清单.html"


def parse_frontmatter(path):
    """只读 frontmatter 的 name/description（不解析嵌套 YAML，够用）"""
    try:
        txt = open(path, encoding="utf-8", errors="replace").read()
    except Exception:
        return {}
    m = re.match(r"^---\s*\n(.*?)\n---", txt, re.S)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).split("\n"):
        mm = re.match(r"^(\w+)\s*:\s*(.*)$", line.strip())
        if mm:
            fm[mm.group(1)] = mm.group(2).strip().strip('"').strip("'")
    return fm


def dir_size(p):
    total = files = 0
    for root, _, fs in os.walk(p):
        for f in fs:
            try:
                total += os.path.getsize(os.path.join(root, f)); files += 1
            except Exception:
                pass
    return total, files


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"


def collect(root):
    items = []
    for cur, _dirs, files in os.walk(root):
        if "SKILL.md" not in files:
            continue
        rel = os.path.relpath(cur, root).replace("\\", "/")
        parts = rel.split("/")
        cat = parts[0] if len(parts) > 1 else "（根目录）"
        name = parts[-1]
        fm = parse_frontmatter(os.path.join(cur, "SKILL.md"))
        size, nfiles = dir_size(cur)
        desc = (fm.get("description") or "").strip()
        items.append({
            "name": fm.get("name") or name,
            "dir": name, "cat": cat, "rel": rel, "path": cur,
            "size": size, "size_h": human(size), "files": nfiles, "desc": desc,
            # ⚠️ 这是**近似**判断，见 SKILL.md「两个分不清的分类维度」
            "custom": bool(re.search(r"[\u4e00-\u9fff]", desc)) or ("十一" in desc),
        })
    # 重名去重：优先留非 .bak 的那份
    seen = {}
    for it in items:
        k = it["name"].lower()
        if k not in seen or "bak" not in it["cat"]:
            seen[k] = it
    return sorted(seen.values(), key=lambda x: (x["cat"], x["name"]))


TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hermes 技能清单 · __DATE__</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
html{{color-scheme:light}}
body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;
background:#f8fafc;color:#0f172a;padding:20px;line-height:1.6}}
.wrap{{max-width:1400px;margin:0 auto}}
h1{{font-size:26px;font-weight:700;letter-spacing:-.02em;margin-bottom:6px}}
.sub{{color:#64748b;font-size:14px;margin-bottom:20px}}
.stats{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:20px}}
.stat{{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.04);transition:all .2s ease-out}}
.stat:hover{{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.08)}}
.stat .n{{font-size:26px;font-weight:700;color:#2563eb;line-height:1.2}}
.stat .l{{font-size:12px;color:#64748b;margin-top:4px}}
.toolbar{{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:14px;margin-bottom:16px;
display:flex;gap:12px;flex-wrap:wrap;align-items:center;box-shadow:0 1px 2px rgba(0,0,0,.04)}}
input[type=search]{{flex:1;min-width:220px;padding:9px 14px;border:1px solid #cbd5e1;border-radius:8px;
font-size:14px;font-family:inherit;background:#f8fafc;outline:none;transition:all .15s ease-out}}
input[type=search]:focus{{border-color:#2563eb;background:#fff;box-shadow:0 0 0 3px rgba(37,99,235,.15)}}
.chips{{display:flex;gap:6px;flex-wrap:wrap}}
.chip{{padding:5px 11px;border:1px solid #cbd5e1;border-radius:999px;background:#fff;font-size:12.5px;
cursor:pointer;color:#475569;transition:all .15s ease-out;user-select:none;font-weight:500}}
.chip:hover{{border-color:#2563eb;color:#2563eb}}
.chip.on{{background:#2563eb;border-color:#2563eb;color:#fff}}
.chip:active{{transform:scale(.97)}}
.grid{{display:grid;gap:12px}}
.card{{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:16px;
box-shadow:0 1px 2px rgba(0,0,0,.04);transition:all .2s ease-out}}
.card:hover{{transform:translateY(-2px);box-shadow:0 4px 14px rgba(0,0,0,.08)}}
.card.mine{{border-left:3px solid #2563eb}}
.chead{{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:8px}}
.cname{{font-size:15.5px;font-weight:650;word-break:break-all}}
.cname code{{font-family:ui-monospace,Consolas,monospace;font-size:14px}}
.tags{{display:flex;gap:6px;flex-shrink:0;flex-wrap:wrap}}
.tag{{font-size:11px;padding:3px 9px;border-radius:999px;white-space:nowrap;font-weight:500}}
.tag.cat{{background:#eff6ff;color:#2563eb;border:1px solid #bfdbfe}}
.tag.mine{{background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0}}
.tag.builtin{{background:#f8fafc;color:#64748b;border:1px solid #e2e8f0}}
.tag.sz{{background:#f8fafc;color:#475569;border:1px solid #e2e8f0;font-family:ui-monospace,monospace}}
.cdesc{{font-size:13.5px;color:#475569;margin-bottom:12px}}
.cpath{{font-family:ui-monospace,Consolas,monospace;font-size:11.5px;color:#64748b;background:#f8fafc;
border:1px solid #e2e8f0;border-radius:6px;padding:7px 10px;margin-bottom:10px;word-break:break-all}}
.cmds{{display:flex;flex-direction:column;gap:6px}}
.cmdrow{{display:flex;gap:8px}}
.cmd{{flex:1;font-family:ui-monospace,Consolas,monospace;font-size:11.5px;background:#f1f5f9;
border:1px solid #e2e8f0;border-radius:6px;padding:7px 10px;color:#334155;overflow-x:auto;white-space:nowrap}}
.cp{{padding:7px 12px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;font-size:11.5px;
cursor:pointer;color:#475569;white-space:nowrap;transition:all .15s ease-out;font-weight:500}}
.cp:hover{{background:#2563eb;border-color:#2563eb;color:#fff}}
.cp.ok{{background:#16a34a;border-color:#16a34a;color:#fff}}
.empty{{text-align:center;color:#94a3b8;padding:50px 20px}}
.foot{{margin-top:24px;padding:14px;background:#fff;border:1px solid #e2e8f0;border-radius:12px;
font-size:12.5px;color:#64748b;line-height:1.8}}
.foot b{{color:#334155}}
@media(max-width:640px){{body{{padding:12px}}h1{{font-size:20px}}.chead{{flex-direction:column}}}}
</style></head><body><div class="wrap">
<h1>Hermes 技能清单</h1>
<div class="sub">生成日期 __DATE__ ｜ 共 __N__ 个技能 ｜ 目录 __ROOT__</div>
<div class="stats">
  <div class="stat"><div class="n">__N__</div><div class="l">技能总数</div></div>
  <div class="stat"><div class="n">__NC__</div><div class="l">专属定制（中文触发）</div></div>
  <div class="stat"><div class="n">__NG__</div><div class="l">通用工具</div></div>
  <div class="stat"><div class="n">__NCA__</div><div class="l">分类</div></div>
  <div class="stat"><div class="n">__SZ__</div><div class="l">总体积</div></div>
</div>
<div class="toolbar">
  <input type="search" id="q" placeholder="搜索技能名 / 简介 / 分类…（拼多多、快递、加班、飞书）">
  <div class="chips" id="chips"></div>
</div>
<div class="grid" id="list"></div>
<div class="empty" id="empty" style="display:none">没有匹配的技能，换个词试试</div>
<div class="foot">
  <b>怎么用这些技能</b><br>技能是操作手册，不需手动调用 —— 说对话我会自动匹配。例如说加班通知／采拼多多帮助中心／核快递账单。<br><br>
  <b>怎么装到别的机器</b><br>技能就是普通文件夹。整包迁移：把 <code>__ROOT__</code> 整个拷过去。<br>
  单个安装：把技能文件夹复制到目标机 <code>&lt;Hermes目录&gt;/skills/&lt;分类&gt;/</code>。<br>
  <b>注意</b>：技能里的脚本路径是本机绝对路径（D:\ / E:\），换机器要改。
</div></div>
<script>
const DATA = __PAYLOAD__;
const CATS = __CATS__;
let curCat = '';
const chips = document.getElementById('chips');
const mk = (label, val) => {{ const d = document.createElement('div');
  d.className = 'chip' + (val === curCat ? ' on' : ''); d.textContent = label;
  d.onclick = () => {{ curCat = val; render(); }}; return d; }};
chips.appendChild(mk('全部 ' + DATA.length, ''));
chips.appendChild(mk('专属定制 ' + DATA.filter(x => x.custom).length, '__mine'));
CATS.forEach(c => chips.appendChild(mk(c + ' ' + DATA.filter(x => x.cat === c).length, c)));
const VALS = [''].concat(['__mine']).concat(CATS);
function esc(s) {{ return String(s).replace(/[&<>"]/g, m => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}})[m]); }}
function render() {{
  const q = document.getElementById('q').value.trim().toLowerCase();
  let rows = DATA;
  if (curCat === '__mine') rows = rows.filter(x => x.custom);
  else if (curCat) rows = rows.filter(x => x.cat === curCat);
  if (q) rows = rows.filter(x => (x.name + ' ' + x.desc + ' ' + x.cat + ' ' + x.dir).toLowerCase().includes(q));
  [...chips.children].forEach((el, i) => el.classList.toggle('on', VALS[i] === curCat));
  const list = document.getElementById('list');
  list.innerHTML = rows.map(x => {{
    const install = `cp -r "${{x.path}}" "<目标机>/skills/${{x.cat}}/"`;
    const zipcmd  = `cd "${{x.path}}/.." && zip -r "${{x.dir}}.zip" "${{x.dir}}"`;
    return `<div class="card${{x.custom ? ' mine' : ''}}">
      <div class="chead"><div class="cname"><code>${{esc(x.name)}}</code></div>
      <div class="tags"><span class="tag ${{x.custom ? 'mine' : 'builtin'}}">${{x.custom ? '专属' : '通用'}}</span>
      <span class="tag cat">${{esc(x.cat)}}</span>
      <span class="tag sz">${{x.size_h}} · ${{x.files}} 文件</span></div></div>
      <div class="cdesc">${{esc(x.desc) || '（无简介）'}}</div>
      <div class="cpath">${{esc(x.path)}}</div>
      <div class="cmds">
        <div class="cmdrow"><div class="cmd">${{esc(install)}}</div><button class="cp" data-c="${{esc(install)}}">复制</button></div>
        <div class="cmdrow"><div class="cmd">${{esc(zipcmd)}}</div><button class="cp" data-c="${{esc(zipcmd)}}">复制</button></div>
      </div></div>`;
  }}).join('');
  document.getElementById('empty').style.display = rows.length ? 'none' : 'block';
  list.querySelectorAll('.cp').forEach(b => {{
    b.onclick = () => navigator.clipboard.writeText(b.dataset.c).then(() => {{
      b.textContent = '已复制'; b.classList.add('ok');
      setTimeout(() => {{ b.textContent = '复制'; b.classList.remove('ok'); }}, 1200);
    }}).catch(() => {{ b.textContent = '失败'; setTimeout(() => {{ b.textContent = '复制'; }}, 900); }});
  }});
}}
document.getElementById('q').addEventListener('input', render);
render();
</script></body></html>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=DEFAULT_ROOT)
    ap.add_argument("--out", default=DEFAULT_OUT)
    a = ap.parse_args()

    items = collect(a.root)
    if not items:
        print(f"❌ {a.root} 下没找到任何 SKILL.md")
        return 1

    n_all = len(items)
    n_custom = sum(1 for x in items if x["custom"])
    cats = sorted({x["cat"] for x in items})
    total_size = sum(x["size"] for x in items)
    date = datetime.date.today().strftime("%Y.%m.%d")

    html = (TEMPLATE
            .replace("__DATE__", date).replace("__ROOT__", a.root)
            .replace("__N__", str(n_all)).replace("__NC__", str(n_custom))
            .replace("__NG__", str(n_all - n_custom)).replace("__NCA__", str(len(cats)))
            .replace("__SZ__", human(total_size))
            .replace("__PAYLOAD__", json.dumps(items, ensure_ascii=False))
            .replace("__CATS__", json.dumps(cats, ensure_ascii=False)))

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w", encoding="utf-8").write(html)
    json.dump(items, open(os.path.join(os.path.dirname(a.out), "skills_index.json"),
                          "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    print(f"✅ {a.out}")
    print(f"   技能 {n_all}（专属 {n_custom} / 通用 {n_all - n_custom}）| 分类 {len(cats)} | {human(total_size)}")
    print(f"   页面 {len(html):,} 字符")
    print("\n── 分类分布 ──")
    for c, n in collections.Counter(x["cat"] for x in items).most_common():
        print(f"   {c:<26} {n}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
