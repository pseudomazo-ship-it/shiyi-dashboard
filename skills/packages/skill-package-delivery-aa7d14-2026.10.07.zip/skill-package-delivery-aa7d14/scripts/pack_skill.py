#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""打包 Hermes 技能 → zip 交付给十一。

用法见 SKILL.md「打包」节。核心行为：
  · 自动在 skills/ 下按目录名找技能目录
  · 收 SKILL.md + 技能自带的 scripts/references/templates/assets（若有）
  · 收 Hermes scripts/ 下的运行脚本（--scripts）
  · 可选参考 md（--ref-md）与 README（--readme）
  · 清理同目录旧包；遇到占用锁（PermissionError）自动改用 _vN 命名，不中断
  · 输出逐文件字节数 + testzip() 结果
"""
import argparse
import datetime
import glob
import os
import re
import sys
import zipfile

SKILLS_ROOT = r"E:\RuanJian\Hermes\skills"
HERMES_SCRIPTS = r"E:\RuanJian\Hermes\scripts"
SUBS = ("scripts", "references", "templates", "assets")


def find_skill_dir(name):
    for root, _dirs, files in os.walk(SKILLS_ROOT):
        if os.path.basename(root) == name and "SKILL.md" in files:
            return root
    return None


def collect(skill_dir, skill_name, scripts, ref_md, readme):
    entries = [(os.path.join(skill_dir, "SKILL.md"), f"{skill_name}/SKILL.md")]
    for sub in SUBS:
        d = os.path.join(skill_dir, sub)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if os.path.isfile(p):
                entries.append((p, f"{skill_name}/{sub}/{f}"))

    for s in scripts:
        p = s if os.path.isabs(s) else os.path.join(HERMES_SCRIPTS, s)
        if os.path.exists(p):
            entries.append((p, f"scripts/{os.path.basename(p)}"))
        else:
            print(f"  ! 缺失脚本 {s}")

    if ref_md:
        if os.path.exists(ref_md):
            entries.append((ref_md, f"参考-{os.path.basename(ref_md)}"))
        else:
            print(f"  ! 缺失参考 md {ref_md}")

    if readme:
        if os.path.exists(readme):
            entries.append((readme, "README.txt"))
        else:
            print(f"  ! 缺失 README {readme}")
    return entries


def clean_old(out_dir, label):
    """删旧包。返回被占用的文件名列表。占用锁不是失败。"""
    pattern = os.path.join(out_dir, f"{label}-技能包_*.zip")
    locked, maxv = [], 1
    for old in sorted(glob.glob(pattern)):
        base = os.path.basename(old)
        m = re.search(r"_v(\d+)\.zip$", base)
        if m:
            maxv = max(maxv, int(m.group(1)))
        try:
            os.remove(old)
            print(f"  已删旧包 {base}")
        except PermissionError:
            locked.append(base)
            print(f"  旧包被占用，跳过 {base}（十一开着，换名继续）")
    return locked, maxv


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True, help="技能目录名（= SKILL.md 的 name）")
    ap.add_argument("--label", required=True, help="交付名，如 数据日报看板")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--scripts", nargs="*", default=[],
                    help="Hermes scripts/ 下的文件名（或绝对路径）")
    ap.add_argument("--ref-md", default=None, help="随包附上的参考 md")
    ap.add_argument("--readme", default=None, help="README 源文件（会存为 README.txt）")
    a = ap.parse_args()

    skill_dir = find_skill_dir(a.skill)
    if not skill_dir:
        print(f"❌ 找不到技能目录: {a.skill}（在 {SKILLS_ROOT} 下按目录名找）")
        return 2

    os.makedirs(a.out, exist_ok=True)
    entries = collect(skill_dir, a.skill, a.scripts, a.ref_md, a.readme)
    if not entries:
        print("❌ 没有任何文件可打包")
        return 2

    locked, maxv = clean_old(a.out, a.label)

    today = datetime.datetime.now().strftime("%Y.%m.%d")
    suffix = f"_v{maxv + 1}" if locked else ""
    zp = os.path.join(a.out, f"{a.label}-技能包_{today}{suffix}.zip")

    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for src, arc in entries:
            z.write(src, arc)
            print(f"  + {arc:<56} {os.path.getsize(src):>9,} B")

    with zipfile.ZipFile(zp) as z:
        bad = z.testzip()
        n = len(z.namelist())

    print(f"\n✅ {os.path.basename(zp)}")
    print(f"   {os.path.getsize(zp):,} 字节｜{n} 个文件｜testzip: {bad or 'OK'}")
    print(f"   路径: {zp}")
    if locked:
        print(f"   ⚠️ 这些旧包被占用删不掉，关掉后需再清: {locked}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
