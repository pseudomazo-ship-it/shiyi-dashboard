# -*- coding: utf-8 -*-
"""蒙倩 店铺货损「欠公司业绩」台账生成器 —— 一次产出 xlsx + md

跑法：uv run --with openpyxl python generate_huosun_ledger.py
改法：只改 RAW（追加月份）和 OUT_DIR（当期工作区目录）两处。

口径：数值 =(退款+推广费)/业绩；标准线 46%；
      欠公司业绩 = 业绩×(数值-46%)，仅超标为正时计；各店取整到分后再求和。

注意：本机无 LibreOffice，公式无法重算 -> 一律写算好的定值，不写公式。
"""
import os
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

STD = 0.46
DATED = datetime.date.today().strftime("%Y.%m.%d")          # 文件名后缀 = 生成当天
OUT_DIR = (r"D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\Hermes Agent"
           r"\电商💚店铺产品数据运营")

# (月份, 店铺, 性质, 业绩, 推广费, 退款)
RAW = [
    ("7月", "蒙倩个护官方旗舰店",     "单链货损",  26092.31, 11958.67,  3290.81),
    ("7月", "蒙倩美容美发官方旗舰店", "单链货损",   1025.23,   668.15,   156.41),
    ("7月", "蒙倩美妆洗护官方旗舰店", "新店货损", 179416.86, 73408.32, 22239.52),
    ("7月", "蒙倩美发旗舰店",         "新店货损",  44704.69, 18874.76,  6657.91),
    ("7月", "蒙倩美发护发旗舰店",     "新店货损",  48591.25, 18610.64,  7102.35),
    ("8月", "蒙倩个护官方旗舰店",     "单链货损",  51345.80, 23401.61, 10216.41),
    ("8月", "蒙倩美容美发官方旗舰店", "单链货损",   7933.10,  4518.31,  2645.92),
    ("8月", "蒙倩护发官方旗舰店",     "单链货损",  16226.93,  6475.42,  3424.80),
    ("8月", "蒙倩美发护发旗舰店",     "新店货损",  72536.72, 30275.40, 11993.41),
    ("8月", "蒙倩美发旗舰店",         "新店货损",  60074.47, 23556.98, 10632.37),
    ("8月", "蒙倩美妆洗护官方旗舰店", "新店货损", 150060.17, 57463.76, 20145.75),
]

HEAD = ["月份", "店铺", "性质", "业绩", "推广费", "退款",
        "退款+推广费", "数值", "超标", "欠公司业绩"]
MONEY, PCT = "#,##0.00", "0.00%"

# ---------- 计算 ----------
rows = []
for m, n, t, y, tg, tk in RAW:
    s = tg + tk
    r = s / y
    rows.append([m, n, t, y, tg, tk, s, r, r - STD, round(y * (r - STD), 2)])

ty = sum(r[3] for r in rows)
ttg = sum(r[4] for r in rows)
ttk = sum(r[5] for r in rows)
ts = sum(r[6] for r in rows)
towed = round(sum(r[9] for r in rows), 2)        # 各店取整后求和，保证表格自洽
rows.append(["合计", "—", "—", ty, ttg, ttk, ts, ts / ty, ts / ty - STD, towed])

# ---------- xlsx ----------
wb = Workbook()
ws = wb.active
ws.title = "货损欠业绩"
thin = Side(style="thin", color="D9D9D9")
bd = Border(left=thin, right=thin, top=thin, bottom=thin)

ws.append(HEAD)
for c in range(1, len(HEAD) + 1):
    cell = ws.cell(row=1, column=c)
    cell.font = Font(bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="1F3864")
    cell.alignment = Alignment(horizontal="center", vertical="center")
    cell.border = bd
for r in rows:
    ws.append(r)

for i in range(2, ws.max_row + 1):
    is_sum = ws.cell(row=i, column=1).value == "合计"
    for c in range(1, len(HEAD) + 1):
        cell = ws.cell(row=i, column=c)
        cell.border = bd
        if is_sum:
            cell.fill = PatternFill("solid", fgColor="F2F2F2")
            cell.font = Font(bold=True)
        if c in (4, 5, 6, 7, 10):
            cell.number_format = MONEY
        if c in (8, 9):
            cell.number_format = PCT
        if not is_sum:
            if c in (4, 5, 6):
                cell.font = Font(color="0000CC")     # 蓝 = 手工输入
            elif c in (7, 10):
                cell.font = Font(color="000000")    # 黑 = 计算得出
        if c in (2, 3):
            cell.alignment = Alignment(horizontal="left")

ws.freeze_panes = "A2"
for i, w in enumerate([8, 24, 10, 13, 13, 12, 14, 10, 10, 14], 1):
    ws.column_dimensions[get_column_letter(i)].width = w

xlsx_path = os.path.join(OUT_DIR, "蒙倩_店铺货损欠业绩_%s.xlsx" % DATED)
wb.save(xlsx_path)

# ---------- md（与 xlsx 同源；正文数字一律程序拼，禁止手打）----------
y2 = lambda v: "{:,.2f}".format(v)
p2 = lambda v: "{:.2f}%".format(v * 100)
sp = lambda v: ("%+.2f%%" % (v * 100))

detail, sum_row = rows[:-1], rows[-1]
md = ["# 蒙倩 店铺货损「欠公司业绩」统计\n",
      "**统计日期**：%s ｜ 标准线 46%%\n" % DATED,
      "> 数值 =（退款 + 推广费）÷ 业绩 ｜ 超标 = 数值 − 46% ｜ "
      "欠公司业绩 = 业绩 × 超标（仅超标为正时计；各店取整到分后求和）\n",
      "## 明细（金额：元）\n",
      "| 月份 | 店铺 | 性质 | 业绩 | 推广费 | 退款 | 退款+推广费 | 数值 | 超标 | 欠公司业绩 |",
      "|---|---|---|---|---|---|---|---|---|---|"]
for r in detail:
    md.append("| %s | %s | %s | %s | %s | %s | %s | %s | %s | **%s** |" % (
        r[0], r[1], r[2], y2(r[3]), y2(r[4]), y2(r[5]), y2(r[6]), p2(r[7]), p2(r[8]), y2(r[9])))
md.append("| **合计** | — | — | **%s** | **%s** | **%s** | **%s** | **%s** | **%s** | **%s** |" % (
    y2(sum_row[3]), y2(sum_row[4]), y2(sum_row[5]), y2(sum_row[6]),
    p2(sum_row[7]), p2(sum_row[8]), y2(sum_row[9])))
md.append("")

# 汇总：按月 + 按性质
md += ["## 汇总\n", "| 口径 | 欠公司业绩 |", "|---|---|"]
months = sorted({r[0] for r in detail})
for m in months:
    g = [r for r in detail if r[0] == m]
    md.append("| %s（%d家） | %s |" % (m, len(g), y2(sum(r[9] for r in g))))
md.append("| **合计** | **%s** |" % y2(sum_row[9]))
for tag in ("单链货损", "新店货损"):
    g = [r for r in detail if r[2] == tag]
    if g:
        md.append("| 其中 %s（%d家次） | %s |" % (tag, len(g), y2(sum(r[9] for r in g))))
md.append("")

# 同店环比（两月都出现的店）
pair = {}
for r in detail:
    pair.setdefault(r[1], {})[r[0]] = r
both = {n: v for n, v in pair.items() if len(v) >= 2}
if both:
    ms = sorted({r[0] for r in detail})
    a, b = ms[0], ms[-1]
    md += ["## 同店 %s→%s 对比（两月都有的 %d 家）\n" % (a, b, len(both)),
           "| 店铺 | %s数值 | %s数值 | 变化 | %s欠 | %s欠 |" % (a, b, a, b),
           "|---|---|---|---|---|---|"]
    for n, v in both.items():
        md.append("| %s | %s | %s | %s | %s | %s |" % (
            n, p2(v[a][7]), p2(v[b][7]), sp(v[b][7] - v[a][7]), y2(v[a][9]), y2(v[b][9])))
    md.append("")

# 结论（从数据推，别手写死）
worst = max(detail, key=lambda r: r[8])
big = max(detail, key=lambda r: r[9])
md += ["## 结论\n",
       "- **合计欠公司业绩 %s**。" % y2(sum_row[9]),
       "- **超标幅度最大**：%s（数值 %s，超标 %s）。" % (worst[1], p2(worst[7]), p2(worst[8])),
       "- **欠款绝对额最大**：%s（%s 元）。" % (big[1], y2(big[9])),
       "", "## 说明\n",
       "- 数值为已计算好的定值；如需「改输入自动重算」的活表可另出一版。",
       "- 生成脚本：`generate_huosun_ledger.py`（追加月份改 RAW 即可重跑）。", ""]

md_path = os.path.join(OUT_DIR, "蒙倩_店铺货损欠业绩_%s.md" % DATED)
with open(md_path, "w", encoding="utf-8") as f:
    f.write("\n".join(md))

print("saved:", xlsx_path)
print("saved:", md_path)
for r in rows:
    print(r[0], r[1], "数值=%.2f%%" % (r[7] * 100), "超标=%.2f%%" % (r[8] * 100), "欠=%.2f" % r[9])
