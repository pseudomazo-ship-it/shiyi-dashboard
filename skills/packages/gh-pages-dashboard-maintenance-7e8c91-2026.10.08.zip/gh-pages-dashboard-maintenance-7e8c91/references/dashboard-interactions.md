# 单文件看板交互（悬停 tooltip / 图例筛选 / 验证）

适用：生成器（`build_view.py` 这类）产出的**单文件 HTML** 看板，手写内联 SVG 折线图，**不引 echarts/d3**。
2026-09-21 在「评价星级日采集」看板上实测跑通。

---

## 一、悬停节点看当天数据（tooltip）

两个需求：① 大图悬停某天的点 → 看那天数字；② 多序列对比图悬停某天 → **一次列出当天所有可见序列**。

全部纯 JS，无依赖：

1. 页面放一个绝对定位浮层：`<div id="chartTip" class="chartTip"></div>`
   （`position:fixed;display:none;pointer-events:none` —— `pointer-events:none` 很关键，否则浮层自己会挡住鼠标）。
2. `window.chartTip(ev, html)` = 填 `innerHTML` + 按 `ev.clientX/clientY` 定位 + `display='block'`；`chartTipHide()` 隐藏。
3. **数据点**：每个点后画一个**透明命中圈**放大热区
   ```html
   <circle cx=… cy=… r="12" fill="transparent" style="cursor:crosshair"
           onmouseover="chartTip(event,'…')" onmouseout="chartTipHide()"/>
   ```
   `r=12` 手感刚好；`fill="transparent"` 不影响视觉但能接事件。
4. **横轴日期**：每天一条**透明竖带**（`<rect>` 占满 y 范围）→ 一次给出当天全部序列；
   标签/值**一一对齐**（用同一个 labels 数组索引，防缺天错位）。
5. tooltip 内容**跟着筛选状态走**：只遍历「当前可见」的序列 → 点图例只看一条后，tooltip 也只列那一条 ✓。

### ⚠️ 坑：内容要嵌进 `onmouseover="…"` 属性 → **内容里的内层 HTML 不能带引号**
外层是双引号属性，内层再用双引号会提前闭合：
- ✅ `<span class=tipdot style=background:#e11d48></span>`（不带引号）
- ❌ `<span style="background:#e11d48">`
更稳的做法：颜色/文字先算成变量再拼，或改用 `addEventListener` 绑定而非内联属性。

---

## 二、点图例筛选单条序列（Y 轴跟着缩）

- 点图例 = 只看这一条，**Y 轴自动缩放到该序列自己的 min/max**（否则几条相近的线挤成一坨，什么也看不出）；
  再点 = 看全部；`Ctrl/Shift+点` = 叠加多条；配一个「全部显示」重置。
- **只有 1 天数据也要渲染**（至少画点）；折线需 ≥2 天 —— 早期写成「1 天不渲染」，用户看着像坏了。
- ⚠️ **聊天窗口的预览窗格不派发点击给页面 JS** → 在预览里点图例「没反应」是**能力边界，不是 bug**。
  要验交互：**双击 html 用浏览器打开**，或直接开线上地址。

---

## 三、怎么验证交互真的生效（最省事的办法）

**在页面上下文里派发 DOM 事件**，直接触发 `onmouseover` 那段逻辑：

```python
js("(() => { "
   "const c = document.querySelectorAll('#dsrChart circle[r=\\"12\\"]')[4];"
   "c.dispatchEvent(new MouseEvent('mouseover',{bubbles:true,clientX:200,clientY:200}));"
   "const t = document.getElementById('chartTip');"
   "return [t.style.display, t.innerText]; })()")
```

实测一次验到 4 件事：内容对不对、列了几个序列、移开后是否隐藏、筛选后是否只列可见的 ✓。
比追真实鼠标事件省事得多，也不受标签页是否在前台影响。

---

## 四、自检清单

1. 生成器跑通（`py_compile` + **真生成一次**），产物里能 grep 到 `chartTip`。
2. 命中热区数量 = 数据点数（大图）/ 日期数（多图）。
3. 悬停 → 有内容；移开 → `display:none`。
4. 点图例筛选后再悬停 → **只列可见序列**。
5. 发布线上后加 `?v=时间戳` 再看（CDN + 浏览器双层缓存）。
