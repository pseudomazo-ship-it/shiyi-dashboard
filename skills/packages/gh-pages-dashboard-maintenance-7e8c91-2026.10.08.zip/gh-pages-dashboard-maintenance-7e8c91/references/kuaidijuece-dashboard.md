# 快递决策看板（shiyi-kuaidijuece）结构与更新细节

> 线上：https://shiyi11.com.cn/logistics/board/ （密码与主体财务看板同一个）
> 仓库：`pseudomazo-ship-it/shiyi-kuaidijuece`（根目录只有 `index.html` + `.nojekyll`，约 53-55KB 单文件）
> 本地工作副本：`E:\RuanJian\Hermes\cache\kuaidijuece-git`
> 2026-09-20 实测：commit `d8fd73e`，线上回读验证通过

---

## 一、页面结构

单文件 HTML，含密码门（`login-overlay` / `ACCESS_PASSWORD` / `sessionStorage.expressDashboardUnlocked`）。

```
<body>
  <div class="login-overlay" id="loginOverlay"> … 密码门 …
  <main class="app">
    <header class="hero">
      <div> eyebrow / <h1>快递决策看板</h1> / <p>说明+价格表版本</p> </div>
      <div class="hero-meta">   ← 右上角，chip 区（flex; justify-content:flex-end）
        <span class="meta-chip">广西云仓 · 中通</span> …
      </div>
    </header>
    <section class="toolbar"> 板块一｜两仓三网决策 / 板块二｜襄阳仓两网决策（data-mode=1/2）
    … 当前决策总览 / 全国快递分配 / 多地区快速决策 …
    renderRules() → <section class="section panel rule-panel"><h3>当前决策规则</h3><div class="rules">…
```

---

## 二、内嵌数据对象（JS，全在同一个 `<script>` 里）

| 对象 | 内容 |
|---|---|
| `postalZones` | 邮政：8 个区 × 7 档（≤300g/≤500g/≤1kg/≤2kg/≤3kg/≤5kg/续重），如 `'三区2': [['云南','北京','内蒙古','海南'], [2.00,2.60,3.10,3.60,4.60,4.00,1.50]]` |
| `zoneOrder` / `allProvinces` | 分区顺序、省份全集 |
| `ytoRates` | 圆通（≤1kg/≤2kg/≤3kg） |
| **`ztoRates`** | **中通**，档位顺序 `[0.01-0.5KG, 0.51-1KG, 1.01-2KG, 2.01-3kg, 3.01-4kg, 4.01-5kg]`，值形如 `'江苏省':[1.35,1.60,2.65,3.30,9.80,11.80]`；西藏/新疆 = `null`（走特殊计价） |
| `ztoProvinceSurcharge` | `{'上海':1,'海南':1,'北京':'bj'}`（`bj`=北京按重量分段加价） |
| `ztoCitySurcharge` | `{'广州':0.5,'深圳':0.5,'阿坝州':'sp','甘孜州':'sp','凉山州':'sp','北戴河区':0.5,'海港区':0.3,'山海关区':0.3,'昌黎县':0.3}` |
| `specialCities` | 按省列特殊城市 + note（给表格展示用） |
| `POSTAL_SLA` | 邮政时效承诺 |
| `XIANGYANG_ADJUSTMENT` | `0.3`（邮政/圆通襄阳加价） |
| `HB_AROUND` | `['湖北','湖南','江西','安徽','河南','陕西','重庆']` |

---

## 三、改数据的正确姿势（块内替换）

### 为什么不能全局替换
2026-09-20 把中通 2.01-3kg 档 3.10→3.30：全文 `3.10` 共 **16 处**，其中
- **3 处是邮政价**（`postalZones` 三区2／三区3／四区）→ 全局替换会改坏邮政价，且**不报错**
- 13 处是 `ztoRates` 常规省

### 替换片段（本次实际使用）
```python
import io
p = r'…\kuaidijuece-git\index.html'
s = io.open(p, encoding='utf-8').read()

i = s.find('ztoRates'); j = s.find('};', i)
block = s[i:j]
block = block.replace('2.65,3.10,9.80', '2.65,3.30,9.80')   # 常规13省  3.10→3.30
block = block.replace('2.65,3.55,9.80', '2.65,3.75,9.80')   # 川渝贵云鲁冀津晋陕 9省  3.55→3.75
block = block.replace('6.70,15.35,', '6.70,15.55,')         # 辽吉黑 3省
block = block.replace('7.70,15.35,', '7.70,15.55,')         # 宁甘青内 4省
s = s[:i] + block + s[j:]
io.open(p, 'w', encoding='utf-8').write(s)
```
**要点**：
- 一律用**带前后锚点的长串**（`2.65,3.10,9.80`），不写裸数字
- 偏远档两种前置价：`6.70,15.35,`（辽吉黑，1-2KG=6.70）与 `7.70,15.35,`（宁甘青内，1-2KG=7.70）
- 改完自检：`postalZones` 切片内 `3.10` **仍应存在**

### 顺带要改的三处（用户按它们认版本）
```python
# ① title
s = s.replace('<title>快递决策看板｜2026/07/25费率</title>',
              '<title>快递决策看板｜2026/09/20费率</title>')
# ② header <p> 说明
old = '<p>…中通价格表：2026/04/03执行；邮政、圆通按本次提供表格。</p>'
new = ('<p>…中通价格表：2026/04/03执行'
       '（<b>2026/09/19起 2.01-3kg档 +0.20元</b>）；邮政、圆通按本次提供表格。</p>')
# ③ 右上角时间 chip（加在 hero-meta 的第一个）
s = s.replace('<div class="hero-meta">\n      <span class="meta-chip">广西云仓 · 中通</span>',
  '<div class="hero-meta">\n      <span class="meta-chip" '
  'style="border-color:#16a34a;background:#f0fdf4;color:#15803d;font-weight:700">更新于 2026/09/20</span>\n'
  '      <span class="meta-chip">广西云仓 · 中通</span>')
```

### 加规则条目（数组驱动）
`renderRules()` 里是 `rules.map(item => \`<div class="rule"><b>${item[0]}</b><span>${item[1]}</span></div>\`)`，
数据是两组 `[['标题','内容'], …]`（板块一 / 板块二，用 `] : [` 分隔）。
中通相关规则加在**板块一**数组的**最后一项之后**（本次加在 `['时效口径', …]` 后面）：
```python
anchor = "    ['时效口径','其他地区未提供完整三网时效表，按价格推荐']\n  ] : ["
```
2026-09-20 实际加入 5 条：`中通调价(9/19起)` / `云仓包装费` / `偏远比考核(9/11起)` / `其他费用` / `账单结构`。

---

## 四、验证脚本（本地 + 线上）

```python
import io, re
s = io.open('index.html', encoding='utf-8').read()
# 1) 新价在
for k in ['江苏省', '四川省', '辽宁省', '内蒙古']:
    m = re.search(r"'%s':(\[[^\]]*\]|null)" % k, s[s.find('ztoRates'):s.find('};', s.find('ztoRates'))])
    print(k, m.group(1))
# 2) 邮政块未被误改
k = s.find('postalZones')
print('邮政块 3.10 出现:', s[k:s.find('};', k)].count('3.10'), '（应 >0）')
# 3) 结构完整
print(s.count('<html'), s.count('</html>'), s.count('<script'), s.count('</script>'))
```
线上回读（CDN 缓存要绕过）：
```python
html = urllib.request.urlopen(url + '?v=20260920', timeout=40, context=ctx).read().decode('utf-8','ignore')
assert '2.65,3.30,9.80' in html and '更新于 2026/09/20' in html
```

---

## 五、2026-09-20 更新记录（本次）

| # | 变更 | 值 |
|---|---|---|
| 1 | 中通 2.01-3kg 档 +0.2 元（2026/9/19 起，**全部省份**） | 常规 3.10→**3.30**（13省）｜川渝贵云鲁冀津晋陕 3.55→**3.75**（9省）｜辽吉黑宁甘青内 15.35→**15.55**（7省） |
| 2 | 右上角更新时间 chip | `更新于 2026/09/20`（绿色） |
| 3 | title | `2026/07/25费率` → `2026/09/20费率` |
| 4 | header 说明 | 补注「2026/09/19起 2.01-3kg档 +0.20元」 |
| 5 | 决策规则区 +5 条 | 中通调价／云仓包装费(8类)／偏远比考核(东三6%·西四3%，超限1.5·2.5元)／其他费用(岛屿·大货·拦截·退件·拆包，÷2分摊)／账单结构 |

**连带影响（要主动告诉十一）**：中通 2kg 档涨到 2.85（含襄阳0.30）后，
**湖北/湖南/江西/安徽/河南** 的 2kg 件决策会从「中通」变为「邮政」2.80 —— 看板逻辑自动重算，
这不是 bug，是涨价后果。

---

## 六、与工作区文档的分工

- **看板**＝线上对外/决策用（只放价格与规则，不放账单明细）
- **工作区 `数据--云仓费用规则/云仓费用规则总表_YYYY.MM.DD.xlsx`**＝完整费用标准台账（含账单执行核对锚点）
- 两者要同步改：改完看板记得回去更新总表，反之亦然（十一两侧都会看）。
