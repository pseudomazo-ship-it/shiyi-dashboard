# GH Pages 发布 + 回读验证（具体命令序列）

## 1. 定位与确认
```bash
# 仓库公开信息(默认分支/私有/文件列表) -- 克隆前必做
curl -s https://api.github.com/repos/pseudomazo-ship-it/shiyi-dashboard | python -c "import sys,json;d=json.load(sys.stdin);print(d['default_branch'],d['private'])"
python - <<'PY'
import json,urllib.request
items=json.load(urllib.request.urlopen(urllib.request.Request(
  "https://api.github.com/repos/pseudomazo-ship-it/shiyi-dashboard/contents/",headers={"User-Agent":"x"})))
for i in items: print(i['type'], i['name'], i.get('size'))
PY
```
预期：默认分支 `main`，根目录 = `index.html`(旧尺寸) + `.nojekyll`(空)。

## 2. 克隆到 cache(不污染成品区)
```bash
cd /e/软件/Hermes && rm -rf cache/shiyi-dashboard-git
GIT_TERMINAL_PROMPT=0 git clone https://github.com/<user>/shiyi-dashboard.git cache/shiyi-dashboard-git
```
凭证：本机 git 已配 Git Credential Manager(GCM)，clone/push 会静默识别已有登录态；`git config user.name`=Eleven, `user.email`=pseudomazo@gmail.com。若 GCM 弹交互式登录窗口，等待用户操作，勿在 pty 里裸敲。

## 3. 替换 index.html 并提交
```bash
cd /e/软件/Hermes/cache/shiyi-dashboard-git
# 先 md5 确认新旧确实不同，避免推了没更新的旧文件
md5sum "<源\.html>" index.html
cp "<源\.html>" index.html
md5sum index.html

git add index.html
git commit -m "更新看板: <说明>"
git push origin main
```

## 4. 等待 Pages 部署 + 回读验证
Pages 推送后 ~30–90s 生效。**不要猜**，回读线上。
```python
import urllib.request, re
body = urllib.request.urlopen(urllib.request.Request(
  "https://shiyi11.com.cn/",
  headers={"User-Agent":"Mozilla/5.0"}), timeout=30).read().decode("utf-8")
# 断言：补全后的新数值、密码 token、代表性主体销售额未误改
assert "967090.09" in body, "新值未上线"          # 本次=镭聚仓储补全
assert "bXE1MjA1MjA=" in body, "密码token丢失"
assert "7752385.0" in body, "主体销售额被误改"
print("线上 index 字节:", len(body.encode("utf-8")))
```
> flake: 一次 `curl -o file` 在 MSYS 下偶发写不进(路径/重定向问题)，改用 Python urllib 直接读最稳。

## 关键注意
- 只回读验证**一个**代表性补数值 + 密码 token + 一个未动值，三项足够确认真上线，别把整个 JSON 都对一遍。
- 推送成功后线上旧尺寸(如 510853)会变(紧凑 JSON 版本更小，如 214545)，属正常。
- 若 `browser_exec` 被 Chrome「allow remote debugging」弹窗卡住，直接改用 urllib(见上)，不要为只读验证绕回浏览器。

## ⚠️ 回读验证 ≠ 确认你的版本上线(并发提交陷阱)
本会话教训：我推了 `296fc12` 并回读到部分新值后宣布「已上线」——但实际上线上 HEAD 是更晚
别人推的 `9488a65f`(43 主体、更新日期 2026/08/31)，我推的版本被叠加了。**只断言「值存在」不够**，
因为别人那版也可能含相同值。必须核对 commit：
```bash
# 线上当前 HEAD sha(唯一权威)  -- 万一回读到 9488a65f 而非你的 296fc12, 说明没真正接管
curl -s https://api.github.com/repos/<user>/<repo>/commits/main | \
  python -c "import sys,json;d=json.load(sys.stdin);print('HEAD',d['sha'][:8],d['commit']['author']['date'],d['commit']['message'][:50])"
# 列出最近提交, 看你的 sha 在不在、是否被覆盖
curl -s "https://api.github.com/repos/<user>/<repo>/commits?per_page=5" | python -c "import sys,json;[print(c['sha'][:8],c['commit']['author']['date'],c['commit']['message'][:45]) for c in json.load(sys.stdin)]"
```
- `git log --oneline`(本地克隆) 与 `api /commits`(线上) 应一致；若本地 HEAD 是别人的晚提交，
  说明你的 push 成功但随后被覆盖。
- 判断「进不去」时的辅助：本地克隆 HEAD(=线上当前版)也可直接拿来加载验证文件健康度，不用等公网回读。
- 若用户反馈「进不去」，先回读+编译+解码密码确认文件健康，再让用户 Ctrl+F5/无痕重开(CDN+浏览器缓存是主因)。
