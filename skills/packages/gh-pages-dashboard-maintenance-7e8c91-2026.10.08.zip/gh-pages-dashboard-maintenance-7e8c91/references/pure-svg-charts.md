# 无依赖纯 SVG 图表件（单文件看板用）

十一 2026-09-25：「数据方面以**表格、仪表盘、柱状图、折线图、饼图、指标卡、表格、进度图**等形式展现」
——以下四个件可拼出上述全部形式（柱/进度 = 横向条形；饼 = 环形图）。

**硬约束**：不引任何外部 CDN（echarts/chart.js 一律不用）。看板要能 `file://` 双击离线打开、
要嵌密码门，多一个外部依赖就多一个“用户打不开”的现场。全部手写 SVG。

---

## 0. 通用几何公式（踩过的错都在这里）

```js
const pt  = (a, r) => [cx + r*Math.cos(a), cy + r*Math.sin(a)];       // 极角 → 直角坐标
const ang = v => a0 + (clamp(v)/MAX) * (a1-a0);                        // 值 → 角度
const large = (ang(to) - ang(from)) > Math.PI ? 1 : 0;                 // 弧 > 180° 才置 1
```

- **半圆的 a0/a1 是 `Math.PI → Math.PI*2`**（左到右的上半圆弧）。写成 `0 → Math.PI` 会变成下半圆（开口朝上），看着像倒着。
- **`large-arc-flag` 漏了就出错**：弧超过 180° 时必须为 `1`，否则 SVG 会自己选“短的那一边”绕过去，大扇区直接画反。
- **扇区起始角从 `-Math.PI/2` 开始**（12 点方向），否则环形图从 3 点开始、不符合直觉。
- 坐标一律 `.toFixed(1)` 再拼进 path —— 浮点全精度会让 HTML 大几十 KB、且无意义。

---

## 1. 仪表盘 gauge（半圆 + 标准线刻线）

```js
function renderGauge(cur){
  const el = document.getElementById('gauge'); if(!el) return;
  const STD = 46, MAX = 100;                 // ⚠️ 量程取 100，别取 70（用户会问「为什么不是100」）
  const W = 260, H = 162, cx = 130, cy = 136, R = 98, SW = 17;
  const a0 = Math.PI, a1 = Math.PI * 2;
  const clamp = v => Math.max(0, Math.min(MAX, v));
  const ang = v => a0 + (clamp(v)/MAX) * (a1-a0);
  const pt  = (a, r) => [cx + r*Math.cos(a), cy + r*Math.sin(a)];
  const arc = (from, to, r) => {
    const [x1,y1] = pt(ang(from), r), [x2,y2] = pt(ang(to), r);
    const large = (ang(to)-ang(from)) > Math.PI ? 1 : 0;
    return `M ${x1.toFixed(1)} ${y1.toFixed(1)} A ${r} ${r} 0 ${large} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
  };
  const cvar = cur >= 46 ? '#e5484d' : (cur >= 42 ? '#e08600' : '#0ea472');
  const diff = cur - STD;
  // 标准线刻线：从内径到外径横跨色带
  const [sx1,sy1] = pt(ang(STD), R - SW/2 - 4), [sx2,sy2] = pt(ang(STD), R + SW/2 + 4);
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:262px">
    <path d="${arc(0, MAX, R)}" fill="none" stroke="#eef1f6" stroke-width="${SW}" stroke-linecap="round"/>
    <path d="${arc(0, cur, R)}" fill="none" stroke="${cvar}" stroke-width="${SW}" stroke-linecap="round"/>
    <line x1="${sx1.toFixed(1)}" y1="${sy1.toFixed(1)}" x2="${sx2.toFixed(1)}" y2="${sy2.toFixed(1)}"
          stroke="#12151b" stroke-width="2.4" stroke-linecap="round"/>
    <text x="${cx}" y="${cy-38}" text-anchor="middle" font-size="43" font-weight="800"
          fill="#12151b" letter-spacing="-2">${cur.toFixed(1)}<tspan font-size="19" font-weight="700"
          fill="#5a6474">%</tspan></text>
    <text x="${cx}" y="${cy-8}" text-anchor="middle" font-size="13" font-weight="700"
          fill="${diff>0?'#e5484d':'#0ea472'}">${diff>0?'高于':'低于'}标准线 ${Math.abs(diff).toFixed(1)}pt</text>
    <text x="12" y="${cy+15}" font-size="11.5" fill="#98a1b0" font-weight="600">0%</text>
    <text x="${W-12}" y="${cy+15}" text-anchor="end" font-size="11.5" fill="#98a1b0" font-weight="600">${MAX}%</text>
  </svg>`;
}
```

- **大数字写在圆心上方**（`cy-38`），弧本身不叠字；`<tspan>` 把 `%` 缩小靠下，视觉更像数据产品。
- **刻度标签（0% / 100%）放在 `cy+15`**（弧线两端下方），不要放在弧顶。

---

## 2. 环形图 donut（业绩构成）

```js
function renderDonut(P, R, A){
  const el = document.getElementById('donut'); if(!el) return;
  const rest = Math.max(0, P - R - A);
  const parts = [
    { n:'退款',     v:R,           c:'#e5484d' },
    { n:'推广费',   v:A,           c:'#e08600' },
    { n:'其他成本', v:rest*0.22,   c:'#7c5cf0' },
    { n:'净额',     v:rest*0.78,   c:'#0ea472' }
  ].filter(x => x.v > 0);
  const tot = parts.reduce((a,b)=>a+b.v, 0) || 1;
  const S = 168, cx = S/2, cy = S/2, R1 = 62, SW = 26, rMid = R1 - SW/2;
  let a = -Math.PI/2, ring = '';                     // ⚠️ -90° 起画 = 12 点方向
  parts.forEach(pp => {
    const sweep = pp.v/tot * Math.PI * 2, a2 = a + sweep;
    if(sweep > 0.001){
      const [x1,y1] = [cx + rMid*Math.cos(a),  cy + rMid*Math.sin(a)];
      const [x2,y2] = [cx + rMid*Math.cos(a2), cy + rMid*Math.sin(a2)];
      const large = sweep > Math.PI ? 1 : 0;          // ⚠️ 漏了这个大扇区会画反
      ring += `<path d="M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${rMid} ${rMid} 0 ${large} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}"
        fill="none" stroke="${pp.c}" stroke-width="${SW}" stroke-linecap="butt"/>`;
    }
    a = a2;
  });
  const rate = (R + A)/tot * 100;                     // 中心数 = 退款+推广 占比
  const rows = parts.map(pp => `<div style="display:flex;align-items:center;gap:7px;font-size:13px;
      font-weight:700;color:var(--ink2);margin-bottom:7px">
      <i style="width:10px;height:10px;border-radius:3px;background:${pp.c};flex:none"></i>
      <span style="flex:1">${pp.n}</span>
      <b style="color:var(--ink)">${(pp.v/tot*100).toFixed(1)}%</b></div>`).join('');
  el.innerHTML = `<div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;justify-content:center">
    <svg viewBox="0 0 ${S} ${S}" width="${S}" height="${S}" style="flex:none">${ring}
      <text x="${cx}" y="${cy-2}" text-anchor="middle" font-size="25" font-weight="800"
            fill="#12151b" letter-spacing="-1">${rate.toFixed(1)}%</text>
      <text x="${cx}" y="${cy+17}" text-anchor="middle" font-size="11.5" font-weight="700"
            fill="#98a1b0">退款+推广</text>
    </svg>
    <div style="min-width:118px">${rows}</div>
  </div>`;
}
```

- **用 `stroke-width` + `rMid` 画环，不要用 `fill` 的 path 拼扇区** —— 后者要在内外弧之间收口，
  极容易算出破面。`rMid = R - SW/2`（色带中心线半径）这一行是关键。
- ⚠️ **语义必须自洽**：标题写「**业绩构成**」而不是「成本结构」；中心写「退款+推广」而不是「成本占比」。
  否则「中心 46.4%」与「图例总和 58.2%」会让人以为算错了（十一会问）。
- `filter(x => x.v > 0)` 必加 —— 0 值扇区会画出 `A r r 0 0 1 x y` 这种零长度弧，某些浏览器渲染出毛刺。

---

## 3. 面积折线图（趋势）

```js
function renderLine(sel){
  const box = document.getElementById('linechart'); if(!box) return;
  const n = sel.length;
  if(n < 2){ box.innerHTML = '<div style="color:var(--ink3);font-size:14px;padding:20px 0">数据不足，至少需要 2 天</div>'; return; }
  const vals = sel.map(d => byDay[d].p);
  const mx = Math.max(...vals), mn = Math.min(...vals);
  const PL = 52, PR = 18, PT = 18, PB = 34;
  const cw = Math.max(560, n * 62);                    // 窗口窄也不挤、日子多可横滑
  const W = cw + PL + PR, H = 250;
  const gx = i => PL + (n === 1 ? 0 : i * (cw / (n - 1)));
  const gy = v => PT + (H - PT - PB) * (1 - (v - mn*0.9) / ((mx*1.08 - mn*0.9) || 1));
  const pts = vals.map((v,i) => [gx(i), gy(v)]);
  const line = pts.map((q,i) => (i?'L':'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join(' ');
  const area = line + ` L ${pts[n-1][0].toFixed(1)} ${H-PB} L ${pts[0][0].toFixed(1)} ${H-PB} Z`;
  // …Y 轴 4 格 grid + ylab、数据点 circle（峰顶加大 + 标注）、X 轴 M/D…
  box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">
    <defs><linearGradient id="lgArea" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#2563eb" stop-opacity=".20"/>
      <stop offset="100%" stop-color="#2563eb" stop-opacity="0"/>
    </linearGradient></defs>
    ${grid}${ylab}
    <path d="${area}" fill="url(#lgArea)"/>
    <path d="${line}" fill="none" stroke="#2563eb" stroke-width="2.6"
          stroke-linecap="round" stroke-linejoin="round"/>
    ${dots}${xlab}
  </svg>`;
}
```

- **Y 轴不从 0 起**：用 `mn*0.9 → mx*1.08` 拉伸，否则电商日业绩的波动会被压成一条平线看不出趋势。
- **`cw = max(560, n*62)`** 让窗口再窄也铺满、日子多了横向可滑（配 `.linewrap{overflow-x:auto}`）。
- **X 轴标签抽稀**：`if(n <= 16 || i % Math.ceil(n/12) === 0)` —— 当月 23 个点时全画会糊成一团。
- 数据点用 `<circle><title>日期　金额</title></circle>` —— **原生 tooltip，零 JS**，悬停就能看具体值。
- ⚠️ 折线图只在「近7天/当月」显示；「当日」「近3天」整块 `display:none`。

---

## 4. KPI 迷你趋势线 sparkline

```js
function sparkline(vals, color){
  if(!vals || vals.length < 2) return '';
  const w = 130, h = 26, pad = 3;
  const mx = Math.max(...vals), mn = Math.min(...vals), rng = (mx - mn) || 1;
  const step = w / (vals.length - 1);
  const pts = vals.map((v,i) => [i*step, h - pad - (v-mn)/rng*(h-pad*2)]);
  const d = pts.map((p,i) => (i?'L':'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const gid = 'sg' + Math.random().toString(36).slice(2,8);    // ⚠️ 每张图独立 id
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${color}" stop-opacity=".2"/>
      <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
    </linearGradient></defs>
    <path d="${d} L ${w} ${h} L 0 ${h} Z" fill="url(#${gid})"/>
    <path d="${d}" fill="none" stroke="${color}" stroke-width="1.8"
          stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}
```

- ⚠️ **渐变 `<linearGradient>` 的 id 必须每张唯一**（同一页 6 张卡）—— 写死 `lgArea` 会让所有
  sparkline 抢用第一个渐变，换成别的颜色失效。
- 容器 `.kpi .spark{margin-top:9px;height:26px;width:100%}` + `preserveAspectRatio="none"` 才能拉满卡宽不变形。
- 环比小字没有数据的两张卡（单量类）也照样给 sparkline，否则那两张会显得空。

---

## 5. 横向条形 / 进度条（各店铺业绩）

纯 `div` + `width:%`，不用 SVG（要横滑、要文字跟着走）：
```css
.srow .sbar{flex:1;min-width:0;height:22px;background:var(--surface2);border-radius:7px;
  overflow:hidden;border:1px solid var(--line)}
.srow .sbar i{display:block;height:100%;border-radius:6px;
  background:linear-gradient(90deg,#7facf7,#2563eb);transition:width .5s cubic-bezier(.2,.8,.3,1)}
.srow.top .sbar i{background:linear-gradient(90deg,#4fd1a5,#0ea472)}   /* 第一名绿 */
```
`width: b.p/mx*100 + '%'`，右侧并列 `业绩` 与 `数值%`（数值按 30%/20% 分红/橙/绿）。

---

## 6. 验证（必须读 DOM，不能只看生成成功）

```python
js("document.querySelectorAll('.spark').length")      # → 6
js("!!document.querySelector('#gauge svg')")           # → True
js("document.querySelectorAll('#donut svg path').length")  # → 4
js("document.querySelectorAll('#linechart svg circle').length")  # → 天数
js("getComputedStyle(document.getElementById('kpis')).gridTemplateColumns")  # 6 列等宽
```
再加上 `vision_analyze` 看截图 —— 它抓「机制性 bug」比抓审美准（本次抓出语义色反了、HTML 转义没渲）。
**但它会把「折叠后默认一片空白」误报成排版问题，它报的结论要按当前设计意图筛一遍再用。**
