# 看板整套换配色（语义色映射法）

> 场景：十一说「换个美化风格」/「多做几个风格我看看」/「用这个风格」。
> 做法：**只换颜色，不动类名和结构**——所以数据、JS、交互一概不可能被搞坏。
> 范例脚本：`E:\RuanJian\Hermes\scripts\stylekit_variants.py`（把 550KB 看板批量出 10 个风格版）。

---

## 一、stylekit 风格库（配色来源）

| 项 | 值 |
|---|---|
| 技能装在 | `E:\RuanJian\Hermes\skills\creative\stylekit`（v0.6.0 / MIT）|
| **正确仓库** | `https://github.com/AnxForever/stylekit-skill` ← Agent Skill |
| ⛔ 别搞混 | `https://github.com/AnxForever/stylekit` 是 **Next.js 网站项目，不是 skill** |
| 拉全文风的接口 | `GET https://www.stylekit.top/api/styles`（返回 `{total:148, styles:[{slug,name,nameEn}]}`）|
| 拉单风格规格 | `GET https://www.stylekit.top/api/styles/<slug>` → `{colors:{primary,secondary,accent[]}, ...}` |
| 本地脚本 | `python scripts/fetch-style.py <slug>`（从技能目录跑）|

**安全审查结论（2026-09-27 实测，可放心用）**：POST/PUT 上传 = **0 处**，上报本机指纹 = 无，
删/写本地文件 = 0，扫描敏感目录 = 无；**唯一网络请求是 GET `stylekit.top`**；
`benchmark.py --llm` 才会调 OpenAI，默认不调。
（它**只读不写不外传**，和 SkillScan / agent-overflow 那种上传型完全不同。）

---

## 二、语义色槽 → 10 套风格色板

先把原 CSS 的所有色值归到左边这些**语义槽**，再按行换成目标风格的值。
（原值取自 Fluent 风那一版；换色后旧值必须全部归零。）

| 语义槽 | 原值（Fluent） | ①Stripe | ②Shopify | ③Notion | ④Linear★深 | ⑤Apple |
|---|---|---|---|---|---|---|
| `bg` | `#f4f6f9` | `#f6f9fc` | `#f7f7f8` | `#ffffff` | `#0a0a0b` | `#f5f5f7` |
| `surface` 卡片 | `#fff` + `rgba(255,255,255,.76)` | `#ffffff` | `#ffffff` | `#fbfbfa` | `#16161a` | `#ffffff` |
| `line` | `#e7eaf0` | `#e6ebf1` | `#e3e3e3` | `#e9e9e7` | `#2a2a30` | `#d2d2d7` |
| `ink` | `#12151b` | `#0a2540` | `#1a1a1a` | `#37352f` | `#f7f8f8` | `#1d1d1f` |
| `ink2` | `#5a6474` | `#425466` | `#4a4a4a` | `#5f5e5b` | `#b4b8c5` | `#515154` |
| `ink3` | `#98a1b0` | `#8898aa` | `#8c8c8c` | `#9b9a97` | `#7a7f8c` | `#86868b` |
| `brand` 主色 | `#2563eb` | `#635bff` | `#008060` | `#37352f` | `#5e6ad2` | `#0071e3` |
| `good` | `#0ea472` | `#0e9f6e` | `#008060` | `#0f7b6c` | `#27ae60` | `#34c759` |
| `warn` | `#e08600` | `#c47f00` | `#b98900` | `#b25e09` | `#f2c94c` | `#f0a020` |
| `bad` | `#e5484d` | `#e0426a` | `#c53030` | `#eb5757` | `#eb5757` | `#ff3b30` |
| `violet` | `#7c5cf0` | `#7a73ff` | `#5b4b8a` | `#a083ff` | `#8b7fd4` | `#a13ff6` |
| `cyan` | `#0891b2` | `#00a8cc` | `#0d7d8c` | `#2eaadc` | `#2d9cdb` | `#32ade6` |

| 语义槽 | ⑥Corporate | ⑦GitHub | ⑧Dashboard | **⑨Minimal★选中** | ⑩Fluent |
|---|---|---|---|---|---|
| `bg` | `#f8fafc` | `#ffffff` | `#f9fafb` | **`#ffffff`** | `#faf9f8` |
| `surface` | `#ffffff` | `#f6f8fa` | `#ffffff` | **`#fafafa`** | `#ffffff` |
| `line` | `#e2e8f0` | `#d0d7de` | `#e5e7eb` | **`#e5e5e5`** | `#e1dfdd` |
| `ink` | `#0f172a` | `#1f2328` | `#111827` | **`#000000`** | `#201f1e` |
| `ink2` | `#475569` | `#59636e` | `#4b5563` | **`#525252`** | `#605e5c` |
| `ink3` | `#94a3b8` | `#8c959f` | `#9ca3af` | **`#a3a3a3`** | `#a19f9d` |
| `brand` | `#1e40af` | `#0969da` | `#6366f1` | **`#000000` 纯黑** | `#0078d4` |
| `good` | `#10b981` | `#1f883d` | `#10b981` | **`#00b894`** | `#107c10` |
| `warn` | `#d97706` | `#9a6700` | `#f59e0b` | **`#d9a400`** | `#8a6200` |
| `bad` | `#dc2626` | `#cf222e` | `#ef4444` | **`#e6395f`** | `#a4262c` |
| `violet` | `#c559f0` | `#8250df` | `#8b5cf6` | **`#7c3aed`** | `#8764b8` |
| `cyan` | `#0891b2` | `#1d7f98` | `#06b6d4` | **`#0891b2`** | `#00838f` |

⚠️ **⑨Minimal 是十一 2026-09-27 拍板选定的**（主色纯黑 + 高饱和语义色），
配套：每槽还要有 `_l` 浅底版（如 `good_l=#e6faf6`、`bad_l=#ffeaf0`、`brand_l=#f5f5f5`）。

⚙️ 另外每套风格还带三项：`ff`（字体栈）、`r_card`（卡片圆角）、`r_pill`（pill 圆角）—— 一起换才像换了风格。

---

## 三、换色脚本骨架（照抄改）

```python
SEMANTIC = {   # 同一语义可能对应多个原值（历史遗留色），全列进来
  "bg":     ["#f4f6f9","#fafbfc","#fafcff","#f3f2f1","#faf9f8"],
  "line":   ["#e7eaf0","#d5dae3","#e1e1e1","#c8c6c4","#e8e7e6","#d9e5ef"],
  "ink":    ["#12151b","#323130"],
  "brand":  ["#2563eb","#3b82f6","#1d4ed8","#0078d4","#005a9e","#106ebe"],
  # … good/warn/bad/violet/cyan 及其 _l 浅底
}

# ① 毛玻璃卡片底（rgba）必须最先换；深色主题换成成品色调的 rgba
for o, a in [("rgba(255,255,255,.82)","0.92"),("rgba(255,255,255,.76)","0.90"),("rgba(255,255,255,.72)","0.88")]:
    t = t.replace(o, f"rgba(250,250,250,{a})")

# ② 语义色逐槽换
for sem, olds in SEMANTIC.items():
    for o in olds:
        t = t.replace(o, THEME[sem])

# ③ 纯白最后换，且必须带词边界（否则污染 #fffbe6 之类）
import re
t = re.sub(r"#fff(?![0-9a-fA-F])", THEME["surface"], t)

# ④ 字体 / 圆角
# ⑤ 自检：旧色归零 + 无非法 hex + 结构配平
assert not re.findall(r"#[0-9a-fA-F]{7,}\b", t), "有非法色值，多半是 #fff 没加词边界"
assert t.count("<section") == t.count("</section>")
```

---

## 四、给十一「看风格」的做法

他说「**多做几个我看看**」时，交付三件套：

1. **N 个完整版 HTML**（每个都是能真打开、能点时段切换的成品，不是截图）
2. **`screenshots/` 目录**：每个风格截一张首屏
3. **`00_风格对比.html`**：卡片网格罗列（缩略图 + 风格名 + 中文描述 + 色板小方块 + 「打开完整看板 →」链接）

截图要点：
```python
cdp('Emulation.setDeviceMetricsOverride', width=1400, height=1000, deviceScaleFactor=1, mobile=False)
goto_url("file:///" + html_path.replace("\\","/")); wait_for_load(); time.sleep(1.3)
js("(()=>{const g=document.getElementById('gate'); if(g) g.remove();"
   "const a=document.getElementById('app'); if(a) a.style.display=''; return 1;})()")   # 跳过密码门
time.sleep(1.0)
shutil.copy(capture_screenshot(), dst)   # ⚠️ 每张截完立刻 copy，否则固定文件名互相覆盖
```

- ⚠️ **每个风格都要独立文件**（不要 N 个风格挤在一个文件里切换）——他可能直接点开某个发人。
- ⚠️ **深色风格必须先用 `vision_analyze` 扫一眼**：本次 ④Linear 首版「背景黑了但卡片还是白的」，
  白底配浅字 → **6 张 KPI 的主数值几乎看不见**，是我漏换毛玻璃卡片底造成的。
  用 `getComputedStyle` 实测确认：`bodyBg=rgb(10,10,11)`、`kpiBg=rgb(22,22,26)`、`kpiVal=rgb(247,248,248)`（对比度 13:1）。
- 推荐话术：指出「④Linear 是深色，手机上看数据累眼」——诚实提示比堆结论更有用。

---

## 五、顺带：两个板块并排（「放在同一行内，**不合并**」）

十一原话：「这两个指标放在同一行内（**不合并**）」= 并排但**各自独立折叠**。

```html
<div class="twocol">
  <section>…各店铺明细…</section>
  <section class="notice">…数据提示…</section>
</div>
```
```css
.wrap>.twocol, #app>.twocol{grid-column:1/-1;min-width:0;margin-top:28px;
  display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px;align-items:start}
.twocol > section{margin-top:0 !important;min-width:0;grid-column:auto}
.twocol .ni{flex-direction:column;align-items:flex-start;gap:3px}   /* 窄栏里改上下两行，否则店名被挤断 */
.twocol table{min-width:700px;font-size:12.5px}
.twocol thead th:first-child,.twocol tbody td.sh{min-width:170px;white-space:nowrap}
@media(max-width:1100px){ /* 手机变上下单栏 */ }
```

**四个坑（全踩了）**：
1. `grid-column:1/-1` 不能省 —— `#app` 是 12 栏 grid，div 不写就只占 1 栏（93px）。
2. 表格 7 列塞进 660px 栏会**截断店铺名** → 给表格 `min-width` + 店名列 `nowrap`，不够就横向滚动。
3. `.ni`（提示条目）在窄栏里要把 `flex-direction` 改成 `column`，否则店名被挤断。
4. **板块显隐逻辑要同步它**：近30天要隐藏这两个板块时，`#app > section` 选择器**选不到 `.twocol`（它是 div）**，
   必须单独写 `document.querySelector('#app > .twocol').style.display = ONLY_TREND ? 'none' : ''`。
   → **通用规则：以后凡新增非 `<section>` 的直接子容器，都要同步加进显隐逻辑。**

验证（实测值）：
```
twocolW=1337px   cols=[679.5, 679.5]   sideBySide=true
店铺名 scrollWidth <= clientWidth+1 → true（不截断）
```
