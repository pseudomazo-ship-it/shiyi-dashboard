# 看板版式改动的布局 / 测量手法（2026-10-08 实踩，全部已跑通）

改单文件看板的排版（挪板块、改栅格、加悬浮件、加排序/提示）时，按这个顺序做：
**先量 → 再改 → 再量 → 最后才推**。这条流程能挡掉本会话踩的全部六个坑。

---

## 0. 测量前置：折叠板块里的元素量出来一定是 0

看板普遍有「板块可折叠、长板块默认收起」。此时板块带 `.collapsed`，内部元素
`getBoundingClientRect()` 返回 **0 宽 0 高**、`offsetWidth` 为 0。

**症状**：你以为 CSS 没生效 / 元素没了，其实只是板块收着。本会话为此白查两轮
（先怀疑 `.core{display:none}`、又怀疑「有两个 `#waterBands`」，都不是）。

**动作**：量之前先把目标板块点开。

```js
js('''(()=>{document.querySelectorAll('section.section').forEach(s=>{
  const h=s.querySelector('h2');
  if(h && h.textContent.includes('数值水位') && s.classList.contains('collapsed'))
    s.querySelector('.section-head').click();
}); return 1;})()''')
time.sleep(1.5)   # 展开有过渡动画，等一下再量
```

---

## 1. 沿父链量宽 —— 定位「右边一大片留白」的标准手法

不要猜是哪层限制了宽度，直接一路打上去：

```js
js('''(()=>{let el=document.querySelector('#waterBands'); const out=[];
while(el && el.tagName!=='BODY'){
  const r=el.getBoundingClientRect(), cs=getComputedStyle(el);
  out.push(el.tagName+'.'+(el.className||'').toString().split(' ').slice(0,2).join('.')+
    ' 宽='+Math.round(r.width)+' left='+Math.round(r.left)+' right='+Math.round(r.right)+
    ' display='+cs.display+' cols='+cs.gridTemplateColumns.slice(0,60));
  el=el.parentElement;
}
return out.join('\\n');})()''')
```

本会话的输出（一眼看出根因）：

```
DIV.bands   宽=822  left=277  display=grid cols=184.4px 184.4px 184.4px 184.4px
DIV.core    宽=1454 left=277  display=grid cols=821.7px 632.1px    ← 两列！
SECTION     ...
MAIN.page   宽=1540
```

**根因**：`.core` 是两列栅格（左 = 环形图 `.gauge-row`、右 = 构成图 `.composition`）；
四档 `.bands` 是它的**第三个**直接子元素 → 自动换到第二行，但**仍然只占第一列**，
右边 632 px 整块空着。

**修法**（一行）：

```css
.bands{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;
  grid-column:1/-1;      /* ← 跨满整行，消灭右侧留白 */
  align-items:start;     /* ← 高度自适应，短的那列不再被拉平 */}
```

修完复核（本会话实测）：容器宽 822 → **1454**，四档各 **343 px**，右边界与主内容区齐平，
**右侧剩余空白 0 px**。

> 同类坑的旁证：`.wrap`（`#app`）本身就是 12 栏 Grid，子元素靠
> `.wrap>section{grid-column:1/-1}` 跨满；**任何新增的非 `<section>` 直接子容器都必须自己写 `grid-column:1/-1`**
> （见 `references/theme-swap-semantic-mapping.md` 里「两栏各 38px 完全塌掉」那条）。规律是同一个。

---

## 2. 常驻悬浮面板：`position:fixed` + 必须挂到 `document.body`

需求形态：「这个说明/图例固定在页面右下角，点一下向上展开，别占版面」。

```css
details.rules-dock{position:fixed;right:18px;bottom:18px;z-index:80;background:#fff;
  border:1px solid var(--line);border-radius:11px;box-shadow:0 10px 28px rgba(15,23,42,.16);
  padding:10px 14px;max-width:345px;width:max-content}
/* 向上展开：summary 落到底部，内容弹在上方 */
details.rules-dock[open]{display:flex;flex-direction:column-reverse}
details.rules-dock summary{cursor:pointer;list-style:none;display:flex;align-items:center;gap:6px}
details.rules-dock summary::-webkit-details-marker{display:none}
details.rules-dock summary::before{content:"▴";color:#94a3b8;font-size:11px}
details.rules-dock[open] summary::before{content:"▾"}
details.rules-dock[open] summary{margin-top:9px;margin-bottom:0}
```

⚠️ **关键坑：面板所处的位置决定它会不会消失。** 第一版我把它留在「异常预警」板块的
卡片列表里 → **板块默认收起时，面板跟着一起不见**（祖先隐藏，fixed 也救不了）。

**正解：页面脚本里把它提到 body 级**（不用改生成器的模板结构，4 行搞定）：

```js
(function(){var rk=document.querySelector('details.rulerow');
  if(rk && rk.parentElement!==document.body) document.body.appendChild(rk);})();
```

验证（解锁密码门后）：`position=fixed`、父元素是 `body`、
距视口右下各 ~18 px、收起态约 190×42 px、点击后 `flexDirection=column-reverse`
且 `规则区.bottom <= summary.top`（证明确实向上展开）。

---

## 3. 表头点击排序（真实数值，不是文本）

```html
<table class="table sortable">
  <thead><tr>
    <th data-col="0">店铺</th>
    <th data-col="1" data-type="num">业绩</th>
    <th data-col="3" data-type="num">数值</th>
  </tr></thead>
  <tbody id="tableBody"></tbody>
</table>
```

单元格带**真实数值**（`data-v`），文本只负责显示：

```js
`<tr><td data-v="${r.name}">${r.name}</td>
   <td data-v="${r.money}" data-label="业绩">${r.moneyRaw}万</td>
   <td data-v="${r.delta}" data-label="环比" class="...">…</td></tr>`
```

```js
document.querySelectorAll('table.sortable').forEach(function(tb){
  var body=tb.querySelector('tbody');
  tb.querySelectorAll('th[data-col]').forEach(function(th){
    th.onclick=function(){
      var c=+th.dataset.col, num=th.dataset.type==='num';
      var dir=th.dataset.dir==='asc'?'desc':'asc';
      tb.querySelectorAll('th[data-col]').forEach(function(x){delete x.dataset.dir;x.classList.remove('asc','desc')});
      th.dataset.dir=dir; th.classList.add(dir);
      var rows=Array.prototype.slice.call(body.querySelectorAll('tr'));
      rows.sort(function(a,b){
        var x,y;
        if(num){ x=parseFloat(a.children[c].dataset.v||a.children[c].textContent)||-1e9;
                 y=parseFloat(b.children[c].dataset.v||b.children[c].textContent)||-1e9;
                 return dir==='asc'?x-y:y-x; }
        x=a.children[c].textContent.trim(); y=b.children[c].textContent.trim();
        return dir==='asc'?x.localeCompare(y,'zh'):y.localeCompare(x,'zh');
      });
      rows.forEach(function(r){body.appendChild(r)});
    };
  });
});
```

配套 CSS：
```css
table.sortable th[data-col]{cursor:pointer;user-select:none}
table.sortable th[data-col]::after{content:"⇅";margin-left:5px;font-size:11px;color:#94a3b8}
table.sortable th[data-col].asc::after{content:"▲";color:#2563eb}
table.sortable th[data-col].desc::after{content:"▼";color:#2563eb}
```

要点：
- **按 `data-v` 的真实数字排** —— 否则「9%」会被排到「100%」后面（字符串比较）。
- 空值/未登记统一给 `-1e9`，落在最后。
- 合计行要 `data-col` 排除或排完再 append 回末尾；本次做法是合计行不参与排序、固定在最后。
- 实测：业绩升序 `0.67 / 0.67 / 0.68 万`，再点一次降序 `31.62 / 20.65 / 18.75 万`。
- 明细表**每个时段各一张**（多份 HTML），`querySelectorAll('table.sortable')` 一次覆盖全部 ——
  切时段后照样能点。

---

## 4. 即时 tooltip（替换原生 `title`）

用户口径：「**趋势线每个节点鼠标放上去要显示对应时间和数据**」。
原生 `title` 要**停约 1 秒**才弹、样式朴素 → 用户会说「看不到/不好用」。

**① 数据挂 `data-tip`，不要用 `title`**（两者会打架，出现双提示）：
```python
dots += ('<i class="pt" style="left:%.2f%%;top:%.2f%%;background:%s" data-tip="%s ｜ %s"></i>'
         % (px(i)/w*100, py(v)/h*100, col(v), dates[i], vtxt[i]))
```

**② 一个全局提示 div + 事件委托**：
```js
(function(){
  var tp=document.createElement('div'); tp.id='ttip'; document.body.appendChild(tp);
  document.addEventListener('mouseover',function(e){
    var t=e.target.closest&&e.target.closest('.pt'); if(!t||!t.dataset.tip) return;
    tp.textContent=t.dataset.tip; tp.style.display='block';
    var r=t.getBoundingClientRect();
    tp.style.left=Math.min(window.innerWidth-tp.offsetWidth-10,
                 Math.max(10, r.left+r.width/2-tp.offsetWidth/2))+'px';
    tp.style.top=Math.max(10, r.top-tp.offsetHeight-10)+'px';
  });
  document.addEventListener('mouseout',function(e){
    var t=e.target.closest&&e.target.closest('.pt'); if(t) tp.style.display='none'; });
  document.addEventListener('scroll',function(){tp.style.display='none';},true);
})();
```
```css
#ttip{position:fixed;z-index:9999;display:none;background:#0f172a;color:#fff;font-size:12.5px;
  padding:6px 10px;border-radius:7px;pointer-events:none;white-space:nowrap;
  box-shadow:0 8px 22px rgba(15,23,42,.28);font-variant-numeric:tabular-nums}
```

**③ 折线图要连圆点也能触发。** 原先只有「每列一条透明热区」（`.thit`），
鼠标落在**圆点**上不一定响应。给圆点也带上数据，并把选择器扩成两个：
```js
dots+=`<circle class="tdot" cx="…" cy="…" r="3.4" data-d="${日期}" data-v="${数值}万"/>`;
// 事件里：
var r=e.target.closest&&e.target.closest('.thit,.tdot');
```

**④ 验证要派发到元素本身**：把 `mouseout` 派发到 `document` 上不会触发隐藏
（`e.target.closest('.pt')` 为空，看着像 bug）—— **要派发到热区/圆点元素上**才算数。

---

## 5. 收尾自检清单（推之前跑）

```js
// ① 结构：四档是否同一行、右边界是否齐平
js('''(()=>{const bs=document.querySelectorAll('#waterBands > *'); const c=document.querySelector('#waterBands').getBoundingClientRect();
const core=document.querySelector('.core').getBoundingClientRect();
return '容器宽='+Math.round(c.width)+' right='+Math.round(c.right)+' 主内容right='+Math.round(core.right)+
' 右侧空白='+Math.round(core.right-c.right)+'px | 档宽='+Math.round(bs[0].getBoundingClientRect().width);})()''')

// ② 悬浮件：position 与归属
js('''(()=>{const d=document.querySelector('details.rulerow'); const r=d.getBoundingClientRect();
return getComputedStyle(d).position+' | 父='+(d.parentElement===document.body?'body':'非body')+
' | 距右下='+Math.round(innerWidth-r.right)+','+Math.round(innerHeight-r.bottom);})()''')

// ③ 顶层板块清单（板块被意外嵌套时一眼暴露）
js('''[...document.querySelectorAll('#app > section')].map(s=>{const h=s.querySelector('h2');
 return (h?h.innerText.split('\\n')[0].trim():'(无标题)')+' ['+getComputedStyle(s).display+']';}).join('\\n')''')
```

外加：**结构配平**（`scripts/check_html_structure.py`）与**污染检查**（`scripts/verify_dashboard_html.py`）
——这两个脚本本来就在本技能里，改模板后都跑一次。
