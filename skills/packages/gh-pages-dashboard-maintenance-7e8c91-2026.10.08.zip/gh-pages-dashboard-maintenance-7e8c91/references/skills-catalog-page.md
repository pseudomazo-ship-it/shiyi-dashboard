# 技能管理台（`/skills/`）维护实录 — 2026-10-07

十一原话：「**gh-pages-dashboard-maintenance、hermes-cron-script-jobs、linghangyuan-overtime；
🔗 https://shiyi11.com.cn/skills/（密码 12511251） 卡片简介，中文简介内容详细一些**」

## 一、文件地图（先认清楚，别一上来就 cp）

| 路径 | 角色 | 密码门 |
|---|---|---|
| `D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\skills.html` | **开发版**（Codex 侧产出，本地预览） | ❌ 无 |
| 同上 `skills_data.json` | 数据源（三方合并结果） | — |
| 同上 `build_catalog.py` | Codex 侧生成器 | — |
| `E:\RuanJian\Hermes\cache\shiyi-dashboard-git\skills\index.html` | **发布版**（= 线上那份） | ✅ 有 |
| `D:\Agent.GongZuoQu\Hermes.GZQ\数据--技能看板\merge_kanban.py` | Hermes 侧灌数据（在**我的**工作区） | — |
| 同上 `desc_1..5_*.py` | 短简介（卡片用，`description`） | — |
| 同上 `detail_A/B/C_*.py` | 长简介（详情面板用，`full_description`） | — |

线上：`https://shiyi11.com.cn/skills/`（密码 12511251），仓库 `pseudomazo-ship-it/shiyi-dashboard`，
Pages 路径 `skills/index.html`。

## 二、字段结构

内联在 HTML 里的一大段 JSON，每条长这样：
```json
{"id":"skill-1","name":"<技能名>","description":"<卡片简介>",
 "full_description":"<详情简介>","version":"…","category":"电商运营",
 "agent":"Hermes","scene":"算加班 · 出通知","original":true, …}
```
- `description` → 卡片，CSS `.description{-webkit-line-clamp:4}` 截 4 行
- `full_description` → 详情面板（渲染处 `s.full_description`）
- 卡片另有 `scene`（「算加班 · 出通知」这类短语）与 `original`（十一独创的「11.」橙标）

## 三、标准流程（本次走通的那条）

1. **改 Hermes 工作区那两个源头**：`desc_*.py`（短）+ `detail_*.py`（长）。
   多行相邻字符串会自动拼接成一个字符串，直接换整段即可。
2. **一键检查线上 vs 本地是不是同一形态**（防整份覆盖）：
   ```python
   old, new = 读(线上skills/index.html), 读(Codex...skills.html)
   for kw in ("password","gate","login"): print(kw, old.count(kw), new.count(kw))
   ```
   实测：`password` 旧 4 / 新 0，`login` 旧 10 / 新 0 → **本地是开发版**。
3. **只替换字段**（脚本名建议 `fix_live_descs.py`，数据源 = Codex 的 `skills_data.json`）：
   ```python
   pat_d = re.compile(r'("name":\s*"%s",\s*"description":\s*")[^"]*(")' % re.escape(name))
   pat_f = re.compile(r'("name":\s*"%s".{0,900}?"full_description":\s*")[^"]*(")'
                      % re.escape(name), re.S)
   ```
   每个 pattern 先 `findall` 计数，必须 == 1。
4. **写回前备份**：`cache\backup_live_skills_index_改前3_<日期>.html`。
5. **断言四件套**（全部通过才推）：
   - 三个技能的新值在（`desc[:40] in seg` / `full[:40] in seg`）
   - 旧简介**清零**（把旧文案的独特片段拿去 `count()`，必须 0）
   - 密码门关键字仍在（`password` / `gate` / `login`）
   - 字符数只增不减、且增量 ≈ 新文案字数
6. **推送**：`git add skills/index.html` → `commit` → `pull --rebase` → `push`（代理 `127.0.0.1:7897`）。
   本次一次成功：`f427b42..928438b main -> main`，`git status -sb` 显示 `## main...origin/main` 无 ahead。
7. **回读线上**：`sleep 50` → urllib 抓 `https://shiyi11.com.cn/skills/?v=<ts>`，
   比字符数（本地 305,756 = 线上 305,756），再逐技能断言新值在/旧值没、`password` 仍在。

⚠️ `git push` 会顺带报一句 `git-credential-manager.exe: No such file or directory`
（全局 helper 指向已迁走的旧目录 `E:/软件/Hermes/...`）—— **那不是失败**，push 照样成功，
看 `main -> main` 那行才算数。

## 四、`merge_kanban.py` 的两个毛病

### ① 不去重（会把 JSON 灌脏）
每次运行都 `现有条目: N → 合并后: N+177`。跑两次：528 → 705，177 个技能名各出现 2~4 次。
**判断**：`Counter(i['name'] for i in items)`，看有没有值 > 1。

**修复姿势**：
```python
codex = [x for x in lst if x.get('agent') != 'Hermes']   # 原样保留
herm  = {x['name']: x for x in lst if x.get('agent') == 'Hermes'}  # 只在 Hermes 内按 name 去重
out = codex + list(herm.values())
```
⛔ **别按 name 全局去重**：`github` / `pdf` / `xlsx` / `ima-skill` / `cocoloop` / `humanizer` /
`anthropic-frontend-design` / `stylekit` / `zhongkui-skill` / `computer-use` / `agent-browser` /
`self-improvement` 这些名字**三方共享**，全局去重会把 Codex 的 351 条砍到 58 条（本会话真踩）。

**先备份再动**：`cp skills_data.json cache/backup_skills_data_脏_<日期>.json`。
本会话忘了这步，跑错去重后只能从脏版再恢复重做。

### ② `full_description` 接错（长简介从来没生效）
`build_entry()` 里原本是：
```python
"description": d,
"full_description": d,      # ← 同一个值；detail_*.py 白写了
```
改成：
```python
# 在 DESC 加载之后补一段
DETAIL = {}
for fn, vn in [("detail_A_ecommerce.py","DETAIL_A"), ("detail_B_office.py","DETAIL_B"),
               ("detail_C_dev.py","DETAIL_C")]:
    try: DETAIL.update(load_mod(fn, vn))
    except Exception as _e: print("⚠️ detail 加载失败", fn, _e)
DETAIL = {k: v for k, v in DETAIL.items() if v}
...
"full_description": DETAIL.get(name, d),
```
⚠️ 改完**清 `__pycache__`** —— `load_mod` 用 `importlib`，pyc 缓存会让新代码不生效。

### ③ 跑它必然在 HTML 那步 `assert` 失败
`assert src.count(old_btn) == 1, "分类按钮锚点异常"` —— HTML 被别的窗口改过就命中不了。
**此时 JSON 已写、HTML 没写**，属正常：继续用「只搬字段」脚本改发布版即可。

## 五、注意事项

- **别碰 Codex 工作区的文件** —— 只有「输出到它、为共用产物」这一条路例外，
  且只改**自己（Hermes）名下的条目**。
- ✓ **卡片简介字数**：十一此前定过「4 行 ≈ 80 字」，但本次他明确要「**内容详细一些**」
  → 按当前指令走（写到 100~160 字），**并在回复里提一句已超原规范**，让他决定压不压回去。
- 本页与 `skills-catalog-sync`（十一自有技能）职责不同：后者管「新技能打包 + 同步推送」，
  本节管「页面本身的字段与坑」。

---

# 补中文简介实录 — 2026-10-08（一次改 5 个）

触发：自动同步推了一条「· domain-hosting-access-control / im-output-formatting /
skills-catalog-sync 已重新打包上线；**卡片简介暂用技能原文，要中文简介跟我说一声**」，
十一回「**卡片简介要中文简介，且介绍详细**」。

## 六、自动同步是怎么写简介的（先搞懂，才知道该在哪补）

`skills-catalog-sync` 里的 `scripts/skill_sync.py`（**十一自有技能，别改**）：
```python
# 第 233-234 行
'description':      desc or pack['description_raw'] or '本地技能，详见技能说明。',
'full_description': pack['description_raw'],
# 第 293-295 行
if old:   # 保留人工写过的字段，别每次同步把中文简介/场景冲掉
    for k in ('description','full_description','scene','icon','original','exclusive'):
        if old.get(k) and not (k == 'description' and args.desc): ...
```
- `description_raw` = 技能 `SKILL.md` frontmatter 的 `description` 字段，**原样搬运**。
  我的技能多数写的是 `Use when …` → 新技能卡片上就是英文/半英文。
- `--desc "中文简介"`（第 255 行）可在同步时直接给中文。
- **人工字段会被保留** → 补完中文简介后，后续同步不会冲掉。

## 七、批量补 5 个的实做步骤

覆盖：`domain-hosting-access-control` / `im-output-formatting` / `skills-catalog-sync` /
`feishu-api` / `logistics-bill-audit`。

1. **改源头**（单一事实源）：`desc_1_ecommerce.py` / `desc_2_productivity.py`（卡片）
   + `detail_A_ecommerce.py` / `detail_B_office.py`（详情）。
   ⚠️ `skills-catalog-sync` **在 desc/detail 里完全没有** → 现加到 `desc_2` + `detail_B`。
2. **灌三个产物**（写一个 `apply_*.py`，从 desc/detail import 后统一写）：
   - `<Codex>\skills_data.json`（遍历 `agent == 'Hermes'` 的条目改两个字段）
   - `<Codex>\skills.html`（开发版）
   - `cache/shiyi-dashboard-git/skills/index.html`（发布版 → 线上）
3. **逐文件断言**（见下）。
4. 推 `shiyi-dashboard` → 回读 `https://shiyi11.com.cn/skills/?v=<ts>` 比字符数。

## 八、本次踩的两个坑

### ① 断言脚本把「开发版无密码门」当成了失败
```python
ok = True
for kw in ('password','PASSWORD_TOKEN','gate'):
    if kw in ('password','gate'):
        ok &= (kw in t)      # ← Codex 开发版本来就没有 password → ok 恒 False
```
**症状**：替换明明打印「10 处 × 2 文件」，总判定却是 ❌。
**正解**：每个文件一份期望值 ——
```python
for path, tag, expect_gate in ((CODEX_HTML,'开发版',False), (LIVE_HTML,'发布版',True)):
    ...
    assert ('password' in t) == expect_gate
```

### ② 正则匹配 `full_description` 必须开窗口
`"name":"X", "description":"…", "full_description":"…"` —— 两个键之间隔着 `description`，
写 `("name":\s*"X",\s*"full_description"…)` **匹配不到且静默跳过**（只打印一句「未匹配」）。
必须用 `("name":\s*"X".{0,1200}?"full_description":\s*")[^"]*(")` + `re.S`。

## 九、本轮字数实况（可作下次的基准）

| 技能 | 卡片 `description` | 详情 `full_description` |
|---|---|---|
| domain-hosting-access-control | 224 字 | 291 字 |
| feishu-api | 200 字 | 258 字 |
| im-output-formatting | 185 字 | 281 字 |
| skills-catalog-sync | 158 字 | 254 字 |
| logistics-bill-audit | 135 字 | 236 字 |

- 卡片栏 CSS `-webkit-line-clamp:4` ≈ 80 字 → **上面这些在卡片上都会被截断**，完整版在详情面板。
  交付时**必须主动说明这一句**，否则他会以为排版坏了。
- 旧规范「4 行 ≈ 80 字」已被 2026-10-08 的「内容详细」覆盖；照当前指令写，并提一句已超原规范。

## 十、简介写法配方（下轮照抄）

```
① 是什么：功能 + 覆盖范围（一句话说全）
② 具体口径 / 产出 / 覆盖清单（用「、」列，别用「等」省略）
③ 「……时用」触发语（他靠这句判断什么时候找你）
④ 可选 ⚠️：最易踩的坑 / 与相邻技能的分工边界
```
反面：`用于处理 X 相关的任务。`（同义反复，等于没写）。
分工边界那句本轮很受欢迎，例：`logistics-bill-audit` 写明「只管查对方有没有多收；价格表/重量判档
看 kuaidi-duizhang；偏远占比规划看 express-region-planning」。
