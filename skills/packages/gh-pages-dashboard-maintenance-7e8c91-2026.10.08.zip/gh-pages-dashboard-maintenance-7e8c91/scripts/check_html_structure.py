# -*- coding: utf-8 -*-
"""
单文件看板 HTML 结构体检（无依赖，可直接跑）

用途：往生成器模板里插了新板块之后先跑一遍，把“标签漏闭合导致整页布局错乱”挡在交付前。
背景：2026-09-27 插「店铺趋势小结」板块时漏了一个 </section>，
      后面 5 个板块全被嵌套进去 → 十一看到的是「看板内容全乱了」。
      页面不报错、生成器 exit 0，所以只能靠结构断言。

用法：
    python check_html_structure.py <看板.html> [更多.html ...]

退出码：0 = 结构 OK；1 = 有问题
"""
import re
import sys

# 这些容器缺失说明模板被改坏了（按需增删；不存在的会报 MISS，不会报错）
EXPECT_IDS = [
    "app", "gate", "kpis",
    "gauge", "donut", "linechart",
    "shopbars", "shoptbl", "noticeBody", "summaryBody",
]
# 新版看板才有的（缺了只提示，不算失败）
OPTIONAL_IDS = ["sttrend", "trendSum", "sttip"]


def check(path):
    txt = open(path, encoding="utf-8", errors="replace").read()
    problems = []

    # ── ① 标签配平 ──
    pairs = [
        ("section", txt.count("<section"), txt.count("</section>")),
        ("div", len(re.findall(r"<div[\s>]", txt)), txt.count("</div>")),
        ("table", txt.count("<table"), txt.count("</table>")),
        ("svg", txt.count("<svg"), txt.count("</svg>")),
        ("script", len(re.findall(r"<script[\s>]", txt)), txt.count("</script>")),
    ]
    print(f"── {path}")
    print(f"   大小 {len(txt):,} 字符")
    for name, o, c in pairs:
        flag = "OK" if o == c else "MISMATCH"
        if o != c:
            problems.append(f"{name}: {o} 开 / {c} 闭（差 {o - c}）")
        print(f"   [{flag:8}] {name:8} {o:>5} 开 / {c:>5} 闭")

    # ── ② 关键容器 ──
    print("   关键容器：")
    for k in EXPECT_IDS:
        ok = ('id="' + k + '"') in txt
        if not ok:
            problems.append(f"缺少必要容器 id={k}")
        print(f"     {'OK  ' if ok else 'MISS'} id={k}")
    for k in OPTIONAL_IDS:
        print(f"     {'OK  ' if ('id="' + k + '"') in txt else '--  '} id={k}（可选）")

    # ── ③ 顶层板块清单（人工核顺序用）──
    heads = re.findall(r'<section[^>]*>\s*<h2[^>]*>\s*([^<\n]+)', txt)
    print("   顶层板块（按出现顺序）：")
    for i, h in enumerate(heads, 1):
        print(f"     {i}. {h.strip()[:40]}")
    print()
    return problems


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    allbad = []
    for p in sys.argv[1:]:
        allbad += check(p)
    if allbad:
        print("❌ 结构有问题：")
        for b in allbad:
            print("   - " + b)
        return 1
    print("✅ 结构 OK（标签配平 + 关键容器齐全）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
