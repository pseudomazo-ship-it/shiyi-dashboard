#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""交付前校验单文件看板 HTML 是否被污染 / 关键特性是否还在。

为什么需要它：生成器跑成功 != 交付给用户的那个文件是好的。
2026-09-25 真踩 —— 生成后的 HTML 被同机另一个窗口覆盖，多出 9 条 CSS 规则，
其中一条把手机端的 KPI 冻结改回 position:static，导致十一连问两次「冻结没生效」。

用法:
    python verify_dashboard_html.py "D:\\Agent.GongZuoQu\\Hermes.GZQ\\数据--数据日报\\日报看板.html"
    python verify_dashboard_html.py <file> --quiet     # 只出退出码，适合塞进 cron 当回归看门狗

退出码: 0 = 干净 / 1 = 有问题
无第三方依赖（只要 stdlib），可直接被 cron / 脚本 import 调用。
"""
import os
import re
import sys

# 每个看板允许的 .kpis 规则数上限（1 条主样式 + 1 条手机端显式声明）
MAX_KPIS_RULES = 3

# 关键片段：缺失即视为生成器被改坏 / 文件被替换
REQUIRED_MARKERS = [
    ('密码门 gate',        'id="gate"'),
    ('内容容器 #app',      'id="app"'),
    ('折叠箭头',           'foldArrow'),
    ('各店铺业绩折叠',     'shopHead'),
    ('各店铺明细折叠',     'shopTblHead'),
    ('语义色 goodDown',    'goodDown'),
    ('基准日 resolveBaseDay', 'resolveBaseDay'),
    # 2026-09-25 第三次改版新增的四张图表（十一要「图表类型要齐」）
    ('核心指标区',         'id="coreBody"'),
    ('仪表盘 renderGauge', 'function renderGauge'),
    ('环形图 renderDonut', 'function renderDonut'),
    ('折线图 renderLine',  'function renderLine'),
    ('迷你趋势线 sparkline', 'function sparkline'),
]


def check(path):
    """返回 (ok: bool, problems: list[str], info: dict)"""
    problems = []
    if not os.path.exists(path):
        return False, ['文件不存在: %s' % path], {}

    with open(path, encoding='utf-8', errors='replace') as fh:
        txt = fh.read()

    info = {'chars': len(txt), 'bytes': os.path.getsize(path)}

    # ---- 1) .kpis 规则数异常 = 被别的窗口/工具动过 ----
    kpis_rules = re.findall(r'\.kpis\s*\{[^}]*\}', txt)
    info['kpis_rules'] = len(kpis_rules)
    if len(kpis_rules) > MAX_KPIS_RULES:
        problems.append(
            '发现 %d 条 .kpis 规则（上限 %d）：文件很可能被别的会话/窗口覆盖过'
            % (len(kpis_rules), MAX_KPIS_RULES))

    # ---- 2) 有人把 position 覆盖成 static = 冻结失效（本次的真根因）----
    static_hit = re.search(r'\.kpis[^{]*\{[^}]*position\s*:\s*static', txt)
    if static_hit:
        problems.append('.kpis 里出现 position:static —— KPI 冻结会失效（整段: %s）'
                        % re.sub(r'\s+', ' ', static_hit.group(0))[:160])

    # ---- 3) sticky 必须在「主样式」和「手机媒体查询」里都存在 ----
    info['has_sticky'] = bool(re.search(r'\.kpis\s*\{[^}]*position\s*:\s*sticky', txt))
    if not info['has_sticky']:
        problems.append('.kpis 未声明 position:sticky —— 顶部指标不会冻结')
    media = re.search(r'@media\s*\(\s*max-width\s*:\s*480px\s*\)\s*\{(.*)', txt, re.S)
    if media and not re.search(r'\.kpis\s*\{[^}]*position\s*:\s*sticky', media.group(1)[:2000]):
        problems.append('手机端 @media(max-width:480px) 里没有显式再声明 .kpis sticky'
                        ' —— 容易被后续规则盖掉')

    # ---- 4) 关键片段是否还在 ----
    for label, marker in REQUIRED_MARKERS:
        if marker not in txt:
            problems.append('缺少关键片段「%s」(%s)' % (label, marker))

    # ---- 5) ⚠️ 不要再用「旧色值是否残留」当判据 ----
    #  2026-09-25 第三次改版把 #2563eb / #e5484d 又请回了调色板（现在的 brand / bad），
    #  旧判据会把**干净文件误判成被污染**。三代色都可能是合法的，色值不能当完整性凭据。
    #  改为断言「最新一代的图表函数在位」—— 缺任何一个都说明拿到的是旧版或被改坏的文件。
    for label, marker in [('仪表盘 renderGauge',  'function renderGauge'),
                          ('环形图 renderDonut',  'function renderDonut'),
                          ('折线图 renderLine',   'function renderLine'),
                          ('迷你趋势线 sparkline', 'function sparkline'),
                          ('核心指标容器',       'id="coreBody"')]:
        if marker not in txt:
            problems.append('缺少图表「%s」(%s) —— 拿到的是旧版 / 被改坏的文件'
                            % (label, marker))

    return (not problems), problems, info


def main():
    argv = [a for a in sys.argv[1:] if not a.startswith('--')]
    quiet = '--quiet' in sys.argv
    if not argv:
        print(__doc__)
        return 2

    ok, problems, info = check(argv[0])
    if not quiet:
        print('文件: %s' % argv[0])
        print('字符 %s | 字节 %s | .kpis 规则 %s 条'
              % (info.get('chars'), info.get('bytes'), info.get('kpis_rules')))
        print()
        if ok:
            print('OK 干净：sticky / 密码门 / 折叠 / 语义色 全部在位')
        else:
            print('发现问题 %d 项：' % len(problems))
            for p in problems:
                print('  - %s' % p)
            print()
            print('修法：改生成器脚本（不是改 HTML）→ 重新跑一次生成 → 再跑本脚本 → 再交付。')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
