# -*- coding: utf-8 -*-
"""drop_skill.py —— 从技能看板下架技能（数据 + 两个 HTML + 包 + 推送）

用途：技能从目录里删掉/移走后，把看板上对应的旧条目清掉。
      `skills_sync_watch.py` 检测到技能消失时会自动调它。

用法：
  python drop_skill.py --name <技能名> [--agent Hermes] [--dry-run] [--no-push]
  python drop_skill.py --names "a,b,c"          # 批量（不看 agent）
"""
import argparse
import io
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import skill_sync as S          # 复用 CFG / load_data / write_data / git / log


def drop(names, agents=None, dry=False, no_push=False):
    src_dir, repo_dir = S.CFG['source_dir'], S.CFG['repo_dir']
    src_html, pub_html = src_dir / 'skills.html', repo_dir / 'skills' / 'index.html'

    hits, removed_pkgs = [], []
    for html in (src_html, pub_html):
        s, i, j, data = S.load_data(html)
        gone = [d for d in data if d['name'] in names and (not agents or d.get('agent') in agents)]
        keep = [d for d in data if d not in gone]
        for k, d in enumerate(keep):
            d['id'] = 'skill-' + str(k)
        hits = gone or hits
        S.log('%s: %d → %d 条' % (html.name, len(data), len(keep)))
        if gone and not dry:
            S.write_data(html, keep)
        for d in gone:
            removed_pkgs.append(d['package_url'].split('/')[-1])

    if not hits:
        S.log('看板里没有这些条目，无需下架')
        return 0

    js = src_dir / 'skills_data.json'
    data = json.loads(js.read_text(encoding='utf-8-sig'))
    keep = [d for d in data if d['name'] not in names or (agents and d.get('agent') not in agents)]
    S.log('skills_data.json: %d → %d 条' % (len(data), len(keep)))
    if not dry:
        js.write_text(json.dumps(keep, ensure_ascii=False, indent=1), encoding='utf-8')

    for pkg in set(removed_pkgs):
        for d in (src_dir / 'packages', repo_dir / 'skills' / 'packages'):
            f = d / pkg
            if f.exists():
                S.log('  删除包 %s' % pkg)
                if not dry:
                    f.unlink()

    for d in hits:
        S.log('  下架: %s（%s）' % (d['name'], d.get('agent')))

    if dry:
        S.log('[dry-run] 未写任何文件')
        return 0
    if no_push:
        S.log('已改本地，按 --no-push 未推送')
        return 0

    S.git(['add', 'skills/index.html', 'skills/packages/'], cwd=repo_dir, proxy=False)
    st = S.git(['status', '--short'], cwd=repo_dir, proxy=False).stdout.strip()
    if not st:
        S.log('无改动，跳过提交')
        return 0
    msg = 'skills 管理台：下架 %d 个技能（%s）' % (len(hits), '、'.join(d['name'] for d in hits[:3]))
    r = S.git(['commit', '-q', '-m', msg], cwd=repo_dir, proxy=False)
    if r.returncode != 0:
        S.log('commit 失败: %s' % r.stderr)
        return 1
    S.git(['pull', '--rebase', 'origin', S.CFG['branch']], cwd=repo_dir)
    r = S.git(['push', 'origin', S.CFG['branch']], cwd=repo_dir)
    S.log((r.stdout + r.stderr).strip()[-300:])
    S.log('✅ 已下架 %d 个并推送' % len(hits))
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--name')
    ap.add_argument('--names', help='逗号分隔')
    ap.add_argument('--agent')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--no-push', action='store_true')
    a = ap.parse_args()
    names = set()
    if a.name:
        names.add(a.name)
    if a.names:
        names |= {x.strip() for x in a.names.split(',') if x.strip()}
    if not names:
        print('需要 --name 或 --names'); return 2
    agents = {a.agent} if a.agent else None
    return drop(names, agents, a.dry_run, a.no_push)


if __name__ == '__main__':
    sys.exit(main())
