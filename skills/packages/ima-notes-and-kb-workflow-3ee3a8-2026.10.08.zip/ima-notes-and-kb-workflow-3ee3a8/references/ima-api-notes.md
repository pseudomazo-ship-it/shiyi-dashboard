# IMA OpenAPI 执行模式与坑（实测 2026/09）

## ⚠️ 笔记标题必须写在 content 首行（2026-09-19 实测，踩过坑）

`import_doc` **没有 title 参数**（只有 `content_format` / `content` / `folder_id` / `folder_name`）；
`add_knowledge` 的 `title` **对笔记（media_type=11）不生效**。
→ **笔记标题只能来自 content 第一行的 `# 标题`**。直接传原始 md（首行无 `#`）→ 标题会变成正文首行文本，不是你要的。

```js
const content = '# 【Hermes-办公室】云仓偏远地区占比统计 · 9.1-9.18_2026.09.19\n\n' + 原md正文;
await imaApi('openapi/note/v1/import_doc', { content_format: 1, content }, {});
```

**验证标题**（读笔记自身元数据）：
```js
const s = await imaApi('openapi/note/v1/search_note',
  { search_type: 0, query_info: { title: 'Hermes-办公室' }, start: 0, end: 30 }, {});
// → data.search_note_infos[].note_book_info.title
```

⚠️ **别用库列表验证**：`get_knowledge_list` / `search_knowledge` **索引延迟很重**——刚传的条目几小时内列不出，
条数会准但标题不可靠。验证标题一律走 `search_note`，验证内容走 `get_doc_content`。

## ⚠️ 大文件必须用 require 方式（2026-09-19 实测，踩过坑）

`node ima_api.cjs <apiPath> '<长json>'` 走命令行 → **Windows 命令行上限 32767 字符**，正文超约 30KB 就报
`spawnSync ... ENAMETOOLONG`（实测 42KB / 47KB / 62KB / 71KB / 267KB **全部失败**；27KB 以下正常）。

**解法**：`ima_api.cjs` 导出 `imaApi(apiPath, body, options)`（返回**响应字符串**，需自己 JSON.parse），
driver 里直接 require 调用，**无长度限制**：

```js
const { imaApi } = require('C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs');
(async () => {
  const resp = await imaApi('openapi/note/v1/import_doc', { content_format: 1, content }, {});
  const noteId = JSON.parse(resp).data.note_id;
  const a = await imaApi('openapi/wiki/v1/add_knowledge',
    { media_type: 11, note_info: { content_id: noteId }, title: TITLE, knowledge_base_id: KB }, {});
})();
```

实测 267KB 全册一次成功。**新写 driver 一律用这个方式**，别再 execFileSync 传大 body。

## 调用方式

- 凭证：`~/.config/ima/client_id` + `api_key`（或环境变量 IMA_OPENAPI_CLIENTID/APIKEY），ima_api.cjs 自动读取
- 单次调用（bash 内可用，短 JSON）：`node ima_api.cjs <apiPath> '<json body>'`
- **复杂中文内容用 driver 脚本**（Windows 下避免 shell 转义/引号问题）：内容写临时 md 文件，用 execFileSync 传参（不经 shell）

```js
const { execFileSync } = require('child_process');
const fs = require('fs');
const cwd = 'C:/Users/Administrator/.workbuddy/skills/ima-skill';
const KB = 'MxOZ443nc9bRu7vPPaXwcCG6adRfPe61qKbM5P_DuCY='; // 按测试选库
const TITLE = '【拼多多】主题.';
function call(apiPath, body) {
  return JSON.parse(execFileSync('node', ['ima_api.cjs', apiPath, JSON.stringify(body)], { cwd, encoding: 'utf8' }));
}
const content = fs.readFileSync(cwd + '/_note_content.md', 'utf8');
const created = call('openapi/note/v1/import_doc', { content_format: 1, content });
const noteId = created.data.note_id;
const added = call('openapi/wiki/v1/add_knowledge', { media_type: 11, note_info: { content_id: noteId }, title: TITLE, knowledge_base_id: KB });
console.log(created.code, added.code); // 两次都应为 0
```

用后删除 `_note_content.md` 和 driver 脚本（保持技能目录干净）。

## 关键行为（实测）

1. **错误码分层**：stderr `-100` 程序错误 / `-200` 需更新 skill（stdout 带 instruction）；stdout `code!=0` 为业务错误，msg 直接展示
   - **`-200` 会拦下一切请求**（原请求未发送），不是参数错。触发条件：`~/.config/ima/last_update_check` 里的日期 ≠ **当天 UTC 日期**（脚本用 `new Date().toISOString().slice(0,10)`）。
   - 继续用当前版本：`date -u +%F > ~/.config/ima/last_update_check`（写**本地**日期会时区不匹配、仍被拦）。
   - 长期做法：driver 开头自动写 UTC 日期（`fs.writeFileSync(..., new Date().toISOString().slice(0,10))`）；或按 instruction 升官方版本。
   - 时间交叉：昨天下班前能跑、今天一调就 `-200` = 跨天，不是环境坏了。
2. **220001 知识重复添加**：目标库已存在该内容或判重复——不是失败；用 search_knowledge 验证归属
3. **一篇笔记可关联多个知识库**：add_knowledge 到新库后旧库条目可能仍保留（实测投产比笔记同时在「拼多多-电商学习📚」和「十一的知识库」）
4. **没有移除/修改接口**（2026-09-20 全量核对：OpenAPI 仅 **17 个**接口，无 delete / remove / update / rename）——换库残留删不掉，**已传笔记的标题也改不了**（十一要求给已传笔记换前缀时证实）。传错只能请用户去 IMA 客户端手删/手改 —— **所以宁可先问、先拿 1 条小样验证标题机制再批量传。**
5. import_doc 返回 `data.note_id`（纯数字 docid，如 7501946906739036）
6. add_knowledge 返回 media_id 格式：`note_<hash>_<noteId><kbShortId>`，后缀是库的内部短 ID（不可用于反查库名）

## 读取链路

- 库内命中条目（media_type=11）→ `get_media_info` 拿 `notebook_ext_info.notebook_id` → `openapi/note/v1/get_doc_content` body `{note_id, target_content_format:0}`（纯文本；markdown 格式不支持）
- media_type=6（微信文章）→ 原文 URL 在 `url_info.url`
- media_type=3（doc）→ 法规/文档类，多为法律条文，不等于操作路径

## 搜索 / 列库（字段名先看清再写循环，别猜 —— 2026-09-28 实测）

**`search_knowledge_base`（列知识库）** —— 空 `query` 就是「全部库」：
```js
imaApi('openapi/wiki/v1/search_knowledge_base', { query: '', limit: 20, cursor: '' });
```
- ⚠️ **`limit` 上限 20**：传 50 直接报 `code 51 · invalid SearchKnowledgeBaseReq.Limit:
  value must be inside range (0, 20]`
- ⚠️ **分页字段叫 `next_cursor`，不是 `cursor`**（请求用 `cursor`，响应读 `data.next_cursor`）
- 响应每条 = **`kb_id` / `kb_name`** / `cover_url` / `member_count` / `content_count` /
  `description` / `creator` / `role_type` / **`base_type`**（`共享知识库` / `个人知识库` / `我加入的订阅知识库`）；结束标志 `data.is_end`
- ⚠️ **别猜字段名**：我第一版猜 `knowledge_base_name` / `list`，结果 20 条全打印成「(无名字)」。
  拿不准就先 `console.log(JSON.stringify(r).slice(0, 2500))` 看原始结构，再写循环。
- 一次翻页循环列全（十一侧实测 **28 个库**，含订阅）：
```js
let cursor = '', n = 0;
for (let i = 0; i < 6; i++) {
  const r = JSON.parse(await imaApi('openapi/wiki/v1/search_knowledge_base', { query: '', limit: 20, cursor }, {}));
  for (const kb of (r.data.info_list || []))
    console.log(`${++n}. ${kb.kb_name} [${kb.base_type}] ${kb.content_count}条  ${kb.kb_id}`);
  if (r.data.is_end || !r.data.next_cursor) break;
  cursor = r.data.next_cursor;
}
```

**`search_knowledge`（库内搜条目）** —— `{query, knowledge_base_id, cursor}`：
- 响应 `data.info_list[]` → `title` / `media_id` / **`media_type`**（`11`=笔记、`99`=文件夹）、`is_end` / `next_cursor`
- ⚠️ **同一个词要在多个库里都搜一遍**：实测「评价星级」在「公司：各事项/第三方」**0 命中**，
  但在「拼多多-电商学习📚」命中 5 条相关笔记、在「Agent知识库（记忆留痕记录）」命中 1 条目标笔记 ——
  **一个库搜不到 ≠ 知识库里没有**（是分库规则把它放到别处了，见 SKILL.md 的分流表）。
- 搜业务资料默认顺序：「公司：各事项/第三方」→「拼多多-电商学习📚」→「Agent知识库（记忆留痕记录）」。
- 面向用户隐藏所有内部 ID，只展示名称/标题/描述

## 就地更新已有的库内笔记 → 只能 `append_doc`（2026-09-28 实测）

十一要「**在原笔记内修改即可**」时，接口集里**没有 update/replace**，做得到的只有**追加**：
```js
const { imaApi } = require('C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs');
const noteId = '7507656881213393';   // 从 search_knowledge 命中的 media_id / get_media_info 取
const content = '# 【Hermes-办公室】XXX · 2026-09-21 修订版（本节为准，上文为历史版）\n\n' + md正文;
const j = JSON.parse(await imaApi('openapi/note/v1/append_doc',
              { note_id: noteId, content, content_format: 1 }, {}));
console.log(j.code, j.msg);          // 期望 code=0 / msg=success
```
**必须读回验证**（返回 0 不等于内容真进去了）：
```js
const g = JSON.parse(await imaApi('openapi/note/v1/get_doc_content',
            { note_id: noteId, target_content_format: 0 }, {}));
const txt = g.data.content || g.data.text;
['修订版','十二·五','14:20'].forEach(k => console.log(k, txt.includes(k)));
```
- ⚠️ **判断追加成功看「关键词命中 + 结尾是新增段落」，不要只看总字数**：
  实测追加成功（`code=0`）后读回，**总字数几乎没变**（旧 15.8k → 仍 15.8k），
  但新章节关键词全部命中、且结尾正是新加的那段 → `get_doc_content` 返回的 `content` 有**长度截断**（头尾拼接）。
- 追加段开头写一句「**本节为准，上文为历史版**」：旧内容**删不掉**（无删除接口），
  要彻底干净得请十一去 IMA 客户端手删旧段 —— 主动告诉他这一点，他才不会以为你没更新。

## 常用知识库 ID（十一）

- 拼多多-电商学习📚：`MxOZ443nc9bRu7vPPaXwcCG6adRfPe61qKbM5P_DuCY=`（内容 640+）
- 十一的知识库：`4qeg0zgtMvSld9YaAmJ2YFaYYAiwmKxPvU695MO6VMc=`（个人库，约 20 条）
- 会计审计知识库（订阅）：`oKJ3G8whis_OV81vlljxFSwLh3mf7n3XuHSC46LCTyE=`
- 国家法律法规数据库（订阅）：`CjgilyA9Ci7ea0N2lOrawqAu9d-76lBF_sDUEHJwKvQ=`
- **公司：各事项/第三方**（业务留痕主库，2100+ 条）：`HOgF7h3Ypt5UOnpfzwmFhXF4YU7Z19HzVz1MR8inYjU=`
  —— 探域机器人资料（触发器规则完整笔记 / 咨询场景vs回复场景 / 兜底话术）都在这里
- **Agent知识库（记忆留痕记录）**（Agent、软件、技术文档）：`0wy6KjHzzkor-e9oBf1c4OCQT8KE9bJ0zcuQwWb9bk4=`
  —— 技能说明类笔记（如「【Hermes-办公室】拼多多评价星级日采集技能说明」）在这里；
  ⚠️ 库**全名带括号后缀**，搜名字时别只用「Agent知识库」
- 抖音/抖店-电商学习：`-1pa4ovogXAtPCIBNHTcpxjkqlvPOcxn5dRj0bzJDCg=`（1.4 万条）
- 小红书-电商学习：`vJJ1e5AJ9l3Fdj9odHiecONInAcRA3d-yFIGLjBqdfw=`
- 京东JD-电商学习：`4ARJbQm3Be3ejGcaIja6UPZ9VebH6jrJ1YecSg6BBMs=`
- 淘天平台-电商学习：`LDHHPmODBCVYC_5ZqA5r3_2jnzoAxwKql8Bbm-Mn1Pk=`
- **订阅库也能搜**（十一明确）：列库/搜索用同一套接口、同一次翻页就能拿到，`base_type` 显示「我加入的订阅知识库」

## 环境注意

- 本机 shell 是 git-bash；**路径一律用正斜杠的 `C:/` 形式**（`C:/Users/Administrator/.workbuddy/...`），**不要用 MSYS 的 `/c/...`**（原生 node 不认）
- **实际路径（2026-09 实测，旧文档里的 `E:/软件/...` 已失效）**：
  - 脚本：`C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs`
  - node：`C:/Users/Administrator/.workbuddy/binaries/node/versions/22.22.2-3/node.exe`
  - ⚠️ `.workbuddy/skills/` 会被工具重装还原，**不要把自写 driver 放进去**，放临时目录
- 输出可能很大：读取长篇正文时用 node 解析截断（如 `.slice(0,1500)`），避免刷屏
