#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""核对「工作区 md → IMA」批量上传的落点。

★ 为什么不用 get_knowledge_list 翻页数条目：
  2026-10-08 实测翻页法会把同一页重复累加，算出「合计 479 / 397」「结论与方案 139/70」这类
  虚高一倍的假数，很容易让人误以为“重复上传了”。本脚本读**进度文件**统计，秒出且可信。

用法：
    python verify_upload_progress.py [cache目录]
默认 cache 目录 = E:/RuanJian/Hermes/cache

依赖：ima_upload_done.json（上传脚本每 10 条落盘）、ima_upload_list.json（待传清单）
"""
import json
import os
import sys
from collections import Counter

CACHE = sys.argv[1] if len(sys.argv) > 1 else r'E:\RuanJian\Hermes\cache'
DONE = os.path.join(CACHE, 'ima_upload_done.json')
LIST = os.path.join(CACHE, 'ima_upload_list.json')


def load(p):
    if not os.path.exists(p):
        print('[!] 找不到 %s' % p)
        return None
    with open(p, encoding='utf-8') as f:
        return json.load(f)


done = load(DONE)
lst = load(LIST)
if done is None or lst is None:
    sys.exit(1)

# 已传：按 folder 字段（形如 'Hermes-办公室/对话留痕'）统计
got = Counter(v.get('folder', '?') for v in done.values())
# 目标：按 agent/type 统计
want = Counter(x['agent'] + '/' + x['type'] for x in lst)

print('=== 落点核对（读进度文件，不信翻页计数）===')
print()
by_agent = {}
for k in sorted(set(list(got) + list(want))):
    n, w = got.get(k, 0), want.get(k, 0)
    mark = 'OK ' if n >= w else '!! '
    print('  %s %-26s %4d / %4d' % (mark, k, n, w))
    a = k.split('/')[0]
    s = by_agent.setdefault(a, [0, 0])
    s[0] += n
    s[1] += w

print()
print('=== 按 Agent ===')
for a in sorted(by_agent):
    n, w = by_agent[a]
    print('  %s %-16s %4d / %4d' % ('OK ' if n >= w else '!! ', a, n, w))

tn = sum(got.values())
tw = sum(want.values())
print()
print('合计 **%d / %d** ｜ 缺口 %d 条' % (tn, tw, tw - tn))

# 缺口点名：清单里有、进度里没有的（= 传失败的）
if tn < tw:
    print()
    print('=== 缺口明细（这些就是待补传的）===')
    for x in sorted(lst, key=lambda z: (z['agent'], z['type'], z['rel'])):
        k = x['agent'] + '/' + x['type'] + '/' + x['rel']
        if k not in done:
            print('  ✗ %s ／ %s ／ %s' % (x['agent'], x['type'], x['rel']))

print()
print('补传：直接重跑上传命令即可（断点续传会秒级跳过已成功的）。')
print('⚠️ 不要清断点重传全部 —— 重传 = 造一批 IMA 删不掉的重复笔记。')
