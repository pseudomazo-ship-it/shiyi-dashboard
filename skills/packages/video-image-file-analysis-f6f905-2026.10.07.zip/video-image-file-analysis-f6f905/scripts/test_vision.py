import sys, os, traceback
os.chdir(r'C:\Users\Administrator\.workbuddy\skills\video-image-file-analysis\scripts')
try:
    sys.argv = ['vision.py', 'analyze', '--image', r'D:\其他文件\00000000000000即用即删\买家秀--总\男士\白金色.jpg', '--prompt', 'analyze']
    import vision
    vision.main()
except Exception as e:
    with open(r'C:\Users\Administrator\.workbuddy\skills\video-image-file-analysis\scripts\error_log.txt', 'w') as f:
        f.write(str(e))
        f.write('\n')
        traceback.print_exc(file=f)
    print('ERROR written to log')
