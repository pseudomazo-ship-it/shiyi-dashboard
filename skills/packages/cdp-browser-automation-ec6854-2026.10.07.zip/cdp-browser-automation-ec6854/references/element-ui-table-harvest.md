# Harvesting a paginated Element UI table on a public/government query site

Verified 2026-09-16 on 国家药品监督管理局数据查询
(`www.nmpa.gov.cn/datasearch/search-result.html`) — query 国产特殊化妆品注册信息,
keyword 蒙倩, **78 rows across 8 pages**, read-only. Class-level technique; NMPA is the worked
sibling example of `dom-pagination-instead-of-signed-api.md`.

## Why the DOM route (the API param is sealed per request)

The page's own calls:

```
https://www.nmpa.gov.cn/datasearch/data/nmpadata/search?7QBHXKaZ=<opaque blob>
https://www.nmpa.gov.cn/datasearch/data/nmpadata/countNums?7QBHXKaZ=<opaque blob>
```

The parameter NAME is stable but the VALUE is a fresh encrypted blob per request — it cannot be
reproduced, and 十一's standing rule is 不逆向签名. Same class of decision as PDD's `Anti-Content`,
with one difference: **here even the list endpoint is sealed**, so the DOM is the only route
(no unprotected sibling endpoint to fall back to — the PDD checklist's step 2 comes up empty).
Enumerate the page's resource entries to confirm before deciding:

```js
performance.getEntriesByType('resource').map(r=>r.name)
  .filter(u=>/api|query|search|list/i.test(u))
```

## Selectors (Element UI)

| Element | Selector |
|---|---|
| body rows | `table.el-table__body tr` |
| header | `table.el-table__header th` |
| page number | `.el-pager li.number` (innerText = the number) |
| active page | `.el-pager li.active` |
| next | `.btn-next` (`disabled` attribute on the last page) |
| total | `.el-pagination__total` → 「共 78 条」 |

⚠️ That page has **2 `.el-pagination` nodes but only 1 `.el-pager`** — key off `.el-pager`.
Clicking a page number with `li.click()` worked here (no mouse-event sequence needed).

## The pitfall that cost two passes: wait on the ROW, not on the pager

`.el-pager li.active` flips the instant you click, but the table body keeps the PREVIOUS page's
rows for a beat. Results from the three attempts on the same page:

| wait strategy | rows read | unique |
|---|---|---|
| fixed `time.sleep(1.6)` | 80 | **43** of 78 |
| poll active-page number | 8 "correct" pages | **10** of 78 |
| **poll first row's 序号** | 80→78 | **78** ✅ |

**Working pattern** — this table's 序号 column is continuous across pages, so page N's first row
must read `(N-1)*pageSize+1`:

```python
FIRST_SEQ = """(() => { const tr=document.querySelector('table.el-table__body tr');
  const td=tr?tr.querySelectorAll('td')[0]:null; return td?td.innerText.trim():'-'; })()"""

js(CLICK_PAGE % target)          # click .el-pager li.number whose text == target
for _ in range(20):
    time.sleep(0.4)
    if js(FIRST_SEQ) == str((target-1)*10 + 1):
        break
time.sleep(0.4)
rows = json.loads(js(GRAB))
```

If the table has no ordinal column, wait for the first row's fingerprint to CHANGE (or use any
per-page predictable value — a date, an id range). Do not settle for a fixed sleep.

## Read the full cell, not the ellipsis

Element UI truncates for display (`蒙倩叶彩染发膏（31）植物调理…`) and keeps the whole string in the
row tooltip:

```html
<div role="tooltip" class="el-popover"><p> 蒙倩叶彩染发膏（31）植物调理型</p></div>
```

```js
const p = tds[1].querySelector('.el-popover p');
name = p ? p.innerText.trim() : tds[1].innerText.trim();
```

## Keep the loop in Python — one short `js()` per step

A whole 8-page loop written as ONE `async` expression blows `browser_exec`'s ~5s
`Runtime.evaluate` budget (`Runtime.evaluate timed out after 5s waiting for the daemon`) **and the
page keeps executing it after you give up** — that silent tail left the user's page parked on
page 7. Put the loop in Python; keep every `js()` call to one small step
(grab-this-page / click-next / read-next-signal).

## Do not dedupe on a non-unique key

Those 78 rows carried only **44** distinct 注册证号 — several products share one certificate. An
early `{r[3]: r}` dedupe silently discarded half the result set and looked like a scrape failure.
Dedupe on a genuinely unique id, or just keep the row ordinal.

## Verify before delivering — and put their page back

- Ordinal continuity: `missing = [i for i in range(1, max_seq+1) if i not in seqs]` → empty, and no
  duplicates. Cross-check against the pager's own 「共 N 条」. 78 rows / 序号 1–78 → done.
- **Restore page 1** when finished — paging moved the user's view; leaving it on page 8 is a
  side effect they did not ask for.
- Output xlsx: 序号 | 产品名称中文 | 注册人中文 | 注册证号 | 批件状态, freeze `A2`, autofilter,
  centered ordinal. ⚠️ Reading/authoring xlsx needs openpyxl — it is **not** in the Hermes venv or
  the uv-managed kernel python; install once with
  `python -m pip install openpyxl --break-system-packages` (plain pip is refused with
  `externally-managed-environment` on a uv-managed interpreter) or run via
  `uv run --with openpyxl python <script>.py`.
