# 十一 现有「上架工具」架构（Electron + 外挂 Chrome）

路径：`D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\GPT\软件：自动上架工具\`
（2026-09-18 实测确认。同目录另有 `自动化上链接搬家（紫盒）1.0`、多份验收截图与规范文档。）

## 启动链
`启动控制台.bat` → `start-console.ps1` → `node_modules\electron\dist\electron.exe "<appRoot>"`。
ps1 第一件事是 `$env:ELECTRON_RUN_AS_NODE = $null`（不清会导致 Electron 以 Node 模式启动即崩）。

## 它怎么“操控浏览器”
`main.js` 的 `ipcMain.handle('pdd:launch-external')`（约 1638 行）：
```js
const PROFILE = path.join(app.getPath('userData'), 'pdd-browser-profile');
spawn(chromePath, [`--user-data-dir=${PROFILE}`, '--remote-debugging-port=9444',
      '--no-first-run', '--no-default-browser-check', '--window-size=1600,1000',
      'https://mms.pinduoduo.com/goods/goods_list'], { detached:true, stdio:'ignore' });
```
→ **程序自己拉起一个独立 Chrome 窗口（独立登录档 + 9444），用户在这个窗口里扫码登录一次，之后程序就在这个窗口里干活。**
这就是十一说的「操控我的浏览器去工作」的既有实现形态。
⚠️ 不要用默认 user-data-dir 起 Chrome——会被要求人工勾「Allow remote debugging」，且会碰他的主档。（本机 `127.0.0.1:9222` 上那个 chrome.exe 对 `/json/version` 返 `404`，这正是 SKILL.md「Attaching to the user's OWN running Chrome」一节说的 Chrome 136+ 已下线 `/json/*`：要改用 `DevToolsActivePort` 文件第 2 行的 browser-level WS 路径。）

## 模块地图（`src/`）
| 文件 | 作用 |
|---|---|
| `pdd-cdp.js` (126行) | 外挂 Chrome 的 CDP 客户端：`/json/list` 选目标 → 持久 WebSocket；对外暴露 `executeJavaScript` / `loadURL` / `getURL` / `sendInputEvent` / `setZoomFactor` / `debugger.sendCommand` |
| `pdd-automation.js` (140行) | 拼多多页面动作 |
| `browser-automation.js` (83行) | 页面脚本：标题读写、保存草稿、提交并上架（都带验证码关键词检测 → `paused:true`） |
| `purple-box-rules.js` (118行) | **紫盒编码/规格引擎（跨平台可复用）** |
| `color-registry.js` (27行) | 色号表读取 |
| `variant-engine.js` / `fullscreen-sku-fill.js` | 规格与全屏 SKU 表 |
| `data/purple-box-colors.json` | 色号表 312 条 `{row,color,code}`，code 已含 `【紫盒】` |
| `main.js` (2420行) / `renderer/` | 主进程 + 界面 |

## 可直接复用的编码管线（`purple-box-rules.js`）
```js
matchFixedColor(rows, specName)      // 从页面上任意规格值串里抠出颜色名（先去「色」，再长值优先 includes）
getColorCodeCandidates(rows, color)  // 查色号表：精确 → 归一化(去「色」) → 模糊包含；返回候选数组
buildSpecCode(rawCode, color, qty)   // `${rawCode}${max(1,qty)}盒`
```
→ 微信小店/抖音的「SKU 编码 = 紫盒色号 + N盒」**一行都不用重写**。
⚠️ `getColorCodeCandidates` 返回数组（同名多码，实测 38 个颜色）；哪些能自动定、哪些必须问，见 `ecommerce/wechat-shop-sku-image-upload` 的 `references/purple-box-code-picks.md`。

## 加一个「微信小店」模块只要改 4 处
1. `src/weixin-cdp.js` —— 复制 `pdd-cdp.js`，把 `pickTarget` 的 URL 判断换成 `store.weixin.qq.com/shop/goods/entry`，端口另定（或与 9444 共用同一 Chrome 的另一个标签 → 只登录一次）。
2. 页面脚本 —— 读规格组/行、`DOM.setFileInputFiles(objectId)` 传图、受控输入写编码。全部在 `<micro-app>.shadowRoot` 内（见 SKILL.md 的 Shadow-DOM 一节）。
3. 编码生成 —— 直接引 `purple-box-rules.js`。
4. 界面加「微信小店」页 + 两个按钮（上传 SKU 图 / 填 SKU 编码）。
**明确不做**：程序绝不点「保存草稿 / 上架」，由十一核完自己提交（他已经定过的交付口径）。

## 规格值命名的 4 种形态（抠颜色时会遇到，必须都兼容）
```
不盖白-榛果灰棕                       // 前缀-颜色
免漂雾感显色【冷棕色】无需漂色          // 文案+【颜色】+文案
两套装【黑茶色】可盖白发               // 套餐+【颜色】+工艺
全新升级丨高配版套盒装【赠送工具和发膜】 // 纯套餐，方括号里不是颜色
```
→ **先读该规格组的完整值列表，再拿值去匹配行**；直接用正则抓第一个 `【…】` 会抓到「赠送工具和发膜」，实测 34 行全错。

## 重新填编码前先读现状（实测）
某膏体染商品 22 行旧编码里：7 行行首多 `a`/`b`、7 行行尾多 `d`/`dd`/`ddd`/`dddd`、1 行是紫盒格式 `C677冷棕茶【膏体套盒】2盒`、1 行写「9度」而不是「双氧」。十一 的指示是「这个都是旧的，重新写紫盒的编码，2盒」→ 整体覆盖。
做法：整列读出现值 → 列异常给十一 → 覆盖 → 回读校验（旧格式残留必须为 0）。
