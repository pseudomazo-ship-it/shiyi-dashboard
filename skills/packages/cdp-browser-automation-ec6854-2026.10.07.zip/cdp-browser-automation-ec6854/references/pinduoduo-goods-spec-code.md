# PDD 商品编辑页 · 规格编码批量填写（多功能登录器项目）

> 实测日期：2026-09-16/17 ｜ 目标页：`mms.pinduoduo.com/goods/goods_add/index?id=...&goods_id=...&type=edit`
> 所属项目：「多功能登录器」（Electron 多店铺管理工具），项目目录在 `Hermes Agent\项目：多店铺套餐登录器\`
> 相关文件：`edit-runner.js`（读取/写入）、`main.js`（IPC：edit:scan / edit:write / edit:plan）、`index.html`（弹窗）、`purple-box-rules.js` + `data/purple-box-colors.json`（312 紫盒色号库）

## 页面真实结构（DOM 实测）

规格表格是**两张独立的 `<table class="TB_tableWrapper_*"`>**：
- `table[0]`：**只有表头** —— 1 个 `<tr>`、10 个 `<th>`、0 个 `<td>`
- `table[1]`：**数据表** —— N 个 `<tr>`、10N 个 `<td>`

**列序（10 列，实测）**：

| 索引 | 表头 | 类型 |
|---|---|---|
| 0 | 净含量 | 纯文字 |
| 1 | **颜色** | **纯文字**，形如 `（Q136#亚麻浅金）染过红绿紫蓝橘黑…` ← **颜色从这里取** |
| 2 | 当前库存 | 纯文字 |
| 3 | 库存增减 | input（空） |
| 4 | 改后库存 | input |
| 5 | *拼单价(元) | input |
| 6 | *单买价(元) | input |
| 7 | *预览图 | input[type=file] |
| 8 | **规格编码** | **input —— 按可用输入框顺序数是第 5 个 = 写入目标** |
| 9 | 状态 | 纯文字（如「已上架」） |

**每行 5 个可用 input**，`ins[ins.length-1]` 就是规格编码框（索引 8）。

## ⚠️ 三个已踩的坑（都会导致「一行都读不到」）

### 坑 1：靠「含『规格编码』字样的容器」定位 → 永远 0 行

```js
// ✗ 错误做法：选 innerText 最短的容器 → 命中的是表头单元格 .sku-thead-th
const modal = [...document.querySelectorAll('div,section')]
  .filter(el => vis(el) && /规格编码/.test(el.innerText || ''))
  .sort((a, b) => a.innerText.length - b.innerText.length)[0];
const root = modal || document;          // ← modal.className === 'sku-thead-th'
root.querySelectorAll('tr').length;      // → 0
```

**根因**：表头单元格里只有「规格编码」4 个字，`innerText` 最短，所以被选中；它内部没有任何 `<tr>`。

**正确做法**：不靠容器定位，直接全局找「可见 + ≥2 个输入框」的 `<tr>`：

```js
const BAD = ['file', 'checkbox', 'radio', 'hidden'];
const trs = [...document.querySelectorAll('tr')].filter(tr => {
  const ins = [...tr.querySelectorAll('input')].filter(e => !BAD.includes(e.type));
  return ins.length >= 2 && tr.offsetWidth > 0 && tr.offsetHeight > 0;
});
```

**实测效果：0 行 → 17 行。**

### 坑 2：新版编辑页**没有「全屏编辑」按钮**

表格**直接就在页面上**（`全屏编辑` 按钮 `count: 0`）。若代码强制「先点全屏编辑，点不到就退出」，流程会直接早退。

**正确做法**：**先直接读**；只有当读到 < 2 行时才去尝试点「全屏编辑」。

### 坑 3：没有滚动容器时，虚拟列表采集返回空

虚拟列表采集依赖「可滚动容器」（`overflowY: auto|scroll` 且 `scrollHeight > clientHeight + 20`）。**行数少时页面根本没有滚动条** → 返回 `null` → 采集函数返回 `[]`。

**正确做法**：滚动容器为 `null` 时，**直接读一次当前可见行**（不要返回空数组）。

## 盒数（套餐数量）从哪来

**规格名里没有「盒」字**（形如 `（Q127#冷棕色）染过红绿紫蓝橘黑咨询客服…`）→ `parseQty()` 解析结果是 0 → 目标编码算不出来。

只有两条路：
1. 从**页面已有的规格编码**里读（正则 `【[^】]*】\s*(\d+)\s*盒`）
2. **人工在确认表里填**（界面已有 `data-f="qty"` 数字输入框，改动后走 `edit:plan` 重算）

**所以这个功能必须保留人工填盒数的入口**，不能指望自动解析。

## 主进程崩溃：`Error: write EPIPE`

**现象**：Electron 弹窗 `A JavaScript error occurred in the main process` + `Error: write EPIPE`（堆栈在 `stream_base_commons` / `net` / `streams/writable`）。

**成因**：与页面的调试通道先断开（切店 / 刷新 / 关掉编辑页 / 软件退出），但通信请求仍在写入 → EPIPE → **主进程未捕获异常**。

**加重因素**：`main.js` **完全没有全局异常兜底**（`process.on('uncaughtException')` 一个都没有），所以任何未捕获异常都会弹框甚至把软件打崩。

**修法**（建议）：
```js
process.on('uncaughtException', (e) => { /* 记日志，不弹框 */ });
process.on('unhandledRejection', (e) => { /* 同上 */ });
```
另可在调用 CDP 前检查连接是否存活（断了就不发）。

> ⚠️ 注意：`appeal-client.js` 里对 `wc.debugger.sendCommand` 有 try-catch，但 EPIPE 发生在**异步写完成回调**里，try-catch **抓不到**。

## 授权系统（本项目）要点

- 授权码格式：`<8位到期日>-<128位十六进制签名>`（**137 字符，无前缀**）；旧 `MQ2-` 前缀由非捕获可选组兼容
- 算法 **Ed25519**（`crypto.sign(null, ...)`，公钥 SPKI OID `1.3.101.112`），签名 64 字节 = 128 hex
- 机器码 = `MachineGuid + 首个非内部网卡 MAC + 主机名 + CPU 架构` 的 SHA-256 前 16 位大写，按 4 位分组
- 待签 payload = `归一化机器码|到期日`
- **`license-signing.js` 故意不进团队版包**（客户端只有校验能力，没有签发能力）—— 打包白名单里**不能加它**
- 私钥仅存 `管理员私钥\license-private.pem`，靠 `PORTABLE_EXECUTABLE_DIR` 三级回退查找，不打进 exe

## 打包白名单坑

`package.json` 的 `build.files` 是**白名单**，漏一个文件 = 打包版缺一个功能（且不报错）。

实测踩过：新增 `edit-runner.js` / `purple-box-rules.js` 后忘了加进白名单 → 打包版规格编码功能直接失效。
**另外数据文件也要加**：`edit-runner.js` 会 `fs.readFileSync(data/purple-box-colors.json)`，光加 js 不加数据照样废。

**改完必须实打包验证**：
```bash
npx electron-builder --win --dir          # 约 30 秒
node -e "const a=require('@electron/asar');console.log(a.listPackage('dist/win-unpacked/resources/app.asar'))"
```
确认新文件**在** asar 里、`license-signing.js` 和 `管理员私钥/` **不在**。
