# 用 CDP 驱动现代 SPA（React / Angular 后台）—— 实测要点

触发：用脚本连 CDP 操作一个 React/Angular 后台（Cloudflare Dashboard、SaaS 控制台、商家后台…），
出现「元素查不到 / 点了没反应 / 向导卡住」。

本文是 2026-10-07 在 Cloudflare 控制台实操一轮的沉淀（同一会话里 Angular 的得物规则中心走的是另一条路，见 §4）。

---

## 0. 前置：先分清「页面没加载完」和「选择器写错」

SPA 首屏渲染慢（Cloudflare 控制台约 5~8 秒）。**查询返回空的第一反应不该是「元素不存在」**：
- **带重试**（3 次 × 2 秒）再下结论
- **打原始返回值** —— `None` / `{'__error__': ...}` / `''` 三种含义完全不同，只打判断结果会把
  「JS 报错」误读成「元素不存在」

---

## 1. ⚠️ 选择器：不要用 `input[type=text]`

React 渲染的 `<input>` **常常没有 `type` 属性**（type 由 JS 控制），
于是 `querySelectorAll('input[type=text]')` 返回 **0**，而 `querySelectorAll('input')` 返回 **9**。

```js
// ✗ 返回 0，看着像「输入框不存在」，会白排查好几轮
document.querySelectorAll('input[type=text]')

// ✓ 全选 input，再按 placeholder + 渲染尺寸过滤
var list = document.querySelectorAll('input');
for (var i = 0; i < list.length; i++) {
  var el = list[i], r = el.getBoundingClientRect();
  if (r.width > 100 && (el.placeholder || '').indexOf('example.com') >= 0) { /* 命中 */ }
}
```

**通用规则**：SPA 里定位元素用 **`placeholder` / `aria-label` / `role` / 渲染尺寸**；
不要依赖 `type`（可能没有）、不要依赖 class 名（CSS Modules 带 hash，如 `TopicItem_desc__2Mh4Y`）。

---

## 2. ⚠️ `Runtime.evaluate` 的返回值可能是 **JSON 字符串**

`returnByValue: True` 时，JS 对象有时回来是 `str`（`'{"x":1090,"y":260}'`），有时是 `dict`。
**不解析就判 `isinstance(raw, dict)` 会静默失败**，症状同样是「查不到」。

```python
parsed = None
if isinstance(raw, str):
    try: parsed = json.loads(raw)
    except Exception: pass
elif isinstance(raw, dict):
    parsed = raw
```

稳妥约定：**JS 侧一律 `return JSON.stringify(obj)`，Python 侧一律 `json.loads`**。

---

## 3. ⚠️ 滚动后坐标会变 —— 点击前**重新取 rect**

`scrollIntoView()` 之后元素位置全变，用滚动前的坐标去点 = 点空。

**铁律：取坐标 → 立刻点，中间不插任何滚动步骤。**
若流程上必须先滚动/等待，就**再读一次** `getBoundingClientRect()` 拿到新坐标再点。

（本次实踩：按钮 `scrollIntoView` 后实际在 `y=889`，用了滚动前的 `y=497` 去点 → 无效，
白排查一轮。失败后**先怀疑坐标，不要先怀疑「CDP 驱动不了这个页面」**。）

---

## 4. 真实鼠标事件序列（对部分 SPA 必需）

```python
async def click(c, x, y):
    await c.send("Input.dispatchMouseEvent", {"type": "mouseMoved",    "x": x, "y": y, "button": "none", "buttons": 0})
    await asyncio.sleep(0.15)
    await c.send("Input.dispatchMouseEvent", {"type": "mousePressed",  "x": x, "y": y, "button": "left", "buttons": 1, "clickCount": 1})
    await asyncio.sleep(0.12)
    await c.send("Input.dispatchMouseEvent", {"type": "mouseReleased", "x": x, "y": y, "button": "left", "buttons": 0, "clickCount": 1})
```

- **`mouseMoved` 不能省**；三步之间要有 100ms 以上间隔（少了不生效）。
- **视口外的元素点不到**（`y > window.innerHeight`）→ 先 `scrollIntoView`，再重新取坐标。
- **不同框架结果不同，按这个顺序试**：
  1. **CDP 完整鼠标序列** —— ✅ 对 Cloudflare 控制台（React）有效
  2. **JS `el.click()`** —— 对普通 `button`/`div` 有效；对有自定义事件处理的组件常无效
  3. **`browser_exec` 的 `click_at_xy`** —— ✅ 对得物规则中心（Angular）有效，而 CDP 完整序列无效
- ⚠️ **别在一条路上反复重试**。同一种点法失败两次就换下一种；
  三条都失败时，看 §5（多半根本不该点）。

---

## 5. ⭐ 向导卡在「下一步 / 继续」时：**直接跳目标 URL，别死磕按钮**

**本次最能省时间的一条。**

Cloudflare 添加域名向导走到「确认扫描到的记录」页，底部的「继续前往激活」按钮：
**JS `.click()` 和 CDP 鼠标事件都不生效** —— 按钮 `disabled=false`、在视口内、`focus()` 过，就是不动。

**正确做法：放弃这个按钮，直接导航到向导的下一个目标页。**
```
不去点「继续前往激活」
→ 直接 location.href = 'https://dash.cloudflare.com/<account_id>/<域名>'
→ 目标页（域名概览）照样渲染，要的 Nameserver 就在上面
```

**通用启发**：多数 SaaS 向导页只是「路由 + 表单」，**目标页能直接用 URL 到达**。
卡在某个按钮上时先问自己「**这一步的终点是哪个 URL**」，直接去，
比研究按钮为什么点不动快一个数量级。

---

## 6. SPA 路由：`location.href='...'` 不一定触发渲染

React Router 应用里直接改 `location.href`，有时**URL 变了但主内容区是空的**（只剩侧边栏）。
本次 `/add-site` 就出现过 —— 等 12 秒仍是空壳，误判成「路径写错了」。

**对策**：
- 从已知能正常渲染的页面（如 `/home`）出发，用**侧边栏真实点击**进入目标页；
- 或先 `location.href` 触发一次整页加载，再在渲染出来的页面上继续点击。

（判断「主内容区」可以粗筛 `main.innerText` 里是否还只有侧边栏文案。）

---

## 7. 判定「这一步成了没有」看 URL，不看按钮状态

每步操作后断言 `location.href` 变了：
```
before = 点击前 URL → click → after = 点击后 URL
before != after  → ✅ URL 变了
before == after  → ℹ️ 没生效（别接着往下做）
```
**URL 不动就是没生效** —— 在错页面上继续操作，错误会累积到后面才暴露，更难查。

---

## 8. 可复用脚本骨架（本机现有）

`D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\`：

| 脚本 | 用途 |
|---|---|
| `cdp.py` | 通用执行器：`--url` 列标签页 / `--on <片段> "<js>"` 执行 / `--open <url>` 新标签 |
| `cf_click.py <x> <y> [秒]` | 完整序列真实点击 + 打印点击前后 URL |
| `cdp_net.py [片段] [秒] [导航URL]` | CDP Network 监听，抓 XHR/fetch 的请求体与响应（**挖接口首选**） |
| `cf_addsite.py` | 含「逐字符真实输入」示例 |

### ⚠️ React 受控输入必须**逐字符打字**

直接设 `el.value = 'x'` **不生效**（React 的 onChange 不触发）。正确姿势：
```python
# ① 先点一下拿焦点  ② Ctrl+A 清空  ③ 逐字符 dispatchKeyEvent
await c.click(box_x, box_y)
await c.send("Input.dispatchKeyEvent", {"type": "keyDown", "key": "a", "modifiers": 2})
await c.send("Input.dispatchKeyEvent", {"type": "keyUp",   "key": "a", "modifiers": 2})
for ch in "shiyi11.com.cn":
    await c.send("Input.dispatchKeyEvent", {"type": "keyDown", "text": ch, "unmodifiedText": ch, "key": ch})
    await c.send("Input.dispatchKeyEvent", {"type": "keyUp",   "key": ch})
    await asyncio.sleep(0.04)
# 打完回读 el.value 确认真的进去了，再去找提交按钮
```

---

## 一句话总结

SPA 驱动最容易翻车的是三件事：
**选择器**（别依赖 `type`/class）、**坐标**（滚动后必须重取）、**卡住的按钮**（直接跳目标 URL）。
三者都不是「CDP 不行」，而是驱动姿势不对。
