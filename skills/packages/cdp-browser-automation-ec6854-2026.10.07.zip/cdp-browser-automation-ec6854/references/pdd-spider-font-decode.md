# 拼多多后台数字的 spider-font 加密：解码 + 后台轮询

实测 2026-09-19，`mms.pinduoduo.com/sycm/goods_effect`（数据中心 → 商品数据）。

## 症状（先认出它，别当成抓取失败）
- 数字屏幕上清清楚楚，但 `textContent` / `innerText` 读出来那几位是**空的**
- 数字在一个 `<span class="__spider_font">` 里，`font-family: spider-font`
- span 的内容是**私用区码点** U+E000–U+F8FF（例：一个 6 位数读出来是 `[61180, 59160, 61180, 44, 60499, 59415, 58848]`，其中 `44` 是真正的半角逗号）
- **「实时」模式是明文 ASCII 数字；历史区间（昨日 / 7日 / 30日 / 周 / 月 / 自定义）才是加密的** —— 先用「实时」确认读法没写错，再切历史区间
- 字体文件长这样：`https://genimg.pddpic.com/upload/mms-trusteeship/fonts/<uuid>.otf`
- 挂 `fetch`/`XHR` 钩子**抓不到数据接口**（app 在加载时就把引用取走了，后挂的钩子看不到）→ **别在找接口上耗时间**，直接解字形

## 关键性质（决定方案能不能自动化）
- 码点→数字的映射**每次页面加载轮换**（同一台机器上三次加载拿到三套完全不同的码点）
- **但每个数字的字形轮廓是稳定的**：实测逐位比对，自身位差 **0.2–2.4**，次优位 **9.6–32.0**（10/10 全中）
- ⇒ **一次人工认字形建参考，之后全自动匹配**，不需要每次叫视觉模型

## 一、建参考（每次换页面时做一次，约 2 次工具调用）

渲染管线（**参考和查询必须用同一个管线**，否则位图对不上）：
```js
const c1=document.createElement('canvas'); c1.width=120; c1.height=170;
const k1=c1.getContext('2d');
const c2=document.createElement('canvas'); c2.width=56; c2.height=56;
const k2=c2.getContext('2d',{willReadFrequently:true});
const sig=(cp)=>{ k1.clearRect(0,0,120,170); k1.fillStyle='#000';
  k1.font='110px spider-font'; k1.textBaseline='top';
  k1.fillText(String.fromCodePoint(cp),8,6);
  k2.clearRect(0,0,56,56); k2.drawImage(c1,6,2,112,120,0,0,56,56);
  const d=k2.getImageData(0,0,56,56).data; let s='';
  for(let i=3;i<d.length;i+=4) s += d[i]>90?'1':'0';
  return s; };   // 3136 bit
```
⚠️ 先 `await document.fonts.ready`（字体没加载时渲染出来是空白）。字体名直接用页面的 `spider-font`。

1. 收集页面上所有 PUA 码点（扫 `span.__spider_font`）
2. 每个码点渲一张大图拼成一张 PNG，交给 `vision_analyze` 读一遍 → 得到「U+XXXX = 数字」
   （实测 10 个码点正好覆盖 0–9，可以拿「是否恰好 10 个且互不重复」当场验证有没有读错）
3. 用**同一管线**把这 10 个码点的签名存成 `{"7": "0101…", "0": "…"}`（digit → 3136 bit）→ 落到工作区 `glyph_ref.json`

## 二、自动解码（此后每次都不用再认字）
页内 JS 返回 `{sigs: {码点: 签名}, rows: [...]}`，Python 侧按汉明距离匹配：
```python
def build_map(sigs, REF):
    M = {}
    for k, s in sigs.items():
        best, bd = None, 10**9
        for dg, rs in REF.items():
            d = sum(1 for x, y in zip(s, rs) if x != y)
            if d < bd: bd, best = d, dg
        if bd < 120: M[int(k, 16)] = best     # 实测正确位 ≤3，次优 ≥9.6
    return M

def decode(raw, M):
    o = ''
    for ch in raw or '':
        cp = ord(ch)
        if 0xE000 <= cp <= 0xF8FF: o += M.get(cp, '?')
        elif ch.isdigit() or ch == '.': o += ch
    return o
```
- ⚠️ **单元格文本里数字后面紧跟「较前1月/昨日 XX%」**，拼接前必须 `.split(/较前|昨日/)[0]`，否则 `3938` 会读成 `3938564`
- ⚠️ **JS 里的映射表必须写成数字字面量键 `{0xE5ED:'5'}`**。写成字符串键 `{"0xE5ED":"5"}` 后 `M[cp]` 永远 undefined，症状是**行数正常、每位全变成 `?`**（本会话踩过，查了半天以为映射又轮换了）
- 匹配阈值拿不准时先打印「自己的差值 / 次优的差值」两个数，正常是 1 个数位级 vs 10 个数位级的差距

## 三、解码验收（必做，这是唯一可信的自检）
**同一行里 `成交转化率 == 成交买家数 ÷ 商品访客数`。**
实测 336 行 0 处不符（8.94=8.94、7.43=7.43、8.23=8.23、4.06、11.59、13.01 全中）。映射错一位、列错一列，这个等式立刻崩。
⚠️ **截图 OCR 不能当基准**：本会话用视觉读用户截图得到的数与该页自身的转化率自相矛盾（弹层遮住半列），按截图做的结论是错的。**页面 DOM 解码 + 转化率自洽 > 截图**。

## 四、页面结构（商品数据页）
- 入口 `/sycm/goods_effect?msfrom=mms_sidenav`
- 筛选框：`input[placeholder*="请输入商品ID查询"]`（多个 ID 用空格/逗号分隔），右侧 41px 宽的「查询」是一个 `[class*=suffixCell]`（**不是 `<button>`**，找 `button` 永远找不到）
- 日期粒度按钮：实时 / 昨日 / 7日 / 30日 / 周 / 月 / 自定义；「月」的月份面板是 `[class*=MPR_month]`，当前月带 `MPR_active`
- **页面上有 2 个 `<table>`：第 0 个只有表头（0 行）**，取 `tbody` 里行数 >2 的那个
- 列序（0-based）：0 商品信息（内含 `ID: xxx`）｜1 商品访客数｜2 商品浏览量｜3 成交金额｜4 成交件数｜5 成交订单数｜**6 成交买家数**｜7 成交转化率｜8 商品收藏用户数｜9 操作

## 五、⚠️ 未解：日期/月份筛选对程序化点击无响应
实测：点「月」→ 选月份，`统计时间` 标签**会变**（React 状态更新了），但**表格数据一个字节都不变**（8 个月读出来逐字节相同）。
试过并**全部无效**：JS `el.click()`、完整 mouse-event 序列、`navigator.userActivation` 为真时的点击、坐标 `Input.dispatchMouseEvent`（本机该域调用还经常 5s 超时）。
**不要在点击方式上反复试错** —— 走下面的协作路线，并明确告诉用户「这页只认真人点击」。

## 六、用户点、脚本后台轮询（已验证可用）
`browser-use` CLI 跑在**同一个 daemon/同一个浏览器**上，所以可以在后台常驻轮询，用户在自己的窗口点：

```bash
cd /e/RuanJian/Hermes && "E:/RuanJian/Hermes/bin/browser-use.EXE" < poll.py
```
helpers 预置（无需 import）：`cdp()` / `js()` / `page_info()` / `new_tab()` / `wait_for_load()`。

骨架：
```python
while time.time() < end:
    tid = next((t['targetId'] for t in cdp('Target.getTargets')['targetInfos']
                if t['type']=='page' and 'goods_effect' in (t.get('url') or '')), None)
    sid = cdp('Target.attachToTarget', targetId=tid, flatten=True)['sessionId']
    v = json.loads(cdp('Runtime.evaluate', expression=JS, returnByValue=True, session_id=sid)['result']['value'])
    key = (v['stat'], v['n'], sum(int(r['buyers']) for r in v['rows'] if r['buyers'].isdigit()))
    if key != last:
        json.dump(hist := hist + [v], open(OUT,'w',encoding='utf-8'), ensure_ascii=False)
        last = key
    time.sleep(4)
```
- 快照按「统计时间标签 + 行数 + 买家合计」去重 ⇒ 用户每切一个月自动落一份
- 用 `terminal(background=true, notify=true)` 起，跑 25 分钟足够用户慢慢点
- ⚠️ **轮询跑着的时候不要再发 `browser_exec`** —— 两个客户端抢同一个 daemon
- 同样的办法适用于任何「用户必须亲手点、但数据在 DOM 里」的页面

## 七、平台页面的筛选器状态必须显式核对
`mms.pinduoduo.com/goods/evaluation/index`：列表**默认勾着「1星」**（`evaluation_search_btn_checked*`），所以「共查询到 580 条」= **580 条差评**，不是全部评价。取消勾选后是 **38744 条**，但平台**只展示 2000 条** ⇒ 全量评价在这页根本采不到。
**规矩：任何「用这页数据做统计」的任务，开跑前先枚举 `1星..5星 / 已举报 / 已回复 / 有图片` 这些 chip 的 `checked` 类，并把口径写进交付物标题。** 用户给「这个页面看，有评价时间」这类指路时，他可能并不知道当前筛选状态。
