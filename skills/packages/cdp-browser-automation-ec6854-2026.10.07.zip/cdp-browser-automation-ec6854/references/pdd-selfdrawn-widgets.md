# 驱动拼多多自绘控件（beast-core）—— 2026-09-21 实测配方

拼多多商家后台大量用自绘组件（beast-core）——日期选择器、下拉、弹窗控件。
本次为了“补采历史某一天的 90 天窗口”，要把评价管理页的「自定义」日期范围设成 `[D−89, D]`，
卡了十几轮才跑通。**这几条适用于所有自绘控件。**

## 四条铁律

### ① 用 CDP 真实鼠标事件，不要用 JS dispatchEvent
`el.dispatchEvent(new MouseEvent('mousedown'...))` 三连对普通筛选按钮（星级等）有效，
但对自绘控件（尤其是弹出面板类）**经常无效**——面板打不开。
```python
def click_xy(x, y, pause=0.9):
    for t in ('mousePressed', 'mouseReleased'):
        cdp('Input.dispatchMouseEvent', type=t, x=x, y=y, button='left', clickCount=1)
    time.sleep(pause)
# 坐标：先用 JS getBoundingClientRect 算出中心点
```

### ② 别用“文字”定位会变文字的按钮 —— 改用 class + 序号
本次按钮选完就从 `自定义` 变成 `2026-06-24 ~ 2026-09-21`，
第二圈再按文字找就找不到了（自己的成功破坏了查找器）。
```js
[...document.querySelectorAll('[class*=evaluation_search_btn]')][3]   // 0近30天 1近90天 2近180天 3自定义
```

### ③ 面板是“开关式”的，而且会被别的操作顺手关掉
- 先判断面板存不存在 **再** 决定点不点（盲点会把它关掉）
  本次判据：`document.querySelectorAll('[data-testid=beast-core-monthRangePicker-year-header]').length`
- 点一次「查询」就会把面板关掉 ⇒ **一次完整的开面板→选值→确认，必须在同一个调用里跑完**，
  否则下一次调用接上去时面板已经不在了（本次因此浪费了两轮）。

### ④ 自绘控件常常有一个必须点的「确认」—— 不点就白干
**本次的胜负手。**只选值不点确认：面板不关、按钮文字不变、筛选条不变、数据也不会变。
```js
// 面板页脚那个「确认」（子节点为 0 + 文字完全相等 + 落在面板区域内的 y）
document.querySelectorAll('*')  →  e.children.length===0 && e.textContent.trim()==='确认'
                                  && e.getBoundingClientRect().y > 90 && < 430
```
> 排查顺序：先扫一遍面板里**所有**短文字元素（button / [class*=btn] / [class*=footer]），
> 把 `确认`『确定』『应用』这类词都搜一遍——比只盯着一两个选择器快得多。

## 回读验证（必做）
自绘控件不会告诉你它成功了。**必须回读页面上的真实状态**：
```js
[...document.querySelectorAll('[class*=search_btn]')].map(e=>e.textContent.trim()).filter(t=>/~/.test(t))
// 必拿到 'YYYY-MM-DD ~ YYYY-MM-DD' 才算提交
```
拿不到就当作**操作失败**返回（本次做成 bail `DATE_FAIL`，不落盘）——不要假设成功。

## 实测锚点（拼多多评价管理页 · 评价时间）
| 东西 | 选择器 / 位置 |
|---|---|
| 计选项 | `[class*=evaluation_search_btn]`，第 4 个 = 「自定义」|
| 面板判定 | `[data-testid=beast-core-monthRangePicker-year-header]`（双月并排，各一个）|
| 往回翻月 | `[data-testid=beast-core-icon-left]` 里 `y<200` 的**第一个**（左右两面板各自独立，能同时显示 6月\|9月）|
| 日期格 | `td[role=date-cell]` 内层 `[class*=RPR_cell]`（`title` = 日，跳过带 `outOfMonth` 的）|
| 确认 | 面板页脚，`textContent==='确认'` 且 `90<y<430` |
| 页面计数条 | `[class*=numberInfo]` → 「共查询到 X 条数据（未包含默认评价）」|
| 店铺名（登录校验）| `.user-name-text` |

## 顺手提醒
- 页面数据接口是**加密 payload**（`xg.pinduoduo.com/xg/pfb/a2`，body = `{"data":"<加密>"}`）
  ⇒ **不要试图直接调接口**取带日期的数据，走 UI。
- 「近30天/近90天/近180天」都是**跟随今天**的；要历史窗口只能用「自定义」。
- 改完筛选/采完数据要**复位**（清掉商品ID、星级别停在 5 星），否则下次采集从脏状态开始。
