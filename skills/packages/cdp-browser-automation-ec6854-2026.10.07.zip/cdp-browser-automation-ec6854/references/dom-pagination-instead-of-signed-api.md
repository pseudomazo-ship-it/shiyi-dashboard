# Signed/anti-bot list API blocked → page the list in the DOM instead

Verified 2026-09-16 on 拼多多商家后台 (`mms.pinduoduo.com`) 商品列表, 61 products.
Class-level technique; the PDD specifics are the worked example.

## Symptom

Dumping the page's OWN request headers (hook `fetch` + `XMLHttpRequest.prototype.setRequestHeader`):

```
POST /vodka/v2/mms/query/display/mall/goodsList
headers: {"content-type":"application/json",
          "Anti-Content":"0asAfa5E-wCEgxqHXYSt_USOOG7qNYOjZhPqgHKqTmZhApN7QJYyQxdECCeM3ne..."}
```

`Anti-Content` is a **per-request signed blob** (every call differs). A hand-rolled
`fetch`/`XHR` from the same page does not carry it and gets:

```json
{"error_code":54001,"error_msg":"操作太过频繁，请稍后再试！","result":{"verifyAuthToken":"..."}}
```

**It is NOT a rate limit.** Waited 60s, retried: still 54001. So do not sleep-and-retry,
and do not reverse the signature (that is defeating bot protection — 十一's standing rule:
不逆向签名、不破验证码). Also note the `error_msg` is deliberately misleading; treat it as
"unsigned request", not "too fast".

## Decision checklist

1. Confirm the signature header is the difference (header dump above).
2. **Check whether the endpoints you actually need are unprotected.** Here the property
   endpoint `/draco-ms/mms/query-goods-property` needed no signature and returned 61/61
   (and 460/460 across a later 8-shop run). Usually only the LIST endpoint is signed.
3. Read the ids from the **rendered DOM**, feed them to the unprotected API.

⚠️ **A hook log shows every request — an endpoint appearing on the page is not necessarily
the data source.** `/plutus/api/plutus/bin/goods/query` is called on the goods-list page but
always returns `{total:0,data:[]}`; the real list is `/vodka/v2/mms/query/display/mall/goodsList`
(response `result.goods_list[]` + `result.total`). Confirm by response body, not URL grep.

## Paging the list in the DOM

PDD pager selectors:

| Element | Selector |
|---|---|
| pager container | `ul[class*=PGT_outerWrapper]` (holds 「共有 N 条 / 每页 / 条」) |
| page number | `li[class*=PGT_pagerItem]` (`innerText` = the number) |
| current page | `li[class*=PGT_pagerItemActive]` |
| next | `li[class*=PGT_next]` (class contains `disabled` on last page) |
| page size | `div.PGT_sizeSelect_5-*` |

The pager sits far down the page (observed y≈1734 in a ~959px viewport) — `scrollIntoView({block:'center'})` first.

**Clicking**: `el.click()`, `click_at_xy()` and `cdp('Input.dispatchMouseEvent')` all failed
(timeout / no effect). The full sequence works, and needs no scroll or coordinates:

```js
['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t =>
  el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,buttons:1})));
```

**Read each page** (product id from `ID: \d+`, name is the preceding line):

```js
(()=>{
  const lines=document.body.innerText.split('\n').map(s=>s.trim());
  const out=[], seen={};
  for(let i=0;i<lines.length;i++){
    const m=lines[i].match(/^ID:\s*(\d+)/);
    if(m && !seen[m[1]]){ seen[m[1]]=1; out.push({id:m[1], name:(lines[i-1]||'').slice(0,80)}); }
  }
  const a=document.querySelector('li[class*=PGT_pagerItemActive]');
  return JSON.stringify({page:a?a.innerText.trim():'?', items:out});
})()
```

Python loop: read → click `li[class*=PGT_next]` → `time.sleep(3.5)` → repeat; stop when the
click helper returns `'disabled'`. Dedupe by id (titles repeat; goods_id does not).

## Verifying the collected count — the badge number is a LIE

The pager's 「共有 N 条」 is the source of truth; the tab badge is not. Verified 2026-09-16
across 8 shops:

- 61 products → pages 1–7 with 10×6 + 1, matching exactly.
- **切店后标签页的「在售中(N)」是上一家店的残留值，偏差可达 2 倍。** 切到蒙倩染发旗舰店后
  徽标写 `在售中(99)`，真实只有 **58** 条（99 是上一家店留下的）；紧接着切下一家又显示 58，
  **恰好等于真实值，纯属巧合**。所以「数字看着对」也不能信。

**判定三件套必须全部对齐，缺一不可**：① 分页器底部「共有 N 条」；② 分页器页码数反推的条数
（如页码 1–6 = 5×10+8 = 58）；③ 实际抓取并按 goods_id 去重后的条数。不一致就
`cdp('Page.reload')` 等 10 秒重读再核。**徽标数永远不作为交付里的总条数。**

在售 / 已下架 / 已售罄 are **separate tabs** — the DOM pass only covers the active one,
so settle the scope with the user first.

## Multiple tabs: the target shop must be found by `mallId`, not by URL

The user switches shops **in their own tab**, while the harness may stay bound to a different
one. Symptom: 用户说「店铺变了」，你读到的还是旧店。A merchant backoffice routinely has 5–7
`goods_list` tabs open **whose URL and title are identical** — so the SKILL.md rule "pick the page
target by URL substring" is useless here. Enumerate, attach, and match on the embedded `mallId`:

```python
def attach_by_mall(mall):
    for t in cdp('Target.getTargets').get('targetInfos', []):
        if t.get('type')=='page' and 'goods_list' in (t.get('url') or ''):
            a = cdp('Target.attachToTarget', targetId=t['targetId'], flatten=True)
            s = a['sessionId']
            v = cdp('Runtime.evaluate', returnByValue=True, session_id=s,
                    expression="(document.documentElement.innerHTML.match(/\\"mallId\\":(\\d+)/)||[])[1]||''")
            if (v.get('result') or {}).get('value') == mall: return t['targetId'], s
            cdp('Target.detachFromTarget', sessionId=s)
    return None, None
```

Drive that page with `cdp('Runtime.evaluate', expression=..., returnByValue=True, awaitPromise=True, session_id=sid)`
instead of `js()`. ⚠️ **`sessionId` does NOT survive across `browser_exec` calls** (fresh process each
time) — re-attach at the top of every call.

Useful side-channel: **hovering the shop name** in the top-right opens a shop menu listing sibling
shops (plus a count and 「查看全部」) — good for checking what is still un-collected. **Read-only;
do not click** — that menu contains 「退出当前账号」. Whether clicking an entry actually switches
shops is still unverified; this session the user did the switching.

## Bonus: cache the shop→mall_id map

Record 店铺名 → mall_id as you go, so the next run can skip shops already harvested. This session
(8 shops): 蒙倩洗护官方旗舰店 173045573 / 蒙倩护发旗舰店 954540899 / 蒙倩护发官方旗舰店 490675086 /
蒙倩护发造型官方旗舰店 275121273 / 蒙倩染发旗舰店 247765139 / 植粹草本染发坊 284731509 /
蒙倩精油官方旗舰店 603811081 / 蒙倩美妆洗护官方旗舰店 727418161.

## Multi-store merge output

Per-shop tables come from `scripts/gen_xlsx_fields.py` (trimmable column set). For the multi-shop
rollup, write a three-sheet merger (this session's lands at
`...\Hermes Agent\pdd采集工具\merge_shuxing_summary.py`): **汇总** (店铺 / mall_id / 在售数 /
每字段缺失数 / 缺失率 + 合计行), **明细** (all rows), **批准文号分布** (certificate × product count ×
shop count). The bundled `merge_shops.py` hard-codes both the filename pattern
(`*_商品资质属性采集_*.xlsx`) and the column order — with a different column set it silently
mis-assigns columns; writing your own is cheaper.

## Cleanup

Your `new_tab` and the user's tab have the same URL — see the tag-and-probe rule in SKILL.md
("Closing YOUR tab when it shares a URL with the user's").

## 相关：用户自有技能 `pdd-merchant-harvest` 的过时点

采集 PDD mms 商品的专用技能是 `pdd-merchant-harvest`（`created_by=None`，**curator 不可写**）。
它以下内容已过时，发现时要主动提醒用户 `hermes curator adopt pdd-merchant-harvest` 才能修：

1. 「接口法 ≫ DOM 渲染法」在**列表**上不再成立 —— 列表接口已需 `Anti-Content` 签名。
2. 第 5 步「`js()` 可直接返回 Promise」未提 5s 响应上限，长任务必须 fire-and-forget + 轮询。
3. Pitfall 5 推荐的 `click_at_xy(x,y)` 实测点不动分页器；有效的是 MouseEvent 序列。
4. Pitfall 10 只说徽标「可能是缓存」，实测是**上一家店的残留值且偏差可达 41 条**（99 vs 58）。
5. 未覆盖「用户在自己标签切店、harness 绑在别的标签」的多标签定位问题。
6. 自带 `gen_xlsx.py` / `merge_shops.py` 写死了列序与文件名模式。
