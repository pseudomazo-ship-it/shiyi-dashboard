# 后台管理页 · 分页数据批量采集（接口回放法）

> 2026-09-25 在探域（agent.tanyuai.com 财务中心·积分消耗明细，37 页 / 3637 条）实测跑通：
> 全程约 3 分钟，0 失败页，取回条数与页面「共 N 条」逐条吻合。
> 适用：任何 antd / Element 风格的分页后台表（电商后台、财务台、客服台明细页）。

## 什么时候用这招

页面已经筛好了、要「把每一页登记下来」，页数 ≥ 10。
**逐页点击 = 慢（37 页 × 2~3 秒）+ 容易点错/被虚拟列表坑**；
**接口回放 = 37 次请求十几秒**，而且拿到的是原始字段（比 DOM 抠字更准）。

⚠️ 前提：**请求体里必须带筛选参数**（先按第 3 步抓一次请求确认）。
若筛选是纯前端过滤（body 里看不到日期）→ 回放会拿到**未筛选的全量**，此时老实点页翻，或自己补参数后校验条数。

---

## 0. 找到「用户在看的那个标签」

页面常开在**用户日常那个浏览器**里，不是专用浏览器。
```python
tabs = list_tabs()
ty = [t for t in tabs if '目标域名' in (t.get('url') or '')]
switch_tab(ty[0])            # 切换后 current_tab() 会带上 🐴 标记
```
- ⚠️ **别用** `cdp('Runtime.evaluate', sessionId=...)` 指定标签：实测会路由到默认标签，
  读回来的是**另一个网站的内容**（当时把拼多多页面当成探域结果，白折腾一轮）。
- `switch_tab()` / `new_tab()` 不动用户可见的标签栏；`activate_tab()` 才切前台（仅在明确需要时用）。
- 用 `current_tab()` 复核当前到底在哪个页面。

## 1. 先读「用户当前筛的是什么」+ 总数

**永远先读页面状态，别猜日期**（用户会自己改筛选，且常和上一轮不同）：
```js
(() => {
  const ins = [...document.querySelectorAll('input')].map(e => ({ph: e.placeholder, val: e.value}));
  const pg = ([...document.querySelectorAll('[class*=pagination]')]
              .map(e => e.innerText.replace(/\s+/g,' ')).filter(x => x.includes('共'))[0]) || '';
  return { inputs: ins.slice(0,4), pager: pg,
           rows: document.querySelectorAll('.ant-table-tbody .ant-table-row').length };
})()
```
- `inputs[0]`=开始时间、`inputs[1]`=结束时间（按 `placeholder` 认更稳）
- 页数 = `ceil(N / 100)`
- `rows`=0 且页面出现「扫码登录/处于登出状态」→ 未登录（见第 6 步）
- 行选择器 antd 用 `.ant-table-tbody .ant-table-row`；表头会多一个 `.ant-table-measure-row`（`tr` 数比数据行多 1，别按 `tr` 数报数）

## 2. 找分页接口

```js
performance.getEntriesByType('resource').map(e => e.name)
  .filter(u => /关键词|list|page|api/i.test(u) && !/\.(js|css|png|jpg|svg|woff|ttf)/i.test(u))
```
按业务关键词过滤（本次命中 `/api/gc/points-bill/paginate`）。

## 3. 抓请求体（证明筛选条件在请求里）

挂 fetch + XHR 双钩子，然后**点一次「第 2 页」触发**（antd 分页 `.ant-pagination-item` 用普通 `.click()` 就能触发 React）：
```js
if (!window.__hooked) { window.__hooked = 1; window.__cap = [];
  const rec = (u,m,b) => { if (String(u).includes('关键词')) window.__cap.push({url:String(u),method:m,body:b||null}); };
  const of = window.fetch;
  window.fetch = function(...a){ try{ const u=(typeof a[0]==='string')?a[0]:a[0]&&a[0].url; const o=a[1]||{};
    rec(u,o.method||'GET',(typeof o.body==='string'?o.body:null)); }catch(e){} return of.apply(this,a); };
  const oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open=function(m,u,...r){this.__u=u;this.__m=m;return oo.call(this,m,u,...r);};
  XMLHttpRequest.prototype.send=function(b){ try{ rec(this.__u,this.__m,(typeof b==='string'?b:null)); }catch(e){} return os.call(this,b); };
}
window.__cap = [];
[...document.querySelectorAll('.ant-pagination-item')].find(e=>e.innerText.trim()==='2')?.click();
```
实测拿到：`POST /api/gc/points-bill/paginate`，body = `{"startTime":"2026-09-17","endTime":"2026-09-17","pageSize":100,"pageIndex":2}`
→ **筛选条件确实在请求体里** ✓ 可以安全回放。

## 4. 回放取全部页（**必须后台跑 + 轮询**）

```python
js(r"""(() => {
  window.__all = []; window.__prog = {done:0, of:N, n:0, bad:[], finished:false, total:null};
  (async () => {
    for (let p = 1; p <= N; p++) {
      try {
        const resp = await fetch('/api/xxx/paginate', {method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({<筛选参数>, pageSize:100, pageIndex:p})});
        const j = await resp.json(); const d = j.data || {};
        if (j.code !== <成功码>) window.__prog.bad.push(p);
        else { window.__prog.total = d.total; (d.results||[]).forEach(r => window.__all.push(r)); }
      } catch(e) { window.__prog.bad.push('p'+p); }
      window.__prog.done = p; window.__prog.n = window.__all.length;
    }
    window.__prog.finished = true;
  })();
  return 'started';
})()""")
# 之后每 3 秒：json.loads(js('JSON.stringify(window.__prog)')) 直到 finished
```

### ⚠️ 为什么必须这样写（两个硬限制）
1. **harness 的 `js()` 有 5 秒响应上限** —— 直接 `await` 一整圈会报
   `Runtime.evaluate timed out after 5s`。**长任务一律「页面后台跑 + 主循环轮询进度」**。
   （同一个 5 秒限制也会咬 `Input.dispatchMouseEvent`：对**非活动标签**派发鼠标事件同样超时 →
   要真鼠标就 `activate_tab()` 切前台再点，或用页面内 `dispatchEvent` 验证接线。）
2. **一次 `js()` 大约只能回 ~25KB 字符串** —— 先算导出文本长度，超了按 26KB 分片取：
   ```python
   while off < L:
       parts.append(js('window.__csv.slice(%d,%d)' % (off, min(off+26000, L)))); off += 26000
   ```

**在页面内发请求**（同源 + cookie/token 自动带上），**不要**在外面用 requests/curl 复刻（会 401 或要逆向签名）。

## 5. 导出与校验

先在页面里拼好 CSV（带表头、字段值用 `"` 转义）：
```js
const esc = s => '"' + String(s == null ? '' : s).replace(/"/g, '""') + '"';
window.__csv = '表头1,表头2\n' + rows.map(r => [r.a, r.b].map(esc).join(',')).join('\n');
```
落地用 `utf-8-sig`（Excel 打开中文不乱码）。

**三条硬校验**（缺一条不算完成）：
1. 取回条数 == 接口 `total` == 页面「共 N 条数据」
2. `bad` 为空（0 个失败页）
3. 业务自检（本次：应扣合计 == 实扣合计，差 0）

## 6. 采完复位 + 交付

- **把列表点回第 1 页**（翻页测试会停在别的页，用户回头一看就懵）
- 交付到桌面：`C:\Users\Administrator\Desktop`（2026-09 实测**不是** OneDrive 重定向）
- Excel 三表：明细（冻结首行 + 筛选 + 千分位 + 打印一页宽）/ 按时间汇总 / 按主体汇总
- 报告：页数 / 条数 / 实体数 / 合计 + **每行一个实体的完整表格** + 文件路径 + 自检（✅通过项 + ℹ️说明）

---

## 坑（都实踩过）

| 坑 | 真相 |
|---|---|
| 读到了别的网站的内容 | `cdp(Runtime.evaluate, sessionId=…)` 不按 session 路由 → 用 `list_tabs()` + `switch_tab()` |
| 一整圈 `await` 报 5s 超时 | 后台跑 + 轮询进度（`window.__prog`） |
| 非活动标签派发鼠标事件超时 | 同上；改用 `activate_tab()` 或页面内 `dispatchEvent` |
| 一次 `js()` 回不完 | ~25KB 上限 → 分片 `slice()` 拼回 |
| **@url 附件显示「扫码登录/处于登出状态」** | 那是**抓取工具自己的未登录视图**，与浏览器真实登录态无关 ✗ —— **先查页面再下结论** |
| 时间列多出「次日 00:00」的 20+ 行 | 该列是**小时桶的结束时刻** → 那是当天 23:00-24:00 那一桶，**不是多余数据** |
| 同一实体名出现两行 | 接口里 `platform` / `thirdShopId` 不同 = **同名不同平台**，不是重复登记 |
| 筛选被换过 | 用户会自己改 → **每次先读 `input.value`**，别沿用上一轮的日期 |
