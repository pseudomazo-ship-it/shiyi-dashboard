# payload 里的辅助函数必须定义在最前面（2026-09-27 实踩）

## 症状

定时采集报：

```
采集失败: NO_RESULT: 没拿到结果。尾部输出：Traceback (most recent call last):
NameError: name 'bail' is not defined
```

看着像「没登录 / 页面没打开」，其实**真正的错误被这个 NameError 盖掉了**，
白排查一整轮（一度以为是登录过期，还让用户去重新登录一次）。

## 根因

payload 里的调用顺序是：

```python
page = next(...)                 # 找页面
if page is None:
    bail('NO_PAGE', ...)         # ← 第 102 行就调用了
...

def bail(code, msg):             # ← 第 113 行才定义
    print('__RESULT__' + json.dumps({'ok': False, 'error': ...}, ensure_ascii=False))
    raise SystemExit(0)
```

payload 是从上往下直线执行的脚本 → 走到 `bail(...)` 时它还**不存在** → `NameError`，
结果 `NO_PAGE`（或别的真因）被顶掉了。

## 修法

把所有 helper（`bail`、`jsv`、`jsv_of`…）**提到文件最前面**（import 之后、任何逻辑之前）：

```python
import json, random, re, time

PIDS = __PIDS__
...

# 先定义，再使用
def bail(code, msg):
    print('__RESULT__' + json.dumps({'ok': False, 'error': '%s: %s' % (code, msg)}, ensure_ascii=False))
    raise SystemExit(0)
```

自检：`def bail` 的行号 **<** 第一次出现 `bail(` 的行号。

```python
lines = open(p, encoding='utf-8').read().split('\n')
d = [i+1 for i, l in enumerate(lines) if l.startswith('def bail')]
c = [i+1 for i, l in enumerate(lines) if 'bail(' in l and 'def ' not in l]
assert d and c and d[0] < c[0], 'helper 定义位置在使用之后！'
```

## 通用教训

1. **payload 不是模块，是「一条直线跑完」的脚本** —— 函数定义位置 = 可用位置，
   和正常 `import` 的「后定义也能用」完全不同。
2. **看到 `NameError: name 'X' is not defined`，先找 X 的定义在第几行** ——
   多数情况只是「定义在使用之后」，不是缺文件/缺依赖。修完再跑，真因才会露出来。
3. **每个失败分支都要报出自己的 code**（`NO_PAGE` / `OPEN_FAIL` / `NOT_LOGIN` / `NO_DATA`），
   否则一个 `NameError` 能把所有分支糊成同一句话，诊断信息全丢。
4. 改完 payload **先 `py_compile` 再跑**，并顺手打印「定义行 < 调用行」的自检结果。
