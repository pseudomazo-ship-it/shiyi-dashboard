# Migrate an unstable embedded WebContentsView driver to an external Chrome (no logic rewrite)

Verified pattern (PDD publish tool): the Electron app drove its publish flow through an
**embedded `WebContentsView`** (`browserView.webContents`), which was UNSTABLE (crashes,
dropped 9335 port, lost login, and every `getBoundingClientRect()` coord went NEGATIVE —
`x=-376, y=-3268` — so buttons landed off-screen and the `全屏编辑` full-screen-SKU button
wasn't reachable). The same page in an external stable Chrome(9444) had normal coords and
visible buttons. Instead of rewriting the whole automation, **substitute a driver object that
mimics Electron's `webContents` interface but routes every call to the external Chrome over CDP.**

## The interface-compatible driver (`pddCdp`)
Put it in `src/pdd-cdp.js`. Single persistent WebSocket keeps DOM `nodeId` valid across
`executeJavaScript` AND `debugger.sendCommand` (they must share one connection or nodeIds expire).

| Electron `webContents` method | CDP equivalent |
|---|---|
| `executeJavaScript(expr)` | `Runtime.evaluate {expression, returnByValue:true, awaitPromise:true, userGesture:true}` → return `result.result.value`; throw on `exceptionDetails` |
| `loadURL(url)` | `Page.navigate {url}` |
| `getURL()` | `/json/list` → pick target URL |
| `debugger.attach()/isAttached()/detach()` | no-op / `!!ws` / no-op |
| `debugger.sendCommand(method, params)` | raw CDP send (`DOM.getDocument`, `DOM.querySelector`, `DOM.setFileInputFiles`, `Input.insertText`, …) |
| `sendInputEvent(input)` | `Input.dispatchKeyEvent` (map ESCAPE/ENTER/TAB/BACKSPACE/DELETE → key/code/windowsVirtualKeyCode) |
| `setZoomFactor()` | no-op (external window isn't zoomed; coords stay stable) |

## WebSocket client
`require('undici').WebSocket` — **the Electron/Node main-process path** (`ws` was NOT in
node_modules; don't rely on global `WebSocket`). Verify before wiring:
`node -e "const{WebSocket}=require('undici'); ..."` connecting to `/json` → target
`webSocketDebuggerUrl` → `new WebSocket(wsUrl)` → send `Runtime.evaluate`, read `document.title`.
Listen on `onopen/onmessage/onclose/onerror`; `client.close()` on reconnect; `ws=null` on close.

## Replace rule (critical — don't over-swap)
Swap `browserView.webContents` → `pddCdp` ONLY for the driver methods and the arg-passes:
- `browserView.webContents.(executeJavaScript|loadURL|getURL|debugger|sendInputEvent|setZoomFactor)` → `pddCdp.$1`
- `(browserView.webContents,` (function arg pass, e.g. `fillSkuData(browserView.webContents, skus)`) → `(pddCdp, `
- `const webContents = browserView.webContents;` → `const webContents = pddCdp;`

Do **NOT** touch the UI/lifecycle uses: `.on(...)`, `.focus()`, `.capturePage()`,
`.canGoBack()/.goBack()/.reload()`, `.close()`, `.setWindowOpenHandler` — keep those on the
real window (or leave to the embedded view). `capturePage()` kept on the embedded window still
works for evidence screenshots, but note it shows the embedded page which may drift from the
external Chrome.

## Verify the swap
- `node --check src/main.js` (syntax).
- Launch Electron (`unset ELECTRON_RUN_AS_NODE; node_modules/electron/dist/electron.exe .`
  via `terminal(background=true)`) — if the driver module `require`s cleanly and Electron stays
  up (multiple electron.exe processes), the swap didn't break startup.

## Honest limit — the swap is NOT the whole fix
Moving the connection target does **not** make PDD's per-char inputs fillable. External Chrome
still needs `Input.dispatchKeyEvent` per character (see `pdd-publish-product-listing.md`); PDD
rejects `.value` / setter / `Input.insertText` injection regardless of embedded vs external.
And a full "publish an item" end-to-end needs the user's real login + a real submit — the driver
swap alone only relocates the connection, it can't be validated without a real session.

## Spawn the durable external Chrome (logged-in, project profile)
```bash
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --user-data-dir="D:/.../pdd-browser-profile" \
  --remote-debugging-port=9444 --no-first-run --no-default-browser-check \
  --window-size=1600,1000 "https://mms.pinduoduo.com/goods/goods_list" &
```
(via `terminal(background=true)`). The `--user-data-dir` profile is the PERSISTENT one the user
logged into once — restarting Chrome with it returns already logged-in (no auth prompt).
