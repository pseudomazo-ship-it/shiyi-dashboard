# 拼多多 评价管理页 — 商品ID 采集配方

实测 2026-09-19（蒙倩攀七花美发店）：**580 条 / 每页 40 / 15 页 / 46 个不同商品ID**。
入口 `https://mms.pinduoduo.com/goods/evaluation/index`（商家后台 → 评价管理 → 评价列表）。
采集后**必须**与页面自报的「共有 580 条」对账。

## DOM 锚点（实测）

| 要什么 | 选择器 | 实测文本 |
|---|---|---|
| 商品ID（**唯一正确来源**） | `div.goods-id` | `ID: 800597284435` |
| 一行（商品名+ID+规格） | `div.goods-info` | `商品名ID: 800597284435奶茶灰棕【无需褪色】 齐腰发看过来【三盒】` |
| 当前页号 | `[class*="pagerItemActive"]` | `1` |
| 下一页 / 上一页 | `[class*="PGT_next"]` / `[class*="PGT_prev"]` | 无文本（图标） |
| 页码按钮 | `[class*="pagerItem"]`（文本 = 页码） | `1` `2` … `15` |
| 总条数 | `[class*="pagerTotalText"]` | `共有 580 条` |
| 行数 | `querySelectorAll('div.goods-info').length` | 40（末页 20） |
| 商品ID 筛选框 | 顶部筛选区「商品ID」 | 可直接贴 ID 过滤（只读核验用） |

⚠️ 页码按钮只在**可见窗口**里存在：在第 15 页时 `pagerItem` 只有 11–15，点不到 `1`。回第 1 页要循环点 `PGT_prev`。

## 抽取 JS（唯一正确写法）

```js
(() => { const T=e=>(e.textContent||'').replace(/\s+/g,' ').trim();
  return JSON.stringify([...document.querySelectorAll('div.goods-id')].map(el=>{
    const gid=T(el); const m=gid.match(/ID[:：]\s*(\d+)/);   // 源头是 div.goods-id，不是整行
    const info=el.closest('div.goods-info'); const full=info?T(info):'';
    return {id: m?m[1]:'', gidText: gid, title: full.split(/ID[:：]/)[0].trim()};
  })); })()
```

**为什么不能用整行文本**：行文本无分隔符，`ID:` 后面紧接规格（`1升大容量`、`400g`、`398g`），
`\d{6,}` 会把规格开头的数字一起吃进去。实测 580 行里 **145 行错**，且成表后完全看不出。
**验收：`Counter(len(id))` 只有一种长度**（实测 580/580 = 12 位）。

## 翻页循环（browser_exec 内）

```python
ACTIVE = """(() => { const a=document.querySelector('[class*="pagerItemActive"]'); return a?a.textContent.trim():''; })()"""
NEXT   = """(() => { const b=document.querySelector('[class*="PGT_next"]'); if(!b) return 'no'; b.click(); return 'ok'; })()"""
PREV   = """(() => { const b=document.querySelector('[class*="PGT_prev"]'); if(!b) return 'no'; b.click(); return 'ok'; })()"""

for _ in range(20):                      # 先回到第 1 页（页码按钮可能点不到 1）
    if int(ev(ACTIVE) or 0) <= 1: break
    ev(PREV); time.sleep(1.4)

rows = []
for pg in range(1, 16):                  # 页数 = ceil(共有 N / 40)，别写死
    cur = int(ev(ACTIVE) or 0)
    d = json.loads(ev(COLLECT))
    for x in d: x['page'] = cur
    rows += d                             # 关键：先收当前页，再翻页
    ev(NEXT)
    for _ in range(25):                   # 等页号真的 +1
        time.sleep(0.7)
        if int(ev(ACTIVE) or 0) == cur + 1: break
    time.sleep(1.0)
```

- 该页 `.PGT_next` **直接 `el.click()` 即生效**（与商品列表页不同，那边要派发完整鼠标事件序列）。先试 `el.click()`，不行再退到事件序列。
- **判断翻页成功看页号，不要看首行文本**：实测第 3 页首行与第 2 页相同（同一商品连排多页），按首行判断会误判成「没翻页」。
- 每页间隔 1~2s；全程只读，不改筛选、不点保存。

## 落表（openpyxl，`uv run --with openpyxl`）

两张 sheet：
1. **商品ID汇总**：序号 / 商品ID / 商品名称 / 评价条数 / 占比 / 出现页
2. **明细**：序号 / 所在页 / 商品ID / 商品名称

- 商品ID 列设 `number_format='@'`（锁文本）；评价条数列 `#,##0`，占比 `0.0%`；冻结首行 + 表头填色 + 边框。
- 交付前 assert：`len(rows) == 页面共有条数`、`all(len(id)==12)`、`sum(counts) == len(rows)`。

## 采完要提醒十一的三件事（实测都出现）

1. 评价高度集中在少数链接：top1 `800597284435` 占 **202 条 / 35%**。
2. 列表里混着**非目标品类商品**：宠物染毛膏 14 条、护发加热帽 7 条、黑油一擦净 1 条。
3. 出现 **「小主--VIP客户专拍」** 这类非真实商品（4 条）—— 这种链接本不该有评价，值得单独点出来。

## 采集完毕的动作

回到第 1 页再结束（用户可能接着看）；自己开的标签采完关掉；报告里写清「行数/去重数/校验结果」。
