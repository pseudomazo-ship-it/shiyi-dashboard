# 定时采集 → 看板 → 推送：完整作业模板（PDD 评价星级日采集，2026-09-21 建）

这是本库中**第一个跑通的「无人值守浏览器采集」完整闭环**，也是一个可复用的骨架：
以后再开同类任务（另一个店铺 / 另一个指标 / 另一个平台），照这个形状搭。

## 需求形态（十一 的原话口径）
> 「每天采集店铺全部近90天的1-5星数据情况、还有采集固定几个商品ID的1-5的数据情况」
> 「只要采集1-5星的数量即可（共查询到 X 条数据（未包含默认评价））」
> 「不需要登记在飞书了，就登记在网页看板内」+「每天把关键数字微信推我手机」

→ 口径必须写进产物：该数是 **「未包含默认评价」的自算口径**，**≠ 评价总量、≠ 平台 DSR**。
→ 别把它和历史 1-8 月那批（另一个店、38,744 条）混着看。

## 目录布局（产出全在 Hermes 自己的工作区）
```
<工作区>\项目：评价星级日采集\
  <看板名>.html          ← 成品看板（浅色系、单文件、离线）
  data\daily.json        ← 唯一数据源，一天一条，脚本 append（同日重跑=覆盖）
  data\run_log.txt       ← 每次运行追加，排障就看它
  pdd-browser-profile\   ← 专用浏览器 profile（⚠️不能删，删了要重新登录）
  脚本\collect_stars.py  ← 采集\.py  ← 渲染看板
  脚本\run_daily.py      ← 总调度：采集 → 看板 → 推送（含微信/UQQ 降级）
```

## 三个脚本的职责与接口
| 脚本 | 职责 | 关键约定 |
|---|---|---|
| `collect_stars.py` | 把一段 Python `PAYLOAD` 从 stdin 喂给 `browser-use.EXE`，拿回 `__RESULT__{json}` | `--dry`＝只采不落盘（自检用）；**全量校验失败返回 1 且不落盘** |
| `build_view.py` | 读 `daily.json` 渲染单文件看板 | 顶配参数 `--in/--out`，**造模拟多天数据验证趋势图**就靠它 |
| `run_daily.py` | 调上面两个 + 推送 | 失败也推（带原因+具体建议）；渲染失败单独告警 |

## 采集侧要点（见 SKILL.md 正文的对应条目）
- **星级筛选是多选复选框** → 每次只能留一个星级；**切换星级自动刷新，不用点「查询」**；商品ID 是独立维度，清空+查询可干净回全店。
- **页面不在就自己 `new_tab(目标URL)`** —— 不要依赖人工把「评价管理」留着（用户关页 = `NO_PAGE` 失败）。
- 一个完整周期 = 全店 5 次 + 每商品 5 次；4 个商品 → 25 次查询，**实测 126~140 秒**。
- 只读：不翻页、不导出、不点保存；**采完复位筛选**（清空商品ID + 回到 1 星）。

## 专用浏览器（脚本自愈，`ensure_browser()`）
```python
CDP_PORT, BU_NAME = 9445, 'pddstars'
PROFILE = os.path.join(BASE, 'pdd-browser-profile')

def ensure_browser():
    """返回 (env_extra, 说明)；起不来就退回默认浏览器，保证不断采。"""
    if _port_alive():
        return {'BU_NAME': BU_NAME, 'BU_CDP_URL': 'http://127.0.0.1:%d' % CDP_PORT}, '专用浏览器已在运行'
    subprocess.Popen([CHROME, '--remote-debugging-port=%d' % CDP_PORT,
                      '--user-data-dir=%s' % PROFILE, '--no-first-run',
                      '--no-default-browser-check', LOGIN_URL],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(20):
        time.sleep(2)
        if _port_alive():
            return {'BU_NAME': BU_NAME, 'BU_CDP_URL': 'http://127.0.0.1:%d' % CDP_PORT}, '专用浏览器已拉起'
    return {}, '⚠️ 专用浏览器 40 秒内没起来 —— 退回默认浏览器'
```
调用方：`env = dict(os.environ); env.update(env_extra)` → `subprocess.run([BROWSER_USE], input=PAYLOAD, env=env, ...)`。
每条日志都写一句「这次用的哪个浏览器」。

## cron 三个任务（全部 `no_agent=True` + `deliver='local'`，脚本自己发消息）
| 时间 | 入口脚本 | 作用 |
|---|---|---|
| 14:00 | `scripts/pdd_stars_daily.py`（转发→`run_daily.py`） | 正采 + 看板 + 推送 |
| 16:30 | `scripts/pdd_stars_retry.py` | 看门狗：今天**没有**数据才补跑 |
| 19:00 | 同上 | 再补一次 |

看门狗的关键：**今天已有数据 → 什么都不输出 → 定时任务不推任何消息**（安静）；真缺数据才跑并推送，文案标「（补采）」。
入口必须放在 `~/.hermes/scripts/`（cron 的 `script` 只认那里的文件名），真脚本留在项目目录。
⚠️ 工作区迁移时**必须同步改这两个入口里的 `TARGET/MAIN` 路径**，否则定时任务当天就失败。

## 推送文案（微信 iLink 不渲染换行 → 多条单行短消息）
例：1 条标题 + 1 条星级明细 + 1~2 条环比/分商品。
`'⭐ ' + '｜'.join('%s星 %s' % …) + …` 用 `｜` 连接，不依赖换行。
失败降级：微信 → QQ；两条都失败也不要静默丢弃。

## 已知脆弱点（交付时主动告诉用户）
- 登录态过期（拼多多隔几天到几周掉一次）→ 告警；16:30/19:00 会补跑。
- 弹验证码 → **不破解**，立即停 + 告警，等人工。
- 电脑关机/休眠 → 14:00 跑空 → 告警 + 补跑。
- 近90天是**滚动窗口**：DSR 变化 = 新评价进来 − 旧评价滑出，不等于「今天新增」。

## 换店铺 / 交给另一台机器（可移植化，2026-09-21 十一要「发给家里 hermes 采集其他店铺」）

把一个跑通的采集作业交给**另一台机器 / 另一个店铺**，靠的是「配置驱动 + 一份安装说明 + 打包」。

### 1. 先把硬编码全部收进 `config.json`（唯一权威）
```json
{ "store": "店铺全名", "window": "近90天", "output": "看板文件名.html",
  "push":    { "weixin": "weixin:<id>", "qq": "qqbot:<id>" },
  "browser": { "port": 9445, "bu_name": "pddstars", "chrome": "C:\\...\\chrome.exe" },
  "products": [ { "id": "996720881635", "note": "" } ] }
```
- 配一个共用 `lib_cfg.py`：`load(BASE, strict=False)` —— **采集用 `strict=True`（配置缺失/损坏直接报错退出）**，出图脚本用默认值兜底（缺配置也能渲染历史数据）。
- `push` / `browser` 允许**留空**：`push` 两个都空 = 不推送（另一台机器要填自己的目标，别把消息发到原来那个人手机上）；`send()` 里先 `[(t,n) for t,n in ((WX,'微信'),(QQ,'QQ')) if t]`，空就返回「未配置推送」而不是报错。
- 每次 `products` 加减 → 看板卡片数 / 趋势线数 / 推送商品段**全自动跟着变**，这是配置驱动最值的部分。

### 2. 打包清单（zip 里放什么、放到哪）
```
<名称>_技能包_<日期>/
  skill/<技能名>/SKILL.md + references/     → <Hermes>\skills\<分类>\
  脚本/                                    → <工作区>\项目：xxx\脚本\
  定时任务入口/                             → <Hermes>\scripts\（⚠️ 要改里面的路径）
  安装说明.md                               ← 5 步装法 + 换店铺 + 自检清单 + 已知坑
  config.template.json                      ← 改名 config.json 放项目根
```
- **`安装说明.md` 里必须写**：部署前提（Windows/Chrome/电脑 14:00 不能休眠/登录态会过期需人工扫码/验证码不破解）、**换店铺只改哪 4 项**、以及**自检清单**（含「故意把 store 改错，必须被拦下」这条）。
- 打包后**实测一次**：解压无损（`zipfile.testzip()`）+ 中文文件名正常 + 包内脚本 `py_compile` 通过。exe/zip 这类要交付的东西，**没验过解压就不算做完**。

### 3. 同一台机器要采多家店
建**两个项目目录**（各自一份 `config.json` + 一份 profile = 一个登录态），并把 `browser.port` / `browser.bu_name` 改成不同的 —— 一个调试端口只能被一个 Chrome 占用。

### 4. 给用户的定心丸（也说给自己听）
**忘了改 `store` 不会静默采错** —— 采集前的主体核对会拦住（页面店铺 ≠ 配置）。可移植化以后，最危险的那类错误变成了一个 1 秒内的硬失败。
