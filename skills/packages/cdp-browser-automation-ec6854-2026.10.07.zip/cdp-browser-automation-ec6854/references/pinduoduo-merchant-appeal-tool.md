# Pinduoduo merchant appeal/review automation tool

Reference for the `cdp-browser-automation` umbrella: concrete architecture + verified flows + gotcha list for an Electron tool that auto-processes Pinduoduo merchant "negative experience" appeals and reconsiderations via an embedded browser.

## Architecture (Electron + CDP, single-tab embedded browser)
- Launch .bat real name: **`【蒙倩】--订单申诉复议工作台.bat`** (NOT `启动工作台.bat`); it clears `ELECTRON_RUN_AS_NODE=` and runs `node_modules\electron\dist\electron.exe .` with `--disable-gpu` flags.
- Port: app exposes `remote-debugging-port=9334`; automation connects to **9334** (the embedded browser), NOT a standalone Chrome.
- Partition: `Session.Partition = 'persist:appeal_tool_01'` shared across all browser windows for one login session.
- `browserWin` = frameless `BrowserWindow` (`frame:false, skipTaskbar:true, parent:mainWindow`, positioned at the main window's right ~x:484) = the "embedded" browser. WebContentsView was unusable (ERR_FAILED).
- Load placeholder `data:` html first, then real URL on `did-finish-load`.
- `setWindowOpenHandler` → in-place `loadURL` so SPA "new tabs" navigate in the same window; automation is single-tab (`closeTabsByUrl` is a no-op).
- Windows: `mainWindow` (width 1560), `browserWin`, `loginWindow`.

## Runtime files
- `src/main.js` — windows, CDP port, IPC (config/run/pause/stop, store, license:activate, browser:show), spawn automation + forward logs, taskbar flash, fitBrowserZoom, syncBrowserWinPosition, flowForceBrowserRepaint, license (getMachineCode/makeAuthCode/isLicensed/showLicenseWindow), single-instance lock, command-watcher.
- `src/preload.js` — `exposeInMainWorld('appealApi', {...})` (browser ctrl, appeal/review config+run+pause+stop, store*, licenseActivate, onLog/onStatus).
- `renderer/` — index.html + app.js + styles.css (two pages: 订单申诉, 复议处理; store dropdown panel, top run bar, config panel, log box 420px).
- `data/cdp-driver.js` — connectTo(pattern), CDPClient (call/eval/typeInto/uploadFiles/clickByText/clickByExpr/waitText), CDP_PORT=9334.
- `data/cdp-run-full.js` (申诉), `data/cdp-run-review.js` (复议).
- `data/appeal-config/` + `data/review-config/` (independent config + evidence). `data/stores/stores.json`, `data/license.dat`, `data/runs/`.

## Support helper (critical)
```js
async function jsClickByText(client, text) {
  const ok = await client.eval(`(() => {
    const n=[...document.querySelectorAll('a,button,span,div')].filter(el=>(el.innerText||el.textContent||'').trim()===${JSON.stringify(text)}&&el.offsetWidth>0&&el.offsetHeight>0);
    if(!n.length) return false; n.sort((a,b)=>a.children.length-b.children.length); n[0].click(); return true;
  })()`).catch(()=>false);
  return !!ok;
}
```
USE it for: 查看详情, 我要申诉, 提交, 确认并提交, 发起复议, 提交复议, 账号登录, 登录.

## Verified flows
**申诉 (appeal)** — connectTo list (`customer_complain_appeal?from=list`) → 查看可申诉订单/查询 → 查看详情(JS) → connectTo `detail?ticketSn=` + waitHumanVerification → 我要申诉(JS) opens in-page modal → pick reason (default 其他; disambiguate from same dropdown as 商品无问题) → fill textarea (appears after reason) → uploadFiles(-1, evidence) → 提交(JS) → verification check → 确认并提交(JS) → success judged ONLY after verification ruled out.

**复议 (reconsideration)** — connectTo `orders/appeals` → click 去复议 (SPA new page, must reuse loaded tab, do NOT close) → waitHumanVerification → 发起复议(JS) → modal: reason dropdown (4 + 其他) → (field expands after reason) fill description → upload → 提交复议(JS) → verification → confirm → success-after-verify.
- **Platform rule: reconsideration evidence must DIFFER from the appeal evidence** → enforce via split config (`appeal-config/` vs `review-config/`); reusing the appeal evidence gets blocked ("请补充与首次申诉不同的有效凭证").

## Verified captcha handling
- Multi-path detect: body+documentElement text; iframe src/name/title (captcha|verify|geetest|yidun|slider|tou|security|pccaptcha|验证); visible div/span class/id (captcha|geetest|yidun|verify|slider|安全验证|验证码|tou-pin|移动滑块).
- Keywords: 验证码|安全验证|拖动滑块|拖动下方滑块|请完成验证|人机验证|安全校验|风险确认|滑块|图形验证|请输入验证码|完成验证|拖动滑块完成拼图|请点击|点击刷新|向右拖动|验证失败.
- On hit: main process `flashFrame(true)` + re-flashes @1.4s/3.2s; do NOT show an in-app banner. Poll 3s up to 5 min; on clear → continue item then next; on timeout → skip item.
- Call waitHumanVerification at: after entering detail/reconsideration page, after submit, and BEFORE judging success.

## Store dropdown + auto-login
- Data stored main-process `data/stores/stores.json`. IPC: store:list/save/import-csv/export-template/pick-csv/login/logout.
- loginStore(account,password): openBrowserWindow(login) → loadURL `mms.pinduoduo.com/login/` (wait ~15s) → click 账号登录 (JS; last visible element with innerText 账号登录) → fill `#usernameId` (placeholder 请输入账号|账号名|手机号) + `#passwordId` (type=password) using the native `HTMLInputElement.prototype.value` setter + dispatch input/change → click 登录 (JS; /^登录$/).

## License binding
- machine code: execSync `reg query "HKLM\SOFTWARE\Microsoft\Cryptography" /v MachineGuid` → SHA-256 → 20 hex chars formatted `XXXX-XXXX-XXXX-XXXX-XXXX`; fallback hostname|arch|cpu.model. (Put in a `.js` file — inline `node -e` backslashes get mangled by the shell.)
- auth code: `HMAC-SHA256(secret, machineCode.toUpperCase())` → 20 hex `XXXXX-XXXXX-XXXXX-XXXXX`. Keep `gen-license.js` (same secret) private; exclude from user package. Set your OWN secret, not a documented constant.
- license.dat = `machine|auth`. Gate: `if (skipAuth || isLicensed()) openMain(); else showLicenseWindow()`. `--smoke-test`/`--no-auth` bypass.

## Verified gotcha list (reproduces cleanly)
1. WebContentsView ERR_FAILED → independent frameless BrowserWindow.
2. First remote loadURL ERR_FAILED → data: placeholder first, then real URL on did-finish-load.
3. Coordinate click doesn't fire nav/submit → JS `el.click()`.
4. Direct URL to reconsideration SPA → "发起复议" won't open modal → must go via 去复议 + reuse loaded tab.
5. "其他" dropdown ambiguous → pick the one sharing a container with 商品无问题.
6. Field expands only after selecting reason → wait + retry.
7. Review evidence must differ from appeal → split config.
8. "已受理" false positive under pending captcha/confirm → re-click 确认并提交 + judge success after verification.
9. Captcha in iframe not in innerText → multi-path detection.
10. "No 5-min wait / repeated invalid clicks" = detection missing the verification → robust detection + call points after page enter / submit / before success.
11. No taskbar flash → main-process grep of the marker → flashFrame + re-flash; no in-app banner (user preference).
12. Black window after minimize→restore (--disable-gpu) → real bounds nudge + invalidate + resize + re-apply zoom on restore/focus/show.
13. Removing zoom hides form fields (responsive) → keep fitBrowserZoom.
14. ELECTRON_RUN_AS_NODE must be empty.
15. Orphan `initStore()`/dead store module → delete.
16. Duplicate IPC handler ("Attempted to register a second handler for 'store:login'") → de-dupe across file.
17. Duplicate buttons / confirm-modal blocking the start → top bar is the single entry; start buttons launch directly.
18. Smoke test drifts on refactor → `pages>=2`, opPanel=`#appealStartTop`, `--smoke-test` skips auth.
19. .bat Chinese 乱码 → GBK + `chcp 936` + CRLF.
20. CSV import BOM first row → strip `\uFEFF`; header must contain 店铺名称/账号/密码.
21. React controlled inputs → native setter + dispatch input/change.
22. JS-click refactor `appeal.ok`→boolean → update post-loop checks, avoid duplicate `const w`.
23. clientWidth too small for zoom → use `getContentBounds().width`.
24. Port 9333→9334; `closeTabsByUrl` no-op; 打开商家后台 auto-opens browserWin.
25. Auth smoke/CI → `--no-auth`/`--smoke-test`; license.dat = `machine|auth`.
