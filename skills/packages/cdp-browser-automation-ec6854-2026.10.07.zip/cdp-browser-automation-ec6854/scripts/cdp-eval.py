#!/usr/bin/env python3
"""Reusable CDP evaluator for a browser launched with `--remote-debugging-port`.

Async `websockets` (NOT `websocket-client`; that module is usually absent on
this host and is the sync variant). Connects the WS, sends Runtime.evaluate
with returnByValue + awaitPromise, prints the JSON result.

Usage:
    python cdp-eval.py <port> '<js_expr>'
    python cdp-eval.py 9333 "document.title"
    python cdp-eval.py 9333 "document.body.innerText.slice(0,2000)"

Notes:
  * Use `( () => {...} )()` for multi-statement bodies; a bare `()=>{}` returns
    the function uncalled.
  * Fire-and-forget a long async flow with `void fn()` and do NOT awaitPromise.
  * A non-empty isolated `--user-data-dir` is what lets the port open WITHOUT
    the Chromium "Allow remote debugging" auth prompt (see SKILL.md).
"""
import asyncio, json, sys, urllib.request

async def main():
    port = sys.argv[1]
    expr = sys.argv[2]
    data = json.load(urllib.request.urlopen(f"http://127.0.0.1:{port}/json"))
    page = next((t for t in data if t["type"] == "page"), None)
    if page is None:
        print(json.dumps({"error": "no page target"})); return
    import websockets
    async with websockets.connect(page["webSocketDebuggerUrl"]) as ws:
        await ws.send(json.dumps({
            "id": 1,
            "method": "Runtime.evaluate",
            "params": {"expression": expr, "returnByValue": True, "awaitPromise": True},
        }))
        while True:
            r = json.loads(await ws.recv())
            if r.get("id") == 1:
                if "exceptionDetails" in r.get("result", {}):
                    print(json.dumps({"exception": r["result"]["exceptionDetails"]}))
                else:
                    print(json.dumps(r["result"]["result"].get("value")))
                break

asyncio.run(main())
