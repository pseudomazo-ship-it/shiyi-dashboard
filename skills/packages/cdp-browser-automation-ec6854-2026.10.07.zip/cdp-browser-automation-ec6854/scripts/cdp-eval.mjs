// CDP evaluate helper for driving/inspecting a running Electron/Chromium app.
// Usage: node cdp-eval.mjs <webSocketDebuggerUrl> '<expression>'
// (Node >= 22 has a global WebSocket. Get the WS URL from curl -s http://127.0.0.1:<port>/json on the target whose url/title you want.)
// Evaluates the expression with {returnByValue:true, awaitPromise:true, userGesture:true} and prints the JSON result.
// To FIRE-AND-FORGET a long async workflow, pass `void fn()` as the expression — it starts and returns immediately.
const [wsUrl, expression] = process.argv.slice(2);
if (!wsUrl || !expression) { console.error('usage: node cdp-eval.mjs <wsUrl> <expression>'); process.exit(1); }

const ws = new WebSocket(wsUrl);
let nextId = 1;
const pending = new Map();
const send = (method, params = {}) => new Promise((resolve, reject) => {
  const id = nextId++;
  pending.set(id, { resolve, reject });
  ws.send(JSON.stringify({ id, method, params }));
});

ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.error) reject(new Error(JSON.stringify(msg.error)));
    else resolve(msg.result);
  }
};

ws.onopen = async () => {
  try {
    await send('Runtime.enable');
    const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
    console.log(JSON.stringify(r.result, null, 2));
  } catch (e) {
    console.error('CDP_ERROR', e.message);
  } finally {
    ws.close();
    setTimeout(() => process.exit(0), 200);
  }
};
ws.onerror = (e) => { console.error('WS_ERROR', e.message || e); process.exit(1); };
