'use strict';
/**
 * cdp_shot.mjs — 按端口 + URL 子串 抓取 CDP page target 的截图。
 * 用途：给已登录的商家后台页面（如 PDD mms.pinduoduo.com）截图，用于确认登录态/面板内容。
 *
 * 用法：node cdp_shot.mjs <port> <out.png> [url_substr]
 *   例：node cdp_shot.mjs 9555 E:\\RuanJian\\Hermes\\cache\\pdd_home.png 'mms.pinduoduo.com'
 *
 * 关键：本机用 Node + undici WebSocket 抓 Page.captureScreenshot 最稳；Python async websockets
 *       在该连接上会挂起（300s 无返回），不要用它替代。
 * 选 target：优先匹配 url 含 url_substr 且不含 '/login' 的 page（登录态页面）；
 *           匹配不到就退回第一个 page。多特征页场景绝不按 pages[0] 一刀切。
 *
 * 依赖：undici（在已有 node_modules/undici 的目录下运行，或 `npm i undici`）。
 * 找端口：for p in 9222 9333 9444 9555; do curl -s --max-time 2 http://127.0.0.1:$p/json/version; done
 */

// ⚠️ 本文件是 .mjs（ESM）——**不能用 require**，否则 `node cdp_shot.mjs` 直接报
//    `ReferenceError: require is not defined in ES module scope`。用 import。
import http from 'node:http';
import fs from 'node:fs';
import { WebSocket } from 'undici';

const [, , port, out, sub] = process.argv;
if (!port || !out) {
  console.log('用法: node cdp_shot.mjs <port> <out.png> [url_substr]');
  process.exit(2);
}

function getTabs() {
  return new Promise((res, rej) => {
    http
      .get(`http://127.0.0.1:${port}/json/list`, (r) => {
        let b = '';
        r.on('data', (c) => (b += c));
        r.on('end', () => {
          try {
            res(JSON.parse(b));
          } catch (e) {
            rej(new Error(`/json/list 返回的不是 JSON: ${b.slice(0, 120)}`));
          }
        });
      })
      .on('error', rej);
  });
}

const tabs = await getTabs().catch((e) => {
  console.error(`❌ 连不上 127.0.0.1:${port} 的 CDP：${e.message}`);
  console.error(`   先确认端口在监听：curl -s http://127.0.0.1:${port}/json/version`);
  console.error('   若 Chrome 136+ 返回 404，改用 DevToolsActivePort 里的 browser-level WS（见 SKILL.md）。');
  process.exit(1);
});

const pages = tabs.filter((t) => t.type === 'page');
if (!pages.length) {
  console.error('该端口没有任何 page target');
  process.exit(1);
}
pages.forEach((p, i) => console.log(i, '|', (p.title || '').slice(0, 24), '|', (p.url || '').slice(0, 74)));

let target = null;
if (sub) {
  // 优先：含子串的主页/工作台，且排除登录页
  target = pages.find((p) => p.url.includes(sub) && !p.url.includes('/login'));
  if (!target) target = pages.find((p) => p.url.includes(sub));
}
if (!target) target = pages[0];
console.log('目标:', (target.url || '').slice(0, 90));

await new Promise((resolve, reject) => {
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  const to = setTimeout(() => reject(new Error('连接 CDP 超时（12s）')), 12000);
  ws.onopen = () => {
    clearTimeout(to);
    ws.send(JSON.stringify({ id: 1, method: 'Page.captureScreenshot', params: { format: 'png' } }));
  };
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.id !== 1) return;
    if (m.error) {
      ws.close();
      reject(new Error(`captureScreenshot 失败: ${m.error.message}`));
      return;
    }
    fs.writeFileSync(out, Buffer.from(m.result.data, 'base64'));
    console.log('已存:', out, '字节:', fs.statSync(out).size);
    ws.close();
    resolve();
  };
  ws.onerror = (e) => reject(new Error(`ws错误: ${e?.message || e?.type || 'unknown'}`));
}).catch((e) => {
  console.error(`❌ ${e.message}`);
  process.exit(1);
});
