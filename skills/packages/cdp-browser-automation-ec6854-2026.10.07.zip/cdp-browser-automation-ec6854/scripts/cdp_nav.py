#!/usr/bin/env python3
"""Connect to a CDP port, navigate the FIRST matching page target, wait, then evaluate an expression.

Usage:
    python cdp_nav.py <port> <navigate_url> <expr> <wait_sec> [tab_match_substr]

* <port>            -- remote-debugging-port of the browser.
* <navigate_url>    -- URL to navigate the chosen tab to (or pass '' to just read without navigating).
* <expr>            -- JS expression to Runtime.evaluate after the wait (print value).
* <wait_sec>        -- seconds to wait after navigation for the SPA to settle (e.g. 4).
* [tab_match_substr]-- OPTIONAL: only drive the page whose URL CONTAINS this substring.
                       REQUIRED when the port hosts MULTIPLE feature pages (PDD backoffice holds
                       售后列表/差评申诉/商品列表 etc. as separate targets) — pick by URL, never
                       by pages[0]. If omitted it uses the first `page` target (fine for single-page).

Why this exists: cdp-eval.py only evaluates, and a shared merchant session exposes several
`page` targets on one port, so navigating + reading needs explicit tab selection to avoid
connecting to the wrong feature (e.g. .../appeals/NegativeExperienceDetail... instead of aftersale_list).
"""
import asyncio, json, sys, urllib.request

async def main():
    port, nav_url, expr = sys.argv[1], sys.argv[2], sys.argv[3]
    wait = float(sys.argv[4]) if len(sys.argv) > 4 else 3.0
    match = sys.argv[5] if len(sys.argv) > 5 else ""

    data = json.load(urllib.request.urlopen(f"http://127.0.0.1:{port}/json"))
    pages = [t for t in data if t["type"] == "page"]
    if match:
        pages = [t for t in pages if match in (t.get("url") or "")]
    if not pages:
        print(json.dumps({"error": "no matching page", "all": [p.get("url") for p in data if p["type"] == "page"]}))
        return
    ws_url = pages[0]["webSocketDebuggerUrl"]
    print("TARGET URL:", pages[0].get("url"))

    import websockets
    async with websockets.connect(ws_url, open_timeout=10) as ws:
        mid = 0
        async def send(method, params):
            nonlocal mid
            mid += 1
            await ws.send(json.dumps({"id": mid, "method": method, "params": params}))
            while True:
                r = json.loads(await ws.recv())
                if r.get("id") == mid:
                    return r
        if nav_url:
            await send("Page.navigate", {"url": nav_url})
            await asyncio.sleep(wait)
        # confirm where we actually landed before trusting the read
        got = await send("Runtime.evaluate", {"expression": "location.href", "returnByValue": True})
        print("LANDED_URL:", got.get("result", {}).get("result", {}).get("value"))
        r = await send("Runtime.evaluate", {"expression": expr, "returnByValue": True})
        if "exceptionDetails" in r.get("result", {}):
            print(json.dumps({"exception": r["result"]["exceptionDetails"]}))
        else:
            print(json.dumps(r["result"]["result"].get("value")))

asyncio.run(main())
