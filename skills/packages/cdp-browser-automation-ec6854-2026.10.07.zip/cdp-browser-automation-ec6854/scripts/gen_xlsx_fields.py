# -*- coding: utf-8 -*-
"""采集结果 → Excel（字段可裁剪版 / 全字段版通用）

比 gen_xlsx.py 多一个「字段清单」参数：只出你要的列，并自动生成「异常备注」标红缺失项。

用法:
  uv run --with openpyxl python gen_xlsx_fields.py <标题json> <属性json> "<店铺名>" <输出目录> ["字段1,字段2,..."]

  标题json : {goods_id: 商品标题}        （列表页 DOM 里 "ID: xxx" 的上一行）
  属性json : [{"goods_id":..,"props":{属性名:值}}, ...]
  字段csv  : 可选，逗号分隔。不传 = 输出全部 20 个属性字段。
             十一的默认口径:"产品名称,化妆品批准文号,注册人/备案人名称"（前面自动带 商品ID/商品标题）

输出:
  <输出目录>/<店铺名>_商品属性采集_YYYY.MM.DD.xlsx
  冻结「商品ID+标题」两列 + 表头行，带筛选器，异常备注列标红。

异常备注对「化妆品批准文号」做了区分（避免把"本就不适用"误报成"漏填"）:
  是否为特殊用途化妆品=否 → "非特殊用途化妆品，无批准文号"（正常）
  是否为特殊用途化妆品=是 → "⚠️特殊用途化妆品但未填批准文号"（真风险，重点盯）
"""
import json, sys, os, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from collections import Counter

DEFAULT_ATTRS = ["品牌", "产品名称", "产品类型", "规格类型", "功能", "功效成分",
                 "适用发质", "适用人群", "是否孕妇可用", "是否为特殊用途化妆品",
                 "化妆品批准文号", "注册人/备案人名称", "注册人/备案人地址",
                 "生产企业名称", "生产企业地址", "生产企业生产许可证号",
                 "产地", "生产日期", "保质期", "包装方式"]

title_path, props_path, shop, out_dir = sys.argv[1:5]
ATTRS = [f.strip() for f in sys.argv[5].split(",") if f.strip()] if len(sys.argv) > 5 else list(DEFAULT_ATTRS)
tmap = json.load(open(title_path, encoding="utf-8"))
props = json.load(open(props_path, encoding="utf-8"))
P = {str(d["goods_id"]): (d.get("props") or {}) for d in props}

HEAD = ["商品ID", "商品标题"] + ATTRS + ["异常备注"]
wb = Workbook(); ws = wb.active; ws.title = "商品属性"
hfill = PatternFill("solid", fgColor="1F4E79")
hfont = Font(color="FFFFFF", bold=True, size=10)
red = Font(color="C00000", size=10)
thin = Side(style="thin", color="D9D9D9")
bd = Border(left=thin, right=thin, top=thin, bottom=thin)

ws.append(HEAD)
for c in range(1, len(HEAD) + 1):
    cell = ws.cell(row=1, column=c)
    cell.fill = hfill; cell.font = hfont
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = bd

stat = Counter()
r = 2
for gid, title in tmap.items():
    p = P.get(str(gid), {})
    vals = {a: str(p.get(a, "") or "").strip() for a in ATTRS}
    parts = []
    if "化妆品批准文号" in ATTRS and not vals["化妆品批准文号"]:
        sp = str(p.get("是否为特殊用途化妆品", "") or "").strip()
        if sp == "否":
            parts.append("非特殊用途化妆品，无批准文号")
        elif sp == "是":
            parts.append("⚠️特殊用途化妆品但未填批准文号"); stat["risk_ap"] += 1
        else:
            parts.append("未填批准文号")
    for a in ATTRS:
        if a == "化妆品批准文号":
            continue
        if not vals[a]:
            parts.append("未填" + a); stat["miss_" + a] += 1
    note = "；".join(parts)
    ws.append([gid, title] + [vals[a] for a in ATTRS] + [note])
    for c in range(1, len(HEAD) + 1):
        cell = ws.cell(row=r, column=c)
        cell.border = bd; cell.font = Font(size=10)
    if parts:
        ws.cell(row=r, column=len(HEAD)).font = red
    r += 1

widths = [16, 46] + [max(12, min(28, len(a) * 2 + 6)) for a in ATTRS] + [30]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = "C2"
ws.auto_filter.ref = "A1:%s%d" % (get_column_letter(len(HEAD)), r - 1)

os.makedirs(out_dir, exist_ok=True)
date = datetime.datetime.now().strftime("%Y.%m.%d")
out = os.path.join(out_dir, "%s_商品属性采集_%s.xlsx" % (shop, date))
wb.save(out)
print("商品数:", r - 2, "| 字段数:", len(ATTRS))
print("字段:", "、".join(ATTRS))
print("异常统计:", dict(stat))
print("saved:", out, os.path.getsize(out), "bytes")
