#!/usr/bin/env python
"""核对页面上传的配图 与 本地文件 是否真的逐槽对位（像素级）。

为什么需要它："30 张全传上了 + URL 互不相同" 只能证明没有重复/丢失，
**证明不了某张图传到了对的槽位**。本脚本给出决定性证据。

用法（PIL 不在 hermes venv 里，必须用 uv）：
    uv run --with pillow python verify_uploaded_image_mapping.py <thumbs.json> <本地文件夹> [正则]

<thumbs.json> = 从页面导出的 [{slotKey, url}]，例如：
    ev("""JSON.stringify([...sr.querySelectorAll('.goods-attr-item')][0]
        .querySelectorAll('.attr-value')).map(...)""")   -> [{"v": "<页面上的规格值>", "url": "<img.src 完整带 token>"}]

[正则] 默认 r'^SKU\\d+_(.+?)_' ，用 group(1) 当本地 key，与记录的 slotKey 精确比对。
     （官方3 那套用 r'^SKU\\d+_(.+?)_蒙倩染发膏'）

判定标准：
    diff(页面图, 它自己那个文件) ≈ 0  且  diff(页面图, 最像的别人) >> 0
并同时打印“本地图两两差异”作为基准（实测 71~209），用于判断区分度够不够。
"""
import io
import json
import os
import re
import sys
import urllib.request

from PIL import Image


N = 24  # 缩放尺寸；24 已经足够区分（实测自己=0.0 / 最像的别人≥71）


def sig(src, n=N):
    im = Image.open(src).convert("RGB")
    im.thumbnail((n, n))
    canvas = Image.new("RGB", (n, n), (255, 255, 255))
    canvas.paste(im, ((n - im.width) // 2, (n - im.height) // 2))
    return list(canvas.getdata())


def diff(a, b):
    return sum(abs(p[0] - q[0]) + abs(p[1] - q[1]) + abs(p[2] - q[2]) for p, q in zip(a, b)) / len(a)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    thumbs_path, folder = sys.argv[1], sys.argv[2]
    pattern = sys.argv[3] if len(sys.argv) > 3 else r"^SKU\d+_(.+?)_"
    rx = re.compile(pattern)

    thumbs = json.load(open(thumbs_path, encoding="utf-8"))
    local = {}
    for f in os.listdir(folder):
        m = rx.match(f)
        if m:
            local.setdefault(m.group(1).strip(), os.path.join(folder, f))
    print(f"本地可对应图片 {len(local)} 张；页面记录 {len(thumbs)} 条")

    sigs = {k: sig(p) for k, p in local.items()}
    keys = list(sigs)
    pairwise = [diff(sigs[keys[i]], sigs[keys[j]]) for i in range(len(keys)) for j in range(i + 1, len(keys))]
    if pairwise:
        print(f"本地图两两差异基准：最小 {min(pairwise):.1f}  最大 {max(pairwise):.1f}")
        if min(pairwise) < 5:
            print("⚠️ 有本地图几乎完全相同 → 本方法对它无区分度，需人工看")

    bad, checked = [], 0
    for t in thumbs:
        key, url = t.get("v") or t.get("slotKey"), t.get("url")
        if key not in sigs:
            print(f"⬜ 页面上有、本地找不到对应图：{str(key)[:24]}")
            continue
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            page_sig = sig(io.BytesIO(urllib.request.urlopen(req, timeout=30).read()))
        except Exception as exc:  # 下载失败不算对错，只报告
            print(f"⬜ {str(key)[:24]} 缩略图下载失败：{exc}")
            continue
        own = diff(page_sig, sigs[key])
        closest, closest_key = min((diff(page_sig, s), k) for k, s in sigs.items() if k != key)
        ok = own < closest
        checked += 1
        if not ok:
            bad.append(key)
        print(f"{'✅' if ok else '❌'} {str(key)[:26]:<28} 自己={own:6.1f} 最像的别人={closest:6.1f} ({str(closest_key)[:10]})")

    print(f"\n串位的：{len(bad)} 个 / 已核对 {checked} 个")
    if bad:
        print("可疑槽位：" + ", ".join(str(b)[:24] for b in bad))
    return 0


if __name__ == "__main__":
    sys.exit(main())
