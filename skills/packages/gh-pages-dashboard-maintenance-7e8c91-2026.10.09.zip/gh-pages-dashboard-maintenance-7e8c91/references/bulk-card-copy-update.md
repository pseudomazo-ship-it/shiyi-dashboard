# 批量补技能卡片简介（一次几十个）

**触发**：十一说「卡片简介以后都用中文，内容稍微详细一些」/「要中文简介」，
或自动同步推送（`shiyi11.com.cn/skills/`）后面接一句范围选择。
2026-10-08 先做过 5 个；**2026-10-09 一次做 26 个自用业务技能**（本节主要是那次）。

---

## 0. 先确认范围 —— 压成一题 A/B/C，他会秒答

179 个 Hermes 技能里绝大部分是第三方通用技能（GitHub / Apple / mlops 那类），
**不要一声不响地全改**。2026-10-09 的问法（他直接回「A」）：

```
A. 只补你自用的业务技能（26 个）
B. 全部 179 个 Hermes 技能都补到 ≤80 字
C. 先不补，以后新同步的按规则来就行
```

⚠️ **多题表单他会放着不回**（历史上抛过 5 题 clarify，他回传全空）。要决策就压成一题带选项。

### 怎么捞候选 —— 按中文占比筛，别按英文关键词筛

```python
cjk = lambda s: len(re.findall(r'[\u4e00-\u9fff]', s or ''))
short = [i for i in items if i['agent'] == 'Hermes' and cjk(i['description']) < 25]
```

⚠️ **「中文偏短」≠「英文原文」**：那 26 个**本来就都是中文**，只是 18~35 字的短句。
真正是英文原文的只有 1 个（`workspace-to-ima-archive`，`Use when 要把工作区/多Agent 的 md …`）。
—— 所以别一上来就批量替换 `Use when`，先按中文占比看一眼真实分布。

> 判断哪些技能是「他自己的业务技能」：按名字关键词取（租 `pdd-` / `feishu-` / `linghangyuan` /
> `overtime` / `huosun` / `kuaidi` / `logistics` / `express` / `goods` / `shipment` / `tanyu` /
> `dewu` / `dianpu` / `related-entity` / `cosmetic` / `combo-sku` / `store-` / `subject` /
> `shiyi` / `wechat-shop` / `console-api` / `ecommerce` / `daily-report` 等）。

---

## 1. 写一个一次性脚本刷四个地方（别逐条 patch）

数据源只有一个：脚本里的 `NEW = {name: (卡片简介, 详情补充句)}`。

| 产物 | 改法 |
|---|---|
| `数据--技能看板\desc_*.py`（卡片）+ `detail_*.py`（详情）| **正则替换源文件**，保持单一数据源 |
| `Codex…\skill_manager\skills_data.json` | 按 `name` + `agent == 'Hermes'` 改两个字段 |
| `Codex…\skill_manager\skills.html`（开发版）| **只搬字段**，别整份覆盖 |
| `cache/shiyi-dashboard-git/skills/index.html`（发布版）| **只搬字段**，别整份覆盖 |

两个正则（都实测过）：
```python
pat_desc   = re.compile(r'("%s":\s*\()"[^"]*"(\s*,\s*")[^"]*(")' % re.escape(name))
pat_detail = re.compile(r'("%s":\s*\n)(?:\s*"[^"]*"\n)+' % re.escape(name))
```
- `desc_*.py` 形态：`"name": ("卡片", "场景标签"),`
- `detail_*.py` 形态：`"name":\n   "行1"\n   "行2",`（多行相邻字符串拼接）
- **详情字段写 `卡片 + "\n" + 补充句`** —— 页面上两者分开看：卡片只 4 行，详情放开写。

⚠️ 源文件里**新技能要先自行加进去**（本次 `workspace-to-ima-archive` 在 desc/detail 里压根没有，是现加的），
否则正则一条都匹配不上、而脚本不会报错。加完**清 `__pycache__`** 再跑。

---

## 2. 落盘前逐条量字数（唯一硬指标）

```python
bad = [n for n, (d, _) in NEW.items() if len(d) > 80]
assert not bad, bad
```

⚠️ 本次第一轮 26 条里有 **4 条超标（88 / 81 / 83 / 87）** —— 肉眼完全看不出来。
**`len()` 是全角标点也算 1 字的，估不出来，必须量。**

**压字顺序**：先砍「…时用」触发语的修饰 → 再砍括号里的举例/枚举项 → 最后才动口径关键词。
⛔ **别为了压字数把口径/坑点删掉** —— 那正是他要的「详细」；砍掉就变成干瘪的同义反复。

---

## 3. 别被「脚本自己崩」误导（三种都真踩了）

**① 尾部语法错 ≠ 前面的写入失败。**
```python
for path, tag in ((HTMLS[1], "线上版(仓库)")):      # ✗ 少尾逗号
```
→ `ValueError: too many values to unpack`，但它是**最后一个校验循环**才崩的，
而 26 条的写入**全部已完成**。崩了先读 stdout 看到哪一步，落盘成功的部分**别重跑**。

**② 「幽灵条目」不是你的脚本写错了。**
技能目录已删、看板里还留着记录的条目，在 HTML 里不满足 `"name": "X", "description": …` 的标准排布
→ 逐条比对会报「HTML 里没有这个条目」。
- 本次 3 条：`linghangyuan-overtime-judgment`、`overtime-leader-judgment`、`pinduoduo-store-health-analysis`
  （都是被新版覆盖后**没下架的残留**；看板的删除检测有 30% 护栏，几条不触发）。
- **处理**：只把「HTML 里有、但值不对」算失败；「HTML 里找不到」**单列出来告诉他**，
  并说一句「要清就说一声」。⛔ **别自己删** —— 那是 `drop_skill.py` 的活，而且是他的看板数据。

**③ 线上 `urllib` 连续超时。**
改成落盘再读：
```bash
curl -s --noproxy '*' -m 180 -o "$LOCALAPPDATA/Temp/skills_check.html" \
  "https://shiyi11.com.cn/skills/?v=$(date +%s)"
```
比在 python 里 `urllib` 拉 310KB 稳（本次 urllib 连超时两轮，curl 一次成）。

---

## 4. 挑「本轮改过的」用这个小判据

脚本给详情塞了换行，于是：
```python
T = [i for i in items if i['agent'] == 'Hermes'
     and isinstance(i.get('full_description'), str) and '\n' in i['full_description']]
```
比另外维护一份名单省事，也不会把别的窗口改过的条目混进来。

---

## 5. 交付前回读线上，别只看本地断言

- 断言三件：新卡片在位、旧文本清零、**发布版仍有 `password`**（开发版没有，分开断言）。
- ⚠️ 推送报 `schannel: failed to receive handshake, SSL/TLS connection failed` → **原样重试**。
  本次连挂 3 次、第 4 次成功。**别因为这个报错去改 `http.sslBackend` / 换远端 / 重配代理。**
- 推完 `git status -sb` 要是 `## main...origin/main`（无 ahead）。

---

## 6. 回报口径

给他：**改了多少条 + 抽查 2~3 条全文 + 线上验证结果 + 幽灵条目那件事**。
⛔ **不要把 26 条全贴** —— 微信单条上限 2000 字符，会被拆成好几条发，
他会问「**你怎么给发我消息是分段的**」（用户体感是“分成了好几段”，不是“格式乱”）。

> 单条重试、分段机制的逐字规则在 `im-output-formatting` 技能；这里是交付视角的摘要。
