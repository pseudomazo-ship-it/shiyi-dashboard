# 外部 Skill 商店榜单 → 搬进自己的看板（CocoLoop 实做 2026-10-09）

场景：十一说「**这个页面内每个板块内的前3页的技能采集到我的 Agent Skills 管理台域名网页内**」
→ 把第三方 Skill 商店的榜单**只读展示**在自己的技能台（`/skills/`）里，供浏览/评估，**不安装**。

目标站：<https://hub.cocoloop.cn/popular>

---

## 一、站点结构（先说清，不然后面全白干）

- 是 **SPA（Next.js）**：**点分类/翻页都不改 URL**（`location.href` 始终 `/popular`）
  → **不能用 `goto_url` 直接跳页**，只能**在页面里点**。
- 顶部 10 个分类是 `<button>`（不是 `<a>`），文字即分类名：
  `总排行 / 近期最热 / 最新上传 / AI 增强 / 办公 / 效率 / 开发 / 设计 / 内容创作 / 专业技能`
- **每页 15 个卡片**；分页条是数字按钮（`BUTTON:1 | 2 | 3 | … | 74`）+ 一个 **`›`** 下一页按钮。
  → 「前 3 页」= 点 2 次 `›`，共 45 条/分类（个别分类会多 1 条，正常）。
- 卡片容器 class 前缀 `Card_card`（CSS Modules 会带 hash），字段：

| 字段 | 选择器 | 说明 |
|---|---|---|
| 英文名 | `[class*=titleEn]` | 卡片主名（判重用这个）|
| 中文名 | `[class*=titleCn__]` | ⚠️ 注意带双下划线，`titleCnRow` 是外框 |
| 一句简介 | `[class*=Card_desc]` | |
| 安全等级 | `[class*=BSSBadge_level]` | `S+ / S / A / B / C / D` |
| 两个数字 | `[class*=Card_stat]` 的**直接文本子节点** | ①**安装量** ②**热度** |
| 链接 | 卡片自身或内部 `a[href]` | 形如 `/skills/15506`，也有外链（如 PixPix 指到站外）|

### ⚠️ 两个数字的提取坑
`Card_stat` 里**混着内联 `<svg>`**（下载/热度图标），直接 `textContent` 会拼出乱码、
还会把**等级字母**也带进来（`S`→`["S","S","80k","10k"]`）。正确做法：**遍历 childNodes、跳过 svg**，
再**只留含数字的项**：

```js
const nums = Array.from(c.querySelectorAll('[class*=Card_stat]')).map(s=>{
  let txt='';
  s.childNodes.forEach(n=>{ if(n.nodeType===3) txt+=n.textContent;
    else if(n.nodeType===1 && n.tagName!=='SVG' && !n.querySelector('svg')) txt+=n.textContent; });
  return txt.trim();
}).filter(x=>/[0-9]/.test(x));       // ⚠️ 必须用「含数字」过滤
// 第一版写成 .filter(x=>!/^[SAB]$/.test(x)) → D 级技能被整行吞掉（grade/installs/heat 全变成 "D"）
```

---

## 二、采集循环（分批跑，跑完追加写 JSON）

⭐ **页数是参数，别写死**：十一先要「前 3 页」（452 条），随后直接说「**扩大到前 10 页**」
→ 100 次翻页。**开工前先确认页数**；分页上限是每分类 **74 页**，所以「前 10 页」很安全。
⚠️ **10 页时每分类约 40 秒**（9 次翻页 × 3.5s + 切分类 4s）→ **每批只跑 2~3 个分类**，
每批结束就 `json.dump` 落盘（脚本随时可重入、中断了接着跑）。5 个分类一批会顶到超时上限。

```python
EXTRACT = '''(()=>{ ...上面的提取逻辑... })()'''      # 返回数组
CATS = ['办公','内容创作','近期最热','最新上传','专业技能']   # 其余 5 个下一批

def click_cat(name):
    return js('''(()=>{const b=Array.from(document.querySelectorAll('button'))
      .find(x=>x.textContent.trim()===%s); if(b){b.click();return 1} return 0})()''' % json.dumps(name))

for cat in CATS:
    click_cat(cat); time.sleep(4)                 # 切分类会重置到第 1 页
    items = []
    PAGES = 10                                     # ← 页数是参数，改这里就行
    for page in range(PAGES):
        for it in (js(EXTRACT) or []):
            if it['en'] and not any(x['en']==it['en'] for x in items):
                items.append(it)                   # 页间去重（同分类内）
        if page < PAGES - 1:
            js('''(()=>{const b=Array.from(document.querySelectorAll('button'))
              .find(x=>x.textContent.trim()==='›'); if(b){b.click();return 1} return 0})()''')
            time.sleep(3.5)
    data[cat] = items
    json.dump(data, open(OUT,'w',encoding='utf-8'), ensure_ascii=False, indent=1)   # 每批都落盘
```

⚠️ **失败方式：`fetch failed` 这种在别的任务里见过的网络抖动** 在这里不会出现 ——
SPA 是纯前端交互，**卡住的表现是「翻页后内容没变」**，所以要**比对翻页前后的标题串**来确认翻页真的生效：
```python
before = js('标题串'); 点›(); sleep(3.5); after = js('标题串'); assert before != after
```

实测产量（两轮都跑过）：

| 页数 | 总量 | 去重后独立技能 | 注入后 HTML |
|---|---|---|---|
| 3 页/分类 | **452 条** | 393 | 454 KB → 586 KB |
| **10 页/分类** | **1501 条** | **1105** | 454 KB → **896 KB** |

⚠️ **数据是内嵌在 HTML 里的**（`const SHOP=[…]`）→ **每打开一次页面就下整包**。
实测 1501 条时：本地加载 **0.4 秒**、切到商店视图渲染 150 张卡 **2.7 秒**（流畅）。
手机流量下 900 KB 会有感知 —— 十一若嫌重，先砍到「只留 S+/S 级」（约 800 条、500 KB）。

等级分布（1501 条）：`S+ 228 / S 572 / A 538 / B 132 / C 9 / D 6 / 未标 16`
→ **S/A 占 90%，门槛不高**；交付时如实说「安装量不等于质量，按等级筛才有区分度」。

榜单之间大量重叠（总排行前 5 里有 3 个是「AI 自我进化/记忆」类同名技能）—— 
**452 → 393、1501 → 1105 的差值就是重叠量**，属于正常，不用去重合并成一条。

---

## 三、注入看板（幂等 + 可重定位）

脚本：`E:\RuanJian\Hermes\cache\cocoloop_inject.py`（读采集 JSON → 生成注入块 → 写两处 HTML）。

**结构**：一个标记块，含 `<style>` + 顶部来源切换 + 商店视图 + 一段 `<script>`
（内含 `const SHOP=[…]` 紧凑 JSON）。

```
<!-- COCOLOOP-BEGIN -->
<style>…</style>
<div class="src-tabs" id="src-tabs">
  <button data-src="local" class="on">本机技能</button>
  <button data-src="shop">商店热门 · 452</button>
</div>
<div id="shop-view" hidden>
  <nav class="category-buttons" id="shop-cats"></nav>
  <div class="section-head"><h2>商店技能</h2><span id="shop-count"></span></div>
  <section class="grid" id="shop-grid"></section>
</div>
<script>…const SHOP=[…]；切分类/搜索/渲染卡片/点卡开原站…</script>
<!-- COCOLOOP-END -->
```

### 注入函数的正确形状 —— **先删后插，不要「找到就替换」**

```python
def inject(path, block, write=True):
    s = io.open(path, encoding='utf-8').read()
    # ① 总是先删掉旧标记块（保证上次插错位置时能被纠正）
    if MARK_BEGIN in s and MARK_END in s:
        a = s.index(MARK_BEGIN); b = s.index(MARK_END) + len(MARK_END)
        s = s[:a] + s[b:]
    # ② 再插到锚点前 —— <main> 内，绝不能是 </header> 之后（sticky 顶栏会盖住）
    key = '<div id="sentinel"'
    i = s.index(key)
    out = s[:i] + block.strip() + '\n' + s[i:]
```

⚠️ 踩过的三件事：
1. 第一版只做「有标记就替换、否则插入」→ **位置插错了就永远改不回来**（脚本跑十次也还在 header 下面）。
2. 必须**同时写两个文件**（Codex 源 `skills.html` 无密码门 + 发布版 `skills/index.html` 有密码门）。
   写前 `cp` 一份备份到 cache。
3. 改完源文件**不能重跑 `skill_sync.py` 去“同步”这个块** —— 它只管 `const skills=[…]`，
   **不搬 UI**。UI 只在源文件里，靠注入脚本各自写两边。

### 验证（本地 + 线上都要，且顺序不能反）

```js
// ① 按钮不再被遮挡（见 SKILL.md 布局坑 7 的 elementsFromPoint 片段）
// ② 分类切换真的换内容（不是只换高亮）
js(`(()=>{const b=Array.from(document.querySelectorAll('#shop-cats button'))
  .find(x=>x.dataset.cat==='开发'); b.click(); return 1})()`)
// 再读 #shop-count 与首张卡 .en —— 变了才算成功
// ③ 搜索能过滤商店技能：#search 触发 input 事件 → 卡片数变少
```

⚠️ **别用「首张卡是否相同」当切换失败的证据**：设计分类的榜首本来就是 PixPix（AI 生图），
和总排行一样 —— 那**不是 bug**。要拿两三个分类互相比较再下结论。

---

## 四、交付话术

- 只报结果：按钮叫什么、几个分类、各多少条、点进去能干什么（含等级/安装量/热度、点卡开原站）。
- **不发链接、不标密码**（十一 2026-10-08 定的交付纪律，唯一例外是 23:55 那条日报推送）。
- ⚠️ **顺手给一条判断**：本次 S/A 级占 90%、总榜前 5 有 3 个是「AI 自我进化/记忆」类同名技能
  → 如实说「**安装量不等于质量，按等级筛才有区分度**」，并重申第三方技能默认不装、要装先过钟馗。
