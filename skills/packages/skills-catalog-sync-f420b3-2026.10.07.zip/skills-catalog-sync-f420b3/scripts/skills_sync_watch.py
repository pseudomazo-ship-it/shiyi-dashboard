# -*- coding: utf-8 -*-
"""skills_sync_watch.py —— 技能自动同步守护（v2：新增 + 更新都同步）

十一 2026-10-07 定（全窗口）：**新生成的 skill 和已存在 skill 的更新，全部第一时间同步到
域名技能管理台** https://shiyi11.com.cn/skills/ ，同步完在微信告知。

本脚本由 cron（job 75c6684105eb，`0 9-23 * * *`，no_agent）每小时调一次：
  · 扫 Hermes / Codex / WorkBuddy 三处技能目录
  · 新技能 → 打包上线
  · 老技能：目录最近动过 → 重新打包算 sha 与看板比对，**只有内容真变了才推**
  · 没有变化 → stdout 空 → 不推送（watchdog 模式，天然不吵）

护栏：
  · 命中业务敏感词的技能不自动推，只在告知里点名「待确认」
  · 目录 10 分钟内还动过的技能先跳过（可能正在编辑），记入 deferred 下轮强制复检
  · 与看板已有技能同名/近同名的目录不自动推（避免重复卡片），首次发现时点名一次
  · 每次动作追加日志 cache/skills_sync_watch.log；状态存 cache/skills_sync_state.json

用法：
  python skills_sync_watch.py              # 正常：发现就同步并推送
  python skills_sync_watch.py --dry-run    # 只报告，不写任何东西
  python skills_sync_watch.py --no-push    # 走完流程但不推线上（本地验证）
  python skills_sync_watch.py --all        # 忽略 mtime 与 grace，全量重比对（慢，排查用）
"""
import argparse
import io
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

SYNC_SCRIPT = Path(r'E:\RuanJian\Hermes\skills\productivity\skills-catalog-sync\scripts\skill_sync.py')
SRC_DATA = Path(r'D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\skills_data.json')
STATE = Path(r'E:\RuanJian\Hermes\cache\skills_sync_state.json')
LOG = Path(r'E:\RuanJian\Hermes\cache\skills_sync_watch.log')
LIVE = 'https://shiyi11.com.cn/skills/'
EDIT_GRACE = 600          # 秒：目录还动过就先不碰

ROOTS = [
    ('Hermes', Path(r'E:\RuanJian\Hermes\skills')),
    ('Codex', Path(r'C:\Users\Administrator\.codex\skills')),
    ('Codex', Path(r'C:\Users\Administrator\.codex\plugins\cache\openai-primary-runtime')),
    ('Codex', Path(r'C:\Users\Administrator\.codex\plugins\cache\openai-curated-remote')),
    ('Codex', Path(r'C:\Users\Administrator\.codex\plugins\cache\openai-bundled')),
    ('WorkBuddy', Path(r'C:\Users\Administrator\.workbuddy\skills')),
]

SKIP_ANY = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', '.idea', '.vscode',
            '.pytest_cache', '.mypy_cache', 'dist', 'build'}

NAME_RE = re.compile(rb'^name:\s*([^\r\n]+)', re.M)
SHA_RE = re.compile(r'SHA-256\s*:\s*([0-9a-f]{64})')


def log(msg):
    line = '[%s] %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg)
    print(line, file=sys.stderr)
    try:
        with io.open(LOG, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass


def load_state():
    try:
        return json.loads(STATE.read_text(encoding='utf-8'))
    except Exception:
        return {}


def save_state(st):
    try:
        STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding='utf-8')
    except Exception:
        pass


def _skip_path(f, root):
    """过滤掉「不是独立技能」的 SKILL.md：太深、隐藏/临时目录、嵌套在别的技能里。"""
    parts = f.relative_to(root).parts
    if len(parts) > 3:                      # 最深只认 <分类>/<技能>/SKILL.md
        return True
    for p in parts[:-1]:
        if p.startswith(('.', '-', '_')):
            return True
    d = f.parent.parent                     # 从技能目录的上一级往上找
    while d != root and d.parent != d:
        if (d / 'SKILL.md').exists():
            return True                     # 父链上还有别的技能 → 是别人的子技能
        d = d.parent
    return False


def collect_skills():
    found = {}
    for agent, root in ROOTS:
        if not root.exists():
            continue
        for f in root.rglob('SKILL.md'):
            if _skip_path(f, root):
                continue
            try:
                with io.open(f, 'rb') as fh:
                    head = fh.read(4096)
            except Exception:
                continue
            m = NAME_RE.search(head)
            if not m:
                continue
            name = m.group(1).decode('utf-8', 'replace').strip().strip('"\'')
            if not name or name[0] in '-._':
                continue
            if name not in found:
                found[name] = (f.parent, agent)
    return found


def newest_mtime(d):
    """技能目录里最新的文件修改时间（不读内容，只 stat）。"""
    newest = 0.0
    try:
        for p in d.rglob('*'):
            if p.is_file():
                try:
                    t = p.stat().st_mtime
                    if t > newest:
                        newest = t
                except Exception:
                    pass
    except Exception:
        pass
    return newest


def existing():
    data = json.loads(SRC_DATA.read_text(encoding='utf-8-sig'))
    return {(d.get('name'), d.get('agent')): d for d in data}


def run_sync(skill_dir, agent, extra):
    env = dict(os.environ)
    env['PYTHONIOENCODING'] = 'utf-8'
    cmd = [sys.executable or 'python', str(SYNC_SCRIPT), str(skill_dir), '--agent', agent] + extra
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8',
                           errors='replace', env=env, timeout=900)
        return (r.stdout or '') + (r.stderr or ''), r.returncode
    except Exception as e:
        return '子进程异常: %s' % e, -1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--no-push', action='store_true')
    ap.add_argument('--all', action='store_true', help='忽略 mtime/grace，全量比对')
    a = ap.parse_args()

    if not SYNC_SCRIPT.exists():
        log('❌ 找不到 skill_sync.py')
        print('⚠️ 技能自动同步异常：找不到 skill_sync.py（%s）' % SYNC_SCRIPT)
        return 1
    if not SRC_DATA.exists():
        log('❌ 找不到看板数据 %s' % SRC_DATA)
        print('⚠️ 技能自动同步异常：找不到看板数据文件。')
        return 1

    now = time.time()
    have = existing()
    have_names = {n for n, _a in have}
    scanned = collect_skills()

    st = load_state()
    last_scan = st.get('last_scan', 0) if not a.all else 0
    deferred = set(st.get('deferred', []))
    seen_amb = set(st.get('reported_ambiguous', []))
    first_run = (not last_scan and not a.all)   # 首次：看板刚建，先只登记时间，不做更新比对

    todo, ambiguous, editing = {}, {}, []
    for n, (d, ag) in scanned.items():
        key = (n, ag)
        if key not in have and n in have_names or \
           (key not in have and any(n.startswith(x + ' ') for x in have_names)):
            ambiguous[n] = (d, ag)
            continue
        if key not in have:
            todo[n] = (d, ag, 'new')                 # 全新技能
            continue
        if first_run:
            continue                                  # 首次不做更新比对
        if not a.all and n not in deferred and newest_mtime(d) <= last_scan:
            continue                                  # 目录没动过，跳过（省时间）
        if not a.all and newest_mtime(d) > now - EDIT_GRACE:
            editing.append(n)
            deferred.add(n)                           # 可能正在编辑，下轮强制复检
            continue
        deferred.discard(n)
        todo[n] = (d, ag, 'update')                   # 最近动过 → 打包比对

    log('扫到 %d 个技能，看板 %d 条；待处理 %d（新 %d / 可能更新 %d），近同名 %d，编辑中 %d'
        % (len(scanned), len(have), len(todo),
           sum(1 for v in todo.values() if v[2] == 'new'),
           sum(1 for v in todo.values() if v[2] == 'update'),
           len(ambiguous), len(editing)))

    new_amb = [n for n in sorted(ambiguous) if n not in seen_amb]
    if not todo and not new_amb:
        st['last_scan'] = now
        st['deferred'] = sorted(deferred)
        save_state(st)
        return 0

    if a.dry_run:
        print('待处理（dry-run 未同步）：')
        for n, (d, ag, kind) in sorted(todo.items(), key=lambda kv: kv[1][2]):
            print('  · [%s] %s（%s）%s' % (kind, n, ag, d))
        for n in editing:
            print('  · [编辑中，跳过] %s' % n)
        for n in new_amb:
            print('  · [同名/近同名，跳过] %s' % n)
        return 0

    extra = ['--no-push'] if a.no_push else []
    added, updated, same, pending, failed, sensitive = [], [], [], [], [], []
    for n, (d, ag, kind) in sorted(todo.items()):
        dry, _ = run_sync(d, ag, ['--dry-run'])
        if '业务敏感词' in dry:
            if kind == 'new':
                log('%s 命中业务敏感词，跳过自动同步（新技能）' % n)
                pending.append(n)
                continue
            # 已有条目的更新：内容本来就已公开，照推，但在告知里点名
            log('%s 命中业务敏感词，但已有条目 → 照常同步并在告知里点名' % n)
            sensitive.append(n)
        m = SHA_RE.search(dry)
        sha = m.group(1) if m else None
        old = have.get((n, ag))
        if kind == 'update' and old and sha and old.get('sha256') == sha:
            same.append(n)                            # 内容其实没变
            continue
        out, rc = run_sync(d, ag, extra)
        pkg = re.search(r'打包\s*:\s*(\S+\.zip)', out)
        pkgname = pkg.group(1) if pkg else ''
        if rc == 0 and ('✅ 线上已更新' in out or '未推送' in out or '无改动' in out):
            log('%s [%s] 同步成功 %s' % (n, kind, pkgname))
            (added if kind == 'new' else updated).append((n, pkgname))
        else:
            log('%s [%s] 同步失败 rc=%s\n%s' % (n, kind, rc, out[-800:]))
            failed.append((n, out.strip().splitlines()[-1] if out.strip() else '未知错误'))

    if not a.dry_run:
        st['last_scan'] = now
        st['deferred'] = sorted(deferred)
        if new_amb:
            st['reported_ambiguous'] = sorted(seen_amb | set(new_amb))
        save_state(st)

    if not (added or updated or pending or failed or new_amb or sensitive):
        return 0

    lines = []
    if added:
        lines.append('🆕 技能自动同步：%d 个新技能已上线' % len(added))
        for n, pkg in added:
            lines.append('· %s　%s' % (n, pkg))
    if updated:
        if lines:
            lines.append('')
        lines.append('♻️ %d 个技能有更新，已重新打包上线' % len(updated))
        for n, pkg in updated:
            lines.append('· %s　%s' % (n, pkg))
    if added or updated:
        lines.append('🔗 %s（密码 11）' % LIVE)
        lines.append('卡片简介暂用技能原文，要中文简介跟我说一声。')
    if pending:
        lines.append('')
        lines.append('⚠️ 未自动同步（新技能包内含敏感词，等确认）：%s' % '、'.join(pending))
    if sensitive:
        lines.append('')
        lines.append('ℹ️ 这几个技能的更新已同步，但内容里含公司/店铺名等字眼，介意的话告诉我：%s'
                     % '、'.join(sensitive))
    if failed:
        lines.append('')
        lines.append('❌ 同步失败：%s' % '；'.join('%s(%s)' % (n, e) for n, e in failed))
    if new_amb:
        lines.append('')
        lines.append('⚠️ 有同名/近同名的技能目录，未自动同步（避免重复卡片）：%s' % '、'.join(new_amb))
    out = '\n'.join(lines)
    print(out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
