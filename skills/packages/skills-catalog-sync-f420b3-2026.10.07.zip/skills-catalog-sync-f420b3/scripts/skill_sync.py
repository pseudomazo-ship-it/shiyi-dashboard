# -*- coding: utf-8 -*-
"""skill_sync.py —— 把新生成/更新的 skill 同步到 https://shiyi11.com.cn/skills/

一条命令走完全程：
  打包 ZIP → 写入源目录和发布仓库两处 packages/ → 更新 skills_data.json
  → 重建两个 HTML 的内联数据 → git 提交推送 → 验证线上

用法：
  python skill_sync.py <技能目录|技能名> [--agent Hermes] [--desc "中文简介"]
                       [--category 办公协同] [--date 2026.10.07]
                       [--dry-run] [--no-push]

约定（与现有条目一致，勿改）：
  slug    = sanitize(name)[:65] + '-' + sha256(name)[:6]
  包名    = <slug>-<YYYY.MM.DD>.zip
  发布版  = 源 HTML + 发布环节注入的密码门（本脚本只动 const skills=[...] 数据块）
"""
import argparse
import hashlib
import io
import json
import re
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

# ---------------------------------------------------------------- 配置
CFG = {
    'source_dir': Path(r'D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager'),
    'repo_dir': Path(r'E:\RuanJian\Hermes\cache\shiyi-dashboard-git'),
    'git_exe': r'E:\RuanJian\Hermes\git\cmd\git.exe',
    'proxy': 'http://127.0.0.1:7897',
    'live': 'https://shiyi11.com.cn/skills/',
    'branch': 'main',
}

AGENT_ROOTS = {
    'Hermes': [Path(r'E:\RuanJian\Hermes\skills')],
    'Codex': [Path(r'C:\Users\Administrator\.codex\skills')],
    'WorkBuddy': [],  # 未知，直接把技能目录路径传给脚本
}

SKIP_ANY = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', '.idea', '.vscode',
            '.pytest_cache', '.mypy_cache', 'dist', 'build'}

SENS_NAME = re.compile(
    r'(credential|secret|api[_-]?key|apikey|client[_-]?secret|access[_-]?token|'
    r'auth[_-]?token|refresh[_-]?token|cookie|session[_-]?id|^\.env|id_rsa|\.pem$|\.key$|'
    r'\.p12$|\.pfx$)', re.I)

SENS_BLOB = re.compile(
    rb'(sk-[A-Za-z0-9_-]{24,}|sk-ant-[A-Za-z0-9_-]{24,}|ghp_[A-Za-z0-9]{30,}|'
    rb'gho_[A-Za-z0-9]{30,}|AKIA[A-Z0-9]{16}|-----BEGIN [A-Z ]*PRIVATE KEY-----|'
    rb'xox[baprs]-[A-Za-z0-9-]{10,})')

# 业务敏感词：命中就提醒人工确认（不阻断）。
# ⚠️ 关键词必须【拆开拼接】，否则本脚本自身的正则字面量会被自己扫中（自指误报）。
_ZX = '专营' + '店'
BIZ_WORDS = re.compile(
    r'[\u4e00-\u9fa5]{2,10}(?:' + '有限' + '公司|' + '旗舰' + '店|' + _ZX + ')'
    + r'|统一社会' + '信用代码|(?:账号|密码|口令)\s*[:：=]|手机' + '号|身份' + '证')

MAX_FILE_BYTES = 90 * 1024 * 1024   # GitHub 单文件硬上限 100MB


def log(msg):
    print(msg, flush=True)


def field(text, name):
    m = re.search(r'^' + name + r':\s*([^\n]*)', text, re.M)
    if not m:
        return ''
    v = m.group(1).strip()
    if v in ('>', '|', '>-', '|-') or v.startswith(('>-', '>+')):
        chunks = []
        for line in text[m.end():].splitlines():
            if not line.strip():
                continue
            if not line.startswith((' ', '\t')):
                break
            chunks.append(line.strip())
        return ' '.join(chunks)
    return v.strip('"\'')


def slugof(name):
    s = re.sub(r'[^a-zA-Z0-9_-]', '-', name).strip('-') or 'skill'
    return s[:65] + '-' + hashlib.sha256(name.encode()).hexdigest()[:6]


def guess_category(name, text):
    n = (name + ' ' + text[:600]).lower()
    rules = [
        ('电商运营', ['pdd', '拼多多', '电商', 'sku', 'shop', 'listing', '客服', '店铺', '发货']),
        ('数据分析', ['excel', 'xlsx', 'spreadsheet', '数据', '报表', '统计', '看板', 'dashboard']),
        ('开发编程', ['code', 'debug', 'test', 'git', 'python', 'node', 'skill-author', 'review']),
        ('文档处理', ['docx', 'pdf', 'powerpoint', '文档', '写作', '排版']),
        ('设计创作', ['design', 'image', 'art', 'svg', 'html', 'css', 'front']),
        ('搜索资讯', ['search', 'web', 'news', 'rss', '论文', '抓取', 'harvest']),
        ('平台服务', ['feishu', '飞书', 'notion', 'airtable', 'google', '邮箱', 'email']),
        ('智能体协作', ['catalog-sync', 'agent', 'delegate', 'subagent', '团队', 'dispatch', 'cron']),
        ('办公协同', ['ima', '笔记', '知识库', '会议', 'meeting', '待办']),
        ('系统运维', ['windows', 'desktop', '系统', '进程', 'disk', 'install', 'upgrade']),
    ]
    for cat, keys in rules:
        if any(k in n for k in keys):
            return cat
    return '办公协同'


def run(cmd, cwd=None, timeout=600):
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None,
                          capture_output=True, text=True, timeout=timeout)


def git(args, cwd=None, proxy=True, timeout=600):
    cmd = [CFG['git_exe']]
    if proxy:
        cmd += ['-c', 'http.proxy=' + CFG['proxy'], '-c', 'https.proxy=' + CFG['proxy'],
                '-c', 'http.version=HTTP/1.1', '-c', 'http.postBuffer=524288000',
                '-c', 'http.lowSpeedLimit=1000', '-c', 'http.lowSpeedTime=600']
    cmd += list(args)
    return run(cmd, cwd=cwd, timeout=timeout)


def find_skill_dir(target, agent):
    p = Path(target)
    if p.is_dir():
        return p if (p / 'SKILL.md').exists() else None
    for root in AGENT_ROOTS.get(agent, []):
        if not root.exists():
            continue
        for f in root.rglob('SKILL.md'):
            if any(part in SKIP_ANY for part in f.parts):
                continue
            rel = f.relative_to(root)
            top = rel.parts[0]
            if top.startswith('.') or '.bak' in top:
                continue
            try:
                text = f.read_text(encoding='utf-8-sig', errors='replace')
            except Exception:
                continue
            if (field(text, 'name') or f.parent.name) == target:
                return f.parent
    return None


def pack_skill(skill_dir, date):
    sk = skill_dir / 'SKILL.md'
    text = sk.read_text(encoding='utf-8-sig', errors='replace')
    name = field(text, 'name') or skill_dir.name
    version = field(text, 'version') or '未声明'
    slug = slugof(name)
    pkg_name = f'{slug}-{date}.zip'

    skipped, biz_hits, nfiles, too_big = [], [], 0, []
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for item in sorted(skill_dir.rglob('*')):
            if not item.is_file() or item.is_symlink():
                continue
            sub = item.relative_to(skill_dir)
            if any(part in SKIP_ANY for part in sub.parts):
                skipped.append(str(sub))
                continue
            if SENS_NAME.search(item.name):
                skipped.append(str(sub))
                continue
            try:
                blob = item.read_bytes()
            except Exception:
                skipped.append(str(sub))
                continue
            if len(blob) > MAX_FILE_BYTES:
                too_big.append(str(sub))
                continue
            if SENS_BLOB.search(blob):
                skipped.append(str(sub))
                continue
            try:
                if BIZ_WORDS.search(blob.decode('utf-8', 'ignore')):
                    biz_hits.append(str(sub))
            except Exception:
                pass
            # 固定时间戳 → 打包确定性（同内容同 sha）
            zi = zipfile.ZipInfo(f'{slug}/{sub.as_posix()}', date_time=(1980, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, blob)
            nfiles += 1
    data = buf.getvalue()
    return {
        'name': name, 'version': version, 'slug': slug, 'package': pkg_name,
        'package_url': 'packages/' + pkg_name, 'bytes': data,
        'package_size': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'nfiles': nfiles, 'skipped': skipped, 'biz_hits': biz_hits, 'too_big': too_big,
        'description_raw': field(text, 'description'),
    }


def load_data(html_path):
    s = html_path.read_text(encoding='utf-8')
    i = s.find('const skills=')
    j = s.find('\nconst $=', i)
    if i < 0 or j < 0:
        raise SystemExit('未找到内联数据锚点: ' + str(html_path))
    blk = s[i + len('const skills='):j].rstrip()
    if blk.endswith(';'):
        blk = blk[:-1]
    return s, i, j, json.loads(blk)


def write_data(html_path, new_list):
    s, i, j, _ = load_data(html_path)
    body = json.dumps(new_list, ensure_ascii=False).replace('</', '<\\/')
    out = s[:i] + 'const skills=' + body + ';' + s[j:]
    html_path.write_text(out, encoding='utf-8', newline='')
    return len(out.encode('utf-8'))


def build_entry(pack, agent, desc, category, date):
    notes = ('本地技能目录重打包，不是官方发行包。仅包含技能文件，不包含运行时、插件服务、'
             '账号授权或第三方依赖；未进行完整安全审计和跨环境安装实测。公开分发前请核实授权与内容。')
    if pack['skipped']:
        notes += f"\n打包时排除了 {len(pack['skipped'])} 个敏感命名或凭据特征文件。"
    return {
        'name': pack['name'],
        'description': desc or pack['description_raw'] or '本地技能，详见技能说明。',
        'full_description': pack['description_raw'],
        'version': pack['version'],
        'category': category,
        'agent': agent,
        'install_method': 'ZIP 手动',
        'package_url': pack['package_url'],
        'source_url': '',
        'source_note': f'本机 {agent} 技能目录',
        'reference_urls': [],
        'notes': notes,
        'updated_at': date,
        'package_size': pack['package_size'],
        'sha256': pack['sha256'],
        'package_root': pack['slug'],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('target', help='技能目录 或 技能名')
    ap.add_argument('--agent', default='Hermes', choices=list(AGENT_ROOTS))
    ap.add_argument('--desc', default='', help='看板卡片上的中文简介（建议 20~60 字）')
    ap.add_argument('--category', default='', help='分类，留空则自动猜')
    ap.add_argument('--date', default=time.strftime('%Y.%m.%d'))
    ap.add_argument('--dry-run', action='store_true', help='只计算并打印，不写任何文件')
    ap.add_argument('--no-push', action='store_true', help='改本地文件但不推线上')
    args = ap.parse_args()

    src_dir, repo_dir = CFG['source_dir'], CFG['repo_dir']
    src_html, pub_html = src_dir / 'skills.html', repo_dir / 'skills' / 'index.html'
    for p in (src_html, pub_html):
        if not p.exists():
            raise SystemExit('缺少文件: ' + str(p))

    skill_dir = find_skill_dir(args.target, args.agent)
    if not skill_dir:
        raise SystemExit('找不到技能: %s（Agent=%s）' % (args.target, args.agent))
    log('技能目录: %s' % skill_dir)

    pack = pack_skill(skill_dir, args.date)
    log('技能名  : %s  (v%s)' % (pack['name'], pack['version']))
    log('打包    : %s  %d 文件  %s B' % (pack['package'], pack['nfiles'], format(pack['package_size'], ',')))
    log('SHA-256 : %s' % pack['sha256'])
    if pack['skipped']:
        log('已排除敏感文件 %d 个: %s' % (len(pack['skipped']), pack['skipped'][:5]))
    if pack['too_big']:
        log('⚠️ 跳过超大文件(>90MB): %s' % pack['too_big'])
    if pack['biz_hits']:
        log('⚠️ 包里出现业务敏感词，共 %d 个文件 —— 同步前请人工确认：' % len(pack['biz_hits']))
        for h in pack['biz_hits'][:10]:
            log('     · ' + h)

    _, _, _, cur = load_data(src_html)
    idx = next((k for k, d in enumerate(cur)
                if d.get('name') == pack['name'] and d.get('agent') == args.agent), None)
    category = args.category or (cur[idx].get('category') if idx is not None else '') \
        or guess_category(pack['name'], pack['description_raw'])
    entry = build_entry(pack, args.agent, args.desc, category, args.date)
    old = cur[idx] if idx is not None else None
    if old:   # 保留人工写过的字段，别每次同步把中文简介/场景冲掉
        for k in ('description', 'full_description', 'scene', 'icon', 'original', 'exclusive'):
            if old.get(k) and not (k == 'description' and args.desc):
                entry[k] = old[k]
        entry['id'] = old.get('id', 'skill-%d' % idx)
        unchanged = (old.get('sha256') == entry['sha256']
                     and old.get('package_size') == entry['package_size'])
    else:
        unchanged = False

    log('条目    : %s' % (('已存在，将更新（id=%s）' % old.get('id')) if old else '新增'))
    log('分类    : %s' % entry['category'])
    if unchanged:
        log('内容    : 与现有包一致（幂等），仅刷新 updated_at')

    if args.dry_run:
        log('\n[dry-run] 未写任何文件。')
        return 0

    for d in (src_dir / 'packages', repo_dir / 'skills' / 'packages'):
        d.mkdir(parents=True, exist_ok=True)
        (d / pack['package']).write_bytes(pack['bytes'])
    log('已写入 ZIP: 源目录 + 发布仓库')

    js_path = src_dir / 'skills_data.json'
    data = json.loads(js_path.read_text(encoding='utf-8-sig')) if js_path.exists() else []
    k = next((i for i, d in enumerate(data)
              if d.get('name') == pack['name'] and d.get('agent') == args.agent), None)
    if k is not None:
        entry['id'] = data[k].get('id', entry.get('id', ''))
        data[k] = entry
    else:
        data.append(entry)
    js_path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    log('已更新 skills_data.json（%d 条）' % len(data))

    new_src = list(cur)
    if idx is not None:
        new_src[idx] = entry
    else:
        new_src.append(entry)
    for i, d in enumerate(new_src):
        d['id'] = 'skill-' + str(i)
    n_src = write_data(src_html, new_src)

    _, _, _, pub_cur = load_data(pub_html)
    pub_idx = next((i for i, d in enumerate(pub_cur)
                    if d.get('name') == pack['name'] and d.get('agent') == args.agent), None)
    new_pub = list(pub_cur)
    if pub_idx is not None:
        new_pub[pub_idx] = entry
    else:
        new_pub.append(entry)
    for i, d in enumerate(new_pub):
        d['id'] = 'skill-' + str(i)
    n_pub = write_data(pub_html, new_pub)
    log('已重建内联数据: 源 %s 字节 / 发布 %s 字节（各 %d 条）'
        % (format(n_src, ','), format(n_pub, ','), len(new_src)))

    if args.no_push:
        log('\n已改本地，按 --no-push 未推送。')
        return 0

    rel = ['skills/index.html', 'skills/packages/' + pack['package']]
    git(['add'] + rel, cwd=repo_dir, proxy=False)
    st = git(['status', '--short'], cwd=repo_dir, proxy=False).stdout.strip()
    log('待提交:\n' + st)
    if not st:
        log('无改动，跳过提交')
        return 0
    msg = 'skills 管理台：同步 %s（%s）' % (pack['name'], args.date)
    r = git(['commit', '-q', '-m', msg], cwd=repo_dir, proxy=False)
    if r.returncode != 0:
        raise SystemExit('git commit 失败: ' + r.stderr)
    git(['pull', '--rebase', 'origin', CFG['branch']], cwd=repo_dir)
    r = git(['push', 'origin', CFG['branch']], cwd=repo_dir)
    log((r.stdout + r.stderr).strip()[-400:])

    blob = git(['show', 'HEAD:skills/index.html'], cwd=repo_dir).stdout
    want = len(blob.encode('utf-8'))
    base = int(time.time())
    for i in range(1, 11):
        try:
            req = urllib.request.Request(CFG['live'] + '?t=%d' % base,
                                         headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
            if len(body) == want:
                log('✅ 线上已更新（%s 字节，与仓库一致）' % format(want, ','))
                return 0
            log('[%d] 线上还是旧版（%s 字节，应为 %s），等待部署…'
                % (i, format(len(body), ','), format(want, ',')))
        except Exception as e:
            log('[%d] 取线上失败: %s' % (i, e))
        time.sleep(20)
    log('⚠️ 已推送但 10 次轮询未见新版，去浏览器强刷确认（Pages 缓存最长 10 分钟）')
    return 1


if __name__ == '__main__':
    sys.exit(main())
