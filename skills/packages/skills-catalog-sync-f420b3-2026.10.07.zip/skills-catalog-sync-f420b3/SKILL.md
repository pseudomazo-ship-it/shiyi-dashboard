---
name: skills-catalog-sync
description: Use when 新生成/更新 skill 要同步到域名技能管理台（打包+推送）。
version: 1.0.0
metadata:
  hermes:
    tags: [skill, 看板, github-pages, 域名, 同步]
    category: productivity
    related_skills: [domain-hosting-access-control, skill-package-delivery]
---

# 新技能 → 域名同步（shiyi11.com.cn/skills/）

**十一 2026-10-07 定的规则（全窗口）：新生成的 skill 第一时间同步到域名，同步内容 = 技能安装包（ZIP）。**
不需要问、不要等确认 —— 生成完就同步，然后报一句结果。

线上：<https://shiyi11.com.cn/skills/>　进入密码 **11**。

## 一条命令跑完全程

```bash
python "<本技能目录>/scripts/skill_sync.py" <技能名或技能目录> --agent Hermes --desc "看板卡片上那句中文简介"
```

实测入口（技能装在 `E:\RuanJian\Hermes\skills\productivity\skills-catalog-sync\`）：

```bash
python "E:/RuanJian/Hermes/skills/productivity/skills-catalog-sync/scripts/skill_sync.py" \
       pdd-store-diagnosis --agent Hermes --desc "诊断PDD店铺 · 看指标" --dry-run
```

常用开关：

| 参数 | 作用 |
|---|---|
| `--agent Hermes\|Codex\|WorkBuddy` | 用技能名定位时，去哪个技能根目录找 |
| `--desc "…"` | 看板卡片上的中文简介（20~60 字）。不给就用 SKILL.md 里的英文 description |
| `--category 电商运营` | 分类。不给则按技能名/正文自动猜 |
| `--date 2026.10.07` | 包名里的日期，默认今天 |
| `--dry-run` | 只算不写（先跑这个看效果） |
| `--no-push` | 改本地但不推线上 |

直接给技能目录也可以（其他 Agent 的技能目录未知时用这个）：
`python … skill_sync.py "D:/某工作区/skills/某技能" --agent WorkBuddy --desc "…"`

## 它替你做的六件事

```
① 打包   <slug>-<YYYY.MM.DD>.zip，slug = sanitize(name)[:65] + '-' + sha256(name)[:6]
         排除 __pycache__/.git/node_modules 等，排除敏感命名与含凭据特征的文件
② 写包   同时写进「源目录 packages/」和「发布仓库 skills/packages/」
③ 数据   更新 skills_data.json（存在则替换，不存在则新增；保留人工写过的字段）
④ 内联   重建两个 HTML 的 const skills=[…]; 数据块（源 + 发布版必须完全一致）
⑤ 推送   git add/commit → pull --rebase → push（走代理）
⑥ 验证   轮询线上字节数 == git show HEAD:skills/index.html 的字节数
```

## 现状事实（改任何东西前先看这段）

```
源文件    D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\
          ├─ skills.html       内联数据（⚠️ 源文件没有密码门）
          ├─ skills_data.json  同样条数
          ├─ build_catalog.py  Codex 侧的生成脚本
          └─ packages\         各技能的 ZIP
发布仓库  E:\RuanJian\Hermes\cache\shiyi-dashboard-git\
          └─ skills\index.html + skills\packages\   ← GitHub Pages 从这里发
线上      https://shiyi11.com.cn/skills/  （仓库 pseudomazo-ship-it/shiyi-dashboard，main）
```

- **发布版 = 源文件 + 发布环节注入的密码门**（`.skill-gate/.skill-login` 的 CSS 与那段
  SHA-256 校验脚本）。两份文件逐块比对过的差异**只有这两处**，其余（含全部数据）完全一致。
  → 所以：**改详情页文案/结构要两处同步**；**改数据由脚本自动两边同步**，不用手抄。
  → ⚠️ 谁要是拿源文件直接发布，线上就是**没有密码**的裸页。
- **数据锚点**：`const skills=` … `\nconst $=`（结尾带一个 `;`）。别用宽松正则。
- 条目按 Agent 分：Codex / WorkBuddy / Hermes，卡片上带 `11. 十一独创` 标签的是自研。

## 坑（都是真踩过的）

1. **push 必须走代理**：直连 github.com:443 超时。
   `git -c http.proxy=http://127.0.0.1:7897 -c https.proxy=http://127.0.0.1:7897 … push`
   （`git-credential-manager.exe: No such file or directory` 那两行警告**无害**，push 照样落地。）
   大包如果报 `HTTP 408 / send-pack: unexpected disconnect`，加 `-c http.version=HTTP/1.1
   -c http.postBuffer=524288000 -c http.lowSpeedLimit=1000 -c http.lowSpeedTime=600` 再推。
2. **验证必须以仓库为准，不能只看 curl**：`git show HEAD:skills/index.html | wc -c` 与线上
   字节数比对，线上 URL 必须带 `?t=<时间戳>` 破 CDN 缓存（Pages 缓存最长 10 分钟）。
   浏览器里若还是旧版，再 `cdp('Page.reload', ignoreCache=True)`。
3. **打包要确定性**：`zipfile.writestr(arcname, data)` 默认会把**当前时间**写进 ZIP 头 →
   每次打包 sha 都变、条目天天刷新。本脚本改成固定 `date_time=(1980,1,1,0,0,0)`，
   同内容 → 同 sha（实测两次打包一致）。
   ⚠️ 代价：与 2026-10-07 之前那批老包相比 **sha 不同但内容逐文件一致**（已用
   `pdd-store-diagnosis` 实测：4 文件、文件名集合相同、同名文件内容全同）。
   所以第一次同步某个**已入库的老技能**时，条目里的 sha 会变一次 —— 正常，不是打包出错。
4. **换日期会残留旧包**：包名带当天日期，跨天重跑生成新包名，老 `<slug>-<旧日期>.zip` 会留在
   packages\ 里。要清理时只删同一 slug 的旧日期包，别批量删。
5. **仓库是 public**：包内容等于公开。脚本会扫业务敏感词（公司全称、店铺全称、
   信用代码、账号密码…）并**列出来**，命中就人工确认一句再推，别默默推上去。
   凭据类特征文件（.env / token / key / cookie / 私钥）脚本直接排除，不进包。
6. **多窗口会同时改 `skill_manager\`**（2026-10-07 实测被覆盖两次）：
   写之前先读最新版，写完**读回复核**条目是否还在；发现被覆盖就再写一次并向十一说明。
   同一份看板建议只让一个窗口改。
7. **技能名歧义会让打包错乱**：两个目录的 SKILL.md 写同一个 `name:` →
   `skill_view()` 报 ambiguous，打包也会互相覆盖。发现同名就把旧版移出技能根目录
   （`软件--技能旧版备份\`），别只改文件夹名（name 取自 frontmatter）。

## 交付纪律

- 同步完**只在那一个渠道回一句**：技能名 + 包名 + sha 前 8 位 + 「线上已更新」+ 线上链接。
- 十一要看效果时，把 `https://shiyi11.com.cn/skills/` 打开（密码 11），点对应卡片看详情。
- 他的口令「建个skill」= 按 `hermes-agent-skill-authoring` 的规范落地 SKILL.md + scripts，
  建完**立刻用本技能同步它自己**（这也是最好的端到端自测）。

## 自动同步守护（cron，2026-10-07 建）

十一的要求：「每次要自动同步到域名，同步后在微信告知我」→ 已建 no_agent 定时任务：

| 项 | 值 |
|---|---|
| job | `75c6684105eb` 技能自动同步 |
| schedule | `0 9-23 * * *`（每天 9-23 点每小时） |
| script | `E:\RuanJian\Hermes\scripts\skills_sync_watch.py` |
| deliver | 微信（weixin:o9cq80wWDQDcn-…@im.wechat） |
| 静默 | **没有新技能就空 stdout → 不推送**（watchdog 模式，天然不吵） |

**watch 脚本干什么（v2，2026-10-07 晚改）**：扫 Hermes / Codex / WorkBuddy 三处技能根目录取 `name`，
与看板 `skills_data.json` 比对：
- **看板里没有的** → 新技能 → 直接调 `skill_sync.py` 上线
- **看板里已有的** → 目录 mtime 晚于上次扫描的，重新打包算 sha 与看板记录比对，
  **只有内容真变了才推**（内容没变不发、也不产生提交）
- 每个都先 `--dry-run`，命中业务敏感词的不推、只报告
- 状态存 `cache\skills_sync_state.json`（`last_scan` / `deferred` / `reported_ambiguous`）

⚠️ **三层过滤不能删**（都是实测扫出来的噪音）：
- 路径 >3 段、或任一段以 `.` `-` `_` 开头 → 跳过（`--help`、`.claude` 这类）
- **父链上还有别的 SKILL.md → 是嵌套子技能**，跳过
  （实测 `ui-ux-pro-max/.claude/skills/` 下 6 个、`xmtp-agent-swarm__skillhub/skills/` 下 1 个）
- 名字与看板已有技能**相同或前缀相同** → 不自动同步，只在微信里点名
  （实测 `ecom-ai-operation-toolkit` 的 WorkBuddy 版、`video-image-file-analysis 多模态视频图片分析专家`）

**护栏**：只同步「看板里完全**没有**的新技能」。已存在技能的**内容更新不自动推** ——
避免半成品/临时改动自动进公开仓库，这类仍走人工（十一说「更新 skill 并打包发我」时跑）。

**护栏（十一 2026-10-07 二次确认后调整）**：**新技能和已有技能的内容更新都自动同步**
（原话：「所有窗口新生成的 skill，以及当前 skill 更新；全部第一时间同步到我的域名」）——
技能改完**不用手动跑**，下一轮 cron（最多 1 小时）自动上线并在微信告知。
防误推的四道保护：
- 目录 **10 分钟内还动过 → 先跳过**（可能正在写），记入 `deferred` 下轮**强制**复检
- 命中业务敏感词 → 不推，只在微信里点名
- 技能名与看板已有条目**同名/近同名** → 不推（避免重复卡片）
- **首次运行**只登记扫描时间、不做更新比对

⚠️ 想让某个技能在写好的过程中别被自动推：先把它放在 `skills\` 目录**以外**，写完再放进去。
需要整体暂停时停 cron `75c6684105eb`。

**实测记录（2026-10-07）**：首跑 205→215 个技能目录 → 新增 1（WorkBuddy 的 `vision-ai`）自动上线；
v2 更新检测实测：改一个技能文件并把 mtime 回拨 15 分钟 → 下轮扫描抓到 1 个 update 并重新打包上线。

## 自检清单

- [ ] `--dry-run` 先跑，确认技能名/包名/sha/分类都对
- [ ] 日志里没有「⚠️ 业务敏感词」未确认就推
- [ ] `skills_data.json` 与两个 HTML 的条数一致（脚本已保证，抽查一条即可）
- [ ] 线上字节数 == `git show HEAD:skills/index.html` 字节数
- [ ] 浏览器（强刷）输 11 进得去、点该卡片看到新条目、下载链接可下
- [ ] 只在十一说话的那个渠道回报一次，不重复发
