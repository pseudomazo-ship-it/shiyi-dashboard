# WeChat `.silk` voice — concrete findings

Session-derived facts for decoding and transcribing a WeChat voice message on this host.

## Container
- Header bytes: `#"SILK_V3` → hex `02 23 21 53 49 4c 4b 5f 56 33` (`\x02\x23!"SILK_V3`).
- Reading the head: `open(path,'rb').read(32).hex()` reveals it. A raw `.silk` is NOT a wav.
- ffmpeg on a `.silk`: `Error opening input file ... Invalid data found when processing input` — ffmpeg cannot decode Silk V3. Do not use it for the decode step.

## Decode with `pilk`
Verified working call:
```python
import pilk, os
pilk.silk_to_wav(silk_path, wav_path, rate=24000)   # rate= is the ONLY accepted kwarg
assert os.path.getsize(wav_path) > 0
```
- `rate=24000` (uint). Rejected kwargs (both raise `TypeError: ... unexpected keyword argument`):
  - `sample_rate=24000`  → invalid keyword
  - `pcm_rate=24000`     → invalid keyword
- `pilk.decode(...)` exists but is a builtin with no inspectable signature; `SilkDecoder(pcm_rate=24000, packet_loss=0)` is the class form. Prefer `silk_to_wav` for a one-shot decode.
- The decode output grew from a ~13KB silk to a ~340KB wav, confirming success.

## faster-whisper corruption signatures (this host)
- `WhisperModel("small", ...)` → `RuntimeError: File model.bin is incomplete: failed to read a value of size 4 at position 0` (model.bin is 0 bytes).
- `WhisperModel("base", ...)` → `huggingface_hub.errors.IncompleteSnapshotError: The cached snapshot ... is incomplete: 3 file(s) are missing (config.json, tokenizer.json, vocabulary.txt). The Hub could not be reached (ConnectTimeout)` — the missing files block load and it tries to reach huggingface.co (no network → ConnectTimeout).
- Actual cached sizes found: tiny `model.bin` = 0 MB, small `model.bin` = 0 MB, base `model.bin` = 138 MB (complete weight file but missing config/tokenizer/vocab).
- So `WhisperModel(...)` sometimes SKIPS download for some models (weight present) and only surfaces the incompleteness when config/tokenizer are also required. Always check `config.json`/`tokenizer.json`/`vocabulary.txt` presence, not just `model.bin` size.

## SenseVoice fallback (verified onnx schema; NOT yet a working transcriber)
- A complete `sensevoice-small` ONNX model exists locally:
  `C:\Users\Administrator\AppData\Roaming\Shandianshuo\models\sensevoice-small\` → `model.onnx` (230MB), `config.yaml`, `tokens.json`.
- **It CAN be run by hand with just `onnxruntime` + `numpy` + `scipy`** (no funasr/torch/librosa needed). Verified graph I/O:
  - inputs: `speech` [batch, feats_length, **560**] float (560 = lfr_m(7) × n_mels(80)); `speech_lengths` [batch] int32; `language` [batch] int32 (0=auto, 1=zh); `textnorm` [batch] int32 (0=no itn).
  - outputs: `ctc_logits` [batch, logits_length, **25055**] float; `encoder_out_lens` [batch] int32.
- `tokens.json` is a **list** (index = token id): `['<unk>','<s>','</s>','▁the','s', ...]` (25055 items). `config.yaml` frontend: fs=16000, n_mels=80, frame_length=25ms, frame_shift=10ms, lfr_m=7, lfr_n=6, window=hamming, cmvn=null.
- To run by hand: decode silk→wav (24k) then resample to 16k (`scipy.signal.resample_poly`); build fbank with **fmin=20** (torchaudio/kaldi-compat; fmin=0 misaligns and the model blanks out); LFR must **flatten each frame to 560** (`reshape(-1)`, pad to exactly 7 points per output frame); feed `language=1`(zh), `textnorm=0`; run with the hermes venv python (has onnxruntime), NOT the execute_code kernel.
- **Honest outcome (NOT yet usable):** it runs and emits ` <|zh|><|EMO_UNKNOWN|><|Event_UNK|><|woitn|>` then mostly `<unk>` (id=0) — but real Hanzi (`有`/`是`) land in top-k, so the frontend is close yet slightly misaligned and blank/unk wins argmax; force-picking a non-unk token yields garbage. So it is **not a drop-in transcriber** until the fbank matches torchaudio's kaldi fbank exactly (needs `librosa`/`torchaudio`, which are absent + network was down). Do not present the hand-rolled pipeline as working.
- Environment context: `Shandianshuo` is a local ASR/assistant app that already has many `recordings/*.wav` and a `transcriptions.json` (it transcribes Chinese fine) — a candidate to investigate if a CLI/API hook is ever needed.

## Platform note
The WeChat gateway surfaces failed transcription as a `[voice message could not be transcribed automatically; the audio is available at: <path>]` placeholder — treat that path as the `.silk` input.
