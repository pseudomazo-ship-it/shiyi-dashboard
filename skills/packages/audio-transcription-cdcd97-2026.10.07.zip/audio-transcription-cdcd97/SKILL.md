---
name: audio-transcription
description: Transcribe voice, esp. WeChat .silk. Decode, then ASR.
---

# Audio / Voice Transcription

Turn a voice message the user sends (very often a WeChat `.silk` file over the gateway) into text. WeChat voice arrives as `.silk` (Silk V3, container header `#"SILK_V3`) which most ASR tools cannot read directly — you MUST decode it to wav first. The decode step is the validated, reusable core; the ASR engine only runs AFTER you confirm it is actually usable (see pitfalls).

## Triggers
- User sends a voice message (`.silk` / `.wav` / `.mp3` / `.m4a`) and expects you to understand/act on it. `<platform>: Could not transcribe automatically ... available at <path>` is the common entry.
- Any "transcribe/summarize/inspect this audio" task.

## Step 1 — Identify the format
Read the file header. WeChat `.silk` starts with the bytes `#"SILK_V3` (hex `022321 53494c4b5f5633`). A raw `.silk` is NOT a wav; ffmpeg rejects it (`Invalid data found when processing input`), so do NOT waste a call on ffmpeg for a `.silk`.

## Step 2 — Decode `.silk` → wav with `pilk`
```python
import pilk
pilk.silk_to_wav(silk_path, wav_path, rate=24000)
```
- **The keyword is `rate=`. NOT `sample_rate=` and NOT `pcm_rate=`.** Those raise `TypeError: ... unexpected keyword argument`. (`pilk.decode(...)` also exists but has a different signature — prefer `silk_to_wav`.)
- Confirm `os.path.getsize(wav_path) > 0` before transcribing.

## Step 3 — Run ASR only after verifying the engine
`faster-whisper` (Chinese: `WhisperModel("small"/"base", device="cpu", compute_type="int8")`, `model.transcribe(wav, language="zh", vad_filter=True)`). **Before transcribing, verify the cached model is COMPLETE** — corrupt/incomplete snapshots fail with confusing errors:
- `model.bin` must be a real size (small ≈ 460MB, base ≈ 140MB, tiny ≈ 75MB). A 0-byte `model.bin` → `RuntimeError: File model.bin is incomplete`.
- The snapshot must also have `config.json`, `tokenizer.json`, `vocabulary.txt`. Missing any → `huggingface_hub.errors.IncompleteSnapshotError`, and it tries to reach HuggingFace to re-download (needs network).

Check with:
```python
import glob, os
for f in glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--Systran--faster-whisper-*/**/model.bin"), recursive=True):
    print(os.path.getsize(f)//2**20, "MB", f)
```
If tiny/small are 0 bytes and base lacks config/tokenizer/vocab + there's no network → **faster-whisper is NOT usable this run.** Don't force it.

## Step 4 — Honesty rule (hard)
If no working engine resolves, **say so plainly and give the user options** — retry as typed text, use WeChat's built-in voice-to-text, or fix the model when network returns. **NEVER fabricate the transcription.**

## Environment facts (this machine)
`pilk`, `faster_whisper`, `onnxruntime`, `numpy`, `scipy` all import from the Hermes venv site-packages (see `cdp-browser-automation` skill for the venv-python note). A local **sensevoice-small** (230MB `model.onnx` + `config.yaml` + `tokens.json`) exists under `C:\Users\Administrator\AppData\Roaming\Shandianshuo\models\sensevoice-small\` but it is runnable by hand with just `onnxruntime`+`scipy` (input `speech`=[batch,T,560]=lfr_m(7)×80 mels + `language`/`textnorm` ints → `ctc_logits`); the hand-rolled fbank doesn't align so it blanks out (mostly `<unk>`). **Not a working transcriber yet.** Verified schema + the `fmin=20`/LFR-flatten-to-560 gotchas in `references/wechat-silk-voice.md`. A reusable probe scaffold already exists: `E:/软件/Hermes/scripts/sensevoice_transcribe.py` (silk→wav→fbank→LFR-to-560→onnx→ctc decode). It RUNS clean (LFR must flush each frame to 560 via `np.concatenate`/`.reshape(-1)`, NOT `np.vstack` which kept dim-3=80 → `Got: 80 Expected: 560`), but yields `<unk>`-dominated output because the hand-rolled fbank still doesn't align with the model's training features (real `有/是/ah` tokens appear in the top-6 but `<unk>` id=0 wins each frame). Reuse the scaffold to iterate on the frontend; do NOT present sensevoice as a working transcriber until the fbank aligns.

## References
- `references/wechat-silk-voice.md` — exact Silk header bytes, the failed `pcm_rate`/`sample_rate` attempts (and why), the faster-whisper corruption signatures, and the sensevoice/Shandianshuo findings.
