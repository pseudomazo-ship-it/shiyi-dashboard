---
name: hermes-desktop-app
description: "Fix/troubleshoot the Hermes desktop app UI and plugins."
version: 1.0.0
author: Hermes Agent
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [hermes, desktop, layout, plugins, troubleshooting, state-db, session-repair]
---

# Hermes Desktop App — Operate, Customize, Troubleshoot

Covers the native Electron desktop app (run `hermes desktop`). Same agent core as CLI/gateway — same config, sessions, skills, memory. Home is `$HERMES_HOME` (here: `E:\RuanJian\Hermes` — ⚠️ the install moved from `E:\软件\Hermes` to `E:\RuanJian\Hermes` in 2026-09; a stale `E:\软件\...` path in any older note/script/launcher must be re-pointed, otherwise you get "file not found" / "Git Bash not found" style failures that look like a broken tool). This umbrella covers the desktop UI and its data, separate from `inspecting-hermes-desktop-dom` (CDP DOM reading) and `windows-electron-app-verify` (third-party Electron apps).

## The two big mental models

1. **Routes vs Layout presets — the #1 source of "chat window disappeared".**
   - Full-page routes (配置档案/profile editor, 产物/Artifacts, 定时任务/cron, 消息平台/messaging, 设置/settings) **take over the main workspace pane and cover the chat**. This is a *navigation* problem, NOT a layout problem.
   - Layout presets (`apply_layout`: default / focus / terminal-deck / quad) only control **which panes are visible** (chat / sessions / files / terminal / review) and their relative sizes. **They do NOT bring chat back from a full-page route.**
   - Symptom that is NOT a layout issue: user says "chat/window keeps disappearing" after clicking something. Root cause is almost always a route page. Do not churn presets hoping to fix it.

2. **The app reads and writes a live SQLite session store** (`$HERMES_HOME/state.db`), plus `sessions/sessions.json` and JSONL transcripts. A "stuck" or "abnormal" **chat** session is often a stale signal in `state.db`, not lost data.

## Restore the chat window (fast path)

```python
focus_pane(pane='chat')     # reveal the chat pane
apply_layout(preset='default')  # chat + left sessions + right file/terminal sidebars
```
If the user keeps hitting this, don't leave them with a manual flow — ship a one-click restore (see desktop plugin below): a status-bar button + a ⌘K palette command that call `host.navigate('/')` to jump out of the covering route back to the home/chat view.

Setting `apply_layout('default')` persists `hermes.desktop.layoutPreset.active` in the renderer localStorage — a restart-friendly default for "all panes visible".

## Desktop plugins (custom UI, no rebuild)

A plugin is ONE plain-JavaScript ESM file the app hot-loads — no build, no repo change.
- Location: `$HERMES_HOME/desktop-plugins/<id>/plugin.js` (folder name **must equal** `id`).
- Only import `@hermes/plugin-sdk`, `react`, `react/jsx-runtime`. Write UI with `jsx()`/`jsxs()`, NOT JSX syntax (file is uncompiled).
- Round-trip pattern used here: a `statusBar.right` chip + a `PALETTE_AREA` command, both calling `host.navigate('/')`.
- Hot-reloads on save; fallback **⌘K → Reload desktop plugins**. On load failure the app shows a toast naming the error.
- **Verify it really loaded** (don't trust the write alone): capture the app with `computer_use(mode='som')` and confirm the status-bar button exists in the element tree near bottom-right (e.g. a `Button` whose label matches, adjacent to the built-in `v0.20.6 HEAD` chip).

See `references/desktop-plugins.md` for a minimal known-good chip + palette command plugin.

## Fix a stuck / abnormal session (state.db)

A chat window that won't open / spins / shows as abnormal is frequently **context-compression failure + a stale compression lock**, not data loss.

Diagnose signs (query `state.db`):
- `compression_failure_error` like `'host compress_context timeout (no summary progress)'`.
- a `compression_locks` row for that session held by a live gateway process (`hermes serve`) but stuck.
- session too large: `~N tokens >= 500k threshold` → preflight compression fires before every turn and streams ~600s without progress.
- data is intact: `sessions.message_count` == `SET count(messages) WHERE active=1`; empty-content rows are normal (hidden / plain-empty assistant turns).

Fix sequence (back up first, always):
1. `cp state.db state.db.bak-<ts>`.
2. Delete the stale lock: `DELETE FROM compression_locks WHERE session_id='<id>'` (it is a concurrency semaphore — removing it drops NO messages).
3. Validate: `hermes sessions repair --check-only` → "opens cleanly — no repair needed"; lock count = 0; message counts intact.

Honest caveat: clearing the lock un-sticks the window, but a long session still exceeds the compression threshold and will re-stall next turn. Recommended durable fix = **archive the long session** (`hermes sessions archive`) and start a fresh one.

`hermes sessions` subcommands: list, export, delete, prune, archive, optimize, clean-markers, optimize-storage, repair (malformed schema), repair-routing, recover (non-destructive rebuild to a NEW file), stats, rename, pin/unpin, pinned, retitle-skills, browse, import. `repair`/`recover` are for structurally damaged DBs — a healthy DB (opens cleanly) does not need them.

See `references/session-repair.md` for the full worked case.

## Locate & change a desktop UI setting (no CDP — packaged build)

When the user asks to hide/show/change some UI element ("how do I get rid of
this?", "where's the setting for X?"), the desktop app is usually a **packaged
build with no CDP port** — the DOM-reading route is closed (`inspecting-hermes-
desktop-dom` is dev-server-only). The reliable path is to **grep the source tree
for the feature's storage key**, then tell the user the UI entry point.

Recipe:
1. **Find the storage key.** Desktop UI toggles persist via
   `persistentAtom(STORAGE_KEY, default, codec)` in
   `apps/desktop/src/store/*.ts`. Keys follow the `hermes.desktop.` convention.
   Grep the store dir for the feature's wording or a likely key name.
2. **Find what renders it.** Grep the consumer component. E.g. sidebar session
   rows' metadata string is built in `apps/desktop/src/app/chat/sidebar/
   session-row-details.ts` (joins `[model, messageCount, toolCallCount]` with
   `' · '`).
3. **Find the default + the toggle.** Read the store's `SIDEBAR_DEFAULT_*`
   constant; the menu that changes it (e.g. `filter-menu.tsx` imports
   `toggleSidebarRowMeta`, `resetSidebarView`). **Default ≠ what the user sees**
   usually means they (or a prior session) toggled it on.
4. **Tell the user the UI path, don't just name the file.** Give the menu
   (filter menu / appearance settings / a Reset entry), and offer to reset the
   storage key to default as a backstop.

Worked example (2026-08 — "模型·N条消息·N次工具调用" strip): sidebar session
rows show `deepseek-… · 75条消息 · 27次工具调用`. That string is built in
`session-row-details.ts` (`sessionRowDetails` joins `[model, messageCount,
toolCallCount]` with `' · '`). **It is NOT gated on `$sidebarRowMeta`** — the
row-meta enum (`cost | pr | preview | profile | tokens | updated` in
`apps/desktop/src/store/layout.ts`, key `hermes.desktop.sidebarRowMeta`,
default `['preview','updated']`) has NO model/message/toolCall entries, so
checking those row-meta boxes cannot produce this strip. The model + message
count actually render as the **card-row footer** — `session-row.tsx` does
`const model = card && session.model ? … : ''` and
`const size = card && session.message_count > 0 ? … : ''`. So the user sees it
because **card-row / inbox mode is on** (`$sidebarCardRows`) or the list density
is high (`hermes.desktop.sessionListDensity`: compact ≤ comfortable ≤ detailed).
Fix WITHOUT touching anything else = set list density to **compact**, or turn OFF
card rows. `resetSidebarView()` also removes it (it sets `$sidebarCardRows=false`),
but that resets grouping/sort/filters too. Do NOT send the user to the row-meta
checkboxes for this one — they are the wrong control. (If the exact gate is ever
ambiguous on a packaged build with no CDP port, grep the source for which
`card &&`/`rowMeta.includes(` guard wraps it; the two live in different clusters.)

## Pitfalls

- Don't blame the layout preset for a route-page takeover — check navigation first.
- Don't clear a compression lock before verifying it's stale; if a compressor is genuinely mid-run the lock is legit. Check age/expiry vs now, and whether the session is mid-turn.
- Always back up `state.db` before deleting any row.
- Don't tell the user a plugin works without confirming the chip/command actually rendered.
- Don't assume a live `127.0.0.1:9333` (or any CDP port) is the Hermes desktop. A user's browser-automation tool (workbench/PDD Chromium) can bind a port too — `curl json/version` returning `Chrome/…` just proves *some* Chromium. `curl json/list` and check the `page` titles are Hermes surfaces before acting.
- **"How do I hide X" — answer the control fast, don't reverse-read the store.** For a simple ask like "get rid of this UI element", the user wants the setting, not an archaeology session. Grep the source once for the storage key + the `card &&` / `rowMeta.includes(` guard that wraps it, map that to a user-facing control (list density, card rows, a checkbox), and *give the answer*. Do NOT spend turns reading leveldb/Local Storage binaries (they're encoded, greps come up empty, it's slow) and don't offer to rewrite the store's localStorage as the primary fix — a setting the user can toggle in the menu is the right answer. If you can't pin the exact gate after a couple of grep passes, pause and ask which screen they're looking at rather than escalating into buried-file forensics they don't care about.
- ⚠️ **A workspace path containing an emoji breaks `MEDIA:` file delivery — always hand over a copy at an emoji-free path.** Verified twice (2026-09): the window's workspace was `...\Hermes Agent\日常沟通🌅\`, and sending `MEDIA:<that path>\<report>.xlsx` made the user's download fail with "下载失败 / File not found" **even though the file was present on disk** (confirmed by an existence + size check). The path contained U+1F305 🌅; an astral-plane character in the handoff path is what breaks the servable-path build — it is NOT a missing file, so do not go hunting for a deleted file. Fix: `shutil.copy2` the artifact to an emoji-free directory (the Desktop, or `$HERMES_HOME/attachments/`) **before** emitting `MEDIA:`, and send that path. Still produce the artifact where the user's file rules want it (their bound workspace) — just deliver from the safe copy, and say both paths so they can go get it either way.
  Corollary: when the user reports "下载失败" twice in one session, expect the emoji workspace as the first hypothesis, not a missing file.
