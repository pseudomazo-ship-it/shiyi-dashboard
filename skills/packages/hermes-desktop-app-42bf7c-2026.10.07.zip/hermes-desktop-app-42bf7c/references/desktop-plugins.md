# Desktop Plugin — Known-Good "Back to Chat" (show-chat)

Verified working. Adds a status-bar button + a ⌘K palette command, both of which `host.navigate('/')` to jump back to the home/chat view.

Save as `$HERMES_HOME/desktop-plugins/show-chat/plugin.js` (folder name == `id`). Hot-reloads on save; fallback **⌘K → Reload desktop plugins**.

Only `@hermes/plugin-sdk`, `react`, `react/jsx-runtime` may be imported. UI is `jsx()`/`jsxs()`, never JSX syntax (file is uncompiled). Keep components small; read state imperatively in handlers (`$.get()`), not from render closures.

```js
import { cn, host, Tip, usePluginI18n } from '@hermes/plugin-sdk'
import { jsx, jsxs } from 'react/jsx-runtime'

const ID = 'show-chat'

function backToChat() { host.navigate('/') }

function Chip() {
  const t = usePluginI18n(ID)
  return jsx(Tip, {
    label: t('chipTip'),
    children: jsx('button', {
      className: cn(
        'inline-flex h-full items-center gap-1 px-1.5 text-[0.6875rem] transition-colors',
        'text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover) hover:text-foreground'
      ),
      type: 'button',
      onClick: () => { backToChat() },
      children: t('chip')
    })
  })
}

export default {
  id: ID,
  name: '回到全部显示',
  register(ctx) {
    ctx.i18n.register({
      en: { chip: '全部显示', chipTip: '回到 聊天 + 全部面板 视图' },
      zh: { chip: '全部显示', chipTip: '回到 聊天 + 全部面板 视图' }
    })
    // status-bar chip (right)
    ctx.register({ id: 'chip', area: 'statusBar.right', order: 150, render: () => jsx(Chip, {}) })
    // ⌘K command
    ctx.register({
      id: 'command',
      area: 'PALETTE_AREA',
      title: '回到全部显示(聊天视图)',
      run: () => { backToChat() }
    })
  }
}
```

## Verification (don't trust the write alone)
1. Reload plugins (⌘K). Then capture the app: `computer_use(action='capture', mode='som', app='Hermes')`.
2. In the returned element tree, confirm a `Button` whose label = the chip text exists at bottom-right, adjacent to the built-in `v0.20.6 HEAD` button. That proves the plugin loaded and rendered.
3. Read the element JSON (saved under `$HERMES_HOME/cache/computer_use/elements_*.json`) to pin the exact label/bounds if the summary is unclear.

## Notes
- A plugin's export default shape is `{ id, name, register(ctx) }`; `idx` must match the folder name.
- No hardcoded colors/backgrounds — panes already sit on the app background. Use theme vars (`var(--ui-text-secondary)`, `var(--ui-accent)`, …).
- If a plugin fails to load the app shows a toast naming the error — fix the file and re-save (hot reload).
- `host.navigate('/')` returns to the home/chat route; `host.navigate(path)` is the general navigation primitive.
