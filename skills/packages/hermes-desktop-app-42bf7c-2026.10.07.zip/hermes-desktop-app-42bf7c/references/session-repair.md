# Fix a Stuck / Abnormal Hermes Session (state.db)

Worked case: session `20260829_205422_996155` (日常沟通🌅, 857 active messages) reported as "聊天窗口异常".

## Root cause observed

The session had grown to `~646,303 tokens`, **above the ~500,000 preflight-compression threshold**. Every time it was resumed, a preflight compression fired and **streamed for 600s without making progress**, repeatedly, leaving: (a) `compression_failure_error`, (b) a stale `compression_locks` row held by a live-but-stalled gateway process (`hermes serve`). The chat window spun / wouldn't open because it was stuck waiting on that compression.

This is NOT lost data — the transcript (857 active rows of 1697) was fully intact.

## Diagnostic SQL (run against `$HERMES_HOME/state.db`)

```python
import sqlite3, time, datetime
con = sqlite3.connect('state.db'); con.row_factory = sqlite3.Row
sid = '<session_id>'
now = time.time()

# 1) compression lock for this session
for r in con.execute('SELECT * FROM compression_locks WHERE session_id=?', (sid,)):
    d = dict(r)
    print('holder', d['holder'], 'acquired', datetime.datetime.fromtimestamp(d['acquired_at']),
          'expires', datetime.datetime.fromtimestamp(d['expires_at']),
          'status', 'OK' if now < d['expires_at'] else 'EXPIRED')

# 2) session failure fields
for r in con.execute("SELECT compression_failure_error, compression_failure_cooldown_until FROM sessions WHERE id=?", (sid,)):
    print(dict(r))

# 3) integrity: message_count should equal active=1 count
mc = con.execute('SELECT message_count FROM sessions WHERE id=?', (sid,)).fetchone()[0]
act = con.execute('SELECT COUNT(*) FROM messages WHERE session_id=? AND active=1', (sid,)).fetchone()[0]
print('message_count', mc, 'active', act, 'MATCH' if mc == act else 'MISMATCH')

# 4) confirm data intact
print('first:', dict(con.execute('SELECT id,role,timestamp FROM messages WHERE session_id=? ORDER BY id LIMIT 1', (sid,)).fetchone()))
print('last :', dict(con.execute('SELECT id,role,timestamp FROM messages WHERE session_id=? ORDER BY id DESC LIMIT 1', (sid,)).fetchone()))
con.close()
```

Note: `sessions` has NO `created_at`/`error`/`session_id` columns — use `last_activity_at`, `id`, and check `PRAGMA table_info(sessions)` for the real column names. `gateway_routing` uses `session_key`, not `session_id`.

## Fix (back up first, always)

```bash
cp state.db state.db.bak-$(date +%Y%m%d_%H%M%S)
```

```python
import sqlite3
con = sqlite3.connect('state.db')
n = con.execute('DELETE FROM compression_locks WHERE session_id=?', ('<session_id>',)).rowcount
con.commit(); print('deleted', n)
con.close()
```

`compression_locks` is a concurrency semaphore — deleting the row drops NO messages.

## Validate

```bash
hermes sessions repair --check-only   # expects: "opens cleanly — no repair needed"
# confirm lock count = 0 and message counts intact
```

## Important caveat

Clearing the lock un-sticks the window, but the session still exceeds the compression threshold, so it will try to compress again next turn and can re-stall. The durable fix is to **archive the long-running session** (`hermes sessions archive` — soft-hide, no deletion) and start a fresh one. If the user wants to keep working in it, expect slow/stalling behavior on a >500k-token session.

## `hermes sessions` subcommands (for reference)

list, export, delete, prune, archive (soft-hide), optimize, clean-markers (stale #78148 tool-call markers — dry-run available), optimize-storage, repair (malformed schema), repair-routing, recover (non-destructive rebuild to a NEW file, offline), stats, rename, pin/unpin, pinned, retitle-skills, browse, import.

`repair`/`recover` are for a structurally damaged DB (schema errors, missing sessions). A DB that opens cleanly does NOT need them — do not run repair/recover casually. `clean-markers --dry-run` first to check whether the stale-marker class even applies.
