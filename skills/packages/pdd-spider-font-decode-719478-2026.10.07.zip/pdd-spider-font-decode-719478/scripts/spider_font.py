# -*- coding: utf-8 -*-
"""拼多多 spider-font 加密数字解码（2026-09-19 实测可用）

用法 A —— 在 browser-use / Hermes browser_exec 环境里（js() / cdp() 已注入）：

    import sys; sys.path.insert(0, r"<技能目录>\\scripts")
    import spider_font as sf
    mapping, raw = sf.page_map(js)          # 建当前页面的 码点->数字 映射
    print(sf.decode('整段原始文本', mapping))

用法 B —— 冷启动（参考位图对不上时）：

    d = json.loads(js(sf.cold_start_js()))  # d['data'] 是 dataURL，存成 PNG
    # 用视觉模型认字 -> mapping = {0xE5ED: '5', ...}
    # 校验必须是 0-9 双射，然后：
    sf.save_ref(sf.make_ref(js, mapping))   # 重建 references/glyph_ref.json

用法 C —— 直接跑本文件自检参考库是否完整：

    python spider_font.py
"""
import json
import os

REF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'references', 'glyph_ref.json')

# ---------------------------------------------------------------- 渲染 JS
_RENDER = r"""(async () => {
  if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch(e){} }
  const cps = new Set();
  document.querySelectorAll('span.__spider_font').forEach(el => {
    for (const c of (el.textContent||'')) { const cp = c.codePointAt(0);
      if (cp >= 0xE000 && cp <= 0xF8FF) cps.add(cp); }
  });
  const list = [...cps].sort((a,b)=>a-b);
  const c1 = document.createElement('canvas'); c1.width = 120; c1.height = 170;
  const k1 = c1.getContext('2d');
  const c2 = document.createElement('canvas'); c2.width = 56; c2.height = 56;
  const k2 = c2.getContext('2d', { willReadFrequently: true });
  const sig = (cp) => {
    k1.clearRect(0,0,120,170); k1.fillStyle = '#000';
    k1.font = '110px spider-font'; k1.textBaseline = 'top';
    k1.fillText(String.fromCodePoint(cp), 8, 6);
    k2.clearRect(0,0,56,56); k2.drawImage(c1, 6, 2, 112, 120, 0, 0, 56, 56);
    const d = k2.getImageData(0,0,56,56).data; let s = '';
    for (let i = 3; i < d.length; i += 4) s += d[i] > 90 ? '1' : '0';
    return s;
  };
  const sigs = {};
  list.forEach(cp => { sigs['0x' + cp.toString(16).toUpperCase()] = sig(cp); });
  return JSON.stringify({ cps: list.map(c => '0x' + c.toString(16).toUpperCase()), sigs });
})()"""

_COLD = r"""(async () => {
  if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch(e){} }
  const cps = new Set();
  document.querySelectorAll('span.__spider_font').forEach(el => {
    for (const c of (el.textContent||'')) { const cp = c.codePointAt(0);
      if (cp >= 0xE000 && cp <= 0xF8FF) cps.add(cp); }
  });
  const list = [...cps].sort((a,b)=>a-b);
  const c = document.createElement('canvas');
  c.width = 120 * list.length; c.height = 170;
  const k = c.getContext('2d');
  k.fillStyle = '#fff'; k.fillRect(0, 0, c.width, c.height); k.textBaseline = 'top';
  list.forEach((cp, i) => {
    k.fillStyle = '#000'; k.font = '110px spider-font';
    k.fillText(String.fromCodePoint(cp), i * 120 + 8, 6);
    k.fillStyle = '#c00'; k.font = '22px monospace';
    k.fillText('U+' + cp.toString(16).toUpperCase(), i * 120 + 4, 128);
  });
  return JSON.stringify({ cps: list.map(c => '0x' + c.toString(16).toUpperCase()), data: c.toDataURL('image/png') });
})()"""


# ---------------------------------------------------------------- 基础函数
def load_ref(path=None):
    return json.load(open(path or REF_PATH, encoding='utf-8'))


def save_ref(ref, path=None):
    json.dump(ref, open(path or REF_PATH, 'w', encoding='utf-8'))


def _diff(a, b):
    return sum(1 for x, y in zip(a, b) if x != y)


def build_map(sigs, ref=None, max_diff=120):
    """sigs: {'0xE5ED': '0101...'}  ->  {57325: '5', ...}"""
    ref = ref or load_ref()
    out = {}
    for key, s in sigs.items():
        best, bd = None, 10 ** 9
        for dg, rs in ref.items():
            k = _diff(s, rs)
            if k < bd:
                bd, best = k, dg
        if best is not None and bd < max_diff:
            out[int(key, 16)] = best
    return out


def decode(raw, mapping):
    """PUA 码点 -> 数字；普通数字与小数点原样保留；其余（千分位逗号等）丢弃"""
    o = ''
    for ch in (raw or ''):
        cp = ord(ch)
        if 0xE000 <= cp <= 0xF8FF:
            o += mapping.get(cp, '?')
        elif ch.isdigit() or ch == '.':
            o += ch
    return o


# ---------------------------------------------------------------- 页面侧接口
def snapshot(js):
    """js: browser-use 的 js() 函数；返回 {cps:[...], sigs:{...}}"""
    return json.loads(js(_RENDER))


def page_map(js):
    """返回 (mapping, raw)。mapping={码点:数字}，raw 便于排查"""
    raw = snapshot(js)
    return build_map(raw['sigs']), raw


def cold_start_js():
    """渲染当前 10 个字形成一张 PNG，交给视觉模型认字（只需一次）"""
    return _COLD


def make_ref(js, mapping):
    """用已确认的 {码点:int -> 数字:str} 生成参考位图库"""
    raw = snapshot(js)
    ref = {}
    for key, sig in raw['sigs'].items():
        dg = mapping.get(int(key, 16))
        if dg:
            ref[dg] = sig
    return ref


# ---------------------------------------------------------------- 取值辅助
def cell_value(text):
    """单元格文本 -> 去掉对比列后的原始段（解码前先切）"""
    import re
    return re.split(r'较前1月|较前1日|昨日', text or '')[0]


def sanity_by_ratio(uv, buyers, cvr, tol=0.02):
    """自检：成交转化率 应等于 买家数/访客数*100。返回 (ok, 计算值)"""
    try:
        u, b, c = float(uv), float(buyers), float(cvr)
    except Exception:
        return None, None
    if u <= 0:
        return None, None
    calc = b / u * 100
    return abs(calc - c) <= tol, round(calc, 2)


if __name__ == '__main__':
    print(__doc__)
    try:
        ref = load_ref()
        lens = {len(v) for v in ref.values()}
        print('参考字形数字:', sorted(ref.keys()))
        print('位图长度一致:', lens, '(应为 {3136})')
        print('参考库完整:', '是' if sorted(ref.keys()) == list('0123456789') else '否 —— 需要冷启动重建')
    except FileNotFoundError:
        print('没有 references/glyph_ref.json —— 走冷启动流程')
