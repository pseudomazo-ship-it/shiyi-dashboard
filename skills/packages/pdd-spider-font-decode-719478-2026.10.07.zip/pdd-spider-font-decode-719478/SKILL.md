---
name: pdd-spider-font-decode
description: Use when 拼多多后台数字读不到(spider-font加密/PUA码点)。字形位图比对自动解码，不靠OCR。
metadata:
  hermes:
    tags: [pinduoduo, anti-scraping, font-decode, canvas, cdp]
    category: ecommerce
---

# 拼多多 spider-font 加密数字解码

拼多多商家后台（商品数据 / 评价数据等页）的数值用**自定义字体加密**：DOM 里不是数字，是私用区码点，直接读是空的或乱码。本技能给出**自动解码法**（不靠 OCR，不靠破解字体文件）。

## 什么时候用（识别特征）

- 页面数字读出来是空的 / 乱码 / 只有 `较前1月`、`昨日` 这类文案
- 元素 class 含 **`__spider_font`**
- `getComputedStyle(el).fontFamily === 'spider-font'`
- `textContent` 里是 **U+E000–U+F8FF 私用区码点**
- 字体文件形如 `https://genimg.pddpic.com/upload/mms-trusteeship/fonts/<hash>.otf`

⚠️ **先确认是不是真的加密**：同一个页面「实时」模式往往是**明文 ASCII 数字**，只有历史区间（昨日/7日/30日/月/自定义）才加密。别一看读不到就说被加密了。

## 核心原理（2026-09-19 实测，关键）

**字形跨轮换稳定 —— 每次刷新只换「码点 ↔ 字形」的映射，字形本身不变。**

实测两轮独立渲染的对比（10 个字形两两比）：
- 同字形差异 **0.2–2.4**
- 次优匹配（最像的另一个数字）差异 **9.6–32.0**
- **10/10 全中**

所以：**一次人工确认参考字形 → 之后全自动**。参考位图已存 `references/glyph_ref.json`。

## 渲染参数（必须与参考完全一致，否则位图对不上）

```js
c1 = canvas 120×170 ; k1.font = '110px spider-font' ; k1.textBaseline = 'top'
k1.fillText(String.fromCodePoint(cp), 8, 6)
c2 = canvas 56×56 ; k2.drawImage(c1, 6, 2, 112, 120, 0, 0, 56, 56)
读取 c2 ImageData，alpha > 90 → '1'，否则 '0' → 3136 位字符串
```

比对用**汉明距离**（逐位不同的个数）：`diff < 120` 判定命中。

## 标准流程

1. **收码点**：`document.querySelectorAll('span.__spider_font')` 里所有 U+E000–F8FF 码点去重
2. **渲染字形**：按上面参数每个码点生成 3136 位签名
3. **建映射**：每个签名与 `references/glyph_ref.json` 的 0-9 参考位图比汉明距离，取最小且 < 120
4. **解码**：PUA 码点 → 对应数字；**普通数字和 `.` 原样保留**；千分位逗号等其他符号丢弃
5. **自检**（必做，见下）

直接用 `scripts/spider_font.py`：
```python
import sys; sys.path.insert(0, r"<技能目录>\scripts")
import spider_font as sf
mapping, raw = sf.page_map(js)      # js = browser-use 的 js()
print(sf.decode(cell_text, mapping))
```

## 冷启动（没有参考位图 / 参考对不上时）

1. `sf.cold_start_js()` 把当前 10 个字形渲染成一张带 U+ 编号的 PNG
2. **用视觉模型认字**（只需一次）：提示词要求按「U+XXXX = 数字」逐行输出，并强调“只管它看起来像什么数字”
3. 检查是否得到 **0-9 各一次的双射** —— 不是双射就说明认错了，重来
4. 拿这个映射调 `sf.make_ref(js, mapping)` + `sf.save_ref()` 重建参考位图库

> 码点会轮换，但**别硬编码码点**；硬编码的映射下次刷新就失效，参考位图不会。

## 解码后必做的自检（本类任务头号坑）

| 检查 | 做法 |
|---|---|
| **内部一致性（最强）** | 找页面上存在算术关系的两列。商品数据页：**成交转化率 = 成交买家数 ÷ 商品访客数 × 100**。实测 6/6 精确吻合（8.94 / 7.43 / 8.23 / 4.06 / 11.59 / 13.01） |
| 位宽 | 商品ID 必须 **12 位**（多一位说明把邻格数字吸进来了） |
| 取值不要整行文本 | 数字与相邻文案会粘连：`ID: 265026677903` 紧跟规格 `1升大容量` → 正则 `\d{6,}` 会抠出 13 位。**必须按 DOM 节点取值** |
| 切掉对比列 | 单元格文本 = 值 + `较前1月` + 百分比，取 `textContent.split(/较前1月|昨日/)[0]` |

## 反面教材（别走这条路）

- **不要用 OCR 读宽表**：实测让视觉模型读一页 42 行表格，**商品ID 全部读错**（十多位乱拼）。宽表 + 密集数字必须走 DOM。
- **不要试图解析字体文件（cmap/glyf）**：字形稳定这一点已经够用，位图比对更简单也更稳。
- **不要写死映射表**：码点每轮刷新都变。

## 相关

- 页面「只认真人点击」的问题（同一批页面常见）：见技能 `pdd-store-monthly-stats` 第六节；采集配方见 `pinduoduo-merchant-cdp` 的 `references/evaluation-review-harvest.md`。
- 参考位图：`references/glyph_ref.json`（0-9 各一条 3136 位）
- 历史映射样例：`references/mapping_examples.md`（仅供理解机制，别硬编码）
