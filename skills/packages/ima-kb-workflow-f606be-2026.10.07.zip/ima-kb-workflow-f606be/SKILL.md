---
name: ima-kb-workflow
description: Use when generating IMA notes or searching the IMA KB.
---

# IMA 知识库/笔记工作流（十一）

This window has TWO standing functions (user-defined contract — applies every session, no re-confirmation):

## Function 1 — 笔记生成上传
**⚠️ 全局规则（2026-09-20 十一更新，所有聊天窗口生效）**：工作区产出 md **定版后须先问十一是否同步**（**不再自动上传**）——“我判断已定版”就主动问一句「这份 md 要不要同步到 IMA 知识库？」，十一说「**md去知库**」才传。范围＝业务留痕 / README / 软件说明 / 技术文档；→ 同步到「**Agent知识库（记忆留痕记录）**」；标题格式 `【Hermes-办公室】+内容+生成日期(YYYY.MM.DD)`。
（旧规则「只要生成了笔记 md 就自动上传」已于 2026-09-20 作废——十一原话：“你不需要我确认核对后最终定版后……你需要询问我是否同步”。）

User sends learning material → produce a note per the IMA note rules → upload + link to knowledge base.
Full rules doc: `references/ima-notes-rules.md`. Compact essentials:

- Title `# **【平台】主题内容.**` → next line 整理日期 → next line 加粗的一句话核心结论.
- 第一章固定 `## 1. 核心理解`; default ~5 chapters (核心理解 / 核心数据或判断标准 / 操作方法 / 风险与注意事项 / 执行清单).
- 子要点统一用 `·`; tables keep only key fields and must end with a conclusion.
- 事实分级标注：条款规定 / 视频观点 / 原文观点 / 运营经验; uncertain content → `⚠️ 需核实` or delete.
- **⚠️ 生成前对齐口径（十一提醒，勿自造简化定义）**：拼多多/抖音主题笔记，生成前先 `search_knowledge` 在对应平台库搜该主题；若库里已有**权威/官方口径**笔记，以库内口径为准。例：投产比平台口径分**实际/净实际/结算**三种——实际=交易额÷成交花费(未剔退单)，净实际=净交易额÷成交花费(剔秒退，系统默认促进净成交主要看它)，结算=结算金额÷成交花费(剔30天内退款)；「投产比=销售额÷花费」属过度简化。欠定名词口径(投产/ROI/转化率/评价得分等)一律以库内权威笔记为准——例：拼多多近90天用户评价得分是黑盒(平台剔'不真实'评价、算法不公开)，自算算术平均≠平台分，勿用算术平均硬套。
- 必用 Humanizer（只调表达/语气/段落连接 — 严禁改事实、数字、日期、作者、链接、后台路径、结论、结构、表格、口诀）.
- 本地图片删除并明确告知（接口不支持本地图）; 网络图片保留。结尾必有 记忆口诀.
- Write via `openapi/note/v1/import_doc` (content_format=1, i.e. Markdown), then `add_knowledge` media_type=11 linking the returned note_id to the **per-platform KB from the mapping table below**（「十一的知识库」是**兜底，不是默认**）。
- **Success = TWO `code:0,msg:success`** (note created + kb linked). On failure say "存储失败" and KEEP the note.
- **大笔记必须分块上传（易踩 100009 大小上限）**：超过单篇上限（约万字级，报 `100009`）时，拆成多块——`import_doc` 写第1块拿 `note_id`，其余每块 `append_doc`（`content_format:1`）。经验块大小 ~7000 字符安全。**上传前先把内容里自加的"分块标记行"（如 `#[](...)`）删掉**，否则会写进笔记；写入前确认全是合法 UTF-8（GBK/乱码会不可逆）。
- **⚠️ 读回校验的坑**：`get_doc_content` 用 `target_content_format=0`（纯文本）读回时**会剥掉 Markdown 标记**（#标题/表格|/代码围栏等），所以读回字节数**远小于**上传字节数，这是正常、不是截断——验证看**开头/标题是否在**，别按长度比对。
- **找知识库 ID 不用猜**：`search_knowledge_base` `{"query":"","cursor":"","limit":20}` 列全部（`data.info_list[].kb_id` + `kb_name`），按名字匹配目标库，再 `add_knowledge`（media_type=11 + `note_info.content_id=<note_id>`）。字段名是 `kb_id`/`kb_name`（不是 name/title）。**⚠️ `limit` 上限是 20**（`(0,20]`），传 `limit:50` 会报 `code 51: invalid ... Limit`，直接失败——列库/检索一律用 `limit:20`。
- **⚠️ 上传前先去重（规则①的落地动作）**：往某库 upload 笔记前，先 `search_knowledge` 在该库搜主题关键词，看是否已存在（同名/同主题/同内容）笔记。有重叠→按规则①**合并或跳过**（读旧笔记内容，把旧版+新版信息合并成一篇，删旧留新），而不是盲目再建一篇造成重复。无重叠→正常 upload。

## Function 2 — 知识库问答（默认不联网）
User asks a question → search the knowledge base ONLY. Do NOT call web-search by default — this is a hard boundary.

- **Found:** answer from KB content, cite the source note title + provenance (条款规定 / 视频观点 / 原文观点 / 运营经验).
- **Not found:** say "不知道" directly, then ask the user ONCE whether they want a web search.
- Do not invent/normalize numbers, thresholds, or source provenance from memory.
- **检索范围 = 全部知识库（自建 + 订阅）**，**每次实时同步**：查询/列库时动态拉 API 最新状态，不用旧缓存/快照。订阅库（会计审计、国家法律法规、AI 类等）内容归创建者维护、以实时拉取为准；订阅库**同样可查**（十一明确）。列库用 `search_knowledge_base` `{"query":"","limit":20}` 分页翻到 `is_end=true`。

### Concrete lookup chain (validated end-to-end)
1. Find KB: `openapi/wiki/v1/search_knowledge_base` `{"query":"<平台关键词>","cursor":"","limit":20}` → `data.info_list[].kb_id`
2. Search content in that KB: `openapi/wiki/v1/search_knowledge` `{"query":"<关键词>","knowledge_base_id":"<kb_id>","cursor":""}` → `info_list[].media_id` (note_...)
3. For a note (media_type=11): `openapi/wiki/v1/get_media_info` `{"media_id":"<media_id>"}` → `data.notebook_ext_info.notebook_id`
4. Read content: `openapi/note/v1/get_doc_content` `{"note_id":"<notebook_id>","target_content_format":0}` → `data.content` (plain text; Markdown read NOT supported)
- **note_id for get_doc_content = the notebook_id from step 3.** target_content_format=0.
- 🛠 **别手写 node 一行式 —— ima-skill 目录里有两个现成的封装脚本，直接跑就行**（2026-10-06 实测省一轮）：
  ```bash
  cd C:/Users/Administrator/.workbuddy/skills/ima-skill
  node _list_kb.cjs                              # 列所有库：名字 + base_type + 内容数 + kb_id
  node _search_kb.cjs "<kb_id>" "<关键词>"        # 在指定库里搜，直接打出序号/标题/media_id
  ```
  `_search_kb.cjs` 内部走的就是 `openapi/wiki/v1/search_knowledge`（带 `knowledge_base_id`），
  已经处理好分页与 `code!=0` 打印 —— **比手拼 `ima_api.cjs ... '{"query":...}'` 稳**，
  而且**路径不带前导 `/`**（写成 `"/openapi/v1/..."` 会静默返回空、exit 0，见下文 Pitfalls）。
- **找笔记 `note_id` 的偷懒法（实测可靠）**：`_search_kb.cjs` 打出的 `media_id` 形如
  `note_<hash>_<note_id><一串后缀>` —— 中间的纯数字段就是 `note_id`，可直接喂 `append_doc` / `get_doc_content`。
  （规范做法仍是 `get_media_info` → `notebook_id`，但手上只有 media_id 时先目测提取能省一步。）
- **⚠️ 「读不到某篇笔记」别先怀疑库选错**：先用 `_list_kb.cjs` 确认库名，再 `_search_kb.cjs` 换主题词试（规则类内容多以**产品名/平台名**作标题，用正文词搜必然空）。
- **⚠️ `search_knowledge` 只匹配「标题/条目名」，不搜正文**（2026-09-26 实踩）：在「公司：各事项/第三方」搜「**记忆**」返回 `info_list: []`，但库里确实有讲记忆的笔记——因为「记忆」只出现在**正文**里。**搜不到 ≠ 库里没有，别据此向十一说「不知道」**。两条补救：
  1. **换主题词/文件夹名再搜**：改搜「**探域**」立刻命中文件夹 `探域机器人` + 一批笔记。规则类/产品类内容多以**产品名/平台名**作标题，用正文词去搜必然空。
  2. **按正文搜笔记**（真正的正文检索，走 **notes** 模块不是 wiki）：
     ```
     openapi/note/v1/search_note
     {"search_type":1,"query_info":{"content":"买家记忆"},"start":0,"end":20}
     ```
     `search_type`：**0=按标题，1=按正文**。返回 `search_note_infos[].note_book_info.note_id` —— **可直接喂给 `get_doc_content`，省掉第 3 步 get_media_info**（第 3 步只在手上只有 wiki `media_id` 时才需要）。翻页按 `start/end` 递增。
- **⚠️ 别把临时文件写到 MSYS 的 `/tmp` 再用 native node/python 读**：git-bash 的 `>` 能写 `/tmp/x.json`，但**原生 node/python 解析不了 MSYS 路径**（会当成盘根），读回必报 `FileNotFoundError`。要么**用管道**（`"$NODE" ... | python -c "json.load(sys.stdin)"`），要么写到 Windows 原生临时目录（`$LOCALAPPDATA/Temp/...`，正斜杠）。中文输出先 `export PYTHONIOENCODING=utf-8`。

> 📁 **探域客服机器人**（十一的专用机器人）资料定位 + 「记忆」功能权威规格见 `references/tanyu-bot-docs.md`。

### 📁 浏览库内文件夹 + 把内容传进指定子文件夹（2026-10-03 实测）

十一说「传到 X 知识库里的 Y 文件夹」时，Y 往往是库里的**子文件夹**，不是库根目录：

```
① 列「我有权限添加」的库：openapi/wiki/v1/get_addable_knowledge_base_list  {"limit": 50}
   → data.addable_knowledge_base_list[].{name, knowledge_base_id}      （11 个）
   ⚠️ limit 上限 50（(0,50]），不传报 code 51

② 列该库根目录：openapi/wiki/v1/get_knowledge_list
   {"knowledge_base_id": "<kb_id>", "limit": 50}
   → data.knowledge_list[].{media_id, title, parent_folder_id, media_type}
     · media_type=99 且 media_id 以 `folder_` 开头 → 这是**文件夹**
     · 其余（如 media_type=11）→ 笔记
   → data.current_path[] = 当前位置（folder_id / name）
   → data.is_end / data.next_cursor 翻页
   ⚠️ knowledge_base_id 必填，不传报 code 51（它不是「列全部库」的接口）

③ 上传到该文件夹：add_knowledge 带 folder_id，值 = 那个文件夹的 media_id（原样带 `folder_` 前缀）
```

**实测（拼多多库）**：`拼多多-电商学习📚` 根目录下 9 个条目**全是文件夹**（media_type=99）：
日常学习-记录 / 原著材料 / 多多进宝 / 营销活动 / 营销工具 / **帮助中心** / 规则相关 / 推广营销 / 基础知识。
⚠️ 名称里用的是全角竖线 `拼多多丨帮助中心`（不是 `拼多多-帮助中心`）——**按 `title` 精确匹配，别照十一的口头叫法拼字符串**。

**另一个列库入口**：`search_knowledge_base` 用 **`keyword`**（不是 `query`）+ `limit:20`，
返回 `data.info_list[].{kb_id, kb_name, base_type, role_type, member_count, content_count, creator}`
—— `base_type` 能区分「我自建的 / 我加入的订阅库」，用来判断某个库归谁维护。

---

## Default knowledge base mapping (per platform / topic) — 2026/09/05 十一确认 full set
- 拼多多内容 → 「拼多多-电商学习📚」 (PDD term/规则 questions default to THIS KB only)
- 抖音/抖店内容 → 「抖音/抖店-电商学习」
- 小红书内容 → 「小红书-电商学习」
- 淘天（淘宝+天猫）内容 → 「淘天平台-电商学习」
- 京东内容 → 「京东JD-电商学习」
- **AI / Hermes / Agent / 记忆留痕相关 → 「Agent知识库（记忆留痕记录）」**（十一自建，非兜底，别混入「十一的知识库」）
- 快递/物流/仓储/云仓/吉客云/对账等公司内部事项 → 「公司：各事项/第三方」
- 其他无法区分 → **兜底:「十一的知识库」**(link with media_type=11)
- **总规则（2026-09 十一明确，所有窗口生效）：**
  - **规则① 只留最新**：知识库内笔记与新版内容重叠时，把旧笔记和**新版合并**，**删旧留新**。同主题同知识库只保留最新一篇，不堆积旧版。
  - **规则①b 权威篇差异补充（2026-09 十一明确）**：若知识库已有一篇**权威/完整篇**（如《【蒙倩】快递决策看板完整规则与计费口径.》），优先**保持权威篇为唯一主页**，把其他版本（工作区md/旧笔记）里的**新增增量**（如价格对比规律、新数据、新规则）**差异补充进权威篇**，让权威篇一次性包含全部，避免两处维护。不新建重复版本。
  - **规则② 分配兑底**：有对应的知识库就分配进对应库；没有符合的，一律用「十一的知识库」兑底。

### 知识库分配决策（按内容主题挑目标库）
1. 有明确平台库（拼多多/抖音/小红书/淘天/京东/快手/公众号）→ 用该平台库（各自平台→各自库）
2. **AI / Hermes / Agent / 记忆留痕相关 → 「Agent知识库（记忆留痕记录）」**
3. 公司内部事项（财务/快递/云仓/客服/人事/私域/主体/吉客云）→ 「公司：各事项/第三方」
4. 以上都不匹配 → 「十一的知识库」（兜底）

## Credentials & execution
- Credentials at `~/.config/ima/client_id` + `api_key` (or env `IMA_OPENAPI_CLIENTID` / `IMA_OPENAPI_APIKEY`).
- **⚠️ 脚本稳定路径**（不用猜目录；本机 skills/ 可能被同步还原，官方目录不稳定）：`C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs`（`.codex`、`.workbuddy` 均有该 skill 备份）。
- **Windows 下 node 一律用 C:/ 正斜杠路径**（native node 不认 MSYS `/c/...`，会把 `/c/...` 误解析成 `E:\c\...` 导致 MODULE_NOT_FOUND）：`node "C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs" "<apiPath>" '<json body>'`。若 skills 目录版可用也可 `cd <ima-skill dir> && node ima_api.cjs ...`，但该目录可能被还原，优先 .workbuddy 稳定路径。
- Read the ima-skill submodules first (`knowledge-base/SKILL.md` for wiki endpoints, `notes/SKILL.md` for note endpoints) to confirm exact request shapes.

## Pitfalls
- **Never hardcode** kb_id / media_id / note_id — always re-resolve via search each time.
- **⚠️⚠️ IMA 笔记标题 = 内容首行（md 的 `# ` 行），`import_doc` 的 `title` 参数无效**（2026-09-20 实踩）：传了 `title` 也没用，IMA 取**正文第一行**作标题 → 实际标题变成了工作区 md 原本的首行「云仓费用规则总表（广西岑溪云仓 · 中通）」，被十一指出「**你实际同步的标题不对**」。**正确做法：上传前先把 md 文件首行改成目标标题（如 `# 【Hermes-办公室】云仓费用规则总表（中通）2026.09.20`），再 `import_doc`**。传错后无更新接口 → 只能**重建一篇 + 请用户在 IMA 客户端手动删旧篇**（额外告知旧篇标题便于搜到）。验证：`search_knowledge` 有 **~10 秒索引延迟**，刚传完搜到的可能还是旧的，应改用 `get_doc_content` 读回首行确认。
- **Never claim saved** unless BOTH import_doc and add_knowledge return `code:0,msg:success`.
- Don't expose internal IDs (kb_id / media_id / folder_id / note_id) to the user — show titles/names.
- Each kb_id differs per lookup; e.g. `拼多多-电商学习📚` kb_id is not stable across the notes-generate flow vs the Q&A flow — always search_knowledge_base first.
- **`add_knowledge` 可能返回 `code:220001 知识重复添加`**：该主题内容在目标库**已存在**（或被判重复）时拒绝添加。这不是成功——别当 success；用 `search_knowledge` 在该库搜主题确认到底在不在、是否需合并去重（规则①），而不是以为添加了。
- **⚠️ 无「整篇更新/覆盖」笔记的接口，只有 `append_doc` 追加**（2026-09 实测）。要更新已有笔记（十一说「同步在我的笔记内」+发知识库列表截图 = 更新截图里那篇，**不是新建**）时：`search_knowledge`(主题关键词) 取 `media_id` → `get_media_info` 取 `notebook_id` → `get_doc_content` 读旧版 → `append_doc`(`note_id` + `content` + `content_format:1`) → `get_doc_content` 读回验证。追加内容开头必须写明「【YYYY-MM-DD 更新版】… 替代上方旧版」，并**主动告知用户旧版文字需在 IMA 客户端手动删**（无删除接口，无法程序化清理）。
- **IMA OpenAPI 无「从知识库删除/移除单条」接口**（`api.md` 全文无 delete/remove/move），且一篇笔记**可同时关联多个知识库（双库共存）**。所以定位错了的笔记**无法程序化移除**——补救只能：①生成时就写进正确库；②让用户在 IMA 客户端手动删除/移除多余库的关联；③接受双库共存（不影响使用，仅冗余）。**多库关联前务必先想清目标库再 add_knowledge**。
- **`-200` 版本更新拦截可绕过（不强制升级）**：`ima_api.cjs` 每日首次调用会 `openapi/check_skill_update`，发现新版即返回 `code:-200` 且**不发送原请求**（会把所有调用卡住）。脚本读 `~/.config/ima/last_update_check` 判断“今天是否已检查”——把**当天 UTC 日期**（`date -u +%F`）写入该文件即跳过检查、用当前已装版本继续干活；无需下载覆盖、不影响功能。
  ⚠️ **必须用 UTC，不能用 `date +%F`（本地日期）**：脚本比对的是 `new Date().toISOString().slice(0,10)`（UTC），本地与 UTC 跨日时写入本地日期**照样被拦**（2026-09 实踩：本地已 9/12、写 `date +%F` 无效，改 `date -u +%F` 立即通过）。
  **最省事**：driver 脚本开头自动写一次，之后每条 driver 自带免疫：
  ```js
  fs.writeFileSync(path.join(os.homedir(),'.config/ima/last_update_check'), new Date().toISOString().slice(0,10));
  ```
  ⚠️ **两种日期别混用**：笔记正文里的「整理日期」用**本地**日期（`date +%Y/%m/%d`，每次现跑），更新检查标记用 **UTC**。要强制检查才设 `IMA_FORCE_UPDATE_CHECK=1`。
- **真升级（十一明确选升级时才做；2026/09/16 实测 1.1.8 → 1.1.10）**：①`IMA_FORCE_UPDATE_CHECK=1 node ima_api.cjs "<任一合法apiPath>" '{}'` → **stderr** 的 `-200` 里带 `instruction`，**stdout** 是 updateContext JSON（含 `latest_version` + 官方 zip 地址，官方最新版可能比用户说的版本号更新，以它为准）；②`curl -sL -o ima-skills.zip "https://app-dl.ima.qq.com/skills/ima-skills-<ver>.zip"` 下载后 `unzip`；③**先备份再覆盖**，且必须覆盖**两处**安装位——`C:/Users/Administrator/.workbuddy/skills/ima-skill`（脚本运行位）**和** `E:\RuanJian\Hermes\skills\ima-skill`（技能读取位）；用 `cp -r <解压目录>/. <目标>/` 这种**覆盖式**拷贝，本地 `references/` 不在 zip 里、覆盖式 cp 不会删它（别用清空目录再拷的方式）；④校验两处 `meta.json` 的 version + 跑一次真实 API 返 `code:0,msg:success`。升级后**顺手对齐三处 `references/ima-notes-rules.md`**。⚠️ 本机该文件曾**三处分叉且规则冲突**（`.workbuddy/skills/ima-skill/references/` 的 9/15 精炼版 136 行 vs `Hermes/skills/ima-skill/references/` 与 `ima-kb-workflow/references/` 的 8/30 展开版 771 行）。**2026/09/16 已合并统一为 165 行权威版**，同步写入三处并 `md5sum` 校验一致。
  - **权威版要点**：按平台归库（拼多多→拼多多-电商学习📚 等 7 库 + 公司事项库 + 十一库兜底），含 **20 项最终验收清单** + 文件名规则。
  - **已废弃的冲突规则**：旧展开版「自动存储规则」写「默认关联到『十一的知识库』」——与平台归库**直接冲突**，照它执行会把拼多多/抖音笔记全塞进兜底库。**见到"默认全进十一库"一律以映射表为准。**
  - **再分叉时的合并方法**：① `grep -nE "^#{1,3} "` 拉两边章节结构定位各自独有章节；② 判定权威**看内容是否与十一已确认的现行做法一致，不看文件新旧或大小**（本例旧的 771 行版反而更大）；③ 只补对方**独有且有价值**的章节（如验收清单、文件名规则），**不搬冗长的展开重复**；④ 覆盖式 `cp` 同步到全部安装位后 `md5sum` 校验。
  - **根因/预防**：`Hermes/skills/` 重装会被还原成打包时的旧版，多副本各自演化必然分叉。已在权威版文件头写明"唯一权威源 + 重装后须重新同步"，但**这是记录约束不是技术强制**——重装后要主动对齐一次。
- **⚠️ API 路径写错会静默返回空，不报错**：`node ima_api.cjs "openapi/list_docs" '{"limit":3}' '{}'` 这种**不存在的路径**会 **exit=0 且 stdout/stderr 全空** —— 极易误判成"没数据/凭证坏了/权限问题"。合法前缀只有两个：笔记 `openapi/note/v1/*`（list_note / list_notebook / search_note / import_doc / append_doc / get_doc_content），知识库 `openapi/wiki/v1/*`（search_knowledge_base / search_knowledge / get_knowledge_list / get_media_info / add_knowledge / create_media / import_urls）。写路径前先 `grep -nE "openapi/" notes/SKILL.md knowledge-base/SKILL.md` 核对，别凭记忆拼。
- **🔴🔴 `imaApi()` 返回的是 JSON 字符串，不是对象！必须先 `JSON.parse`（2026-09-29 踩，差点把笔记写两遍）**：
  `const r = await imaApi('/openapi/note/v1/append_doc', {...})` 拿到的 `r` 是 **string**；
  直接读 `r.code` 永远是 `undefined`、`r.data` 永远是 `undefined` → **一次成功会被当成失败**。
  **危险后果**：我把 `code:undefined` 当成失败，于是“重试”了一次 —— 其实第一次也成功了，
  只是我没解析。**每次都“失败”每次都重跑 = 笔记里出现多段重复修订**，而 IMA **没有删除接口**，只能让十一手删。
  ```js
  const raw = await imaApi('/openapi/note/v1/append_doc', {note_id, content_format: 1, content});
  const r = typeof raw === 'string' ? JSON.parse(raw) : raw;
  console.log(r.code, r.msg);          // 0 / success  ← 这才算数
  ```
  **判定成功一律看 `r.code === 0`，不看有没有抛异常**（网络/参数错才抛，业务失败是 `code != 0`）。
  **写库类操作（import_doc / append_doc / add_knowledge）重试前，必须先确认上一次到底成没成** ——
  用 `get_doc_content` 读回看内容在不在（数一数「【修订】」出现了几次），再决定要不要重跑。
  同类小坑：`get_doc_content` 是 `/openapi/note/v1/get_doc_content`（**不是** `get_doc`），
  且 `target_content_format` **只能用 `0`(PLAINTEXT)** —— 传 `1`(MARKDOWN) 会拒。
- **node 不在 PATH 时用绝对路径**：`C:/Users/Administrator/.workbuddy/binaries/node/versions/<ver>/node.exe`（必须 C:/ 正斜杠；版本号会变，先 `ls ~/.workbuddy/binaries/node/versions/` 取最新）。
