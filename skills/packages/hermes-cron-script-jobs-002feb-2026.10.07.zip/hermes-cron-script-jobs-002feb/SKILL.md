---
name: hermes-cron-script-jobs
description: Use when building/troubleshooting Hermes cron script jobs.
---

# Hermes 定时任务脚本（no_agent cron script jobs）

适用：给十一做的所有**「脚本型」定时任务** —— 数据日报/周报、评价星级采集、等待提醒哨兵等。
**内容/排版**写什么看 `im-output-formatting`；本技能只管**任务本身怎么搭、怎么不挂、怎么验**。

---

## 一、形态与投递语义（先搞清这个，很多坑不用踩）

`cronjob(action='create', no_agent=True, script='xxx.py')`：
- **脚本 stdout 逐字投递**（就是一条消息）→ 脚本里 `print(完整内容)` 即可，
  **不要在脚本里自己分条 `hermes send`**
- ✅ **空 stdout = 什么也不发**（这就是看门狗模式的基础）
- ⚠️ **非零退出 / 超时 = 发告警** → 「故意静默」必须 `exit 0`，不能 `exit 1`
- `prompt` / `skills` 在 no_agent 下**被忽略**（但仍建议写清楚，它是给自己看的文档）
- ⚠️ Hermes cron **只认 `<Hermes>\scripts\` 下的文件名** → 真脚本在项目里的，写一个**转发脚本**

### 转发脚本模式（推荐，本次全部任务都用它）
```python
TARGET = r'D:\<工作区>\项目：XXX\脚本\run_daily.py'
if not os.path.exists(TARGET):
    print('找不到主脚本 %s（工作区是否又迁移了？）' % TARGET); raise SystemExit(1)
p = subprocess.run([sys.executable or 'python', TARGET], capture_output=True, text=True,
                   encoding='utf-8', errors='replace', timeout=1500, cwd=os.path.dirname(TARGET))
out = ((p.stdout or '') + (p.stderr or '')).strip()
print(out or '无输出（返回码 %d）' % p.returncode)
raise SystemExit(p.returncode)      # ⚠️ 返回码必须传出去，否则失败被吞成成功
```
好处：工作区可迁移（只改 `TARGET`），cron 配置永远不动。

---

### ⚠️ `deliver` 写多个目标 = 同一内容发多份（2026-09-28 十一当场问「为什么给我发两遍」）

```python
cronjob(action='create', ..., deliver='qqbot,weixin:o9cq…@im.wechat')   # ❌ 每跑一次发两份
cronjob(action='create', ..., deliver='qqbot')                          # ✅ 只发一份
```

- 逗号分隔是**逐个投递**，不是「优先/兜底」。他看到的是**同一条内容在两处各一份**，
  原话：「我要求你给我发一下加班通知，但是你给我**同一条消息推送两遍**」。
- **十一定（2026-09-28，长久规则）：只在他找你的那个渠道回、且只回一次；新建任务默认 `deliver='qqbot'`。**
- **定位（一次抓到）**：`grep "delivered to" E:\RuanJian\Hermes\logs\agent.log | tail`
  → 一次运行**正常一行**；出现两行（`qqbot:` + `weixin:`）就是这里。
- 改：`cronjob(action='update', job_id=…, deliver='qqbot')`；改完核 `cron/jobs.json` 里的 `deliver`。
- ⚠️ 建任务时**别把「多一个渠道更保险」当默认** —— 那是重复打扰。
  同理 **`deliver` 与脚本内自己 `hermes send` 不要同时用**（脚本推一遍 + cron 投一遍 = 两遍）。
- ✅ **但他显式指定「这个任务只发微信」时照做**（2026-09-28 加班通知：`deliver='weixin:o9cq…@im.wechat'`）。
  默认 QQ 只管**他没说话的新任务**；**别拿默认去覆盖他的指定**。
- **改渠道要连带处理配套、并改 prompt**：
  | 方向 | 配套动作 |
  |---|---|
  | QQ → 微信 | 「微信保活」必须 running，否则互动窗口过期、推送 `ret=-2` |
  | 微信 → QQ | 保活可 pause（没别的任务推微信时） |
  改完**把 job 的 prompt 一起改**（no_agent 下 prompt 只是文档，但下次读到旧渠道会困惑）。
- **同一件事他会拆成两条规则**：「定时去哪」和「我手动喊口令时结果回哪」是两件事，**分开记**
  （加班通知：定时=微信、QQ 喊口令=回 QQ）。别当成他改回去了。

### ⚠️ 默认会给投递内容套一层**英文包装**（2026-09-28 十一要求关掉）

系统默认 `cron.wrap_response: true` → 十一收到的不是脚本原文，而是：
```
Cronjob Response: <任务名>
(job_id: …)
-------------

<正文>

To stop or manage this job, send me a new message (e.g. "stop reminder …").
```
他原话：「**多余的字符英文代码不要给我，类似 Cronjob Response:**」，
理由：「**因为我要整段复制，粘贴到其他对话框**」—— 包装会跟着一起被复制走。

**修法**（`E:\RuanJian\Hermes\config.yaml`，顶层加）：
```yaml
cron:
  wrap_response: false
```
- ✅ **不用重启网关**：`hermes_cli.config.load_config()` 按 config 文件的 `(mtime_ns, size)` 缓存，
  文件一改缓存即失效 → **下一次投递就读到新值**。
  （2026-09-28 实测：13:12 改文件 → 13:15 那次投递已按新值走）
- **验收必须看配置值，不只看 patched 回执**：
  ```python
  from hermes_cli.config import load_config
  print(load_config().get("cron"))        # 要看到 'wrap_response': False
  ```
- 代价：用户不再看到「回复可停止此任务」的英文提示（他不需要）。
- **别去改 `cron/scheduler.py` 里拼装那段** —— 改核心代码升级就没了，配置开关就是为这个留的。

---

## 二、跑点怎么排：主任务 + 看门狗要**错开**

排期时问三个问题：1) 一天给几次机会？2) 失败能不能当场重试？3) 两个任务会不会撞同一分钟？

- **和看门狗错开**：主任务自带超时上限（例：转发 `timeout=1500` ＝ 25 分钟），看门狗放太近
  会在主任务还没跑完时误判「今天没数据」→ **重复补跑**。
  规则：**看门狗 ≥ 主任务启动 + 主任务超时预算**。实例：主 `20 14 * * *`（14:20）
  → 看门狗 `50 14 * * *`（14:50）✅（一开始想放 14:20 被这套推理否掉）
- **避开整点**：多个任务挤在 `:00` 容易同时动浏览器/文件（实抓到的隐患：看门狗原为每小时整点，
  与 14:00 主任务同一时刻）
- 改跑点：`cronjob(action='update', job_id=…, schedule='20 14 * * *')`；
  **顺手把 prompt 里的旧时间一起改**，否则以后自己读到「每天 14:00」会困惑
- **非整点、非 24h 的间隔可以直接写分钟数**：`schedule='1410m'` = **每 23.5 小时**
  （实例：微信保活任务，取 23.5h 是为了卡在主动推送互动窗口过期之前；cron 里会规范化成 `every 1410m`）。
  设完**用 `cronjob(action='list')` 看 `next_run_at` 核对**，别按「现在 + 间隔」自己心算。

---

## 三、看门狗（watchdog）模式：把「单一机会」变成「反复补的机会」

**为什么需要**（十一问过「为什么要看门狗」，这套解释他认）：
- 一天通常**只有一次**采集机会，**一失败当天数据就永久缺一条**（看板断档、均分算不准）
- 失败**绝大多数不是脚本的错，是环境**：电脑没开机/休眠、登录态过期、页面被关、
  浏览器/网络瞬时故障、平台风控
- 这些原因**当场重试没用**（登录过期立刻再试 10 次也失败，得等人工扫码）
  → 必须**隔一段时间、由外部条件恢复后再试**
- 比喻：主任务是「早上 7 点那班车」，看门狗是「之后还有一班」

**怎么做**：
```python
if any(h.get('date') == TODAY for h in hist or []):
    raise SystemExit(0)          # 今天已有数据 → 静默退出，不推任何消息
env['XXX_RETRY'] = '1'           # 没有 → 补跑完整流程（标记 RETRY，推送文案可标「（补采）」）
```
- **静默不是失败**：看门狗 `status: silent (empty output)` ＝ **今天已有数据、正常**
- **成本≈0**：有数据就是一次文件读，不打扰用户
- 看门狗自己也要能告警：补跑失败 → 打印原因 + `exit 1`（让 Hermes 发告警）

**没有看门狗时必须说清替代兜底**（十一 2026-09-21 先要求删掉、后要求加回，两次都直接执行）：
删掉 ＝ 「当天一次失败就那天缺数据」，所以**必须**同时交代：主任务失败时脚本会主动推告警
（`⚠️ …采集失败 + 原因`）→ **用户看到转你一声，你手动补跑**。

---

### 变体：**推送/上线类任务**要配「白天补推」兜底（2026-09-28 实例）

采集类看门狗盯的是「今天有没有数据」；**推送/上线类要盯「线上跟本地一不一致」**。

**踩到的坑**：数据日报只排了 23:45 生成 + 23:55 推链接。9/27 夜里 `git push` 失败
（`Failed to connect to github.com port 443`，国内网络常见，**Pages 域名走 CDN 却正常**）
→ 线上停在当天中午的旧版 → 十一白天点开看到的是**前天的数据**，还以为是「看板和飞书不一样」。

**口袋方案**（`scripts/daily_push_retry.py` + cron `502623247cea`，每天 7/10/13/16/19 点）：
```
读本地 gen + 线上 gen → 一致 → 空输出（静默，不打扰）
                      → 不一致 → --push-only 重推，最多 3 轮（每轮间隔 20 秒）
                      → 仍不一致 → 告警，写清「本地版本 vs 线上版本 + 可能原因」
```
- **成功也要安静**：网络恢复后自动补上了 → 最多发一条短确认，别每次跑都报一次。
- 排查口诀：怀疑「看板/网页数据不对」时，**先看线上那条 `meta.gen` 是不是最新**，再怀疑取数 ——
  一眼分清「数据旧」还是「数据错」（这次花了半天才发现是前者）。

---

## 三-1、⚠️ 带推送的脚本：**手动跑就会多推一条** → 必须留「不推送」模式

**十一当场问过「为什么会给我发两遍」**，查出来的真相：脚本**自身带推送**，
而我为了给他看内容**直接跑了它** → 脚本先推一条，我又把同一内容贴给他 = 两遍。

**同一天这个任务跑了 4 次、推了 4 次**（`ls -t cron/output/<job_id>/` 一眼看见 16:17 / 16:19 / 16:36 / 22:25）：
定时那班 + 有人补登后重跑 + 我手动查 + 别的窗口再跑 —— **谁跑都推一条**。

**规矩（设计任务时就定下来）**：
1. 带推送的脚本**一律留一个「只打印、不推送」模式**（`--dry` 或环境变量 `XXX_NOPUSH=1`）
   → **我手动取内容给他看时一律带它**；该发的时候**只让定时任务发**。
2. 更稳一层：**脚本默认不推送**，只有「定时任务那班的入口脚本」才带推送开关 →
   定时/手动/别的窗口任何来源跑，都只有定时那班真的发一次。
3. **幂等兜底（可选）**：记 `{date, 内容hash}`，同一天同内容已发过就静默退出；
   内容变了（如补登后判定变了）才再发。
4. **排期时先数这个脚本有几个触发源**（主任务 / 看门狗 / 手动 / 别的窗口）——
   有几个就可能在一天里推几条。

### 变体：**「脚本自推 + cron 兜底」**（2026-09-29 实做，最新形态）

当十一要求「**这个任务只推到微信**」时，比他手动改 `deliver` 更稳的做法是：
**让脚本自己推目标渠道，`deliver` 只当兜底**。

```python
body = "```\n" + "\n".join(L) + "\n```"

if "--show" in sys.argv:        # 只打印不发送（我手动取内容给他看时用）
    print(body); sys.exit(0)
if "--no-send" in sys.argv:     # 完全静默
    sys.exit(0)

# ⚠️ 绝不能加 shell=True（2026-09-29 血泪）！多行 body 会被 Windows cmd 在第一个换行处截断
#    → 只发出去第一行（代码块场景就是 ```）→ 十一收到的是一个「**空白消息**」。
#    → 列表参数 + 绝对路径 exe，hermes 也要绝对路径（cron 的 PATH 里没有它）。
HERMES = r"E:\RuanJian\Hermes\hermes-agent\venv\Scripts\hermes.exe"
r = subprocess.run([HERMES, "send", "--to", WX, body], capture_output=True, text=True,
                   encoding="utf-8", errors="replace", timeout=120, shell=False)
ok = r.returncode == 0 and ((r.stdout or "") + (r.stderr or "")).strip().lower().startswith("sent")
if ok:
    sys.exit(0)                 # 推成功 → stdout 空 → cron 不投递
print("⚠️ 微信推送失败，本条改走 QQ：" + err[:200])
print("")
print(body)                     # 失败 → 交给 cron 投到兜底渠道
```

**关键认知（很容易看反）**：
- 这种写法下 **job 的 `deliver` 应该是「兜底通道」（`qqbot`），而不是脚本推的那个渠道**。
  实测：`deliver='weixin:…'` + 脚本自推微信 = **微信挂了就彻底收不到**（没有兜底）。
  → 所以看到「他说只推微信，但 `deliver=qqbot`」**不是配错**，去读脚本再下结论。
- **`--show` 是给我自己用的**：十一在 QQ 喊口令、而任务链路是「脚本自推微信」时，
  我要用 `--show` 拿正文在 QQ 回他（不然会既推微信、我又贴一遍 = 两遍）。
- 三-1 第 1/2 条的「不推送开关」在这里具体化为 `--show` / `--no-send`。
- 排查口诀：**「为什么他说的渠道和 `deliver` 不一致」→ 先 `grep -n "hermes send\|sys.exit(0)" 脚本`**，
  看脚本是不是自己发了。

**排查口诀**：用户说「**同一份东西给我发了两遍**」→
① `ls -t cron/output/<job_id>/ | head -6` 数今天跑了几次；
② 看脚本有没有自带推送、有没有不推送模式；
③ 再回头看是不是我「推一份 + 贴一份」（见 `im-output-formatting` 的回复渠道纪律）。

**排查口诀二**：用户说「**你发的是空白内容** / 只收到一个空代码块」（**不是**两遍、也不是少了行）→
① `grep -n "shell=True" <发送脚本>` —— 命中就是本节上面那个坑；
② 修完加上「发送日志」（见 `chat-report-push` §4.2）——这类脚本**成功时 stdout 故意留空**，
   cron output 只记「无输出（返回码 0）」，事后零痕迹，只能靠 `data/send_log.txt` 分辨
   「发了没到」还是「压根没发」。

---

## 四、⚠️ 定时任务最大的坑：cron 注入的 `PYTHONPATH` 污染子进程环境

**症状**：手动 `python xxx.py` **正常**，但**定时任务必失败**，报
`ModuleNotFoundError: No module named 'pydantic_core._pydantic_core'`（或其它 `.pyd` 加载不了）。

**根因**：
- Hermes cron 执行脚本时会**注入 `PYTHONPATH`**（`cron/scheduler.py`），指向 Hermes venv
  （Python 3.11）的 `site-packages`
- 脚本里 `subprocess` 调的若是**另一个 Python 环境**（uv tool / 独立 venv / 打包 exe），
  例：`browser-use.exe` 是 **uv 跳板**，真跑的是
  `%APPDATA%\uv\tools\browser-use\Scripts\python.exe`（**Python 3.14**）
- 3.14 的进程拿着这张错地图去加载 **cp311** 的 `.pyd` → 版本不匹配 → 报错
- 手动终端没那个 `PYTHONPATH` → 正常。**这就是「手动能跑、定时任务必挂」的全部分歧。**

**判定口诀**：**手动能跑通 + 定时任务报 `pydantic_core` → 就是这个坑。**
（我一开始误判成「瞬时故障」，因为中间手动跑成功过 ——
**别用「手动跑了一次成功」去否定环境差异的假设**。）

**修复**：调子进程前清掉继承来的变量
```python
env = dict(os.environ)
for _k in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
    env.pop(_k, None)          # 让子进程用它自己那套环境
```

**验收（必做，别靠眼睛）**：带 `PYTHONPATH` **复现定时任务条件**再跑一次
```bash
cd E:/RuanJian/Hermes/scripts
PYTHONPATH="E:/RuanJian/Hermes/hermes-agent/venv/Lib/site-packages" python 你的入口脚本.py
```
修复前必失败、修复后成功 —— 这才算「明天不会再挂」的证据。

**推广**：任何脚本用 `subprocess` 调另一个 Python 环境，**先清 `PYTHONPATH`**。
完整证据链与复现命令见 `references/env-pollution-pydantic-core.md`。

---

## 四-1、🔴 同类坑之二：cron 的 **PATH 里没有 git（和一堆命令）**

**症状**：`❌ [WinError 2] 系统找不到指定的文件。` —— **脚本前几步全成功，就最后一步挂**。

**实例（2026-09-27 23:45，坑了三天才发现）**：数据日报同步任务
```
拉取 6,142 条记录         ✅
✅ 结构自检通过
✅ 已生成 index.html      ✅
✅ 本地副本                ✅
❌ 推送异常：[WinError 2] 系统找不到指定的文件。   ← 就这里
```
**后果**：线上停在旧版，23:55 推给十一的链接点开是旧数据。

**根因**：脚本里这样找 git ——
```python
# ❌ 错
git = shutil.which("git") or r"C:\Program Files\Git\cmd\git.exe"
```
- **cron 环境 PATH 干净** → `which("git")` 返回 `None`
- fallback `C:\Program Files\Git\cmd\git.exe` **这台机器上根本不存在**
  （Hermes 自带 git 在 `E:\RuanJian\Hermes\git\`）
- → `subprocess` 拿到 `None`/不存在的路径 → `WinError 2`

**判定口诀**：
• 报 `pydantic_core` → **PYTHONPATH 污染**（第四节）
• 报 **`WinError 2`** → **PATH 里找不到可执行文件**（本节）
• 两者共同特征都是：**手动跑必成功、定时任务必挂**

**⚠️ 最容易把人坑进去的地方**：
因为我的 shell PATH 里有 git，**我手动跑一定成功** ——
于是反复得出「推送链路没问题」的结论，实际定时任务坏了整整三天。
**别用「我手动推成功了」去证明定时任务正常**（同理：别用一次手动成功否定环境差异）。

**修法（候选列表探测，绝对路径优先）**：
```python
_GIT_BIN = None
def _git(*args, proxy=False, timeout=180):
    global _GIT_BIN
    if not _GIT_BIN:
        for c in (shutil.which("git"),
                  r"E:\RuanJian\Hermes\git\cmd\git.exe",
                  r"E:\RuanJian\Hermes\git\bin\git.exe",
                  r"E:\RuanJian\Hermes\git\mingw64\bin\git.exe",
                  r"C:\Program Files\Git\cmd\git.exe"):
            if c and os.path.exists(c): _GIT_BIN = c; break
    if not _GIT_BIN:
        raise RuntimeError("找不到 git 可执行文件")
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")   # 免交互，防卡死
    if proxy:
        env["HTTPS_PROXY"] = env["HTTP_PROXY"] = "http://127.0.0.1:7897"
    return subprocess.run([_GIT_BIN, "-C", REPO] + list(args), ..., env=env)
```
**同一个仓库里发现的错误写法**：`cmd = ['git']`（写在工作区 `weekly_sync.py` 里）——
**依赖 PATH 的一律要改绝对路径**。

**顺手查**：这台机器上还装了哪些命令是脚本依赖、但 cron 里可能找不到的
（`git` / `uv` / `node` / `hermes` …）。新增调外部命令的脚本先想一遍。

**验收（必做）**：模拟 cron 环境跑一次。**两种写法，命令行版证据最硬**（能跑完整流程）：

```bash
# ✅ 推荐：最小 PATH，跑完整流程
cd E:/RuanJian/Hermes/scripts
PATH="C:/Windows/system32;C:/Windows" "E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" 你的脚本.py
# 修前：❌ 推送异常：[WinError 2]；修后：✅ 已推送上线（第 1 次，直连）
```

```python
# 也可以：只在 Python 内部改 PATH，测单个函数
os.environ["PATH"] = r"C:\Windows\system32;C:\Windows"   # cron 常见最小 PATH
# 再调你的函数，看能不能找到可执行文件
```

⛔ **别用 `env -i` / `env -u PATH`**（2026-09-28 白跑两轮）：把 PATH 整个清掉后
**连 `python.exe` 自己都启动不了**，退出码 0、零输出，看起来像「脚本没问题」——
实际是根本没跑起来。要复现就**给最小 PATH，不能不给**。

修前必报 `WinError 2`、修后能找到绝对路径并跑通 = 才算好。

---

## 四-2、⚠️ 单独看「脚本 exit 0」不能证明成功

**no_agent 任务的 `last_status: ok` 只反映退出码**。脚本吞了异常、`except: pass` 后照样 `exit 0`，
在 cron 列表里看起来一切正常。

**实例**：数据日报同步任务 `last_status: ok`，但实际推送环节报错 ——
真正的证据在 `cron/output/<job_id>/<时间>.md` 的 stdout 里。

**规矩**：
1. 排查定时任务「为什么没效果」时，**先读 `cron/output/<job_id>/` 里对应时间的 md**，
   不要只看 `cronjob(action='list')` 的 status
2. 脚本里**对外副作用的关键步骤失败要 `print` 出来**（并尽量 `exit 非0`），别静默吞
3. 推送类任务的告警文案**必须带真实错误原因**，不要写「多半是网络问题」这类猜测 ——
   会把排查方向带偏（十一就因此以为推不上去是 github 连不上）

### 排查定时任务「昨晚怎么没生效」的标准动作（2026-09-28 实测走通）

`cronjob(action='list')` 只给 `last_status` —— **不够用**。完整时间线在这两处：

**① `E:\RuanJian\Hermes\cron\executions.db`（SQLite）**
```python
import sqlite3
con = sqlite3.connect(r"E:\RuanJian\Hermes\cron\executions.db")
# 表 executions: id/job_id/source/status/started_at/finished_at/error
# 表 cron_incidents: job_id/state/failure_type/first_seen_at/error/output_file
for r in con.execute("SELECT status,started_at,finished_at,error FROM executions "
                     "WHERE job_id=? ORDER BY started_at DESC LIMIT 5", (JOB_ID,)):
    print(r)
```
→ 一眼看出**那一刻到底跑没跑、跑了多久、有没有 error**。

**② `E:\RuanJian\Hermes\cron\output\<job_id>\<日期_时间>.md`** —— **stdout 原文**，
`WinError 2` 这种报错就藏在这里；`executions.error` 反而是空的（因为脚本 exit 0）。

**③ 时间线对账：`git log --format="%h %ad %s" --date=format:"%m-%d %H:%M"`**
（看仓库里到底哪几次真的产生了提交）。**「任务 status=ok」但 git 里没有那一次的提交**
＝ 生成/推送环节挂了但被吞掉 —— 这是定位问题最快的一招。

**④ 先确认今天几号**：`date` —— 见下方「五、」的跨天陷阱。

---

## 四-3、✍️ 脚本作者坑：**helper 定义在调用之后 → NameError 盖住真错误**（2026-09-27 实踩）

**症状**：采集任务失败，尾部输出只有：
```
NameError: name 'bail' is not defined
```
看起来像脚本坏了，实际是**真正的失败原因被它盖掉了**。

**根因**：脚本里的 `bail()`（打印错误 JSON 后退出）**定义在页面查找之后**，
而 `if page is None: bail('NO_PAGE', …)` 在定义之前就跑了 →
真正该报的 `NO_PAGE`（页面没打开）被 `NameError` 顶替。
**代价**：十一以为是「登录态过期」，跑去重新登录 —— 排查方向整整歪了一轮。

**规矩**：
1. `bail / 报错 / 日志` 这类 helper **一律写在文件最顶上**，早于任何可能调它的代码。
2. **`except` 分支里自定义的报错文案，是可信度链最弱的一环** ——
   排查时先看**原始异常类型与消息**，不要只信脚本自己那句话。
3. **验收不用跑全流程**：`grep -n "def bail\|bail(" 脚本` 确认 **`def` 的行号 < 首次调用行号** 即可。
4. 改的是**采集脚本**时，顺手确认一下「失败原因分类」是不是也被这层 NameError 污染过
   （历史上的失败原因不能全信）。

---

## 四-4、🔴 同类坑之四：**本机代理软件把国内接口挡了**（2026-09-28 实踩）

**症状**：定时任务报**取不到飞书 token**、或**投递失败**，报错里带 `127.0.0.1:7897`：
```
⚠️ 加班判定：飞书取 token 失败，今天没算出来
delivery error: QQBot send failed ... Cannot connect to host 127.0.0.1:7897 ssl:default
  [远程计算机拒绝网络连接]
```
（当天实情：加班通知 16:00 那次**没送达**，十一是从别处看到内容的。）

**根因**：这台机器装了代理软件（`com.vortex.helper`，监听 **127.0.0.1:7897**）。
python 的 `urllib` **默认会读 Windows 系统代理** → 飞书 / QQ / 微信这些**国内接口也被塞进代理** →
代理一抽风（重启、切节点、未启动）脚本整条失败。**特征是报错里的 `127.0.0.1:7897`。**

**修法（脚本内显式绕开，国内接口全部直连）**：
```python
import urllib.request
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
```
加在 import 之后即可（对本进程所有 `urllib` 调用生效）。已加到：
- `overtime_daily.py`（加班判定 → 飞书）
- `E:\RuanJian\Hermes\scripts\daily_dashboard.py`（日报 → 飞书）

**分清哪个目标该用代理**：
| 目标 | 代理 | 理由 |
|---|---|---|
| 飞书 / QQ / 微信 / 国内后台 | **绕开** | 国内直连，走代理只会被挡 |
| github.com（git push） | 另说 | ⚠️ 报错仅 `Failed to connect to github.com port 443`（**没有**代理地址）= **直连被墙**，与本节不是同一回事；当晚两种走法都没通，靠「白天补推」兜底 |

⛔ **别去改 Windows 系统代理开关** —— 只在脚本里按目标绕开，否则会连带影响其它窗口（模型调用、其它 agent）。

**判定口诀**：报错里有 `127.0.0.1:7897` / `Cannot connect to host` → 代理坑（本节）；
没有任何代理地址的网络报错 → 是直连本身的问题，另一条路。

---

## 五、验收：跑过 ≠ 成功

1. **手动触发**：`cronjob(action='run', job_id=…)` → 结果（含实际 stdout 与投递目标）异步回到对话
2. **读日志**：`E:\RuanJian\Hermes\cron\output\<job_id>\<时间>.md` —— 看 `Status`
   （`silent` / `ok` / `error`）与 `Delivery target`
3. **脚本有对外副作用时（推 GitHub Pages / 写看板）要回读线上**：抓线上页面（加 `?v=<时间戳>` 防缓存），
   比对**关键数字或长度** —— 别只搜关键词（旧版也含关键词，会误报成功）
4. **改配置后看真实输出**：`python scripts/xxx.py | head -12`，不看 patch 成功的回执

### ⚠️ 跨天陷阱：上下文里的「今天」会过期（2026-09-28 实踩）

这个会话从 9/27 开到 9/28，我按 9/27 思考了一整轮，**实际已经是 9/28 07:57**，
差点把「今早 07:42 的自动更新」解释错。

**凡涉及今天/昨天/近N天/「昨晚怎么没跑」的排查，第一件事就是 `date`。**
补充诊断：**看文件 mtime + `git log` 的时间线**，它们比脑子里的日期可靠。

### 报「已修好」时：给修复前后的**对照证据**，不要只说结论

十一会追问一句「**不会出任何纰漏问题了吧**」—— 那是在说「你刚才的结论我不够信」。
正确回应不是「放心，没问题」，而是：

1. **同一条件下的前后对照**（最有说服力）：
   | 环境 | 修复前 | 修复后 |
   |---|---|---|
   | 我的 shell（PATH 有 git）| ✅ | ✅ |
   | cron 最小 PATH | ❌ `WinError 2` | ✅ 推送成功 |
2. **全部实测过的检查项列表**（逐项写「怎么验的」，不是「应该没问题」）
3. **仍然存在的真实风险**单独列（如「电脑 23:45 没开机 → 当前兜不住」）——
   **不夸大、也不藏**。说「绝对不会出问题」是假承诺，十一要的是知道哪块稳、哪块不稳。

---

## 六、这些脚本是**多窗口共享文件**

`E:\RuanJian\Hermes\scripts\*.py` 会被**别的窗口的会话同时改**（patch 工具会提示
`modified by sibling subagent … at HH:MM`，且对方改动已在文件里）。规矩：
- **改前先看当前代码**（`grep -n -A3 "^def xxx" scripts/*.py`、`tail -20`），别凭上一轮记忆直接 patch
- **改后复查**；**不要顺手把对方按新要求做的改动改回去**
  （例：对方按「统一用万」改了 `wan()`，却把小额压成 `0.1万→0.0万` ——
  正确做法是**保留对方的方向、修精度**，不是回退）
- 交付前专门看**最极端的那行数据**（小额/零值/最大额）——「格式统一」类改动的错都出在那里

---

## 七、十一的偏好（硬性）

- 改跑点/改时间/删任务：**直接执行**，别反复确认；执行完报「原来→现在 + 下次触发时间」
- **失败告警要点名到具体原因和下一步动作**（不泛泛说「有异常」）
- 「**临时要数据**」＝ **单独现算现给**，不复用推送内容、不等定时任务
- 讲解这类机制用**大白话 + 生活比喻**（班车 / 错地图），结论前置
- **改渠道是一次性的、偏好是长期的**：他要「以后都这样」时，除了改 job，还要把偏好写进
  `im-output-formatting` / 记忆（本次：定时通知类一律走微信、聊天回复回当前渠道）。
- **推送正文只要结论、不要附属信息**（2026-09-29，主体财务看板周更）：
  他原话「**完成后微信告知我已更新即可，不需要其他内容**」→ 成功输出就一行
  `✅ 主体财务看板已更新（10/05）`，**条数、网址、耗时一律去掉**（原来会带「1234条数据 ｜ 网址」）。
  同类长尾输出都该按这个收。
- **推送类改完要连带改渠道与文案两处**：脚本里的成功输出 + job 的 `deliver`/`prompt`，
  只改一处会出现「内容对了但发到旧渠道」或「渠道对了但内容还是一长串」。

---

## 七-1、停用 / 恢复一个采集（2026-09-27 实做）

十一说「**XX 采集停止，完结，以后都不需要了**」时：

**两个动作都要做，少一个等于没停：**
1. `process(kill)` 掉**正在跑的那一次** —— 否则它跑完照样落盘 / 上线 / 推送
2. `cronjob(action='pause', job_id=…)` 把 job 停掉
   ⚠️ **只 kill 不 pause = 没停**：第二天到点它自己会再跑起来

**停之前先核一遍还有没有别的 job 跑同一个脚本**（`hermes cron list`，或直接读 `cron/jobs.json`）：
同一个采集曾同时挂「日任务 + 每小时守护」，只停一个等于没停。

**恢复**用 `cronjob(action='resume')`；**默认不要 `remove`** —— 保留 job（连 prompt/脚本）便于以后复用。
脚本/数据/看板一律**不删**。

⚠️ **多个数据源打包在同一个 job 里时，停一个就是全停**：
实例：`run_daily.py` 串了「评价星级 → 补采 → **维度指标** → 看板 → 上线 → 推送」，
十一只说停「评价采集」，我把 job 一 pause，**维度指标也跟着停了**。
→ 所以执行完**必须主动报两件事**：
1. 「连带还有哪些也停了」（把清单列出来，别让他以为维度指标还在跑）
2. 「要不要拆成独立 job 单独跑」—— 要保留的就得**先拆成独立脚本/job**，不能直接 enable 原 job

停完的回报格式（十一习惯）：表格列「定时任务 | 时间 | job_id | 状态」，
再加一句「脚本与看板全部保留，随时可复用」。

---

## 八、报信类一次性任务（`in Xm`）：先自证前提，再报

**踩坑实录（2026-09-23）**：十一说「重启之后你还在吗」→ 我挂了 `in 5m` 的一次性任务，脚本里直接 `print("✅ 电脑已重启完成，我回来了")`。
结果 **重启命令根本没执行**（被硬性禁止清单拦下），但 17:44 那条**照发**，成了假消息 —— 十一拿着它来问「电脑重启好了吗？」。

**铁律：一次性「完成后告诉我」的任务 = 一条断言。脚本必须先自证前提，不能「到点就报」。**
```python
up_min = (now - 开机时间).total_seconds() / 60
if up_min > 10:                 # 没重启过 → 什么也别说
    raise SystemExit(0)         # ⚠ 空 stdout = 不发消息；别 exit 1（那会发告警）
print(f"✅ 已重启完成（开机 {up_min:.1f} 分钟）· {now:%m/%d %H:%M}")
```
可用的「自证」事实：开机时长（`LastBootUpTime`）、目标文件 mtime、看板/接口回读、日志尾部。**凡“时间到了就假定完成了”的写法都是错。**

**顺带记下：系统重启/关机在硬性禁止清单里** —— `shutdown /r` 无论怎么授权（含 `--yolo`、approvals off）都执行不了，别重试、别换 PowerShell/计划任务绕。
正确做法：直接给十一一行 `shutdown /r /t 60`（Win+R 粘贴）让他自己跑，或用向日葵 AweSun 远程。**“我做不到”的结论必须先查证再讲**（对比 `LastBootUpTime` 与当前时间），不要凭印象答。

---

## 九、相关

- `im-output-formatting` —— 推什么、怎么排版、微信不渲染换行时改走 QQ
- `references/env-pollution-pydantic-core.md` —— PYTHONPATH 污染完整证据链与复现命令
- `references/cron-env-path-and-git.md` —— **PATH 里没 git** 完整证据链（executions.db 查询、
  最小 PATH 复现命令、代理兜底、推送链路三层兜底设计）
- 具体任务：`pdd-stars-daily-collect`（用户自有）、`feishu-yunying-daily-report`、`session-waiting-alerts`
