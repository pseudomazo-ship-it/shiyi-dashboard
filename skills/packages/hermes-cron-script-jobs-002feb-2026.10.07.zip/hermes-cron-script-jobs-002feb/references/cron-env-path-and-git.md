# cron 环境 PATH 里没有 git —— 完整证据链

**日期**：2026-09-27 夜 发现问题 / 2026-09-28 上午 定位并修复
**影响**：数据日报定时任务连续失败，推送的看板链接点开是旧数据
**耗时**：从「用户反馈」到「定位根因」花了一整个会话 —— 反推的话，**早读 executions.db 能省一半时间**

---

## 一、用户看到的现象

> 「现在日报推送是什么问题导致昨天晚上推送给我的是没有更新的内容」

十一收到 23:55 的 QQ 推送，点开链接看到的是**旧数据**。

---

## 二、报错原文（藏在 cron/output 里，不在 status 里）

`cron/output/ee58ecb16feb/2026-09-27_23-45-50.md`：

```
拉取 6,142 条记录
覆盖 269 天 / 26 家店
✅ 结构自检通过（section/div 均配平）
✅ 已生成 E:\RuanJian\Hermes\cache\shiyi-dashboard-git\daily\index.html  (551,369 字符)
✅ 本地副本 D:\Agent.GongZuoQu\Hermes.GZQ\数据--数据日报\日报看板.html
❌ 推送异常：[WinError 2] 系统找不到指定的文件。
```

**关键特征**：**前四步全 ✅，只有推送 ❌**。而 `cronjob list` 显示 `last_status: ok` ——
因为脚本 `except` 住了异常、最后 `exit 0`。

`cron/output/a56150a4e42f/2026-09-27_23-55-23.md`（**这条就是推给十一的内容**）：

```
⚠️ 数据日报：线上还是旧版，已自动重推仍未生效

　本地生成时间：2026-09-27 23:45
　线上生成时间：2026-09-27 12:27
　（本地数据是新的，网页可能需要手动刷一次或等 Pages 构建）

🌐 https://pseudomazo-ship-it.github.io/shiyi-dashboard/daily/
```

⚠️ 最后那句**猜测（「可能需要手动刷」）把排查方向带偏了** —— 十一以为是网络问题。
告警文案不能写猜测，要带真实错误。

---

## 三、根因

```python
# ❌ 错
git = shutil.which("git") or r"C:\Program Files\Git\cmd\git.exe"
```

| 环境 | `shutil.which("git")` | fallback 路径 | 结果 |
|---|---|---|---|
| **我的 shell** | ✅ 有 | — | **成功** |
| **cron** | ❌ `None`（PATH 干净）| **`C:\Program Files\Git\cmd\git.exe` 不存在** | **`WinError 2`** |

**这台机器的 git 在 `E:\RuanJian\Hermes\git\`**（`cmd/`、`bin/`、`mingw64/bin/` 三处都有），
不在 `C:\Program Files\Git\`。

### ⚠️ 我为什么误判了三天

**因为我的 shell PATH 里有 git，我手动跑一定成功。**
于是 9/27 中午我手动推成功一次，就得出「推送链路没问题」的结论 ——
**实际定时任务一直是坏的**，只是白天没人看。

> **铁律：不能用「我手动跑成功了」去证明定时任务正常。**
> 两者环境不同，手动成功恰恰是**掩盖**问题的原因。

---

## 四、排查路径（下次直接照这个走）

### ① 读 cron 执行库
```python
import sqlite3
con = sqlite3.connect(r"E:\RuanJian\Hermes\cron\executions.db")
con.row_factory = sqlite3.Row
for r in con.execute("SELECT status,started_at,finished_at,error FROM executions "
                     "WHERE job_id=? ORDER BY started_at DESC LIMIT 5", ("ee58ecb16feb",)):
    print(dict(r))
```
`executions` 字段：`id / job_id / source / process_id / pid / process_started_at / status /
claimed_at / started_at / finished_at / error`
`cron_incidents` 字段：`job_id / error_sig / state / failure_type / first_seen_at /
last_seen_at / acked_at / closed_at / error / output_file`

### ② 读 stdout 原文（**真正的报错在这里**）
```
E:\RuanJian\Hermes\cron\output\<job_id>\<YYYY-MM-DD_HH-MM-SS>.md
```
按 mtime 倒序列目录就能找到那一次。

### ③ git log 时间线对账
```bash
cd E:/RuanJian/Hermes/cache/shiyi-dashboard-git
git log --format="%h %ad %s" --date=format:"%m-%d %H:%M" -12
```
**「任务 status=ok」但 git 里没有那一次的提交** ＝ 那一次根本没成功。
本次实测：23:45 那一档**没有任何提交**，而 12:27 / 09:33 有 —— 问题立刻聚焦。

### ④ 先 `date` 确认今天几号
本次会话跨天（9/27 → 9/28），我按 9/27 思考了一整轮。

---

## 五、修复

### 1) git 候选列表探测（绝对路径优先）
```python
_GIT_BIN = None

def _git(*args, timeout=180, proxy=False):
    global _GIT_BIN
    if not _GIT_BIN:
        for c in (shutil.which("git"),
                  r"E:\RuanJian\Hermes\git\cmd\git.exe",
                  r"E:\RuanJian\Hermes\git\bin\git.exe",
                  r"E:\RuanJian\Hermes\git\mingw64\bin\git.exe",
                  r"C:\Program Files\Git\cmd\git.exe",
                  r"C:\Program Files (x86)\Git\cmd\git.exe"):
            if c and os.path.exists(c):
                _GIT_BIN = c; break
    if not _GIT_BIN:
        raise RuntimeError("找不到 git 可执行文件")

    cmd = [_GIT_BIN]
    if os.path.exists(_GIT_GCM):                       # 显式凭据管理器
        cmd += ["-c", "credential.helper=" + _GIT_GCM]
    cmd += ["-C", REPO] + list(args)

    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")   # 免交互，防卡死
    if proxy:
        env["HTTPS_PROXY"] = env["HTTP_PROXY"] = _GIT_PROXY
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                          encoding="utf-8", errors="replace", env=env)
```

### 2) 代理兜底（直连失败自动重试）
```python
_GIT_PROXY = "http://127.0.0.1:7897"
_GIT_GCM = (r"C:\Users\Administrator\.workbuddy\binaries\PortableGit"
            r"\versions\1.2.0\mingw64\bin\git-credential-manager.exe")
```
推送循环里：**先直连，失败改走 proxy=True 再试**，两次都不行才报错。
> 这个做法是从评价星级的 `publish.py` 抄来的，它里面早写着：
> 「本机 git 直连 GitHub 常被重置（Empty reply / Connection reset），走本地代理才稳。」
> **同一台机器上别的脚本踩过的坑，就该搬到所有同类脚本。**

### 3) 同款隐患（同一台机器上找到的第二处）
`D:\Agent.GongZuoQu\Hermes.GZQ\项目：主体财务看板自动同步\weekly_sync.py`：
```python
# ❌ 错 —— 依赖 PATH
def git(*args, proxy=False):
    cmd = ['git']
```
**新增任何调外部命令的脚本，一律写绝对路径探测。**

### 4) 告警文案带真实错误
`daily_report_push.py` / `daily_push_retry.py`：重推时 `capture_output=True` 捕获 stdout，
失败时取最后 3 行贴进告警的「失败原因」行。

---

## 六、验证（两层，缺一不可）

### ① 最小 PATH 跑完整流程（决定性证据）
```bash
cd E:/RuanJian/Hermes/scripts
PATH="C:/Windows/system32;C:/Windows" \
  "E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" daily_dashboard.py
```
**修复后实测**：
```
✅ 已推送上线（第 1 次，直连）
✅ 线上已核实更新（gen=2026-09-28 08:14）
=== EXIT=0 ===
```

⛔ **`env -i` / `env -u PATH` 白跑两轮** —— PATH 全清后**连 python.exe 都起不来**，
退出码 0、零输出，看着像「脚本没问题」。要复现就**给最小 PATH，不能不给**。

### ② 与用户的正向路径对照
| 环境 | 修复前 | 修复后 |
|---|---|---|
| 我的 shell（PATH 有 git）| ✅ 成功 | ✅ 成功 |
| **cron 最小 PATH** | ❌ **`WinError 2`** | ✅ **成功推送** |

**同一环境、修前必挂、修后必成** = 这才是「明天不会再挂」的证据。

---

## 七、推送链路的三层兜底（梳理清楚，以后照这个设计）

| 层 | 时机 | 干什么 |
|---|---|---|
| 1 | **23:45** `daily_dashboard.py` | 取数→生成→commit→push（6 轮重试，直连+代理）→**回读线上 meta.gen 核对** |
| 2 | **23:55** `daily_report_push.py` | 本地 vs 线上 gen 不一致 → 自动重推一次 → 仍不一致 → **告警带真实错误** |
| 3 | **7/10/13/16/19 点** `daily_push_retry.py` | 一致=静默；落后=重推最多 3 轮；仍不行=告警 |

### ⚠️ 已知局限（十一 2026-09-28 报备，待他拍板）
**第 2/3 层只推「已有文件」，不重新取数。**
所以 **23:45 时电脑没开机 → 本地文件还是前一天的 → 白天补推 5 次也只是把旧文件推 5 遍**，
线上永远缺当天的数据。

> 白天补推能救「网络问题」，**救不了「电脑没开机」**。修法：让白天补推先判断本地数据够不够新，
> 不新就完整跑一遍（取数+生成+推）。十一尚未拍板。

---

## 八、一句话教训

> **「手动能跑、定时必挂」在 Hermes 里有两类环境差异：**
> **报 `pydantic_core` → PYTHONPATH 污染；报 `WinError 2` → PATH 里缺可执行文件。**
> **两类都不能用「我手动跑了一次成功」来排除。**
