# 证据链：cron 注入的 PYTHONPATH 污染子进程 Python 环境

案例：2026-09-21 拼多多评价星级日采集（十一报「14:20 采集又失败了」）。

## 症状

定时任务 stdout（`cron/output/65799414e2ab/2026-09-21_14-00-09.md`）：

```
采集失败: NO_RESULT: 没拿到结果。尾部输出：
Traceback (most recent call last): / ModuleNotFoundError: No module named 'pydantic_core._pydantic_core'
```

同一天 14:00 与 14:20 两次失败、描述一模一样；
**中间 14:09 手动跑 `python run_daily.py` 却成功** → 一度误判为「瞬时故障」。

## 定位过程（可复用）

1. 确认 venv 里的 pydantic_core 本身是好的：
   ```bash
   python -c "from pydantic_core import _pydantic_core; print(_pydantic_core.__file__)"
   # → ...\hermes-agent\venv\Lib\site-packages\pydantic_core\_pydantic_core.cp311-win_amd64.pyd  ✅
   ```
2. 报错来自脚本 `subprocess` 调的外部 CLI（browser-use harness），不是主进程。
3. 读 exe 内嵌字符串，发现它是 **uv trampoline**，真跑的是：
   `C:\Users\Administrator\AppData\Roaming\uv\tools\browser-use\Scripts\python.exe`
4. 该环境自检 —— **Python 3.14.7**，含 `_pydantic_core.cp314-win_amd64.pyd`，单独跑**正常**：
   ```bash
   BU="C:/Users/Administrator/AppData/Roaming/uv/tools/browser-use/Scripts/python.exe"
   "$BU" -V
   "$BU" -c "from pydantic_core import _pydantic_core; print('OK')"
   ```
5. **复现（决定性一步）**：给 3.14 的进程设上 Hermes venv 的 `PYTHONPATH`：
   ```bash
   PYTHONPATH="E:/RuanJian/Hermes/hermes-agent/venv/Lib/site-packages" "$BU" \
     -c "from pydantic_core import _pydantic_core; print('OK')"
   # → ModuleNotFoundError: No module named 'pydantic_core._pydantic_core'   ← 一字不差
   ```
6. 坐实来源：`grep -rn "PYTHONPATH" hermes-agent/` →
   `cron/scheduler.py`：`env_overlay["PYTHONPATH"] = os.pathsep.join(pythonpath_entries)`
   （cron 为让脚本能 import 而注入；这就是定时任务与手动终端的环境差）。

## 修复与验收

```python
# 脚本里调 browser-use harness 的位置
env = dict(os.environ); env.update(env_extra)
for _k in ('PYTHONPATH', 'PYTHONHOME', 'PYTHONSTARTUP'):
    env.pop(_k, None)
```

验收 = **带污染条件复现**（不是普通手动跑）：
```bash
cd E:/RuanJian/Hermes/scripts
PYTHONPATH="E:/RuanJian/Hermes/hermes-agent/venv/Lib/site-packages" python pdd_stars_daily.py
# 修复后：评价星级已采集并更新看板：全店 366 条 / 均分 4.5929 / 用时 141s / 推送 OK(微信) / EXIT=0
```

## 教训

- 「手动跑成功」**不能**用来否定环境差异假设：手动与 cron 的差别（`PYTHONPATH`）恰恰是这个 bug 的全部原因。
- 两个 Python 版本共存时，报 `No module named X.X` 但 X 明明装着 → 先怀疑**跨版本 site-packages 串味**。
- `subprocess` 调 uv tool / 打包 exe / 别的 venv 的脚本，一律先清 `PYTHONPATH`。
- 连带教训：为「错开跑点」而调看门狗时间时，间隔必须覆盖主任务的超时预算，否则会**重复补跑**。
