---
name: memory-migration-into-hermes
description: "Import another AI assistant's user profile into Hermes."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [memory, migration, profile, user, ingestion, onboarding, import]
---

# Migrating a user's long-term memory into Hermes

When a user says "take over my memory / migration profile / remember me like my
other assistant did", they are handing you a large (often multi-thousand-char)
profile of themselves written by another AI assistant (WorkBuddy, Claude, a custom
agent, a doc). The job is to turn that into Hermes's persistent memory — not just to
store it.

## When to use
- User says "take over my memory / migration profile / remember me like my other assistant did".
- User hands you a long document that IS their profile/setup from another AI assistant, and asks you to keep it.
- You need to onboard a user's existing preferences, rules, and business context into Hermes persistent memory (`memory` tool · USER.md / MEMORY.md).
- You're deciding what to store vs. archive when a user provides a big onboarding profile.

## The core tension: archive size vs. always-loaded budget
Hermes's built-in memory has **hard char budgets** that the `memory` tool enforces:
- `USER.md` — about the user (who they are, how to communicate): default ~1375 chars.
- `MEMORY.md` — the agent's notes (environment facts, conventions, procedures): default ~2200 chars.
A full profile archive is usually 5–40 KB — far beyond both budgets combined. **You
cannot load it all.** So split it:

1. **Full archive → a file** (never truncated). Store the whole thing verbatim as
   e.g. `memories/profile-archive-<name>.md`. Version it (`-v2`, `-v3`...) when the
   user later supplies a refined version — don't overwrite the prior one (they may
   want to diff or roll back). This is the "deep per-task access" layer.
2. **High-signal condensed entries → the `memory` tool** into USER/MEMORY. This is
   the "loaded on every session start" layer. Pick the facts that change *how you
   work with this user every turn*: identity, collaboration rules, decision-making
   style, fixed format/output rules, high-frequency business, toolchain, and the
   current focus items. Leave versioned/months-dated/batch numbers in the archive
   file, not in always-loaded memory.

## Two memory stores — what goes where
- **`target=user`**: who the user is + how to communicate with them. Identity,
  communication style, fixed language/format preferences, decision authority
  (recommend but don't decide), password/口令 meaning, prior-correction patterns.
- **`target=memory`**: the agent's operating notes. Business structure, toolchain,
  deliverable format rules (Excel/HTML/code conventions), high-frequency workflows,
  business rules. If a fact is "about the user", it belongs in `user`; if it's "how
  to do this class of work in their environment", it belongs in `memory`.

## The `memory` tool's real behavior (pitfalls that waste turns)
- Each write is **append/plus global budget**; the budget is checked only on the
  **final** result of a batch. So do all removes/replace-shortens and adds in ONE
  `operations` batch, atomically, to free room and add together.
- `replace` needs `old_text` to be a **short unique substring** of an existing
  entry. It must match byte-for-byte what's on disk — paste the *actual current
  text* (read the USER.md/MEMORY.md or the `current_entries` in the error), don't
  reconstruct it from memory. A mismatched `old_text` rolls back the whole batch.
- **`replace` requires the `content` param** (not just `new_text`) — the tool
  rejects `replace` with `error: content is required`.
- After **4 failed consolidation attempts in one turn**, the tool hard-stops
  (`Memory consolidation failed 4 times this turn`). Don't keep retrying the same
  shape — that means you're over budget again. Stop, compute the real char counts,
  and shorten something first.
- Corrections to earlier entries are done with `replace` (or `remove` + `add`),
  never by adding a contradictory duplicate — that leaves two live stores arguing.
- To inspect current usage/entries, read the on-disk files
  (`memories/USER.md`, `memories/MEMORY.md`) rather than guessing.

## Dynamic-data flagging (critical for a business user)
The archive WILL contain numbers that go stale: store counts, order counts, fiscal
revenue, batch/plan dates, inventory, platform-rule thresholds, product-line specs,
pricing. The user is explicit: treat dated/batched numbers as **historical
snapshots** and always re-read the current data on the task. So:
- In condensed memory, either omit them or flag them, e.g. `⚠️以当期资料为准` /
  `⚠️ 需核实` / `当前数据无法判断` / `以平台后台为准`.
- Keep a `⚠️` marker (in text) rather than silently trusting the number later.
- When a refined archive contradicts an earlier one (e.g. default browser
  Edge-vs-Chrome, store counts 20-vs-22), the **newest file + current user
  instruction wins**. Note the conflict explicitly rather than silently mixing.

## Sensitive credentials
Accounts, dashboard passwords, kb_id tokens, legal-person names, credit codes are
user assets. Keep them in the **archive file** (where the user owns and controls
it), but do NOT inject them into always-loaded memory / the system prompt — they
would end up in every session context. Store a pointer like `密码见档案文件`
instead, and read the archive only when the task needs it.

## Workflow
1. Check existing `memories/` for prior archives and current USER/MEMORY.md.
2. Write the full archive to a new versioned file (verbatim, no edits).
3. Compute the condensation: pick high-signal USER entries + MEMORY entries.
4. Apply via `memory` with `operations` batches (remove/replace to make space +
   add new). Keep each entry a single dense line; use `§` as the on-disk delimiter
   (the tool manages it), don't hand-edit the files.
5. Verify by reading the files back (`read_file`) — confirm entries landed,
   no orphaned fragments, budget not exceeded.
6. Report: what was archived, what got condensed into which store, what was flagged
   `⚠️` as dynamic, and what was deliberately left out (with reasoning).

## Pitfalls
- Do NOT try to make memory "complete" by squeezing everything in — the budget is
  the budget. A crowded MEMORY.md at 96% is a warning, not a win. Prefer a pointer
  (`详规则见 profile-archive-*.md`) over cramming.
- Do NOT silently drop a prior archive or claimed "done" for a write the tool
  rejected.
- A batch that overflows returns `would be at N/N chars -- over the limit`. That's
  guidance: shorten, don't add more.

## Outbound: producing a portable profile FOR other AI tools (2026-10-01)

The mirror image of the import above. Trigger phrasing:
「帮我整理一份我的个人使用画像，用途是让我在不同 AI 工具之间保持一致的协作体验」
／「把自己信息全方位总结、掉给别的 AI 当记忆」／「更新一下档案」.

**Deliverable = 一个带日期的 .md + 同一份内容同步到 IMA 知识库**，然后回报两个位置、note_id、
以及「还有哪些维度没纳入」。骨架见 `templates/cross-ai-profile.md`。

### 他指定的输出形态（别自己发挥）
- 五个分类，**按此顺序**：`指令` / `身份` / `职业` / `项目` / `偏好`。
- 分类内**一行一条**，按日期**从早到晚**排，每行格式严格为 `[YYYY-MM-DD] - 条目内容`；
  日期不知道就写 `[unknown]`（**别猜日期**）。
- 整份**包在一个 ``` 代码块里**，方便他整段复制。
- 代码块之后**简要说明**：是否已覆盖当前能整理出的全部信息；**列出你不确定的维度，交他判断要不要补**。

### 内容规则（都是他明确提过的）
- **「仅整理可从长期记忆中明确识别并客观存在的规则，不临时新增、不强加、不脑补未明确提出的要求」**
  —— 没提过的一律不写。
- **「尽量保留我原本的表述方式，不要过度改写」** —— 引他的原话
  （例：「我多一个口」「重复不需要管，你只需要按照规则保留对应内容就行」），不要润色成你的话。
- **缺的维度就缺着**：标 `无此信息`，不要替他填。实际缺的是：年龄、教育背景、过往职位经历、语言能力。
- **隐私一律剔除**：账号、密码、密钥、手机号、微信号、证件类全部不写
  （他的硬规矩：档案里绝不放账号/密码/密钥）。
- **先找已有的那份来改** —— 他 2026-09-29 已经要过一版（12 节结构的 `十一-完整信息档案_*.txt`）。
  从头重造 = 把沉淀丢掉；正确做法是读旧的 + 记忆 + USER.md，按新形态重组。

### 同步到 IMA：机制 + 硬限制
1. **上传前先去重**：`search_knowledge` 搜「个人使用画像 / 个人档案 / 完整信息档案」等词。
2. `openapi/note/v1/import_doc`（`content_format:1`）→ 拿 `note_id`。
   ⚠️ **标题只能写在 content 首行 `# 标题`**，`import_doc` 没有 title 参数。
3. `openapi/wiki/v1/add_knowledge`（`media_type:11`、`note_info.content_id`、`knowledge_base_id`）。
4. **两次 `code=0` 才算成功**；之后 `get_doc_content` **读回数一遍**关键词（五个分类名各查一次），
   不要只看“上传成功”四个字。
5. 库的分流：**给 AI 用的档案 →「Agent知识库（记忆留痕记录）」**。
6. ⚠️ **IMA 没有修改/替换接口**（全量仅 17 个接口，无 update/delete/rename）
   → 想“在原笔记里改”**只能 `append_doc` 追加**；出全新版本 = 新 note + **让他在客户端手删旧的**。
   **别答应“就地改”**（他 2026-09-22 要求过“笔记内编辑更新”，这条限制要当面说清）。
7. 传完在 `USER.md` 留一条指针（文件路径 + note_id + 「更新一下档案」= 改这一份），下次直接改。

### 长度纪律
长文档**先存文件**；他说手机不方便收文件时，再分段直接发消息（每段 ≤3000 字、标「第 N/M 段」）。

### 同手法也用于「把内部规则交给别的 AI 工具」（2026-10-01）

他原话：「**这个规则我要告诉 codex，但是它的途径和你途径不一样。所以你只需把通用的规则整理一下，我告诉他**」。

→ **不是删减版、也不是照抄版，而是「同一套判断、去掉本机实现」**。判断哪些该删哪些该留：

| 删掉（本机专有，换途径就不适用） | 保留（判断规则，换任何途径都成立） |
|---|---|
| 接口名与路径（`import_doc` / `append_doc` / `add_knowledge` / `wiki/v1` …） | 触发条件、分流规则、新建 vs 追加的取舍 |
| 脚本路径、node 路径、命令行长度上限、调用方式 | 命名/标题格式、日期取哪一天、标题必须写首行 |
| 错误码表（鉴权 / 重复 / 超限 / 版本检查 …） | 成功判定原则（「建了」≠「进库了」）、验证顺序由强到弱 |
| 知识库 ID、文件夹 ID、凭证文件位置 | 验收清单、铁律、风险与合规写法 |

- **交付形态**：一个 md + 同步到 IMA。md 末尾附一节「**本版通用化时删掉了什么**」——
  他自己就知道哪些是环境相关、换机器要重配。
- 成品已归档：`D:\Agent.GongZuoQu\Hermes.GZQ\文档--IMA上传规则\IMA知识库笔记上传规则_通用版_2026.10.01.md`
  （同名笔记已进「Agent知识库（记忆留痕记录）」，note_id `7511296794695148`）。
- **保留多少取决于对方途径差多远**：若对方只能人工在客户端粘贴，「接口 / 验证」两块整体删掉，
  只留内容规则与命名规则。

## References
- [references/profile-archive-structure.md](references/profile-archive-structure.md) — snapshot of the 2026-08 migration for "十一" (e-commerce operator): three versioned archives + the USER/MEMORY condensed split, as a worked example.
- [templates/cross-ai-profile.md](templates/cross-ai-profile.md) — fill-in skeleton for the OUTBOUND profile (五分类 + 行格式 + 内容规则), the shape he signed off on.
