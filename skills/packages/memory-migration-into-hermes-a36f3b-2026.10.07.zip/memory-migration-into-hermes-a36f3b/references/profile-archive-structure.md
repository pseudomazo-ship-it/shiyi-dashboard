# Worked example: migrating "十一" (e-commerce operator) into Hermes

Captured 2026-08. The user moved from one AI assistant ("WorkBuddy") to Hermes and
handed over three successive, increasingly detailed profile archives. This is the
**shape** of the split that worked, with the real budgets.

## Three-version archive (file layer, verbatim, versioned — never overwritten)
Stored under `memories/`:
- `profile-archive-shiyi.md` (21 KB) — v1 from "三哥"/WorkBuddy.
- `profile-archive-shiyi-v2.md` (34 KB) — v2, a more detailed media/reference version.
- `profile-archive-shiyi-v3.md` (45 KB) — v3, the user's own handwritten definitive version.

Each is kept so the user can diff/roll back. The latest is the one read for detail;
the earlier ones are not deleted.

## Condensed entries (always-loaded layer, char-budgeted)
Final state after iterative batching:
- `USER.md` — 9 entries, ~1,151 / 1,375 chars. Carried: identity/role/location/spouse;
  priority metrics; communication style (结论前置, 数字精确, 表格化, 直接给可执行方案,
  禁空话/AI腔, decision-authority "给判断依据让十一决定"); 口令 meanings; input-handling
  defaults (paste→clean/analyze/flag/act); file-version conventions; compliance boundary
  (don't fabricate, don't send without authorization); and a "rule hierarchy"
  (当前指令 > 批次 > 最新母版 > 历史习惯).
- `MEMORY.md` — 15 entries, ~2,153 / 2,200 chars. Carried: business structure (35家主体);
  product line (flagged ⚠️ 以当期资料为准); toolchain (incl. an Edge-vs-Chrome correction);
  delivery rules (Excel/HTML/code); 云仓/快递; high-frequency workflows; IMA knowledge-base
  rules; 公众号 assistant boundaries; 旗舰店考核; brand qualification. Plus a short
  **index pointer** (`详规则见 profile-archive-shiyi-v3.md`) so detailed rules are read
  on demand rather than crammed into the always-loaded budget.

## Budget behavior worth memorizing
- MEMORY.md **saturated at ~96% (2,105/2,200)** and stayed there — the condensing of
  high-frequency rules is done; anything more belongs in the archive file, not memory.
- Several batched adds failed with `would be at N/N chars -- over the limit`; the fix
  was always to **shorten existing entries first** (e.g. dropping historical price
  snapshots from the 云仓 entry) rather than add more. `replace` + `add` in one batch
  keeps it atomic.
- A `replace` was rejected twice because `old_text` didn't byte-match the entry on
  disk (a `榆/岑` typo and a presumed old wording). Pasting the exact text from the
  on-disk `current_entries` is the fix.

## Business-spec dynamic flags
The V3 archive carried: store counts (22家 vs "20多家" historical), body counts (35 vs
37), quarterly revenue (25Q3 322万, 税率0.68% flagged ⚠️异常), product-line specs, W220
批次 colors. Each either stayed in the archive or got a `⚠️ 需核实` / `以当期资料为准`
marker in memory. None were trusted as live facts.
