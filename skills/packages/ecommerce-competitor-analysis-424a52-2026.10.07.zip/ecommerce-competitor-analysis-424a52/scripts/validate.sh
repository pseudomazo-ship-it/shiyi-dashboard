#!/bin/bash
# ecommerce-competitor-analysis Skill 验证脚本
# 验证竞品分析报告完整性与数据合规性

set -e

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo "=== 电商竞品分析 Skill 验证 ==="
echo "Skill目录: $SKILL_DIR"
echo ""

# 1. 检查必要文件存在
echo "[1/7] 检查文件结构..."
REQUIRED_FILES=(
  "SKILL.md"
  "scripts/validate.sh"
  "scripts/ecommerce-analysis.py"
  "references/电商竞品分析指标.md"
  "references/examples/sample-input.md"
  "references/examples/expected-output.md"
  "references/templates/report-template.md"
  "assets/config.json"
)

PASS=true
for f in "${REQUIRED_FILES[@]}"; do
  if [ -f "$SKILL_DIR/$f" ]; then
    echo "  ✅ $f"
  else
    echo "  ❌ 缺失: $f"
    PASS=false
  fi
done

# 2. 检查SKILL.md章节结构
echo ""
echo "[2/7] 检查SKILL.md结构..."
REQUIRED_SECTIONS=("角色设定" "工作流" "输出格式" "示例" "约束条件" "验证 Checklist")
for section in "${REQUIRED_SECTIONS[@]}"; do
  if grep -q "$section" "$SKILL_DIR/SKILL.md" 2>/dev/null; then
    echo "  ✅ 章节: $section"
  else
    echo "  ⚠️  缺失章节: $section"
    PASS=false
  fi
done

# 3. 检查示例输入输出
echo ""
echo "[3/7] 检查示例完整性..."
if [ -f "$SKILL_DIR/references/examples/sample-input.md" ]; then
  INPUT_LINES=$(wc -l < "$SKILL_DIR/references/examples/sample-input.md" 2>/dev/null || echo 0)
  echo "  示例输入: ${INPUT_LINES} 行"
fi
if [ -f "$SKILL_DIR/references/examples/expected-output.md" ]; then
  OUTPUT_LINES=$(wc -l < "$SKILL_DIR/references/examples/expected-output.md" 2>/dev/null || echo 0)
  echo "  预期输出: ${OUTPUT_LINES} 行"
fi

# 4. 检查Python脚本可执行性
echo ""
echo "[4/7] 检查Python脚本..."
PYTHON_SCRIPT="$SKILL_DIR/scripts/ecommerce-analysis.py"
if [ -f "$PYTHON_SCRIPT" ]; then
  if python3 -m py_compile "$PYTHON_SCRIPT" 2>/dev/null; then
    echo "  ✅ Python语法检查通过"
  else
    echo "  ⚠️  Python语法警告（可能无python3）"
  fi
else
  echo "  ❌ 缺失: ecommerce-analysis.py"
  PASS=false
fi

# 5. 检查config.json合法性
echo ""
echo "[5/7] 检查config.json..."
CONFIG="$SKILL_DIR/assets/config.json"
if [ -f "$CONFIG" ]; then
  if python3 -c "import json; json.load(open('$CONFIG'))" 2>/dev/null; then
    echo "  ✅ JSON格式合法"
  else
    echo "  ❌ JSON格式错误"
    PASS=false
  fi
else
  echo "  ❌ 缺失: config.json"
  PASS=false
fi

# 6. 检查报告模板变量
echo ""
echo "[6/7] 检查报告模板..."
TEMPLATE="$SKILL_DIR/references/templates/report-template.md"
if [ -f "$TEMPLATE" ]; then
  VARS=$(grep -o '{{[^}]*}}' "$TEMPLATE" 2>/dev/null | wc -l)
  echo "  模板变量数量: $VARS"
  if [ "$VARS" -gt 0 ]; then
    echo "  ✅ 模板包含变量占位符"
  else
    echo "  ⚠️  模板无变量占位符"
  fi
else
  echo "  ❌ 缺失: report-template.md"
  PASS=false
fi

# 7. 总结
echo ""
echo "=== 验证结果 ==="
if $PASS; then
  echo "✅ PASS - 所有检查通过"
  exit 0
else
  echo "❌ FAIL - 存在上述问题，请修复"
  exit 1
fi
