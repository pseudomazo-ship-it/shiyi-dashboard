#!/usr/bin/env python3
"""
ecommerce-analysis.py
电商竞品数据分析脚本
功能: 读取竞品CSV数据，计算价格竞争力/销量表现/评价质量等维度评分
依赖: Python标准库（csv, json, statistics）
用法: python3 ecommerce-analysis.py --input 竞品数据.csv --output 分析结果.json
"""

import csv
import json
import sys
import argparse
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from statistics import mean


@dataclass
class Product:
    """竞品数据结构"""
    name: str
    price: float  # 元
    sales: int = 0  # 月销量
    rating: float = 0.0  # 评分 0-5
    review_count: int = 0  # 评论数
    seo_score: float = 0.0  # SEO评分 0-10

    # 计算维度评分（0-10）
    def price_score(self, avg_price: float) -> float:
        """价格竞争力: 越低越好"""
        if avg_price == 0:
            return 5.0
        ratio = self.price / avg_price
        if ratio <= 0.8:
            return 9.0
        elif ratio <= 1.0:
            return 7.0
        elif ratio <= 1.2:
            return 5.0
        else:
            return 3.0

    def sales_score(self) -> float:
        """销量表现: 越高越好（对数归一化）"""
        if self.sales <= 0:
            return 0.0
        if self.sales >= 10000:
            return 10.0
        elif self.sales >= 5000:
            return 8.0
        elif self.sales >= 1000:
            return 6.0
        elif self.sales >= 100:
            return 4.0
        else:
            return 2.0

    def rating_score(self) -> float:
        """评价质量: 评分×评论数综合"""
        if self.rating == 0:
            return 0.0
        base = (self.rating / 5.0) * 8.0
        # 评论数加权
        if self.review_count >= 1000:
            bonus = 2.0
        elif self.review_count >= 100:
            bonus = 1.0
        else:
            bonus = 0.0
        return min(10.0, base + bonus)

    def seo_score_normalized(self) -> float:
        """SEO强度: 直接使用（假设输入已归一化到0-10）"""
        return min(10.0, max(0.0, self.seo_score))


def read_csv(input_path: str) -> List[Product]:
    """读取竞品CSV数据"""
    products = []
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    p = Product(
                        name=row.get('name', row.get('产品名', '未知')),
                        price=float(row.get('price', row.get('价格', 0))),
                        sales=int(float(row.get('sales', row.get('销量', 0))),
                        rating=float(row.get('rating', row.get('评分', 0))),
                        review_count=int(float(row.get('review_count', row.get('评论数', 0)))),
                        seo_score=float(row.get('seo_score', row.get('SEO评分', 0))),
                    )
                    products.append(p)
                except (ValueError, KeyError) as e:
                    print(f"⚠️  跳过无效行: {e}", file=sys.stderr)
    except FileNotFoundError:
        print(f"❌ 文件不存在: {input_path}", file=sys.stderr)
        sys.exit(1)
    return products


def analyze(products: List[Product]) -> Dict:
    """执行完整竞品分析"""
    if not products:
        return {"error": "无有效竞品数据"}

    # 计算平均价格
    avg_price = mean([p.price for p in products if p.price > 0]) if any(p.price > 0 for p in products) else 0

    # 各维度评分
    results = []
    for p in products:
        scores = {
            "price_score": round(p.price_score(avg_price), 1),
            "sales_score": round(p.sales_score(), 1),
            "rating_score": round(p.rating_score(), 1),
            "seo_score": round(p.seo_score_normalized(), 1),
        }
        # 综合评分（等权平均）
        scores["overall_score"] = round(mean(scores.values()), 1)
        results.append({
            "name": p.name,
            "price": p.price,
            "sales": p.sales,
            "rating": p.rating,
            "review_count": p.review_count,
            **scores,
        })

    # SWOT分析（基于综合评分最高者）
    best = max(results, key=lambda x: x["overall_score"])
    worst_scores = {k: min(r[k] for r in results) for k in ["price_score", "sales_score", "rating_score", "seo_score"]}
    worst = {k: v for k, v in worst_scores.items()}

    swot = {
        "strengths": f"综合评分最高: {best['name']} ({best['overall_score']}/10)",
        "weaknesses": f"价格竞争力最弱: 需关注价格策略",
        "opportunities": "市场空白点待挖掘（需人工判断）",
        "threats": "头部竞品综合评价较高，进入门槛存在"
    }

    return {
        "products": results,
        "avg_price": round(avg_price, 2),
        "swot": swot,
        "recommendations": [
            "关注价格策略，提升竞争力",
            "加强评价管理，提高评分与评论数",
            "优化SEO关键词覆盖",
        ]
    }


def main():
    parser = argparse.ArgumentParser(description="电商竞品数据分析脚本")
    parser.add_argument("--input", "-i", required=True, help="输入CSV文件路径")
    parser.add_argument("--output", "-o", help="输出JSON文件路径（可选，默认stdout）")
    args = parser.parse_args()

    print(f"📊 读取竞品数据: {args.input}")
    products = read_csv(args.input)
    print(f"✅ 成功读取 {len(products)} 个竞品")

    result = analyze(products)

    output_json = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output_json)
        print(f"💾 分析结果已保存: {args.output}")
    else:
        print(output_json)


if __name__ == "__main__":
    main()
