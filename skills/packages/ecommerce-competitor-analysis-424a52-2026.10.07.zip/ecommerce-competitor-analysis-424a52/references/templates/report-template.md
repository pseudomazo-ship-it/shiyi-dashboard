# 竞品分析报告：{{product_category}}

> 生成时间：{{generated_at}}
> 分析竞品数：{{competitor_count}}款
> 数据来源：{{data_source}}

---

## 执行摘要

{{# 关键发现（3-5条）}}
1. 
2. 
3. 

---

## 竞品对比表

| 维度 | {{# 竞品1名称}} | {{# 竞品2名称}} | {{# 自身产品名称}} |
|------|---------------|---------------|-------------------|
| 价格 | {{comp1_price}} | {{comp2_price}} | {{self_price}} |
| 月销量（估算） | {{comp1_sales}} | {{comp2_sales}} | {{self_sales}} |
| 评分 | {{comp1_rating}} | {{comp2_rating}} | {{self_rating}} |
| 评论数 | {{comp1_reviews}} | {{comp2_reviews}} | {{self_reviews}} |
| 核心卖点 | {{comp1_selling_point}} | {{comp2_selling_point}} | {{self_selling_point}} |
| SEO强度 | {{comp1_seo}}/10 | {{comp2_seo}}/10 | {{self_seo}}/10 |

---

## 多维评分（0-10）

| 维度 | {{# 竞品1}} | {{# 竞品2}} | {{# 自身产品}} | 说明 |
|------|---------------|---------------|-------------------|------|
| 价格竞争力 | {{comp1_price_score}} | {{comp2_price_score}} | {{self_price_score}} | 越低越好 |
| 销量表现 | {{comp1_sales_score}} | {{comp2_sales_score}} | {{self_sales_score}} | 越高越好 |
| 评价质量 | {{comp1_rating_score}} | {{comp2_rating_score}} | {{self_rating_score}} | 综合评分+评论数 |
| SEO强度 | {{comp1_seo_score}} | {{comp2_seo_score}} | {{self_seo_score}} | 关键词覆盖 |
| **综合得分** | **{{comp1_overall}}** | **{{comp2_overall}}** | **{{self_overall}}** | 等权平均 |

---

## SWOT矩阵

### 优势（Strengths）
{{# 竞品相对优势（基于数据）}}
- 
- 

### 劣势（Weaknesses）
{{# 竞品相对不足}}
- 
- 

### 机会（Opportunities）
{{# 市场空白点}}
- 
- 

### 威胁（Threats）
{{# 潜在竞争风险}}
- 
- 

---

## 评价情感分析（Top 3正向词 / Top 3负向词）

| 竞品 | 正向关键词 | 负向关键词 |
|--------|------------|------------|
| {{comp1_name}} | {{comp1_pos_words}} | {{comp1_neg_words}} |
| {{comp2_name}} | {{comp2_pos_words}} | {{comp2_neg_words}} |
| {{self_name}} | {{self_pos_words}} | {{self_neg_words}} |

---

## 行动建议

{{# 按优先级排序（高/中/低）}}
1. **建议1**（优先级：高/中/低）
   - 具体行动：
   - 预期效果：

2. **建议2**（优先级：高/中/低）
   - 具体行动：
   - 预期效果：

3. **建议3**（优先级：高/中/低）
   - 具体行动：
   - 预期效果：

---

## 附录：数据说明

- 价格数据来源：{{price_source}}（抓取时间：{{price_time}}）
- 销量数据：{{sales_source}}（{{sales_note}}）
- 评分数据：{{rating_source}}
- SEO数据：{{seo_source}}

> ⚠️ 本报告数据来源于公开渠道，仅供参考，不构成投资或商业决策建议。
