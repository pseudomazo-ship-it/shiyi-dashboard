# 案例：SDKDNS 登录卡「请等待」—— Hyper-V 保留端口占住内核控制端口（2026-09-14）

## 症状
十一的机场客户端 SDKDNS（Electron，装在 `E:\RuanJian\SDKDNS`）打开后，账号密码已填好（配置里有），点登录**永久卡在「请等待」转圈**，不报错、不返回。

## 排查过程（按时间序，含白走的路）
1. **先怀疑软件文件坏** → 用 `%LOCALAPPDATA%\sdkdns-updater\installer.exe`（同版本 1.6.4、当日下载）提权静默重装到 `E:\RuanJian\SDKDNS`。
   **结果：没用，症状一模一样。** ← 教训：别一上来就重装。
2. 查订阅 / 服务器 / 版本：订阅**有效**（Basic 150G，剩 290 天）、`sdk.dmitai.com:443` **可连通**、版本 1.6.4 与安装包一致 → 排除账号与服务器。
3. `Get-NetTCPConnection` 锁进程：UI 进程持续 `127.0.0.1:<随机端口> → 127.0.0.1:39797 SYN_SENT`，而 **39797 无人 LISTENING**。
4. **读内核日志（决定性证据）**：`C:\Users\Administrator\.config\com.vortex.helper\log\core-2026-09-14.log`
   ```
   level=error msg="External controller listen error: listen tcp 127.0.0.1:39797: bind:
   An attempt was made to access a socket in a way forbidden by its access permissions."
   ```
5. `netsh int ipv4 show excludedportrange protocol=tcp` → `39749-39848` / `39849-39948` / `39949-40048`，**39797 正在其中** → 确诊。

## 修复
提权脚本（`Start-Process powershell -Verb RunAs -File fix.ps1`，结果 `Out-File` 后 Python 读回）：
1. `taskkill /F /IM SDKDNS.exe /T` + `com.vortex.helper.exe`（普通权限报「拒绝访问」，必须提权）
2. `net stop winnat` → 保留段**自动消失**（`netsh delete` 反而报「找不到元素」，说明是 winnat 动态预留的，不是静态排除）
3. `net start winnat`
4. `TcpListener` 绑定 39797 测试 → **SUCCESS**

## 修复后验收（实测）
- 39797 `LISTENING`（PID = 内核进程）
- UI ↔ 内核 `127.0.0.1:14838 → 39797 ESTABLISHED`（原为 SYN_SENT）
- 内核日志只剩 `start clash at: <pid>`，无 bind 报错

## 遗留风险（未处理）
- **重启电脑后可能复发**：winnat 重新启动时会重新预留端口段，可能再压住 39797。已向用户提出做「一键修复脚本 + 把动态端口范围改回 Windows 默认」（本机当时是 `start=10000 num=55000`，Windows 客户端默认应为 49152 起）。**该持久化处理尚未执行、未验证。**

## 环境事实
- 客户端：SDKDNS（Electron + Vortex/clash 内核；helper 在 `%USERPROFILE%\.config\com.vortex.helper\`，含 `service.xml` / `config.yaml`（加密）/ `Country.mmdb`）
- 用户配置：`%APPDATA%\sdkdns\vortex.json`（**账号密码明文**，含订阅信息与 proxy_port 7897）
- 本机另有 HMA VPN 残留网卡（Disconnected）+ `~/.config/clash` 目录；`com.vortex.helper` 监听 7897 供代理使用
- 同类症状若再现：**先读 `~/.config/com.vortex.helper/log/core-<date>.log`**，一行就能看出是不是 bind 被拒。
