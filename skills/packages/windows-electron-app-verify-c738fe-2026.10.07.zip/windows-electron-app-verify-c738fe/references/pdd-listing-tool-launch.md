# 链接差异化·批量上架控制台 —— 启动验收证据与累计修复清单

项目路径：`D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\GPT\软件：自动上架工具`（Electron 桌面应用，package name `product-differentiation-console`，V0.1 MVP）。

## 启动链路
- `启动控制台.bat` → `powershell -NoProfile -ExecutionPolicy Bypass -File start-console.ps1`
- `start-console.ps1`：清 `ELECTRON_RUN_AS_NODE` → 校验 `node_modules/electron/dist/electron.exe` 存在（缺则弹 MessageBox 退出 1）→ `Start-Process electron.exe <appRoot>`
- `安装依赖.bat` → `install-runtime.ps1`：用捆绑 pnpm（`C:\Users\Administrator\.cache\codex-runtimes\codex-primary-runtime\dependencies\`）装依赖 + 设 ELECTRON_MIRROR

## 2026-08-30 实测启动结果（验收通过）
| 检查项 | 结果 |
|---|---|
| start-console.ps1 退出码 | 0（未弹 missing-runtime 报错窗）|
| electron.exe | 存在，v44.0.0（244MB）|
| node_modules/electron 符号链接 | 已修复指向当前路径 `node_modules/.pnpm/electron@44.0.0/node_modules/electron` |
| ELECTRON_RUN_AS_NODE | 空 |
| electron 进程 | 主 PID 4756 + 渲染/GPU/工具共 4 进程，稳定不闪退 |
| 主窗口 | MainWindowHandle=1312810（=0 的 3 个是辅助进程，正常）；IsWindowVisible=True；标题=「链接差异化 · 批量上架控制台」 |

## 累计修复清单（本应用踩过的坑，均已在源码/启动脚本内修好）
1. pnpm 工作区搬家 → electron 符号链接断 → junction 重建 + 改 `.modules.yaml` virtualStoreDir。
2. `ELECTRON_RUN_AS_NODE=1` → electron 以 Node 模式崩在 `app.getPath` → 启动脚本清变量。
3. GPU 进程崩溃（受限环境）→ `src/main.js` 顶部 `app.commandLine.appendSwitch('no-sandbox')` + `app.disableHardwareAcceleration()`（app ready 前）。
4. SKU 自动填写失败 → `fillSkuData`：虚拟列表精确滚到 pending 目标行 + 定位失败重试 + 规格编码列缺失降级跳过 + 主循环/定位统一用库存输入框 scrollIntoView。
5. 用户规则：上架前把平台旧 SKU 全删重加 → 填色后页面自动滚底，滚动定位重构。
6. 「发布新商品」按钮检测：商品列表页有**多个同名元素**（侧边栏导航 46,155 / 46,841，cls 为空）+ **真按钮**（内容区 292,476，cls=`BTN_outerWrapper`）。流程之前的 find 抓到第一个（假按钮）点不中 → 需**优先选带按钮类(BTN|btn|button)的项**，否则回退到面积最大者。真按钮点击 PDD 也「时灵时不灵」（反自动化，`nativeClick` 有时成功有时不跳），最稳是留人工点一下。
7. `selectPublishCategory` 卡死根因：`Boolean(document.querySelector('[data-e2e-id="e2e-publish-button"]'))` 在选类目页**不存在** → `categoryFirst=false` → 整段选类目块被跳过 → 流程停在 /goods/category。**改成只判断 `location.pathname.includes('/goods/category')`**。
8. 类目值：模板默认 `category='其他染发烫发产品'`，但真实三级类目是「**彩染染发膏**」→ 别名表需把默认/未知值回退到 `['彩染染发膏','彩染染发']`（美发护发/假发 > 染发烫发 > 彩染染发膏）。
9. 架构：流程**混用两个浏览器**——「内嵌 browserView」(`WebContentsView`，黑屏/CDP无响应/GPU问题，仅显示层) +「9444 外挂 Chrome」(`pdd-cdp.js` 硬编码 `PORT=9444`，正常)。填充函数 `setFilesOnPlatformInput`（图片上传）原本 `const webContents = browserView?.webContents`（坏的）→ 改成 `const webContents = pddCdp`（9444）。`fillProductAttributes`/`fillSkuData` 流程里传的已是 `pddCdp`。内嵌 WebContentsView 黑屏是已知硬伤，别当流程能用它。
10. 流程「选类目后自动填充」**编排断**：手动用 9444 CDP 选完类目进编辑器后，app 的 `fillPublishTemplate` 不会自动接上填充（`selectPublishCategory` 卡住没正常返回）→ 编辑器保持空白。要全自动需把 `selectPublishCategory` 的类目树点选做稳（定位/展开），让 fillPublishTemplate 能继续。

## 当前状态（⚠️需人工/实测核实）
- 单元测试 17/17 通过；`browser-smoke` 加载 mms.pinduoduo.com 正常、截图成功。
- 全链路自检遗留 3 个问题：① 特殊用途化妆品未选上 ② 库存未填 ③ 详情图 0/100 未上传。
- 卡点：拼多多服务端把自动化会话踢下线（页面显示扫码登录）→ 需人工重新登录商家后台才能验证到「提交成功」。
- 风控提示：拼多多约每登录会话消耗 1 次完整自动化流程；页面 DOM 会随平台更新，标题/保存草稿识别需真机验收。

## 验收/目录
`验收/`（79 项，08.27-08.28 真实拼多多后台 DOM 审计）+ 根目录多张 PNG 界面验收截图 + `step-two-audit.json`/`step-two-error.txt` 实测轨迹。这是判断哪个环节还不稳的证据链，逐项对照用。
