---
name: windows-electron-app-verify
description: "Launch or verify a Windows Electron desktop app."
---

# Windows Electron 桌面应用：启动 / 排查 / 界面验收

十一自己开发多款 Windows 桌面工具（链接差异化·批量上架控制台、订单申诉复议工具、差评自动举报软件）。本技能覆盖：把一个 Electron（或任何 Win32 GUI）应用跑起来、确认它真的启动成功没崩、把看不到的窗口调到前台并截图验收。这些工具多数通过 `*.bat → powershell -File *.ps1 → Start-Process node_modules/electron/dist/electron.exe` 启动。

## 触发场景
- 用户让你「运行一下看看有什么问题」某个 `启动控制台.bat` / `start-console.ps1` 包
- 应用打不开 / 双击没反应 / 闪退 / 窗口不出现
- 需要向用户证明*应用真的起来了*（进程、窗口标题、界面渲染）而非「我猜应该行」

## 启动链路先摸清
先读 `*.bat` 和 `*.ps1`，看它调的是哪个 electron 可执行文件、有没有额外校验。典型链路：
```
启动控制台.bat  →  powershell -File start-console.ps1  →  Start-Process electron.exe <appRoot>
```
`start-console.ps1` 顶部通常会 `$env:ELECTRON_RUN_AS_NODE = $null`（防御这个坑），先确认它在。

## 启动崩溃根因表（按概率）
| 现象 | 根因 | 修复 |
|---|---|---|
| 双击 bat 打不开，弹 "Electron runtime is missing" | pnpm 工作区移动/复制后 `node_modules/electron` 符号链接断裂，仍指向旧路径 | PowerShell `New-Item -ItemType Junction` 重建顶层链接到 `.pnpm/electron@<ver>/node_modules/electron`；同步改 `.modules.yaml` 的 `virtualStoreDir` 为当前路径（Git Bash `rm` 删不掉断链，用 `Remove-Item`） |
| 启动即崩 / `--version` 输出的是 Node 版本(v24 之类) | 环境变量 `ELECTRON_RUN_AS_NODE=1` 强制 electron 以 Node 模式运行，崩在 `app.getPath` | `powershell` 里 `$env:ELECTRON_RUN_AS_NODE = $null`；启动脚本顶部加。判据：`electron.exe --version` 输出 Node 版本 ≈ 大概率有这变量。⚠️ 从 bash/git-bash 启动时 `export ELECTRON_RUN_AS_NODE=""`（空字符串）**仍会触发 Node 模式**——Electron 只看变量*是否存在*（非 NULL），不看真值。**必须 `unset ELECTRON_RUN_AS_NODE`**；`unset` 后 `electron.exe --version` 应显示真正的 Electron 版本（如 v44.0.0） |
| 打开商家后台/登录页时整个应用自动退出，日志 "GPU process isn't usable. Goodbye." (exit 3) | 受限环境（远程桌面/无独显/沙箱受限）GPU 进程无法初始化、反复崩溃 | 在 `app.commandLine.appendSwitch('no-sandbox')` + `app.disableHardwareAcceleration()`（app ready 之前）。`--no-sandbox` 有效、`--disable-gpu` 单独无效 |
| 打包版（electron-builder 产物）启动即崩，弹 "A JavaScript error occurred in the main process / Cannot find module '<pkg>'" | electron-builder 的 `files` 配置（如 `["src/**/*","renderer/**/*","package.json"]`）**不含 node_modules**，但源码某处 `require('<pkg>')`（常见于 CDP/WebSocket 客户端如 `undici`）没被打进 asar | 在 `build.files` 加 `node_modules/<pkg>/**/*`，并把该包加进 `dependencies`（`grep -rhoE "require\\(['\"][^./][^'\"]*['\"]\\)" src/*.js | sort -u` 先列出所有非相对/非 node 内置 require，逐个确认） |
| 启动外挂浏览器失败 "ENOTDIR, not a directory"（`--user-data-dir`/`mkdirSync` 报） | 用 `path.join(__dirname, '..', 'xxx')` 算外挂 profile/数据目录 → 打包后 `__dirname` 在 **app.asar 内**，`..` 推到 `app.asar`（一个**文件**）→ 父路径不是目录 → ENOTDIR | 用 `app.getPath('userData')` 拼（asar 外可写目录），不要用 `__dirname` 推 |
| pnpm install 报依赖链接断 | `.pnpm` 内所有包链接也指向旧路径 | app 启动不需要它；彻底修＝删 node_modules 后 `pnpm install`（store 在 `D:\.pnpm-store\v11`，本地重建快） |

## 启动 Windows Store（UWP / MSIX 打包）应用 —— 不能直接跑 exe
`C:\Program Files\WindowsApps\<Pkg>\...\App.exe` 这类**打包应用**（如 Store 版 ChatGPT）**直接执行 exe 会被 ACL 拒绝 / 起不来**。正确两步：
1. 取启动标识（PowerShell；勿在 bash 里内联 `$_`，见上文引号坑）：
   `powershell -NoProfile -Command "Get-StartApps | Where-Object {$_.Name -like '*ChatGPT*'} | Select Name,AppID | ConvertTo-Json"`
   → `AppID` 形如 `OpenAI.Codex_2p2nqsd0c76g0!App`
2. 用 explorer 启动：`explorer.exe shell:AppsFolder\<AppID>`。**用 Python `subprocess.Popen(["explorer.exe", r"shell:AppsFolder\<AppID>"])` 最稳**（免 bash 对 `!` 的历史扩展）。
3. 验证：打包应用会起**多个同名进程**（主 + 渲染 + GPU + utility），“同名进程很多”是正常结构，别判成异常。

## 窗口起来了但只有 logo / 白屏（app 加载不出来）—— 先查它要连的域名
窗口已出现但内容只是**白屏 + 中央 logo**（splash 卡住）时，别急着说“应用坏了”：
1. **socket 层逐域名探测**（不要用 HTTP 状态码下结论）：`socket.connect((host,443),timeout=5)` 逐个试。本次实测 `chatgpt.com` **超时**，而 `openai.com` / `api.openai.com` / `www.baidu.com` 全通 → 直接锁定“它要连的域名不通”。
2. 读注册表代理配置：`HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings` 的 `ProxyEnable` / `ProxyServer`。本次 `ProxyServer=127.0.0.1:7897`（代理软件在跑、端口可连）但 **`ProxyEnable=0`（系统代理关闭）** → 应用直连超时。
3. ⚠️ 经代理用 `urllib` 访问 `chatgpt.com` 返回 **403 是 Cloudflare 挡裸请求，属正常**，**不能据此判“域名不通”**——通不通只看 socket 层。
- **修复（本次仅定位、未端到端验证）**：在代理客户端打开“系统代理”开关（或置 `ProxyEnable=1`）后**重启该应用**。动之前**先跟用户讲明“开系统代理 = 全机应用都走代理”**，不要擅自改系统代理设置。

## 应用卡在启动/登录转圈（“请等待”、一直转圈）：先查本地端口是不是被系统保留段占了

不是所有“连不上”都是远程域名的事。**应用 UI ↔ 本地内核/服务的回环端口被 Windows 保留端口段占了**，症状一模一样：窗口正常、点登录/启动后**永久转圈**，而**重装、换版本、清配置全都无效**。

**诊断三步（走完基本能定罪）**：
1. **先找应用自己的日志**——最快最准，别猜。Electron/代理类应用常写在 `%APPDATA%\<app>\log\`、`%USERPROFILE%\.config\<app>\log\`、`%LOCALAPPDATA%\<app>\log\`。命中的那行长这样：
   `External controller listen error: listen tcp 127.0.0.1:39797: bind: An attempt was made to access a socket in a way forbidden by its access permissions`
   —— “forbidden by its access permissions” = **被系统禁止绑定**（不是被别的进程占用，是被“保留”）。
2. **看连接状态**：`Get-NetTCPConnection | Where-Object {$_.State -eq "SynSent"}`。UI 进程反复 `SYN_SENT` 到 `127.0.0.1:<port>`、而该端口**没人 LISTENING** → 就是它。
3. **查保留段**：`netsh int ipv4 show excludedportrange protocol=tcp`。端口落在表里 = 确诊。本机由 **Hyper-V / winnat** 预留（典型把 `39749-40048` 这类中段整段吃掉）。

**修复（需管理员）**：
```powershell
net stop winnat          # 停后该保留段会自动消失
# 若仍在，删冲突段：netsh int ipv4 delete excludedportrange protocol=tcp startport=<s> numberofports=<n>
net start winnat
# 验证能绑定：
$l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, <port>); $l.Start(); $l.Stop()
```
验收 = 该端口 `LISTENING` + UI↔内核 `ESTABLISHED`（不再 SYN_SENT）+ 应用日志无 bind 报错。
⚠️ **停 winnat 会短暂断网**，动手前告知用户。

**防复发 = 把「动态端口范围」改回 Windows 默认（根因层修复，实测有效）**：
winnat 预留的段落在哪，取决于系统的**动态端口范围**。这个范围被改宽后，预留段会被推到 `39700-40000` 这种**应用常用端口**的中段，撞车概率大增。本机实测 `netsh int ipv4 show dynamicport tcp` = 启动端口 `10000` / 端口数 `55000`，而 Windows 默认是 `49152` / `16384`。
```powershell
netsh int ipv4 show dynamicport tcp     # 先看：不是 49152/16384 就是被改过
net stop winnat
netsh int ipv4 set dynamicport tcp start=49152 num=16384
netsh int ipv4 set dynamicport udp start=49152 num=16384   # udp 通常本就默认，确认即可
net start winnat
netsh int ipv4 show excludedportrange protocol=tcp         # 预留段应回到高位(如 50000)
```
改完**必须实测绑定**目标端口（`TcpListener` 试绑），不能只看表。本次改完 `BIND 39797 / 39798 / 7897` 全 SUCCESS、预留段只剩 `5357` 与 `50000-50059` → 复发概率大幅下降。若仍撞，再给用户留一键修复脚本。
⚠️ 全程需管理员（`Start-Process -Verb RunAs -File <script>.ps1`），脚本结果 `Out-File` 后由 Python 读回（PS 中文编码坑）。

**别做的事**：出现这种症状**先别急着重装**。本次先重装了一遍，白费——证据一直躺在日志里。顺序永远是 **日志 → 连接状态 → 保留段**，再决定要不要重装。

## 重装到指定目录（electron-builder / NSIS 安装包）
用户要求“装到 E:\RuanJian”这类非默认位置时，NSIS 支持静默 + 指定目录（实测有效）：
```powershell
cmd /c "`"$installer`" /S /D=E:\RuanJian\<AppName>"
```
- `/D=` 必须是**最后一个参数且路径不加引号**——用 PowerShell 的 `-ArgumentList` 数组传会被加引号导致解析失败，**用 `cmd /c` 拼整条命令行**。
- 装完验证：目标目录有 exe，且 `%LOCALAPPDATA%\Programs\<App>` **不存在**（证明没落到默认位置）。
- 重装前**先备份 `%APPDATA%\<app>` 的用户配置**（账号/订阅/登录态在里面；该目录里带 `lockfile`/`LOCK` 的文件会因应用在跑而复制失败 → 先停进程）。
- 应用以更高权限运行时 `taskkill` 报「拒绝访问」：必须提权（`Start-Process powershell -Verb RunAs -File <script>.ps1`）才能杀干净；脚本结果 `Out-File` 后用 Python 读回（见 PS 中文编码坑）。

## 确认「应用真的起来了」（核心验收流程）
1. **进程存活**：`tasklist | grep -i electron` → 4 个进程（主 + 渲染 + GPU + 工具进程）= 正常结构；<4 或进程数持续下降 = 在崩。
2. **主窗口句柄/可见性**：用 PowerShell 从主进程取 `MainWindowHandle != 0` 且 `IsWindowVisible`（其余是**辅助进程**，`MainWindowHandle=0` 是正常的，别误判成问题）。
3. **标题**：`Get-Process electron | Select MainWindowTitle`，应等于 `APP_TITLE`（本项目「链接差异化 · 批量上架控制台」）。标题对 = 渲染进程把界面画出来了。
4. **窗口不在前台**（很常见）：应用从代理终端后台拉起，会被前置窗口（如 Hermes）挡住。用 Win32 置顶，不要花时间在「为什么找不到」上：
```powershell
$h = [IntPtr]<主进程 MainWindowHandle>  # 从上面第2步取
[W]::ShowWindow($h, 9) | Out-Null                              # 9 = SW_RESTORE
[W]::SetForegroundWindow($h) | Out-Null
```
5. **截图验收**：优先 `computer_use capture`；若枚举不到该窗口或连接掉了，改用 Win32 `PrintWindow`：创建兼容位图 → `PrintWindow(hwnd, hdc, 2)`（2 = PW_RENDERFULLCONTENT）→ 存 PNG。

## git-bash → PowerShell 引号坑（必踩，写进脚本文件）
Hermes 的 terminal 走 **git-bash / MSYS**，不是 PowerShell。`powershell -Command '...$_.MainWindowHandle...'` 里所有 `$`、`$_` 会被 bash 提前吃掉 → PowerShell 报 `ParserError: UnexpectedToken` 或空结果。
- **解法**：把 PowerShell 逻辑写进临时 `*.ps1` 文件（`$LOCALAPPDATA/Temp/xxx.ps1`），再用 `powershell -NoProfile -ExecutionPolicy Bypass -File 路径` 运行，一次成形。
- `Add-Type -Language CSharp -TypeDefinition @"..."@` 里若带 `struct`/`out` 参数务必用 here-string，且类名/签名写对，否则报 `AmbiguousParameterSet`/`TypeNotFound`。能不放 struct 就不放，最小化签名。
- **git-bash 会吃掉 Windows 单斜杠参数**：`taskkill //PID <pid> //T //F` 在 bash 里 `//` 被当成路径转换，报「无效参数/选项 - '//PID'」。杀 GUI/Electron 线程用 PowerShell：`powershell -NoProfile -Command "Stop-Process -Name electron -Force"`（或 `-Id <pid>`）。
- **GUI Electron 不能在前台命令结尾加 `&` 后台化**（Hermes 的 terminal 工具会拒绝含 `&` 的前台命令并提示改用 background=true）。长驻 GUI 应用用 `terminal(command=..., background=true)` 拉起。
- 直接改 `workspace-state.json`（应用的持久化状态）要在**停止应用后**再做：运行中的 app 会在某些交互时 `persist()` 重写该文件覆盖你的修改。改完再重启即生效（登录 Cookie 存 `Partitions/<shop>/`，重启保留）。

## 环境与权限注意（牢记，别当结论）
- **cua-driver 有时枚举不到应用窗口**（被挡/位于其它虚拟桌面/连接被回收）。这是**回落时机**：改用 Win32 兜底。**不要**把「cua-driver 找不到窗口」写成永久结论；它只是这一跳不可用。
- **截图/PrintWindow/某些命令可能触发安全审批**，没被同意就**别重试、别换命令绕**——停在该步，用其它可验证证据（进程存活、窗口句柄、标题）向用户报告。
- 这类工具「打开但看不到窗口」常见于**代理终端后台拉起**，不代表用户双击 bat 有问题；帮用户区分「从终端拉起被挡」vs「用户双击也看不到」。

## 交付建议
启动验收的结论要用**可核验证据**支撑（退出码、进程数、MainWindowHandle、IsWindowVisible、标题），别用「应该没问题」。每项给结果+如何复现，让十一对着看。

## 参考
- `references/pdd-listing-tool-launch.md` — 链接差异化·批量上架控制台 这台具体应用的启动验收证据与累计修复清单（该项目的专属细节）。
- `references/sdkdns-port-39797-case.md` — SDKDNS 登录卡「请等待」完整案例：Hyper-V/winnat 保留段占住内核控制端口 39797 的诊断证据链与修复脚本。
