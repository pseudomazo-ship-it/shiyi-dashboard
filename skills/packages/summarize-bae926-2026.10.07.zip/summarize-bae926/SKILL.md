---
name: summarize
description: Summarize URLs or files with the summarize CLI (web, PDFs, images,
  audio, YouTube).
description_zh: 总结网页、PDF、音频和视频内容
description_en: Summarize web pages, PDFs, audio & video
version: 1.0.0
homepage: https://summarize.sh
metadata:
  clawdbot:
    emoji: 🧾
    requires:
      bins:
        - summarize
    install:
      - id: brew
        kind: brew
        formula: steipete/tap/summarize
        bins:
          - summarize
        label: Install summarize (brew)
icon: https://www.google.com/s2/favicons?domain=summarize.sh&sz=256
display_name: summarize
display_name_en: summarize
visibility: public
---

# Summarize

Fast CLI to summarize URLs, local files, and YouTube links.

## Quick start

```bash
summarize "https://example.com" --model google/gemini-3-flash-preview
summarize "/path/to/file.pdf" --model google/gemini-3-flash-preview
summarize "https://youtu.be/dQw4w9WgXcQ" --youtube auto
```

## Model + keys

Set the API key for your chosen provider:
- OpenAI: `OPENAI_API_KEY`
- Anthropic: `ANTHROPIC_API_KEY`
- xAI: `XAI_API_KEY`
- Google: `GEMINI_API_KEY` (aliases: `GOOGLE_GENERATIVE_AI_API_KEY`, `GOOGLE_API_KEY`)

Default model is `google/gemini-3-flash-preview` if none is set.

## Useful flags

- `--length short|medium|long|xl|xxl|<chars>`
- `--max-output-tokens <count>`
- `--extract-only` (URLs only)
- `--json` (machine readable)
- `--firecrawl auto|off|always` (fallback extraction)
- `--youtube auto` (Apify fallback if `APIFY_API_TOKEN` set)

## Config

Optional config file: `~/.summarize/config.json`

```json
{ "model": "openai/gpt-5.2" }
```

Optional services:
- `FIRECRAWL_API_KEY` for blocked sites
- `APIFY_API_TOKEN` for YouTube fallback
