import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

# 数据格式：[(日期, 成交金额, 退款金额, 成交花费, 成交订单, 退款订单), ...]
DATA = [
    # TODO: 替换为从截图提取的实际数据
]

FILE_PATH = r'D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\（通用）、个人工作区\拼多多6-7月交易推广数据汇总_v2.xlsx'


def write_pdd_excel(data, file_path=FILE_PATH):
    """将拼多多交易推广数据写入 Excel 并格式化。"""
    wb = Workbook()
    ws = wb.active
    ws.title = '交易推广数据'

    headers = ['日期', '成交金额', '退款金额', '成交花费', '成交订单', '退款订单']
    ws.append(headers)

    for row in data:
        ws.append(row)

    header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')
    header_alignment = Alignment(horizontal='center', vertical='center')
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_alignment
        cell.border = thin_border

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center', vertical='center')
            if cell.column == 1:
                cell.number_format = 'yyyy-mm-dd'
            elif cell.column in [2, 3, 4]:
                cell.number_format = '#,##0.00'
            else:
                cell.number_format = '0'

    ws.column_dimensions['A'].width = 12
    ws.column_dimensions['B'].width = 14
    ws.column_dimensions['C'].width = 14
    ws.column_dimensions['D'].width = 14
    ws.column_dimensions['E'].width = 12
    ws.column_dimensions['F'].width = 12

    wb.save(file_path)
    print(f'已更新：{file_path}')
    print(f'数据行数：{len(data)}')


def verify_excel(file_path=FILE_PATH):
    """读取 Excel 并输出合计。"""
    df = pd.read_excel(file_path)
    print('行数:', len(df))
    print(df.to_string(index=False))
    print('\n合计：')
    print(df[['成交金额', '退款金额', '成交花费', '成交订单', '退款订单']].sum().to_string())


if __name__ == '__main__':
    write_pdd_excel(DATA)
    verify_excel()
