# -*- coding: utf-8 -*-
"""把多张采集表合并成总表（明细 + 按店统计）
用法: python merge_shops.py <采集表目录> <输出xlsx路径> [mall_id映射.json]
  采集表文件名形如: <店铺名>_商品资质属性采集_YYYY.MM.DD.xlsx
  mall_id映射.json: {"店铺名": "mall_id", ...}（可选，用于在总表补 mall_id 列）
"""
import glob, os, re, sys, json
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

src, out = sys.argv[1], sys.argv[2]
mall = {}
if len(sys.argv) > 3 and os.path.exists(sys.argv[3]):
    mall = json.load(open(sys.argv[3], encoding="utf-8"))

files = [f for f in glob.glob(os.path.join(src, '*商品资质属性采集*.xlsx'))
         if '~$' not in os.path.basename(f)]
data = []
for f in files:
    shop = re.split(r'_商品资质属性采集_', os.path.basename(f))[0]
    wb = load_workbook(f, read_only=True); ws = wb.active; n = 0
    for r in ws.iter_rows(min_row=2, values_only=True):
        if not r or r[0] in (None, ''): continue
        gid, title, ap, pn, rg, note = (list(r) + [''] * 6)[:6]
        data.append([shop, mall.get(shop, ''), str(gid), title or '', ap or '', pn or '', rg or '', note or ''])
        n += 1
    wb.close()
    print('%-30s %4d' % (shop, n))

stat = {}
for row in data:
    s = stat.setdefault(row[0], {'mall': row[1], 'n': 0, 'ap': 0, 'pn': 0, 'rg': 0})
    s['n'] += 1
    if not row[4]: s['ap'] += 1
    if not row[5]: s['pn'] += 1
    if not row[6]: s['rg'] += 1
order = sorted(stat.items(), key=lambda kv: -kv[1]['n'])

wb = Workbook()
hf = PatternFill('solid', fgColor='1F4E79'); hfont = Font(color='FFFFFF', bold=True, size=10)
red = Font(color='C00000', size=10)

ws = wb.active; ws.title = '明细'
HEAD = ['店铺', 'mall_id', '商品ID', '商品标题', '化妆品批准文号', '产品名称', '注册人/备案人名称', '异常备注']
ws.append(HEAD)
for c in range(1, len(HEAD) + 1):
    cell = ws.cell(row=1, column=c); cell.fill = hf; cell.font = hfont
    cell.alignment = Alignment(horizontal='center', vertical='center')
r = 2
for shop, _ in order:
    for row in data:
        if row[0] != shop: continue
        ws.append(row)
        if row[7]: ws.cell(row=r, column=8).font = red
        r += 1
for i, w in enumerate([26, 12, 16, 46, 20, 30, 26, 30], 1):
    ws.column_dimensions[chr(64 + i)].width = w
ws.freeze_panes = 'A2'; ws.auto_filter.ref = 'A1:H%d' % (r - 1)

ws2 = wb.create_sheet('按店统计')
H2 = ['店铺', 'mall_id', '在售商品数', '缺批准文号', '缺产品名称', '缺注册人/备案人', '文号缺失率', '品名缺失率']
ws2.append(H2)
for c in range(1, len(H2) + 1):
    cell = ws2.cell(row=1, column=c); cell.fill = hf; cell.font = hfont
    cell.alignment = Alignment(horizontal='center', vertical='center')
rr = 2
for shop, s in order:
    ws2.append([shop, s['mall'], s['n'], s['ap'], s['pn'], s['rg'], s['ap'] / s['n'], s['pn'] / s['n']])
    ws2.cell(row=rr, column=7).number_format = '0.0%'
    ws2.cell(row=rr, column=8).number_format = '0.0%'
    for col in (4, 5, 6, 7, 8):
        v = ws2.cell(row=rr, column=col).value
        if v: ws2.cell(row=rr, column=col).font = red
    rr += 1
T = {'n': sum(s['n'] for _, s in order), 'ap': sum(s['ap'] for _, s in order),
     'pn': sum(s['pn'] for _, s in order), 'rg': sum(s['rg'] for _, s in order)}
ws2.append(['合计', '', T['n'], T['ap'], T['pn'], T['rg'], T['ap'] / T['n'], T['pn'] / T['n']])
for c in range(1, len(H2) + 1):
    ws2.cell(row=rr, column=c).font = Font(bold=True)
ws2.cell(row=rr, column=7).number_format = '0.0%'; ws2.cell(row=rr, column=8).number_format = '0.0%'
for i, w in enumerate([28, 12, 12, 12, 12, 15, 12, 12], 1):
    ws2.column_dimensions[chr(64 + i)].width = w
ws2.freeze_panes = 'A2'; ws2.auto_filter.ref = 'A1:H%d' % rr

wb.save(out)
print('----')
print('明细行:', len(data), '| 店铺数:', len(stat))
print('缺文号:', T['ap'], '| 缺品名:', T['pn'], '| 缺注册人:', T['rg'])
print('saved:', out, os.path.getsize(out), 'bytes')
