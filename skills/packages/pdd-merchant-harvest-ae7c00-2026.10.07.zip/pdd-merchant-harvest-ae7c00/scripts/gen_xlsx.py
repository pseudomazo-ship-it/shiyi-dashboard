# -*- coding: utf-8 -*-
"""采集结果 → Excel
用法: python gen_xlsx.py <ids_json> <attrs_json> <店铺名> <输出目录>
  ids_json   : {goods_id: 商品标题}
  attrs_json : [{gid, ap, pn, rg, sp}, ...]  (批准文号/产品名称/注册人/是否特殊用途)
输出: <输出目录>/<店铺名>_商品资质属性采集_YYYY.MM.DD.xlsx
"""
import json, sys, os, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

ids_path, attrs_path, shop, out_dir = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
tmap = json.load(open(ids_path, encoding="utf-8"))
attrs = json.load(open(attrs_path, encoding="utf-8"))
A = {d["gid"]: d for d in attrs}

HEAD = ["商品ID", "商品标题", "化妆品批准文号", "产品名称", "注册人/备案人名称", "异常备注"]
wb = Workbook(); ws = wb.active; ws.title = "商品资质属性"
hfill = PatternFill("solid", fgColor="1F4E79"); hfont = Font(color="FFFFFF", bold=True, size=10)
red = Font(color="C00000", size=10)
ws.append(HEAD)
for c in range(1, len(HEAD) + 1):
    cell = ws.cell(row=1, column=c); cell.fill = hfill; cell.font = hfont
    cell.alignment = Alignment(horizontal="center", vertical="center")

stat = {"no_ap": 0, "no_pn": 0, "no_rg": 0, "risk": 0, "missing_id": 0}
r = 2
for gid, title in tmap.items():
    d = A.get(gid)
    if d is None:
        stat["missing_id"] += 1
        ws.append([gid, title, "", "", "", "⚠️接口未返回，需人工核实"])
        ws.cell(row=r, column=6).font = red; r += 1; continue
    ap = (d.get("ap") or "").strip(); pn = (d.get("pn") or "").strip()
    rg = (d.get("rg") or "").strip(); sp = (d.get("sp") or "").strip()
    parts = []
    if not ap:
        stat["no_ap"] += 1
        if sp == "否": parts.append("非特殊用途化妆品，无批准文号")
        elif sp == "是": parts.append("⚠️特殊用途化妆品但未填批准文号"); stat["risk"] += 1
        else: parts.append("未填批准文号")
    if not pn: parts.append("未填产品名称"); stat["no_pn"] += 1
    if not rg: parts.append("未填注册人/备案人"); stat["no_rg"] += 1
    note = "；".join(parts)
    ws.append([gid, title, ap, pn, rg, note])
    if parts: ws.cell(row=r, column=6).font = red
    r += 1

for i, w in enumerate([16, 46, 20, 30, 26, 30], 1):
    ws.column_dimensions[chr(64 + i)].width = w
ws.freeze_panes = "A2"
ws.auto_filter.ref = "A1:F%d" % (r - 1)

os.makedirs(out_dir, exist_ok=True)
date = datetime.datetime.now().strftime("%Y.%m.%d")
out = os.path.join(out_dir, "%s_商品资质属性采集_%s.xlsx" % (shop, date))
wb.save(out)
print("rows:", r - 2, "| stat:", stat)
print("saved:", out, os.path.getsize(out), "bytes")
