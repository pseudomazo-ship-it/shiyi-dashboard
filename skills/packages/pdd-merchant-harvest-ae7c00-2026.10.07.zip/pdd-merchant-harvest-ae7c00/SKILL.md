---
name: pdd-merchant-harvest
description: "Use when 采集拼多多商家后台(mms)商品属性数据。连已登录Chrome逆向接口并发取数出表。"
version: 0.1.0
author: 十一, Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [拼多多, 数据采集, 浏览器自动化, 电商]
    related_skills: [product-price-monitor]
---

# 拼多多商家后台数据采集

连用户**已登录**的 Chrome，找到后台的数据接口，用页面内并发 fetch 批量取数并导出 xlsx。
只做只读采集（列表/属性/价格等），不做写操作。这套"连已登录浏览器 + 找接口 + 并发 fetch"的套路可迁移到其它 SPA 商家后台。

## When to Use

- 批量采集 `mms.pinduoduo.com`（拼多多商家后台）的商品列表 / 商品属性 / 价格等数据
- 商品数量多（几十到几百），逐个点开页面等渲染太慢
- Don't use for：TEMU/跨境后台（接口不同，套路通用但要重新找接口）；改价、上下架等写操作

## Prerequisites

- 用户的 Chrome **已登录**目标店铺后台（Windows 默认 `C:\Program Files\Google\Chrome`）
- Chrome ≥ 136 需手动授权远程调试（每次连接弹一次 Allow，属正常）
- `browser_exec` 可用
- 导出 xlsx：系统 Python 3.11 + openpyxl（`python -m pip install openpyxl --break-system-packages`）

## Procedure

### 1. 连上用户的 Chrome

让用户在 Chrome 打开 `chrome://inspect/#remote-debugging`，勾选 **Allow remote debugging for this browser instance**，弹窗点 Allow。

```python
# browser_exec
print(page_info())
```

- 完成标准：`page_info()` 返回当前页 url/title；若仍报 `remote-debugging-setup`，让用户再点一次 Allow（每连接都会弹）

### 2. 开自己的标签，不动用户的

harness 默认绑在连接时的活动标签。用 `new_tab(url)` 开自己的标签（同 profile 已登录），采完关掉。

```python
new_tab('https://mms.pinduoduo.com/goods/goods_list?msfrom=mms_sidenav'); wait_for_load()
```

- 完成标准：`cdp('Target.getTargets')` 里用户原有标签未被导航

### 3. 找数据接口（通用套路）

注入请求钩子 → 导航目标页 → 读记录。

```python
cdp('Page.enable')
hook = """
window.__reqs=[];(function(){
 var of=window.fetch;window.fetch=function(){try{var u=(arguments[0]&&arguments[0].url)||arguments[0];var o=arguments[1]||{};window.__reqs.push('F:'+u+' || '+(o.body?String(o.body):''))}catch(e){};return of.apply(this,arguments)};
 var oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
 XMLHttpRequest.prototype.open=function(m,u){this.__u=u;this.__m=m;return oo.apply(this,arguments)};
 XMLHttpRequest.prototype.send=function(d){try{window.__reqs.push('X:'+this.__m+' '+this.__u+' || '+(d?String(d):''))}catch(e){};return os.apply(this,arguments)};
})();"""
cdp('Page.addScriptToEvaluateOnNewDocument', source=hook)
goto_url('目标页面URL'); time.sleep(1); wait_for_load(); time.sleep(7)
print(js("(window.__reqs||[]).filter(u=>/goods|detail|property/i.test(u)).join('\\n')"))
```

- 完成标准：打印出数据接口 URL **和** 请求体（含业务参数名）

### 4. 单个复现验证

页面内同步 XHR（同源自动带 cookie）：

```python
js("(function(){var x=new XMLHttpRequest();x.open('POST','/接口路径',false);"
   "x.setRequestHeader('Content-Type','application/json');"
   "x.send(JSON.stringify({goods_id:1004634003809}));"
   "return 'HTTP'+x.status+'|'+x.responseText.slice(0,1500)})()")
```

- 完成标准：`HTTP200` 且返回 JSON 含目标字段

### 5. 并发批量取数

`js()` 内部 `awaitPromise=True`，可直接返回 Promise：

```python
import json
js("""(async()=>{const ids=%s;const out=[];
 for(var i=0;i<ids.length;i+=10){
   var rs=await Promise.all(ids.slice(i,i+10).map(function(gid){
     return fetch('/draco-ms/mms/query-goods-property',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({goods_id:Number(gid)})})
      .then(function(r){return r.json()}).catch(function(e){return {err:String(e)}});}));
   out.push.apply(out,rs);} return JSON.stringify(out);})()""" % json.dumps(ids))
```

- 完成标准：返回条数 = 目标条数；字段可解析
- 实测：**113 条 1.4 秒**

### 6. 落盘出表

browser_exec 的 Python 把结果写入 `$BH_AGENT_WORKSPACE`，再用 `write_file` 写生成脚本、`terminal`（系统 Python）跑出 xlsx：冻结首行、筛选器、缺失标红。

配套脚本（本技能 `scripts/` 下，可直接拿来用）：

```bash
python scripts/gen_xlsx.py <ids_json> <attrs_json> "店铺名" <输出目录>
# 多店汇总（明细 + 按店统计两张表）
python scripts/merge_shops.py <采集表目录> <输出xlsx路径> [mall_id映射.json]
```

- 完成标准：xlsx 行数 = 采集条数，且抽样核对无误

## Quick Reference — 已知接口（拼多多商家后台）

| 用途 | 接口 | 请求体 |
|---|---|---|
| 商品列表 | `POST /vodka/v2/mms/query/display/mall/goodsList` | 分页参数 |
| 商品属性（全字段） | `POST /draco-ms/mms/query-goods-property` | `{"goods_id":123}` |
| 商品主数据 | `POST /glide/v2/mms/query/commit/on_shop/detail` | `{"goods_id":123}` |

- 列表页：`/goods/goods_list?msfrom=mms_sidenav&page=N`（每页 10 条；页面显示"共有 N 条"）
- 详情页（可直开但慢，SPA 需渲染）：`/goods/goods_detail?goods_id=X`
- 属性结构：`result.goods_properties[] = {name, values:[{value}]}` → 转 `name → "值1、值2"`
- 常用属性名：`化妆品批准文号`、`产品名称`、`注册人/备案人名称`、`是否为特殊用途化妆品`、`功效成分`、`生产企业生产许可证号`

## 实战补充（2026-09-16 实测：8 家店连采 460 条）

### 1. 列表接口带 Anti-Content 风控 → 改走 DOM 翻页
手搓 `fetch`/`XHR` 打 `/vodka/v2/mms/query/display/mall/goodsList` 会返回 `{"error_code":54001,"error_msg":"操作太过频繁"}`——因为页面请求带 `Anti-Content` 签名头，脚本请求没有。**不要去逆向签名（合规红线）**。改走：
1. 滚到分页器 `ul[class*=PGT_outerWrapper]`，读 `共有 N 条`；
2. 逐页点「下一页」`li[class*=PGT_next]`，每页从 `document.body.innerText` 按 `^ID:\s*(\d+)` 抽 ID + 上一行标题；
3. **点击必须派发完整鼠标事件序列**：`new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,buttons:1})`，t 依次 `pointerdown→mousedown→pointerup→mouseup→click`。只 `el.click()` 不生效；browser_exec 里 `Input.dispatchMouseEvent` 易超时。
4. 属性接口 `/draco-ms/mms/query-goods-property` **不受此限**，可直接并发打。

### 2. 「在售中(N)」标签是缓存值，切店后不刷新
实测：染发旗舰店实际 58 条，标签却显示 `在售中(99)` = 上一家店的数；植粹显示 58 也疑似顶掉。**只认分页器「共有 N 条」**，并与实际抓到条数交叉核对（`N == uniqueIds`）才算数。

### 3. 切店可能发生在别的标签页
用户可能在**另一个标签**切店，你绑定的标签还是旧店（表象：用户说「店铺变了」而你没变）。做法：`Target.getTargets` 列出所有 `goods_list` 标签 → 逐个 attach 读 `"mallId":(\d+)` → 按目标 mallId 选中 → `cdp('Runtime.evaluate', session_id=sid, ...)` 在该 session 上跑全部 js。

### 4. browser_exec 的 js() 有 ~5 秒上限
长任务（60+ 请求）直接 await 会 `Runtime.evaluate timed out`。**fire-and-forget + 轮询**：`void (async()=>{...window.__prog=..;window.__done=true})()` 立即返回，再每 4 秒读 `window.__prog`/`window.__done`。

### 5. 店铺切换菜单
悬停右上角店铺名会弹出店铺列表 +「查看全部」+ 店铺总数（无需退出重登）。但**不要自动点**——紧邻「退出当前账号」，误点掉登录。

### 6. 输出两档字段
- 精简 5 字段：商品ID / 商品标题 / 产品名称 / 化妆品批准文号 / 注册人·备案人名称（+异常备注）
- 全 20 字段：品牌/产品类型/规格类型/功能/功效成分/适用发质/适用人群/是否孕妇可用/是否特殊用途化妆品/批准文号/注册人·备案人名称+地址/生产企业名称+地址+生产许可证号/产地/生产日期/保质期/包装方式
- 异常备注须区分「未填」与「本就不适用」：批准文号为空时看 `是否为特殊用途化妆品`——「否」→「非特殊用途化妆品，无批准文号」（正常）；「是」→ 标 ⚠️ 风险。

### 7. 与 NMPA 台账交叉核对
- **国妆特字**（特殊化妆品）在「国产特殊化妆品注册信息」表；**粤G妆网备字**（普通化妆品）**不在这张表，属正常**，别误判为缺失。
- 缺失项用官网 `hzpba.nmpa.gov.cn/gccx/`（国产普通化妆品备案信息）复查——**该页有验证码，按规矩不自动识别，填好备案编号后交人工输码**。

## Pitfalls

1. **同步 XHR 循环 100+ 次必超时**（IPC timeout）→ 必须 `Promise.all` 异步并发
2. `js()` 返回超长会被截断 → 分批返回或只回传精简字段
3. **接口法 ≫ DOM 渲染法**：113 条约 1.4s vs 6-7min，且接口能拿到页面未渲染出的字段
4. 空值多半是**卖家未填**（非特殊用途化妆品本就没有批准文号）→ 表内登记异常即可，别当抓取失败
5. JS `element.click()` 触发不了 React 合成事件；要真实点击用 `click_at_xy(x,y)`（坐标取 `getBoundingClientRect`）
6. 每次连接 Chrome 都会弹 Allow，属正常，提醒用户即可
7. 接口路径/参数会随平台改版失效（⚠️ 以实测为准），套路不变
8. 采集完关掉自己开的标签；**只读采集，不写不提交，不擅自对外发送**
9. **翻页别写死页数上限**：循环到"某页 0 条"为止。实测写死 `range(1,14)` 会把大店截断（某店 140 条，13 页只抓到 130）。用足够大的上限（如 20）+ 按 goods_id 去重兜底
10. **计数以新读为准**：刚切店时列表页"在售中(N)"可能是缓存值（实测出现 90 vs 91）。以底部"共有 N 条"或第二次读取为准，并与实际抓到条数核对

## Verification

- 采集条数 == 列表页"共有 N 条"
- 抽样比对接口结果 vs 页面 DOM（本项目对账 112/113 一致，接口法补上了 DOM 漏渲染的 1 条）
- xlsx：行数正确、冻结首行、筛选器可用、缺失项标红
