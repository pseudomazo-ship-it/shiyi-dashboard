---
name: windows-desktop-maintenance
description: "Fix Windows desktop icons & .lnk shortcuts, PS encoding."
metadata:
  hermes:
    tags: [windows, desktop, shortcut, lnk, icon-cache, powershell, encoding]
    category: software-development
---

# Windows 桌面修复：图标缓存 / 快捷方式路径漂移 / PS 中文编码

用户在 Windows 上报「桌面图标变空白/蓝块」「某个文件夹改名后一堆快捷方式图标失效」「快捷方式打不开」时，用本技能。核心三类：**图标缓存损坏**、**.lnk 快捷方式目标/图标路径被改名后的旧路径拖着**、**PowerShell 中文被 subprocess 解码打断**。

## 1. 先诊断：是「图标缓存」还是「路径漂移」

两类症状看着一样，但根因和修法完全不同：

| 症状 | 根因 | 先做什么 |
|---|---|---|
| **所有/多数**图标变蓝色通用块、文字乱码重叠、布局乱 | 图标缓存（IconCache）损坏 | 重建图标缓存（见 2） |
| **个别**软件图标失效，且指向某个被改名的父目录（如 E:\软件 → E:\RuanJian） | .lnk 的 TargetPath/IconLocation 仍指向旧路径 | 读每个 .lnk 的 TargetPath + IconLocation（见 3） |
| 目录改名后**整批**失效 | 同上，批量修 | 见 3 |

**关键：改名后图标失效，光改 TargetPath 不够。** Windows 图标从 `IconLocation` 字段读，不读 TargetPath。只改 TargetPath、IconLocation 还指向旧路径 → 图标依旧失效。**两个都要改成新路径。**（本次踩过：改了 TargetPath 用户仍报「没恢复」，查出来是 IconLocation 旧。）

## 2. 重建图标缓存（标准法）

```powershell
Stop-Process -Name explorer -Force
Start-Sleep -Seconds 2
Remove-Item "$env:LOCALAPPDATA\IconCache.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\iconcache_*.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Force
Start-Process explorer
```

- explorer 重启会闪一下，正常。
- 图标重建**渐进式**：刚重启可能没全刷新，让用户「右键桌面→刷新/F5」再看。
- 重建缓存**只解决**「图标缓存损坏」，**解决不了**「路径漂移」——两者独立，别混。

## 3. 修复 .lnk 快捷方式（TargetPath + IconLocation 都要改）

### 读取目标/图标

```powershell
$sh = New-Object -ComObject WScript.Shell
$lnk = $sh.CreateShortcut($full)
$lnk.TargetPath   # 目标程序
$lnk.IconLocation # 图标来源（改路径时常漏）
```

### 扫全三处位置

改前**必须扫**：`$env:USERPROFILE\Desktop`、`$env:PUBLIC\Desktop`、`$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs`。只扫用户桌面会漏公共桌面/开始菜单的失效项（本次漏过，用户报「没恢复」才发现）。

### 只对「新路径下 exe 真实存在」的才改

改前用 `os.path.exists(new_exe)` 验证：旧 `E:\软件\X` → `E:\RuanJian\X`，**目标 exe 在新路径存在才改**。新路径找不到＝「软件缺失」，处理是**删失效 .lnk（先备份）**或让用户重装，不是改路径。

### ⚠️ 公共桌面 .lnk 需管理员权限才能 Save

`C:\Users\Public\Desktop` 下的 .lnk 有管理员保护，普通进程 `$lnk.Save()` 会报「无法保存快捷方式」。需提升：

```powershell
Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','<script>.ps1' -Verb RunAs -Wait
```

会弹一次 UAC。用户桌面的 .lnk 普通权限即可改。

### 改前备份（可回滚）

改任何 .lnk 前 `Copy-Item`/`shutil.copy2` 备份到临时目录。

## 4. ⚠️ PowerShell 中文输出 → subprocess 解码坑（高频踩）

`subprocess.run(["powershell",...])` 且 PS 输出**含中文**时，Python `capture_output=True` **必现** `UnicodeDecodeError`（PS 默认 GBK，Python 按 UTF-8 解）→ 崩溃且误判「脚本失败」。

**三招绕开（按优先）**:
1. **不读 stdout**：`capture_output=True` 后不解析/打印 `r.stdout`，只用 `r.returncode` 判断。
2. **结果写文件，Python 读文件**：脚本里 `Out-File ... -Encoding UTF8`，Python `io.open(encoding="utf-8", errors="ignore")` 读回。**推荐、最可靠**。
3. **脚本含中文写 .ps1 文件再 `-File` 执行**：不把中文路径当命令行参数传，映射硬编码进 UTF-8-BOM .ps1（`open(path,"w",encoding="utf-8-sig")`），再 `powershell -File fix.ps1`。

**另**：`$var` 在 git-bash 里被转义成空 → PS 报「应为值表达式」——PS 脚本要么写 .ps1 执行，要么避免把 `$` 内嵌进 bash 双引号命令。

## 5. 「软件缺失」≠「路径失效」——别改错方向

改路径前先确认软件**新路径下到底存不存在**。全盘（C/D/E）`os.walk` 找不到该 exe（如 SaySo、GitHub Desktop 本次），＝「软件不在电脑上」——处理是**删失效 .lnk（先备份）**或提示重装。别浪费时间改不存在的目标。

## 6. 同批疑似：C 盘空间清理的安全做法（邻域）

用户报 C 盘满要清理——**先扫描→列表→确认→只清纯垃圾**：临时/缓存/日志（user Temp、浏览器 cache、uv/npm/pip 缓存、traces/logs）。

- **绝不碰**：用户文档、工具本体（`.workbuddy\binaries` 的 node/python/git）、模型缓存（faster-whisper）、工作区数据。
- `uv cache` 用**官方命令** `uv cache clean` 清（能处理占用缓存），别直接删目录。
- 大目录递归统计（`du`/`Get-ChildItem -Recurse`）在 Win 上**慢会超时** → 后台跑或限深度。
- 本机常见大项（参考）：`.workbuddy`（内 `binaries`=工具本体不能删、`traces/logs` 可清）、`.cache`（模型）、`Documents`；uv/npm/pip 缓存。

## 7. 就地改「用户正开着的」Excel/Office 文件 —— 会写不进去

用户说「在原文件改就行」时，**他往往正开着那个文件**。判据（看到就定性，别绕）：

- Python `open(path, "r+b")` 或 `openpyxl.save(path)` 抛 `PermissionError: [Errno 13]`；
- **同目录存在 `~$<文件名>` 锁文件** ← Office 的锁标记，**这个才是铁证**。本次先怀疑了权限/只读属性，白查一轮。
- `shutil.copytree` 备份该目录时 `lockfile` / `LOCK` / `~$*` 会 `Permission denied`（正常，忽略即可）。

**正确姿势（不让用户干等）**：
1. **先把结果写到旁边**（`<原名>_new.xlsx` 或临时目录），别卡在那儿等用户关文件。
2. 告诉用户「关掉 Excel 后回我一句」，并说明工作区里为什么暂时多了一个文件。
3. 用户说关了之后**先复验可写**（再试 `open(path,"r+b")` / 看 `~$` 是否消失），**别只信口头「关了」**。
4. 复验通过 → `os.remove(原文件)` + `shutil.move(_new, 原文件)` 归位，保证工作区只留一个成品（符合用户「同信息只留最新版」的规则）。

## 8. 按「只留最新版」删旧文件 —— 走回收站，不要直接 rm（可回滚）

用户规则「同报表只留最新版、其他历史文件删除」会反复触发删除动作。**删除不可逆 → 一律送回收站，不永久删**，并在回复里明说「在回收站，随时能还原」。

`.ps1` 内核：

```powershell
Add-Type -AssemblyName Microsoft.VisualBasic
[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($f, 'OnlyErrorDialogs', 'SendToRecycleBin')
```

- **路径含中文/emoji（工作区目录叫「电商💚店铺产品数据运营」这种）→ 不要 `powershell -File x.ps1`**（PS 5.1 读 UTF-8 无 BOM 的 .ps1 中文会乱码，路径对不上，还会白报 NOT FOUND）。改成**把脚本转 UTF-16LE base64 走 `-EncodedCommand`**：
  ```bash
  B64=$(python -c "import base64;print(base64.b64encode(open(r'C:/.../x.ps1','rb').read().decode('utf-8').encode('utf-16-le')).decode())")
  powershell -NoProfile -EncodedCommand "$B64"
  ```
  （`-EncodedCommand` 的输出在终端里仍会是乱码，**别看输出内容，看关键字 `RECYCLED` / `NOT FOUND` 就行**。）
- 每个文件**先 `Test-Path -LiteralPath` 判断存在再删**，逐条打印 `RECYCLED: <路径>` / `NOT FOUND: <路径>`，好核对。
- 删完**双重验证**：(a) `ls` 确认目录里真没了；(b) 再用 `Shell.Application` 看回收站：
  ```powershell
  $rb=(New-Object -ComObject Shell.Application).Namespace(10); $rb.Items() | ForEach-Object { $_.Name + ' | ' + $_.ExtendedProperty("System.Recycle.DateDeleted") }
  ```
  ⚠️ **回收站报的时间是 UTC，比北京时间早 8 小时**——别拿它跟本地时间对不上就以为没删成功。
- 删前分清：**成品可删，原始数据/模板/脚本/源码一律不删**（用户明确规则）。输出时把「删了什么」列清楚。
- ⚠️ **同名的迭代文件会互相覆盖**：用同一个生成脚本 + 同一日期后缀再跑一次，旧版就没了。想保留全字段版/初始版，先把原始 JSON 和生成脚本留底（可从原始数据一条命令重跑），而不是靠留着旧 xlsx。

## 9. 文件夹改名报「拒绝访问」—— 是「有进程把它当工作目录」占着

用户说「把 X 文件夹改名成 Y」，`os.rename` / `cmd /c move` / `Rename-Item` **全部报 `WinError 5 拒绝访问`**时，**不要花时间查权限/只读属性/杀软** —— Windows 不允许重命名「被进程当作当前工作目录（CWD）」的目录。

### 三步排除法（1 分钟定性，先做这个）

| 测试 | 结果 | 结论 |
|---|---|---|
| 往目标目录里**写一个临时文件** | 能写 | 不是权限问题 |
| 重命名它的**子文件夹** | 能改 | 锁在**该目录这一层**，不在里面 |
| 重命名**同级其他文件夹** | 能改 | 不是父目录/全局权限问题 |

三条都「能」→ **就是这个目录本身被某进程占着 CWD**，去找进程。

### 找占用进程（关键：命令行里看不出来）

`Get-CimInstance Win32_Process` 的 `CommandLine` **查不到 CWD**（本次靠它白查一轮，一个都没匹配上）。改去翻**目标应用自己的配置/会话记录**里的 cwd：

- Codex：`~/.codex/config.toml`（`[projects.'<path>']`）、`~/.codex/process_manager/chat_processes.json`（`"cwd"`）、`~/.codex/archived_sessions/*.jsonl`、`~/.codex/memories/raw_memories.md`
- 通用起手：`Get-Process | Where-Object { $_.Path -like "*<应用目录>*" }` 列出该应用全部进程，再逐个 `Stop-Process -Force`。

### 杀进程的坑（Electron 类应用）

- Electron 应用**有多层进程**：主 exe + `*-code-mode-host` / `*-computer-use-*` 子进程 + `node` / `node_repl` 运行时 —— **一次能列出 20+ 个**，只杀主进程会被**守护机制重新拉起**（本次杀了 8 个，残留 5 个）。
- **正确顺序**：列全 → 逐个 `Stop-Process -Id X -Force` → `Start-Sleep 3` → **再扫一遍补杀** → 再睡 2s。
- 杀完**立刻试改名**，成功率高。

### ⚠️ 改名之后必须跟着做

1. **应用配置里的旧路径会失效**（`config.toml` 的 `[projects]`、会话 jsonl 的 `cwd`、`chat_processes.json`）→ 提醒用户**在该应用里重新添加项目**，它不会自动找到改名后的目录。
2. **目录内的 .lnk 会失效**（TargetPath / IconLocation 仍指旧路径）→ 见本文第 3 节批量修。
3. **用户可能说「让那个应用自己改」—— 那是行不通的**：应用自己就是占用者，必须先退出它。把这个因果关系直接讲清楚，别陪着试。

### 备用：大批量文件迁移用 robocopy

```bash
robocopy "<源目录>" "<目标目录>" /E /MT:16 /R:1 /W:1 /NP
```

- `/E` 含空目录、`/MT:16` 多线程、`/R:1 /W:1` 不重试不等待。
- **不加 `/MOVE`** —— 用户说「复制」就只复制，删不删由他决定（他常要自己核对后再删）。
- **18GB / 8 万文件量级必须 `background=true` + `notify=true`** 跑，前台必超时；完成后用 `process wait` 或等通知。
- 验证进度**别用** `find | wc -l` 或 `os.walk` 全遍历（8 万文件会超时）→ 先比**顶层项是否逐一对齐**（`os.listdir` 对比新旧顶层），确认无缺失再深入。
- **迁移完成后的三重验证**（用户说「等下删旧目录」时，这三步跑完才许他说可以删；本次 80,939 文件全部通过）：
  1. **robocopy 结尾汇总**：`失败 = 0`，且两边**字节数相等**（本次 80,939 文件 / 18.116 GB / 失败 0 / 16 分 05 秒）。
  2. **`robocopy /L` 复查（最省事也最硬）**：`/L` 只列不拷，**输出为空 = 零遗漏**。
     ```bash
     robocopy "<源>" "<目标>" /E /L /NJH /NJS /NFL /NDL /NP
     ```
     （`/NJH /NJS` 去表头，输出干净，一眼看出还有没有东西要传。）
  3. **独立文件数核对**：自己手写 `os.scandir` 递归计数（**比 `os.walk` 快一个量级**，8 万文件约 1 秒），新旧必须**完全相等**。
- ⚠️ **别只凭 robocopy 的退出码**：它成功复制了文件也返回 1（1 = 有文件被复制，是正常值，不是错误）——用汇总统计判断，不要用退出码判断。

## 相关

- 辅助脚本见 `scripts/rebuild_icon_cache.ps1`（可直接跑）。
