$ErrorActionPreference = "SilentlyContinue"
# Rebuild Windows icon cache: stop explorer, delete icon/thumb caches, restart explorer.
# Run directly: powershell -NoProfile -ExecutionPolicy Bypass -File rebuild_icon_cache.ps1
Stop-Process -Name explorer -Force
Start-Sleep -Seconds 2
Remove-Item "$env:LOCALAPPDATA\IconCache.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\iconcache_*.db" -Force
Remove-Item "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db" -Force
Start-Process explorer
Start-Sleep -Seconds 3
$p = Get-Process explorer -ErrorAction SilentlyContinue
if ($p) { Write-Output "explorer restarted, PID=" + $p.Id } else { Start-Process explorer; Write-Output "explorer relaunched" }
