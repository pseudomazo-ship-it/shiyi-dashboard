---
name: feishu-base-automation
description: "Create/configure a Feishu Base 多维表格 via the bitable API."
version: 1.0.0
author: Hermes Agent
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Feishu, Lark, Base, bitable, 多维表格, API, automation]
---

# Feishu Base (多维表格) automation via API

Complement to the bundled `feishu` skill. The bundled one **reads** a Base by
link and its "Base rows are not text-extractable" limit applies to that
read-by-link path. THIS skill is the **write/configure** path: given the Feishu
app has `drive` + `bitable` scope, you can create a Base, add tables, and add/
remove fields over the REST API. 十一 relies on 多维表格 for 色号表、售后补发表、
采集表 etc. — when he asks you to *build* one, use this, not the read skill.

## Prerequisite: the Feishu app must have `drive` + `bitable` scope
Without it, every bitable/drive call returns:
`{"code":99991672,"msg":"Access denied. One of the following scopes is required:
[drive:drive, drive:drive:readonly, space:document:retrieve]..."}`
For 十一's app `cli_aa1fb172da38dbce`, this was fixed in the Feishu open platform
(`https://open.feishu.cn/app/<app_id>/auth`) → 权限管理 → add 多维表格/云文档
(`bitable`, `drive:drive`) → **版本管理与发布 → 发布一个新版本** (scope changes
do NOT take effect until a version is published).

## Token first
Get a `tenant_access_token` from `.env` creds:
```bash
# read FEISHU_APP_ID / FEISHU_APP_SECRET from E:\软件\Hermes\.env, then:
curl -s -X POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal \
  -H "Content-Type: application/json" \
  -d '{"app_id":"<APP_ID>","app_secret":"<APP_SECRET>"}'
# → {"code":0,"tenant_access_token":"t-...","expire":7200}
```
In `execute_code`, read the creds from `.env` with a regex (the kernel can't see
bash `/tmp` files or MSYS paths — read `E:/软件/Hermes/.env` directly).

## Endpoints (all use `Authorization: Bearer <token>`)
- **Create the Base (app):** `POST /open-apis/bitable/v1/apps` with
  `{"name":"<名>"}` (an empty `folder_token` caused 9499; omit it). Returns
  `app.app_token`, `app.default_table_id`, `app.url`
  (e.g. `https://my.feishu.cn/base/<app_token>`).
- **Add a field:** `POST /open-apis/bitable/v1/apps/<app_token>/tables/<table_id>/fields`
  with `{"field_name":"<名>","type":<n>}`. Returns `code:0,msg:success`.
- **List fields:** `GET .../fields?page_size=50` → `items[]` with
  `field_id`, `field_name`, `type`, `ui_type`, `is_primary`.
- **Delete a field:** `DELETE .../fields/<field_id>`.

## Field `type` codes (verified)
| type | ui_type | use |
|---|---|---|
| 1 | Text | free text (收件人/地址/SKU/订单号) |
| 2 | Number | numeric (数量) |
| 3 | SingleSelect | dropdown (状态/店铺/原因) — add `property:{"options":[{"name":"..."}]}` |
| 5 | DateTime | date (自动创建时间) |
| 17 | Attachment | file |

## Gotchas (each hit while building the 补发表)
- A freshly created Base ships with **sample fields** (文本/单选/日期/附件/数字),
  plus a **primary key** field. List fields first and **delete the extra samples**
  (`单选`/`日期`/`附件`) — but keep the primary key row.
- **The primary key field name CANNOT be renamed.** Renaming it returned
  `{"code":99992402,"msg":"field validation failed"}`. Leave it (first column;
  usable as an auto-sequence/notes column) rather than fighting it.
- **A `field_name` that collides with the primary key** (e.g. re-adding "补发单号"
  when the primary already is it) returns 9499 Bad Request — check the existing
  field list before adding to avoid duplicate/conflicting names.
- Terminal shows Chinese field names as mojibake (`�ռ�������`); the API response
  is fine — verify with `field_name` from the JSON, not the console display.
- The first auto-created table is the only table; rename it via the Base UI or
  add a second table. For a two-table design (客服采集表 + 组长主表), create the
  app then create the second table through the API or instruct the user to add a tab.

## Recommended pattern: batch field creation in `execute_code`
Field-by-field curl gets tedious and re-reads the token each time. Do it in
`execute_code`: read creds from `.env`, fetch the token once, loop an `add_field`
helper (`subprocess.run(["curl",...])` with `json.dumps` payload), print `code/msg`
per field. See the 补发表 build in the session for a working field list:
`收件人姓名/联系电话/收货地址/补发SKU/补发数量/原始订单号/补发原因` (text/number),
`状态` (SingleSelect with 待组长核实/已核实/单号已回填/已完成), `ERP单号`, `核实人`,
`创建时间` (DateTime).

## Bulk read of a big table: dump once, analyze locally
`GET /records?page_size=500` + `page_token` paging. A 6,400-row table dumps in
**~26 s** — but doing per-row field parsing (num()/date/文本) INSIDE the paging
loop makes the same script take **6+ minutes and time out**. Split it:
1. dump script: fetch pages, store raw `[{"rec": <id>, "fields": {...}}]` to
   `cache/<table>_raw.json`, print page progress, done.
2. analysis scripts: load that JSON, all parsing/grouping/filtering locally
   (seconds). Re-dump only when the table changed.

## Bulk delete + rollback
- Backup first: loop `GET /records/<record_id>` per id, save the full `record`
  objects to a local JSON.
- Delete: `POST /bitable/v1/apps/<app>/tables/<tbl>/records/batch_delete` with
  body `{"records": ["recA","recB",...]}` → returns `deleted:true` per id.
- **Verify by re-reading**: a deleted id comes back `code!=0`; re-GET every id and
  assert none still exist. Also re-dump and re-count rows.

## Duplicate detection pitfalls
- Group by (日期, 店铺名); a day+shop pair with >1 record is a duplicate group.
- **Compare BUSINESS values only** (业绩/退款/推广). If the equality signature
  includes metadata (问卷编号, created time), every group looks "different" and
the check silently returns 0 duplicates — that exact bug produced 0 of 70.
- Two records for the same day+shop with **different 业绩** are NOT safe to
auto-delete: keep them and ask 十一, showing the neighbouring days' values as
context for which number is plausible.
