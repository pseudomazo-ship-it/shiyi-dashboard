# Waiting-sentinel implementation (verified 2026-08)

Full working detection script for the Windows workspace. This was built and verified end-to-end this session (synthetic session → emit file → WeChat `sent`).

## Script: `E:\软件\Hermes\scripts\waiting_sentinel.py`

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""等待哨兵: 扫 state.db, 找出正在等十一回复的桌面会话, 写明到 emit 文件."""
import sqlite3, time, json, os, sys


def norm_path(p):
    r"""兼容 MSYS(/e/xx) 和 Windows(E:/xx 或 E:\xx) 两种路径写法."""
    if not p:
        return p
    p = p.replace("\\", "/")
    if p.startswith("/"):
        drive = p[1:2].upper()
        if len(p) > 2 and p[2] == "/":
            return f"{drive}:/{p[3:]}"
    return p


DB_PATH = norm_path(os.environ.get("WAITING_SENTINEL_DB",
                     os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "state.db")))
DB_PATH = os.path.normpath(DB_PATH)
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "waiting_sentinel_state.json")

IDLE_MINUTES = 5
ACTIVE_WINDOW_MIN = 3
COOLDOWN_MIN = 30
DESKTOP_SOURCES = {"desktop"}

DECISION_HINTS = ["是否", "请选择", "请确认", "要不要", "选哪个", "同意吗", "确认吗",
                  "可以吗", "要哪个", "怎么办", "怎么处理", "继续吗", "是否继续",
                  "请回复", "请告诉我", "你决定", "你来定", "选一个", "需要你"]
REPORT_ONLY_HINTS = ["有问题随时", "有需要", "我会继续", "等你看", "完成", "已生成", "已修复",
                     "已验证", "成功了", "通过", "有什么需要我做的"]


def log(msg):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_state(state):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    os.replace(tmp, STATE_FILE)


def looks_like_question(text):
    """真正的等你拍板: agent 明确征询(含决定/征询词) 且句末带问号, 且非纯汇报收尾."""
    if not text:
        return False
    t = text.strip()
    if any(rh in t for rh in REPORT_ONLY_HINTS):
        return False
    has_decision = any(dh in t for dh in DECISION_HINTS)
    ends_question = t.rstrip().endswith(("？", "?", "吗", "呢", "吧"))
    return has_decision and (ends_question or "？" in t or "?" in t)


def main():
    dry_run = "--dry-run" in sys.argv
    now = time.time()
    state = load_state()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.execute("""
        SELECT session_id, MAX(timestamp) AS last_activity
        FROM messages
        WHERE role = 'tool' OR (role = 'assistant' AND finish_reason = 'tool_calls')
        GROUP BY session_id
    """)
    activity_map = {r["session_id"]: r["last_activity"] for r in cur.fetchall()}

    cur.execute("""
        SELECT m.session_id, m.role, m.content, m.timestamp, m.finish_reason, s.title
        FROM messages m
        JOIN (SELECT session_id, MAX(timestamp) AS mt FROM messages GROUP BY session_id) last
          ON m.session_id = last.session_id AND m.timestamp = last.mt
        JOIN sessions s ON s.id = m.session_id
        WHERE s.archived = 0
    """)
    rows = cur.fetchall()

    hits = []
    for r in rows:
        if r["role"] not in ("user", "assistant"):
            continue
        sess = cur.execute("SELECT source FROM sessions WHERE id=?", (r["session_id"],)).fetchone()
        src = (sess["source"] if sess else "unknown") or "unknown"
        if src not in DESKTOP_SOURCES:
            continue
        title = r["title"] or "(无标题)"
        ts = r["timestamp"]
        if not ts:
            continue
        idle_min = (now - ts) / 60.0
        if idle_min < IDLE_MINUTES:
            continue
        last_act = activity_map.get(r["session_id"], 0)
        act_age_min = (now - last_act) / 60.0 if last_act else 999
        if act_age_min < ACTIVE_WINDOW_MIN:
            continue

        waiting, reason = False, ""
        if r["role"] == "user":
            waiting, reason = True, "你刚发话，agent未回答"
        elif r["role"] == "assistant" and looks_like_question(r["content"]):
            waiting, reason = True, "agent抛问题等你确认"
        if not waiting:
            continue

        sid = r["session_id"]
        prev = state.get(sid, {})
        last_remind = prev.get("last_remind", 0)
        if last_remind and (now - last_remind) / 60.0 < COOLDOWN_MIN:
            continue

        hits.append({"session_id": sid, "title": title, "idle_min": round(idle_min, 1),
                     "reason": reason, "content": (r["content"] or "").strip()[:120],
                     "finish_reason": r["finish_reason"]})

    conn.close()
    if not hits:
        log("本次扫描：没有会话在等你")
    else:
        log(f"本次扫描：{len(hits)} 个会话在等你")
        for h in hits:
            log(f"  [{h['title']}] 闲置{h['idle_min']}分钟 | {h['reason']} | 最后: {h['content']}")

    if not dry_run and hits:
        for h in hits:
            state[h["session_id"]] = {"last_remind": now, "title": h["title"]}
        save_state(state)
        log(f"已记录 {len(hits)} 个会话的提醒时间（防重复）")
        if os.environ.get("WAITING_SENTINEL_EMIT"):
            out_path = norm_path(os.environ["WAITING_SENTINEL_EMIT"])
            lines = []
            for h in hits:
                stuck_at = time.strftime("%H:%M", time.localtime(now - h["idle_min"] * 60))
                if "发话" in h["reason"]:
                    wait_type = "你发了消息，我还没回复"
                else:
                    wait_type = "我把问题抛给你，等你拍板"
                lines.append(f"【{h['title']}】")
                lines.append(f"  状态：{wait_type}")
                lines.append(f"  卡住内容：{h['content']}")
                lines.append(f"  约 {stuck_at} 起等你，已拖 {int(h['idle_min'])} 分钟")
                lines.append(f"  回复示例：直接发你的决定（如“同意/改成40%/先跳过”）")
                lines.append("")
            with open(out_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines).strip())
            log(f"已写入提醒文件: {out_path}")


if __name__ == "__main__":
    main()
```

## Emit-file format (what the cron reads)
```
【<会话标题>】
  状态：我把问题抛给你，等你拍板   (或: 你发了消息，我还没回复)
  卡住内容：<last message text>
  约 HH:MM 起等你，已拖 X 分钟
  回复示例：直接发你的决定（如"同意/改成40%/先跳过"）
```

The prefix `【哨兵】`/`【任务等待提醒】` is prepended by the cron's `hermes send` command, NOT in the script. To change it, update the cron prompt's `hermes send --to "weixin:<id>" "<prefix>$(cat <emit>)"` string.

## cron prompt (the prompt that ran as job 95a001bb1e77)
```
你是"任务等待提醒哨兵"的一次守卫轮询。检查是否有桌面端聊天窗口正在等十一回复决定，若有，就发微信提醒他；若无，就静默结束。

第1步：运行检测脚本。用 bash:
  WAITING_SENTINEL_DB="E:/软件/Hermes/state.db" WAITING_SENTINEL_EMIT="E:/软件/Hermes/scripts/waiting_sentinel_emit.txt" python "E:/软件/Hermes/scripts/waiting_sentinel.py"
注意：Windows 下路径必须用 E:/软... 格式，不要用 /e/软件/...。若 python 不在 PATH 用 hermes venv python。

第2步：read_file E:/软件/Hermes/scripts/waiting_sentinel_emit.txt。
  - 非空 → 有会话在等，发微信: hermes send --to "weixin:o9cq...@im.wechat" "【哨兵】$(cat 'E:/软件/Hermes/scripts/waiting_sentinel_emit.txt')"
  - 空/不存在 → 无会话等他，结束，不发任何消息。

第3步：发完微信后，删除 emit 文件，避免下次重复处理。

注意：每5分钟自动跑，后台无人值守，自主完成不要问问题。发送目标固定为 weixin:<chat_id>。若脚本报错，不发消息，静默重试一次或直接结束，宁可漏提醒也不骚扰。最终回复简要说明是否发了提醒、提醒了哪个会话。
```

Health check: find the WeChat target with `hermes send --list weixin`; the bare `hermes send --to weixin` fails (no home channel) — use the full `weixin:<chat_id>`.

## Test harness (throwaway DB, NOT live state.db)
```python
import sqlite3, time, shutil, os, tempfile
tmp = os.path.join(tempfile.gettempdir(), "sentinel_test.db")
shutil.copy("state.db", tmp)  # copy so you don't touch live data
cur = sqlite3.connect(tmp).cursor()
now = time.time()
tsid = "SENTINEL_TEST_" + str(int(now))
cur.execute("INSERT INTO sessions (id,source,title,started_at,last_activity_at,archived,message_count) VALUES (?,?,?,?,?,0,1)",
            (tsid, "desktop", "测试·退款率阈值", now-600, now-600))
cur.execute("INSERT INTO messages (session_id,role,content,timestamp,finish_reason) VALUES (?,?,?,?,?)",
            (tsid, "assistant", "这个退款率阈值，你定个数字吧，要不要改成40%？", now-540, "stop"))
conn.commit(); conn.close()
# then WAITING_SENTINEL_DB=<tmp> WAITING_SENTINEL_EMIT=<emit> python waiting_sentinel.py
# then cat <emit>, hermes send --to "weixin:<id>" "【哨兵】$(cat <emit>)"
```
Clearing the dedup state (`waiting_sentinel_state.json`) is required to retest the same synthetic session id — it goes into COOLDOWN after the first non-dry-run.
