# Delivery & cadence overrides (v3, 2026-09-03)

The multi-DB v2 upgrade fixed COVERAGE + attribution. This session the user made
three **behavioral** changes to the delivery contract. Each is a hard preference
that overrides the earlier defaults. Confirm each with the user before building,
but encode them here so a future session starts already knowing.

## 1. Sustained remind-until-reply (replaces the 30-min COOLDOWN dedup)

User: `哪怕没回复，每2小时也重复提醒直到我回。`

The old `COOLDOWN_MIN = 30` dedup (skip a session for 30 min after reminding) is
**gone**. The stop signal is the *waiting condition ending*, not a cooldown.

Verified logic in `scan_one_db`:
- Record `last_msg_ts` (the waiting message's `timestamp`) in the hit and in the
  state record as `last_msg_ts`.
- **Stop rule (verified):** compare the session's CURRENT last-message timestamp
  to the recorded `last_msg_ts`. Equal → same pending decision → keep reminding.
  Advanced (new message, i.e. user replied) → wait is over → do NOT append to hits.
- Test masked both directions:
  - A not replied on cycle 1 → hits=1; A not replied on cycle 2 (2h later, last
    msg unchanged) → hits=1 (STILL reminded — correct).
  - A replied (last msg became `user`) → hits=0 (stopped — correct).
- To test, DON'T use the live `state.db`. Build a throwaway DB with the schema
  (`sessions` + `messages`), insert synthetic rows, and call `ws.scan_one_db(tmpdb,
  '主工作区', now, state)` directly via `importlib` on the script file.

## 2. Per-session split delivery (each stuck window = its own WeChat message)

User: `把需要我回复的内容以对话框为载体分开发我一次` → "发到我微信（每个卡住的窗口单独发一条微信）".

Before, the emit file was a single text blob and cron did `hermes send ... "$(cat <emit>)"`
(ONE message for all). Now the emit file is a **JSON array**, one object per hit:

```json
[
  {"agent":"主工作区","title":"Bot Chat",
   "header":"【主工作区·Bot Chat】",
   "meta":"状态：agent抛问题等你确认｜闲置 124 分钟｜约 18:12 起等你",
   "content":"<full original message, verbatim>"}
]
```

The cron prompt must **iterate** the array and `hermes send` **once per item**, each
body = `header + "\n" + meta + "\n" + content`. This requires the cron agent to parse
JSON (read_file the `.json`, then a small python one-liner per item or a loop) —
not a single `$(cat ...)`. Rename the env var / path to reflect JSON
(`waiting_sentinel_emit.json`).

## 3. Silent hours (22:00–08:00)

User: `夜间22点-隔天8点这个时间段不通知。`

Put this in the SCRIPT, not the cron, so no emit file / no message is produced at all:

```python
def in_silent_hours(now=None):
    now = now if now is not None else time.time()
    h = time.localtime(now).tm_hour
    return h >= 22 or h < 8

# at the top of main():
if in_silent_hours(now):
    log("夜间静默时段(22:00-08:00)，跳过")
    return
```

Belt-and-suspenders: also state it in the cron prompt ("during 22:00-08:00 the
script bails and produces no emit file, so treat as nothing waiting").

## 4. Frequency 5min → 2h

User moved the cadence from every-5-min to every-2-hours. cron schedule:
`0 */2 * * *` (top of every even hour). Note the difference between "detection
frequency" and the old "dedup cooldown": 2h is how often the cron runs; the
sustained-remind stop rule (above) is what prevents it from re-pushing a
*resolved* wait.

## Combined contract (what the user ended up wanting)
- Scan every 2 hours (cron `0 */2 * * *`), across main + all specialist profile DBs.
- If ANY session is stuck waiting, push ONE WeChat per stuck window (JSON emit).
- Keep pushing the same pending decision every 2 hours until the user replies.
- Never notify 22:00–08:00.
- Stop pushing a window as soon as its last message changes (reply / agent resumed).
