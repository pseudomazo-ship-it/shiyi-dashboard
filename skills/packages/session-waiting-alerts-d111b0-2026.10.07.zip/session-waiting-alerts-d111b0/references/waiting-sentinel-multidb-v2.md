# Multi-DB upgrade (v2, verified 2026-09-02)

The base single-DB script above monitors the MAIN `state.db` only. This session's
real bug: each specialist agent (h-2..h-5, a separate profile) has its sessions
in its OWN `profiles/<name>/state.db`. So a sentry scanning only the main DB
never sees a specialist waiting — "哨兵不灵敏" was a COVERAGE gap, not a
sensitivity bug. The fix is a multi-DB scan, now the working v2 of the script.

## Root cause (verified with the real DBs)
- Main DB: `E:\软件\Hermes\state.db` — 18 desktop sessions.
- Each specialist: `E:\软件\Hermes\profiles\11/state.db`, `.../h-2/state.db`, `.../h-3/state.db`, `.../h-4/state.db`, `.../h-5/state.db` — **same schema** (`sessions`/`messages`), and specialist sessions are ALSO `source='desktop'`.
- The main DB (`SELECT DISTINCT profile_name`) only ever contains `default`; specialist sessions live only in their own DB.
- Key insight: widening `DESKTOP_SOURCES` to `bot`/`profile` is a DEAD END — the sessions aren't in the main DB. Only a multi-DB scan reaches them.
- Also: old-format state records (written before the `agent` field existed) have `agent=None`; the dedup check must NOT treat those as "already reminded" or the first v2 run silently skips real waiting hits. Clear them on upgrade.

## Working v2 additions to the script
```python
def discover_dbs():
    """返回 [(库路径, 智能体标识)]：主库 + 每个分身(profiles/<name>)的库。"""
    dbs = [(MAIN_DB, "主工作区")]
    profiles_dir = os.path.join(HERMES_ROOT, "profiles")
    if os.path.isdir(profiles_dir):
        for name in sorted(os.listdir(profiles_dir)):
            if name.startswith("."):
                continue
            pdb = os.path.normpath(os.path.join(profiles_dir, name, "state.db"))
            if os.path.isfile(pdb):
                dbs.append((pdb, f"智能体 {name}"))
    return dbs
```
- `HERMES_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))`
- `MAIN_DB` replaces the old single `DB_PATH`; keep `WAITING_SENTINEL_DB` env override for MAIN_DB for testing.
- Refactor the per-DB scan into `scan_one_db(db_path, agent_label, now, state)` returning hits, each hit carrying an `agent` field.
- `main()` loops `discover_dbs()`, accumulates `all_hits`, and passes each DB's `agent_label` into every hit.
- The emit line becomes `【<agent>·<window title>】` — e.g. `【主工作区·Bot Chat】状态：agent抛问题等你确认｜闲置124分｜约18:12起等你`.
- Dedup state record becomes `{last_remind, title, content, agent}`; also match on `content` (not just session_id) so a changed question re-reminds, and clear legacy `agent=None` records.

## Verified emit output (multi-DB)
```
【主工作区·Bot Chat】状态：agent抛问题等你确认｜闲置124分｜约18:12起等你
【主工作区·公司🔴主体/财务/仓库/快递】...｜闲置225分｜约16:30起等你
【主工作区·解析星智拼上拼文件夹】...｜闲置35分｜约19:41起等你
【主工作区·Group: rmtjyb089-28pj4】...｜闲置108分｜约18:27起等你
```
All are genuine "waiting for a decision" windows (each ends in `要不要...？`/`你确认...`/`你点头我就发`); a control message `报表已生成完毕，数据核对无误，有问题随时找我。` is correctly EXCLUDED (report-only). This confirms the DECISION/REPORT_ONLY word-split is still the correct anti-false-positive core — the multi-DB change is purely coverage + attribution, not the classifier.

## cron prompt for v2
Same 3-step shape as the base, but step 1 no longer needs a `WAITING_SENTINEL_DB` override (script auto-discovers main + profiles). Pass `WAITING_SENTINEL_EMIT` at `E:/...` and keep the full `weixin:<chat_id>` target. Update the prompt text to say it scans "主工作区 + 各分身智能体 h-2~h-5", so the Cron agent describes coverage correctly.
