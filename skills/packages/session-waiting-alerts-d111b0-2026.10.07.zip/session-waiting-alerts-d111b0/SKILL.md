---
name: session-waiting-alerts
description: "Sessions stuck waiting on the user; auto-remind via phone."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [cron, sentinel, waiting, reminder, wechat, state-db, session-status, notify]
---

# Session-Waiting Alerts (cron sentinel)

## 🔴 当前状态（2026-09-28，**先读这段**，别照着下面的微信旧文改回去）

- **投递渠道已从微信改为 QQ**：哨兵任务（job `95a001bb1e77`，`0 */2 * * *`）的 prompt
  已从「逐条单独发**微信**」改成「逐条单独发 **QQ**」，目标写死 `qqbot:<十一的QQ>`，
  逐条 `sleep 4` 节流保留。原话：「**我在 qq 跟你聊天…你就只需要在 qq 回复我就可以了**」。
  → 改法：重写 job 的 `prompt`（把 `weixin:<chat_id>` 换成 `qqbot:<chat_id>`，再全量替换「微信」），
  改完 `grep` 一遍 prompt 确认「微信」出现次数 = 0。
- ⚠️ **「不需要处理其他窗口的消息」≠ 停掉哨兵**：他 2026-09-28 说过
  「不需要在意其他窗口，也不需要去处理其他窗口的消息」，我据此问要不要停哨兵，
  他选的是「**只改回复渠道（哨兵保留，别动它）**」。
  **哨兵是「替你提醒」，不是「替你处理」—— 别读成停用，也别顺手去 pause 它。**
- **QQ 没有微信那个互动窗口问题**（不会报 `ret=-2 prepare failed`，也不需要「微信保活」配合）
  → 长期无人值守的通知优先走 QQ。
  下文关于 iLink 限流 / `-2` / 飞书兜底的内容是**微信时期**的历史：换 QQ 后基本用不上，
  但**哪天把哨兵改回微信就得重新按那套做**（并同步 resume「微信保活」任务）。
- 改渠道时**顺手把 job 的 prompt 改一致**（no_agent 下 prompt 只是给自己看的文档，
  但下次读到旧渠道/旧时间会困惑）。

A standing request pattern: **"each chat window, while working a task, if I don't reply for N minutes and it needs my decision, send the task name + stuck problem to my WeChat; I reply in WeChat and it continues."** This is a cron + detection-script approach: a script polls the session DB, finds desktop sessions that morphed into a "waiting on the user" state, emits a reminder text, and a cron job delivers it to the user's phone. It is a *notification* sentinel, not an auto-resume mechanism.

**Extension (2026-09, user requirement):** the user now runs several *specialist agents* (each a separate profile/窗口). The sentry must ALSO identify **which agent / which work item** the stuck window belongs to — the reminder must carry that identifier (e.g. `【上架执行】` / `【退款处理】` / `【内容生成】`) so they can tell at a glance which specialist is waiting. When the reminder format is set up, derive the agent tag from the session's project/工作区 name or the window title, and embed it as the prefix in the emit text. Don't send a bare `【会话标题】` that doesn't connect a specialist to the pending decision.

## When to use
- User says "如果超过X分钟我没回复，就把任务发到我微信" / "等回复提醒"/"哨兵".
- You need to know which chat window is stuck waiting for the user and what it's blocked on.
- Trigger = desktop sessions whose last message is the *user* (agent didn't answer yet) OR the *agent* asked a decision question, plus an idle timeout + no recent tool activity.

## Honest scope (set expectations up front)
This detects "waiting for user" and *notifies*. It does NOT seamlessly resume the original window from the phone reply. A WeChat message and a desktop window are **different sessions**; the phone reply comes to a new session that has no memory of the desktop window. The realistic model: user replies in WeChat → you relayed the decision back to the original window. Say this before building, don't promise auto-resume.

## Architecture
1. A Python script (`scripts/waiting_sentinel.py`) queries `state.db` and classifies each desktop session.
2. On a hit, the script writes a reminder file (`waiting_sentinel_emit.txt`) and records the session in a dedup state file (`waiting_sentinel_state.json`).
3. A cron job runs the script every N minutes, reads the emit file, and `hermes send`s the reminder to the user's WeChat, then deletes the emit file.

**Delivery-override (2026-09, user requirements — ask / confirm each before building):**
- **Per-session split delivery:** the user wanted "以对话框为载体分开发" — each stuck window sent as its OWN WeChat message, NOT merged. So the emit file is now a **JSON array** (`waiting_sentinel_emit.json`), one object per hit (`header` / `meta` / `content`), and the cron prompt must loop the array and `hermes send` once per item. This needs a cron prompt that can iterate JSON (e.g. a small python one-liner to assemble each message body), not a single `$(cat <file>)`.
- **Silent hours:** "夜间22点-次日8点不通知" — the script checks `in_silent_hours()` and bails (returns, writes nothing) when `hour >= 22 or hour < 8`. Put this in the script, not the cron, so no emit file is even produced during quiet hours.
- **Frequency:** user moved it from every-5-min to **every-2-hours** (`0 */2 * * *` in cron).

Detection script lives at `E:\RuanJian\Hermes\scripts\waiting_sentinel.py`（Hermes 根目录 2026-09 已迁到 `E:\RuanJian\Hermes`，下文/旧文里的 `E:\软件\Hermes\…` 是迁移前路径，新脚本别照抄）; see the full source + config knobs in `references/waiting-sentinel-impl.md`.

## The core classification (what counts as "waiting on the user")
Hermes classifies a session's lifecycle from the shape of its LAST message (`classify_session_status` in `hermes_state.py`):
- last role == `user` → **interrupted** (you spoke, agent never answered) = waiting for reply.
- last role == `assistant` with **pending tool_calls** (no tool result followed) → interrupted (agent doing work, NOT waiting).
- last role == `tool` → interrupted (agent consuming a result, still working).
- last role == `assistant`, normal finish → complete (done).

So "waiting on the user" is messy in the DB. The robust classifier uses BOTH signals:
- (a) last message is the **user** → definitely waiting for reply, OR
- (b) last message is **assistant AND looks like a decision question** (see below) AND idle ≥ threshold AND no recent tool/stream activity.

The hard part is (b): a normal "task complete, ask me if you need anything" summary is NOT a decision question. The distinguishing feature is **agent explicitly soliciting a decision**, not just containing a question mark.

**⚠️ SUPERSEDED (user's FINAL flip, this session): the user explicitly said 「不需要加请求识别，只要有对话框回复了消息，我5分钟没有回复，就统一转达给我」.** So the semantic decision/report-only split BELOW is now OPTIONAL. The shipped contract as of the latest instruction is **unconditional relay**: any desktop session where the agent spoke last + 5min no reply → remind, REGARDLESS of content. Keep the word-split logic in the script as a toggle (off by default) to reduce spam only if the user later complains about noise — but the current default is relay-everything. **Always read the LIVE script first to know which mode is actually wired** (its `elif r["role"] == "assistant": waiting = True` may already be the simplified unconditional form).

## Decision-hint vs report-only-hint (the anti-false-positive core)
Decide with two word sets — this is the difference between a working sentinel and one that spams the user every 5 minutes:

**DECISION_HINTS** (agent genuinely asking you to pick): `是否, 请选择, 请确认, 要不要, 选哪个, 同意吗, 确认吗, 可以吗, 要哪个, 怎么办, 怎么处理, 继续吗, 是否继续, 请回复, 请告诉我, 你决定, 你来定, 选一个, 需要你`.

**REPORT_ONLY_HINTS** (agent just wrapping up; NOT a decision): `有问题随时, 有需要, 我会继续, 等你看, 完成, 已生成, 已修复, 已验证, 成功了, 通过, 有什么需要我做的`.

Match rule: `any(DECISION in text) AND (ends with ?/？/吗/呢/吧 OR contains ？/?)` AND **no** `REPORT_ONLY` word. A hit like `退款率阈值要不要改成40%？你定个数字吧。` fires; `分析完成，报表已生成，有问题随时说。` does NOT. This was verified: the report-only summary is the exact false positive you must exclude.

## Other filters (all ANDed)
- `archived = 0` — skip archived sessions.
- `source = desktop` (or whatever surface you're monitoring) — skip gateway DMs/bots unless you want them.
- idle minutes ≥ threshold (default 5) since last message, AND ≤ a staleness cap.
- **Staleness cap `MAX_IDLE_MINUTES = 60` — ADOPTED this session (the "闲置 822 分钟为什么给我发" bug).** A window idle longer than the cap is a stale/old message (many hours old) and must NOT be treated as "currently waiting" — skip it. This prevents flood of old reminders so the sentinel only fires for fresh (5–60min) waits. Implement as `if not (IDLE_MINUTES <= idle_min <= MAX_IDLE_MINUTES): continue`. Deliberately drops the >60min "still waiting" case — if the user later wants those reminded again, raise or remove the cap.
- no recent tool/stream activity within `ACTIVE_WINDOW_MIN` (default 3 min) — if the agent is still working (recent `tool`/`tool_calls` rows), it is NOT waiting.

## Reminder cadence — READ the user's current preference before assuming dedup
The cadence toggles between two modes and the user has flipped it twice. **Ask which they want — or read the LAST instruction given.** The two modes:
- **Once-per-message (current, 2026-09 — user's latest flip):** "同样一个需要我待回复的消息，只通知我一次就行". Same session + same pending content → notify ONCE only. Only when the pending content CHANGES (a genuinely new decision question) or it's a brand-new wait do we remind again. **This is the shipped default right now.**
- **Sustained-remind-until-reply (a prior, now-superseded preference):** "哪怕没回复，每2小时也重复提醒直到我回" — remind every cycle until the user replies.

The robust once-per-message dedup (verified this session) keys on **content identity, not timestamps**: `if prev.get("last_remind") and prev.get("content") == cur_content: continue` (skip). `prev` is `state[session_id]`, so this is per-session; `cur_content` is the pending message text. Because the pending decision's own text is the stable identifier, content-equality correctly fires only when the SAME question is (re)presented and stays silent otherwise. Do NOT switch to a timestamp-based rule unless the user asks for sustained-until-reply again — if they say "持续提醒", drop the content-equal early-continue and instead record `last_msg_ts`, reminding while the last-message timestamp stays fixed.

- **(Superseded) sustained-remind stop rule** — only relevant if the user says "持续提醒" again. The old design recorded `last_msg_ts` (the waiting message's timestamp) per session; as long as the current last-message timestamp equals it, the same pending decision → keep reminding; once it advances → stop. This is NOT the current contract (once-per-message is), but keep it in mind if the user flips back.
- `--dry-run` prints hits but does NOT write state or emit file — use it to test.

## Windows path gotcha (bit this session)
The script reads `WAITING_SENTINEL_DB` / writes `WAITING_SENTINEL_EMIT` from env vars. **On Windows, native Python `open()` needs `E:/...` not MSYS `/e/...`.** An `E:/` or `E:\` path works; `/e/软件/...` throws `FileNotFoundError`. The script's `norm_path()` helper converts `/e/foo` → `E:/foo`. In the cron prompt, pass `E:/软件/...` style paths, never `/e/软件/...`. (Native tools don't do MSYS→Windows path translation.)

## cron prompt shape (CURRENT — JSON array + per-item send + throttle)
Give the cron job a self-contained prompt (it runs in a fresh session with no chat context). Template:
1. Run the detection script with `WAITING_SENTINEL_DB=` and `WAITING_SENTINEL_EMIT=` pointing at the real files (E:/ paths).
2. `read_file` the emit file. Empty/missing → nothing waiting, stay silent. **The emit file is a JSON ARRAY — one object per hit** (`header` / `meta` / `content`) — so do **NOT** `$(cat)` it as one blob. Iterate the array and `hermes send` **once per item**; message body = `header` + blank line + `meta` + blank line + `content` (content is the raw pending message, passed through **verbatim — never summarized, never truncated**).
3. **Throttle the batch: `sleep 4` between sends** (put the instruction in the prompt explicitly, e.g. `⚠️ 每发完一条必须 sleep 4 秒`). A tight loop of 5-6 `hermes send` calls trips iLink's rate-limit circuit. If a batch is big, cap it and let the next cycle carry the rest instead of hammering.
4. Delete the emit file after sending so it's not re-processed next cycle.
5. Night silence (22:00–08:00) is handled **inside the script** (it writes no emit file at all), so the prompt needn't check the clock — but say so in the prompt, otherwise a future run "fixes" it in the wrong place.

Watch the delivery target: **`hermes send --to weixin` (bare platform) FAILS with "No home channel set"** — target must be the full `weixin:<chat_id>` (find it with `hermes send --list weixin`). Prefix string is hardcoded in the prompt (e.g. `【哨兵】`); change it there, not in the script.

**⚠️ CORRECTION (2026-09-12, verified against the live server): that "rate limited" message is usually a MISDIAGNOSIS — the WeChat channel is simply DOWN, not throttled.**
`hermes send --to weixin:...` returning `iLink sendmessage rate limited; cooldown active for 30.0s` *repeatedly* (every retry still reports exactly 30.0s) does NOT mean a 30s cooldown is passing. In the adapter (`gateway/platforms/weixin.py`), `_send_text_chunk_locked` treats iLink `ret/errcode == -2` as a rate limit (`RATE_LIMIT_ERRCODE`), and with `WEIXIN_RATE_LIMIT_CIRCUIT_THRESHOLD=1` a single -2 opens a 30s circuit. So each new attempt: circuit expired → real send → server answers -2 again → circuit re-armed → the same "cooldown 30.0s" string. Retrying every 30-60s never helps; it can loop forever.

Diagnose it directly instead of guessing (bypasses the gateway, prints the raw iLink response):
`python E:/RuanJian/Hermes/scripts/_ilink_send.py ctx|noctx E:/RuanJian/Hermes/scripts/_msg_0.txt`
On 2026-09-12 both modes returned `{"ret":-2,"errmsg":"prepare failed"}` — i.e. the iLink bot cannot push to this user at all right now (interaction/session window closed; the tokenless "degraded fallback" only auto-triggers on `-14`, and it fails too).
**What actually works when this happens:** `python E:/RuanJian/Hermes/scripts/_sentinel_deliver.py` — it reads the emit JSON, tries WeChat, and on failure re-sends the SAME full text to Feishu (`feishu:oc_bca55f9a0eb248be1147220b837bf1c7`) plus a one-line channel note. Feishu returned `sent` while WeChat was down. Real fix for the user: send any message to the Hermes bot in WeChat once, which reopens the push window.
Practical cron rule: if the first WeChat send fails, do NOT sit in a retry loop — fall back to Feishu immediately and report the channel outage.

**Original note (kept for the genuinely-throttled case):** when several per-session messages must be sent, send them **one at a time with `sleep 4` between each** (each message individually, 4s apart), and only report "sent" on a non-rate-limited `sent` reply. Do NOT rapid-fire `hermes send` calls in a tight loop to retry. If even 4s spacing still hits the cooldown on a 5-6 message batch, reduce the per-cycle count (send 3, let the next cycle pick up the rest) — don't keep hammering.

## Sensitivity diagnosis (verified 2026-09) — why it feels "not sensitive"

When the user asks "哨兵是不是不灵敏?" don't answer from memory — run a dry-run AND audit the actual DB. Two concrete failure classes surfaced:

1. **`source` filter is too narrow AND — the real bug — specialists live in SEPARATE DB files.** The script only monitors `DESKTOP_SOURCES = {'desktop'}` against the MAIN `state.db`. But each specialist agent (h-2..h-5, a separate profile) has its OWN `state.db` at `E:\软件\Hermes\profiles\<name>\state.db` (same schema: `sessions`/`messages`, and their sessions are also `source='desktop'`). So the sentry scanning only the main DB NEVER sees a specialist waiting — **widening `DESKTOP_SOURCES` alone cannot fix this, because those sessions aren't in the main DB at all.** The verified fix is a **multi-DB scan**: enumerate `main state.db` + `profiles/*/state.db` (skip `.deleted`), run the classifier against each, and tag every hit with the agent it came from (`主工作区` / `智能体 h-2` / ...). A future session debugging "哨兵不灵敏" must FIRST check whether the waiting window belongs to a specialist profile and, if so, look in that profile's own DB — not assume everything is in the main `state.db`. Check the real distribution with `SELECT source, COUNT(*) FROM sessions GROUP BY source` AND confirm whether specialists have their own DB files before assuming coverage.

2. **The shipped script may have REGRESSED from the reference.** The `references/waiting-sentinel-impl.md` version gates `assistant` on `looks_like_question(...)` (the anti-false-positive core). But the ACTUAL `scripts/waiting_sentinel.py` on disk may have been simplified to `elif r["role"] == "assistant": waiting = True` — which treats EVERY assistant reply as "waiting" (false-positive spam) and abandons the DECISION/REPORT_ONLY word-split. **Always read the LIVE script, not the reference transcript, before judging its behavior.** The reference is the *intended* design; the .py file is what really runs. Verify which one is current before patching either.

3. **`idle` upper bound.** If the version you're testing has a `MAX_IDLE_MINUTES` guard (">60min stale → skip"), a window stuck waiting for over an hour is NEVER reminded — which reads as "insensitive" for something genuinely awaiting you. Decide deliberately: no upper bound (remind until answered, rely on COOLDOWN to throttle) vs a staleness cutoff.

Diagnostic recipe: `python scripts/waiting_sentinel.py --dry-run` to see what it currently finds, then `SELECT source,title,last_activity_at,last message role from sessions JOIN messages ...` to look for waiting windows it's NOT catching. An empty "nothing waiting" result is NOT proof it's working — it may be a coverage gap.

### "为什么没有哨兵提醒我?" / "是不是坏了?" — answer in THIS order, with evidence, never from memory
1. **Silent hours** — if it is now 22:00–08:00 the script bails by design; that IS the answer, not a defect (say it plainly so the user doesn't think it died).
2. **Nothing is actually waiting** — run `--dry-run`. An empty result is the correct answer; the user is often conflating "no tasks" with "no pending decisions", so say 「当前没有会话在等你」 and, if they want progress rather than pending decisions, check the projects for them (the sentinel deliberately does NOT report progress).
3. **Staleness cap** — a window idle longer than `MAX_IDLE_MINUTES` is deliberately skipped, so a genuinely-waiting-but-old window yields silence. State the cap value out loud when this is the cause.
4. **Already reminded once** — per-message dedup means the same pending text never fires twice; only changed content re-fires. If the user says "I never got it", check whether it fired earlier and the content simply hasn't changed.
5. **Coverage gap** — the waiting window may live in a specialist `profiles/<name>/state.db` (see the multi-DB section).
6. **Delivery channel down** — detection worked but the WeChat push failed. Look for the iLink `ret=-2` signature in the cron run output before blaming sensitivity; the recovery is the user sending any message to the bot once.
Report which of the six it was plus the single command that proves it. Same discipline in reverse for "突然给我发了一堆/闲置822分钟为什么发我" → that is the staleness cap being absent/raised, or content-change re-firing.

## How to widen to specialist agents (2026-09, VERIFIED multi-DB approach)
The user runs several specialist agents (each a separate profile/窗口) and wants the sentry to flag WHICH one is waiting. Because each specialist has its own `profiles/<name>/state.db`, the fix is **not** a source-filter change — it's a **multi-DB scan**. Implemented and verified in `scripts/waiting_sentinel.py` v2:

1. **Discover DBs:** `discover_dbs()` returns `[(main state.db, "主工作区"), (profiles/<name>/state.db, "智能体 <name>"), ...]` by globbing `HERMES_ROOT/profiles/*/state.db` (skip `.deleted`). `HERMES_ROOT` = `dirname(dirname(script))`.
2. **Scan each DB** with the same classifier, and carry the DB's agent-label into every hit (`agent` field).
3. **Tag the emit text** with `【<agent>·<window title>】` so the reminder names the specialist. Verified output: `【主工作区·Bot Chat】状态：agent抛问题等你确认｜闲置124分｜约18:12起等你`.
4. **Dedup by agent too** — the state record now stores `{last_remind, title, content, agent}`; a legacy record with `agent=None` (written by an older script) must NOT be treated as "already reminded," so clear it on first run of the new version or those hits get silently skipped.

The decision-hint/report-only split still applies per window; the multi-DB change is purely about *coverage* + *attribution*. Don't widen `DESKTOP_SOURCES` to `bot`/`profile` expecting to reach specialists — their sessions aren't in the main DB, so that's a dead end.

## Verification (don't trust "it was created")
Test the whole chain with a throwaway DB and a synthetic session, NOT the live `state.db`:
1. Copy `state.db` to a temp file, insert a fake desktop session + an assistant message with a decision hint (idle > threshold, no recent tool rows).
2. Run the script against the temp DB (`WAITING_SENTINEL_DB=<temp>`), `WAITING_SENTINEL_EMIT=<emit file>`; confirm it writes a non-empty emit file with `【<title>】/ 卡住内容 / 闲置 X 分钟`.
3. `cat` the emit file, then `hermes send` it to the user; confirm `sent`.
4. Clean up the temp DB, emit file, and clear `waiting_sentinel_state.json` (a test session will be in COOLDOWN from the earlier non-dry-run and block a retest).

**Do NOT use the live `state.db` session as the test subject** — your own conversation is constantly producing messages, so the "last message" keeps moving and the injected test row gets overshadowed by real activity. Use a dedicated synthetic session id.

## Notes
- `stt.enabled` is irrelevant here; this is session-state detection, not voice.
- This is a *notification* companion to the desktop work, not a replacement for the user reviewing/tasking in the window. The email-style pattern is: sentinel pushes the pending decision; the user decides (in WeChat or back in the window); the work continues.

See `references/waiting-sentinel-impl.md` for the exact classifier code, env-var wiring, emit-file format, and the cron job prompt that worked. For the **v2 multi-DB upgrade** (covering specialist agents h-2..h-5 whose sessions live in separate `profiles/<name>/state.db` files), see `references/waiting-sentinel-multidb-v2.md` — the verified `discover_dbs()` + `scan_one_db()` refactor and the `【<agent>·<title>】` emit attribution. For the **v3 delivery/cadence overrides** (sustained remind-until-reply, per-session JSON split delivery, 22:00–08:00 silent hours, 2h frequency), see `references/waiting-sentinel-delivery-v3.md`.
