# -*- coding: utf-8 -*-
"""单页 Excel 骨架 —— 所有数据堆在一个工作表里，可打印在一页宽。

用法：改 BASE / D（数据源） / 各 section() 之间的内容即可。
运行：uv run --with openpyxl python this_script.py [输出路径]

设计要点：
  · 只有一个工作表；“所有数据在一个页面内” = 一个 sheet，不是多个 tab
  · 蓝字 = 非计算来源（估算/补录/外部提供）；黑字 = 计算所得
  · 估算链上的每一格都要蓝（比率/差值/倍差一并标）
  · 冻结首行、无网格线、横向、fitToWidth=1
"""
import json
import os
import sys

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ---------------- 输入 ----------------
BASE = r"<工作区项目目录>"
D = json.load(open(os.path.join(BASE, '脚本', '_computed.json'), encoding='utf-8'))  # 由看板脚本 dump
OUT = os.path.join(BASE, '<成品名含日期>.xlsx')
if len(sys.argv) > 1:          # 目标被 Excel 占用时先写到临时路径
    OUT = sys.argv[1]

# ---------------- 样式 ----------------
F_TITLE = Font(name='微软雅黑', size=14, bold=True, color='FFFFFF')
F_SEC = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
F_HEAD = Font(name='微软雅黑', size=10, bold=True, color='1F2937')
F_TXT = Font(name='微软雅黑', size=10, color='000000')
F_EST = Font(name='微软雅黑', size=10, color='2F5597')     # 蓝 = 非计算来源
F_SUM = Font(name='微软雅黑', size=10, bold=True, color='000000')
F_NOTE = Font(name='微软雅黑', size=9, color='7F7F7F')
FILL_TITLE = PatternFill('solid', fgColor='0F1117')
FILL_SEC = PatternFill('solid', fgColor='2F5597')
FILL_HEAD = PatternFill('solid', fgColor='DCE6F1')
FILL_SUM = PatternFill('solid', fgColor='FFF2CC')
FILL_EST = PatternFill('solid', fgColor='F2F7FF')
THIN = Side(style='thin', color='BFBFBF')
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

N = '#,##0'                 # 计数
P2 = '0.00%'                # 比率
P1 = '0.0%'
D4 = '0.0000'               # 平均分
PD = '+0.0000;-0.0000;0.0000'   # 差值（带符号）
MUL = '0.00"×"'            # 倍数
NCOLS = 12                  # 合并单元格时用得上的总列数

wb = Workbook()
ws = wb.active
ws.title = '全部数据'        # 只要一个工作表
r = 1


# ---------------- 行写入辅助 ----------------
def title(text, sub=''):
    global r
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, text)
    c.font = F_TITLE; c.fill = FILL_TITLE
    c.alignment = Alignment('center', 'center')
    ws.row_dimensions[r].height = 26
    r += 1
    if sub:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
        c = ws.cell(r, 1, sub); c.font = F_NOTE
        c.alignment = Alignment('left', 'center'); r += 1


def section(text):
    global r
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, text)
    c.font = F_SEC; c.fill = FILL_SEC
    c.alignment = Alignment('left', 'center')
    ws.row_dimensions[r].height = 20
    r += 1


def head(cols):
    global r
    for i, h in enumerate(cols, 1):
        c = ws.cell(r, i, h); c.font = F_HEAD; c.fill = FILL_HEAD
        c.alignment = Alignment('center', 'center'); c.border = BOX
    r += 1


def row(vals, fmts=None, est=None, summary=False):
    """est = 需要标蓝的列号集合（1 起）；summary = 合计行样式"""
    global r
    est = est or set(); fmts = fmts or []
    for i, v in enumerate(vals, 1):
        c = ws.cell(r, i, v); c.border = BOX
        c.alignment = Alignment('left' if i == 1 else 'center', 'center')
        if fmts and i <= len(fmts) and fmts[i - 1]:
            c.number_format = fmts[i - 1]
        if summary:
            c.font = F_SUM; c.fill = FILL_SUM
        elif i in est:
            c.font = F_EST; c.fill = FILL_EST
        else:
            c.font = F_TXT
    r += 1


def blank(h=6):
    global r
    ws.row_dimensions[r].height = h
    r += 1


# ---------------- 内容（按需改） ----------------
title('报表标题', '口径：…   生成：Hermes YYYY.MM.DD')

blank()
section('【一】总览')
head(['指标', '数值', '说明'])
row(['示例总量', D['T_TOTAL'], '口径说明', ][:3], [None, N, None])
row(['示例合计', D['T_TOTAL'], ''], [None, N, None], summary=True)

blank()
section('【二】分项（估算行整条标蓝）')
head(['项目', '数量', '占比', '估算列'])
row(['示例', 100, 0.5, 0.9], [None, N, P2, MUL], est={2, 3, 4})

blank()
section('【三】口径说明')
for t in ['1. 数据来源…', '2. 推算/补录口径…', '3. 蓝色字＝非计算来源；黑色字＝计算所得。']:
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, t); c.font = F_NOTE
    c.alignment = Alignment('left', 'center'); r += 1

# ---------------- 列宽 / 冻结 / 打印 ----------------
for i, w in enumerate([22, 12, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12][:NCOLS], 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A2'
ws.sheet_view.showGridLines = False
ws.page_setup.orientation = 'landscape'
ws.page_setup.fitToWidth = 1
ws.page_setup.fitToHeight = 0
ws.sheet_properties.pageSetUpPr.fitToPage = True
ws.print_options.horizontalCentered = True

wb.save(OUT)
print('已生成:', OUT, os.path.getsize(OUT), '字节 | 工作表:', wb.sheetnames, '| 行数:', r - 1)
