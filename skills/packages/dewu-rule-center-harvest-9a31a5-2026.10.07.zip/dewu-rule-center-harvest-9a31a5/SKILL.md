---
name: dewu-rule-center-harvest
description: "Use when 采集得物(stark.dewu.com)规则中心内容入库或要绕过其接口签名限制。"
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [得物, dewu, stark, 规则中心, 采集, 签名, IMA知识库]
    related_skills: [cdp-browser-automation, pdd-help-center-harvest, ima-notes-and-kb-workflow]
---

# 得物规则中心采集

## 当前进度（2026-10-04）

| 分类 | 状态 |
|---|---|
| **规则公示中心** | ✅ 已采 340 条 → 162 万字 → 切 79 篇 → 全量入 IMA「得物平台-电商学习」，回读验证 79/79 在位、0 失败、0 重名 |
| 商品管理 / 交易管理 / 售后服务 / 营销推广 / 违规管理 / 规则解读 | ⬜ 未采 |
| 协议专区 / 平台资讯 / 违规公示 / 招商入驻 / 历史协议规则 | ⬜ 未采 |

参考用时：单分类 340 条约 40 分钟（只能驱动页面，没有捷径）。
剩余 11 个分类规模未知，采之前先跑一遍分类树拿 `total` 估工时。

## 何时用
十一要「把得物规则中心内容存进知识库」「采集得物平台规则」时。

## 结论前置：得物和拼多多不一样，**接口有签名保护**

| | 拼多多帮助中心 | 得物规则中心 |
|---|---|---|
| 接口直连 | ✅ 可用 | ❌ 401 签名认证失败 |
| 全站规模 | 3,473 条 | 仅「规则公示中心」就 340 条 |
| 采集耗时 | 90 秒 | 约 40 分钟（只能驱动页面）|
| 正文长度 | 中位 90 字 | 中位 3,610 字 / 最长 2.5 万字 |

## 服务端接口（供参考，**不要直连**）

```
POST /api/v1/h5/merchant-study/merchant/document/common/stark/getCategoryTree   分类树
POST /api/v1/h5/merchant-study/merchant/rule/votePage                          列表分页(type=2)
POST /api/v1/h5/merchant-study/merchant/rule/page                              列表分页(带 levelOneCode)
POST /api/v1/h5/merchant-study/merchant/document/common/stark/getDocumentDetail 正文
```

请求头：`SK`(静态密钥) / `clientId: stark` / `sysCode: DU_USER` / `channel: pc` / `appid: h5` / `platform: h5` / `passportToken`
请求体：每个都带 `sign` 字段。

**⚠️ 不要复现这个 sign**：
- 它是平台接口防护，不是验证码；逆向它 = 绕过防护 + 容易触发风控
- 实测 `sign` 是**无状态的**（同样参数永远同 sign，无时间戳）——技术上很容易推，但这正是**不该推**的信号
- 实测：无 sign / 空 sign / 假 sign 全部 401；只有页面自己生成的 sign 才 200
- **正确做法**：让页面自己发请求，只截获响应

## ✅ 可行路径：驱动页面 + 截获响应

### 第一步：拿全量 id（翻页 + hook）

**必须用 Browser Use（`browser_exec`）的真实鼠标点击**：
- ❌ CDP `Input.dispatchMouseEvent`（含完整 move/press/release 序列）**驱动不了 Angular** —— 实测点分页 `activePage` 不变
- ✅ `browser_exec` 的 `click_at_xy(x, y)` **有效**
- ❌ JS `element.click()` 对标题div有效、对分页无效

**hook 必须同时挂 XHR 和 fetch**（得物用的是 `fetch`）：
```js
window.__cap = [];
// XHR
const oO = XMLHttpRequest.prototype.open, oS = XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open = function(m,u){ this.__u=u; return oO.apply(this,arguments); };
XMLHttpRequest.prototype.send = function(b){ const self=this;
  this.addEventListener('load', function(){ try{
    if(/merchant-study/.test(self.__u||'')) window.__cap.push({via:'xhr', api:self.__u.split('/').pop(), body:b, resp:self.responseText});
  }catch(e){} });
  return oS.apply(this,arguments); };
// fetch ★得物用这个
const oF = window.fetch;
window.fetch = function(u, o){
  const url = (typeof u==='string')?u:(u&&u.url)||'';
  return oF.apply(this,arguments).then(res => {
    if (/merchant-study/.test(url)) { const c = res.clone();
      c.text().then(t => { try{ window.__cap.push({via:'fetch', api:url.split('/').pop(), body:o&&o.body, resp:t}); }catch(e){} }).catch(()=>{}); }
    return res; });
};
```

**翻页**：分页控件是 `1 2 3 4 5 ••• 34` + **next 按钮**（`li[class*=ant-pagination-next]`）。
用 next 一路翻到底（点数字会卡在中段）。每页 10 条。

```python
# 关键：每次点击前 scrollIntoView，坐标要在视口内
def click_next():
    r = js("""(() => {
      const wrap = document.querySelector('[class*=ant-pagination]');
      wrap.scrollIntoView({block:'center'});
      const nx = wrap.querySelector('li[class*=ant-pagination-next]');
      if (!nx || String(nx.className).indexOf('disabled')>=0) return 'disabled';
      const rr = nx.getBoundingClientRect();
      return JSON.stringify({x: Math.round(rr.left+rr.width/2), y: Math.round(rr.top+rr.height/2)});
    })()""")
    p = json.loads(r); time.sleep(0.4); click_at_xy(p["x"], p["y"])
```

### 第二步：逐条取正文

**不要点标题进详情再返回**（history.back() 会回到 about:blank）。
**直接改 URL**：页面自己会带正确 sign 去请求详情。
```python
goto_url(f"https://stark.dewu.com/rule-center/detail?type=2&categoryId=0&where=list_details&courseId={id}")
time.sleep(2.6)
d = json.loads(js(READ_JS))
```

**正文提取 + 裁剪**（`div.ruleCenterContainer` 含大量导航噪音）：
```js
const c = document.querySelector('[class*=ruleCenterContainer]');
let t = c.innerText || '';
// 起点：左侧导航最后一项之后
const i = t.indexOf('历史协议规则');
if (i >= 0) t = t.slice(i + 6);
// 终点
for (const stop of ['关于本次规则意见征集','关联平台','这条知识对你有帮助']) {
  const e = t.indexOf(stop); if (e > 0) { t = t.slice(0, e); break; }
}
t = t.replace(/\n{3,}/g, '\n\n').replace(/[ \t]+\n/g,'\n').trim();
```

## 结构

- **URL**：`https://stark.dewu.com/rule-center/detail?type=2&categoryId=<x>&where=list_details`
- **左侧是多级层级树**：`ant-tree-node-content-wrapper`，一级在 `left≈309`，二级在 `left≈333`
  - ⚠️ **点一级分类会展开二级 → 后续所有坐标漂移**，每次操作前要重新取坐标
  - 切换分类会导致页面导航 → **hook 丢失**，所以先采完列表再逐条取正文
- **一级分类**（12 个）：规则公示中心 / 违规公示 / 招商入驻 / 商品管理 / 交易管理 / 售后服务 / 营销推广 / 违规管理 / 规则解读 / 协议专区 / 平台资讯 / 历史协议规则
- ⚠️ 页面显示「登 录」也能看内容 —— **不需要登录**

## 切分策略（得物正文很长，不能照搬拼多多）

```
仅「规则公示中心」340 条 = 162 万字（中位 3,610 字/条，最长 2.5 万字）
```
- ❌ 每 10 条一篇 → 每篇 4.7 万字 ≈ 140KB，超 IMA 上限
- ✅ **按字数装箱**（贪心，每篇 ≤ 20,000 字，保持单条完整不切断）→ **79 篇**，最大 70KB
- 单条本身就超 2 万字的（如《商家服务协议》25,241 字）单独成篇，不要切正文

## IMA 上传

```js
// ① 建笔记（import_doc 无 title 参数，标题必须写在 content 首行）
const raw1 = await imaApi('openapi/note/v1/import_doc', { content_format: 1, content: md全文 });
const noteId = JSON.parse(raw1).data.note_id;
// ② 挂到库（不传 folder_id = 根目录）
await imaApi('openapi/wiki/v1/add_knowledge', {
  media_type: 11, title, knowledge_base_id: 'uzErjPa0D7sQUnyp-xrgRQTwfM9U_PJ9JwGKPvHoIJI=',
  note_info: { content_id: noteId }
});
```
库名：**得物平台-电商学习**（`uzErjPa0D7sQUnyp-xrgRQTwfM9U_PJ9JwGKPvHoIJI=`），无子文件夹，笔记挂根目录。
**必须回读验证**：`get_knowledge_list` 循环到 `is_end`，数条目。

## 脚本

位置：`D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\`
- `dewu_build.py` —— 按字数装箱切 md（读 `dewu_docs.json` → `笔记\`）
- `ima_upload_dewu.cjs` —— 批量传 IMA（断点续传，靠 `.upload_done.json`）
- `cdp_net.py` —— CDP Network 监听（挖接口用，**得物这一步靠它才找到接口**）
- `dewu_hook.py` —— CDP 注入捕获器，读页面 `window.__cap` 看响应字段结构（排错用）
- 采集交互本身用 `browser_exec`（Browser Use），**不在本地脚本里** —— 换机器时要有 Browser Use 环境才能重跑采集

数据流：`dewu_ids.json`（id 清单）→ 逐条 goto 详情截响 → `dewu_docs.json`（340 条正文）→ `dewu_build.py` → `笔记\*.md` → `ima_upload_dewu.cjs` → IMA + `notes_index.json`

产物：`D:\Agent.GongZuoQu\Hermes.GZQ\数据--得物规则中心\`
（`dewu_ids.json` / `dewu_docs.json` / `笔记\` / `notes_index.json`）

## 坑总结

1. **CDP Input 驱动不了得物页面** → 用 Browser Use 的 `click_at_xy`
2. **得物用 fetch 不是 XHR** → hook 要同时挂两个
3. **导航（切分类/刷新）会重置 hook** → 先在列表页采完 id，再逐条 goto 详情
4. **`history.back()` 回不到列表**（回到 about:blank）→ 用 `goto_url`
5. **分页控件只有 1-5 + 末页** → 用 next 按钮
6. **层级树展开会漂移坐标** → 每次操作前 `scrollIntoView` + 重新取坐标
7. **正文含大量导航噪音** → 用「历史协议规则」和「关联平台」做锚点裁剪
8. **单条最长 2.5 万字** → 切分按字数不按条数
9. **`browser_exec` 默认 300s 超时** → 批量任务传 `timeout_s`（最大 1800），每批 ≤150 条
10. **第 1 页容易漏**（hook 注入时页面已加载完）→ 最后回第 1 页补一次
