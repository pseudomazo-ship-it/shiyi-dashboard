---
name: windows-disk-cleanup
description: "Windows清理：磁盘垃圾/缓存 + 内存/进程（关软件腾内存）。Use when 用户要清C盘/磁盘满/电脑卡/内存占用高/指定关掉某软件时。"
version: 1.0.0
license: MIT
author: Hermes Agent
platforms: [windows]
metadata:
  hermes:
    tags: [windows, disk-cleanup, cache, temp, uv, npm, clean]
    category: productivity
---

# Windows 磁盘清理（安全版）

十一的电脑 C 盘常年 90%+ 满，会周期性要求清理。目标是「清干净且不影响使用」。本技能给「Scan → 分类 → 让用户确认 → 删」的流程 + 实测踩坑，避免下次再犯。

> **内存/进程清理（关软件腾内存）见 `references/process-memory-cleanup.md`** —— 枚举进程、按 PID 关（中文进程名会编码错）、`-Force` 前先问用户。触发语：「电脑卡 / 内存占用高 / 关掉 Chrome、抖音 / 电脑运行了哪些软件」，以及「**文件夹改名/删除报『拒绝访问』**」（那是进程占用，不是权限问题，同文件 §6 有三个探针定位法）。

## 黄金法则

1. **先扫不删**：任何清理前先列出「能删什么、多大、删了什么影响」给用户，确认后再删。绝不先删。
2. **绝对不能动的**：
   - `~/.workbuddy/binaries/`（node / PortableGit / python）—— WorkBuddy 运行时工具本体，删了 WorkBuddy 挂
   - `~/.workbuddy/workspace/sessions/`、`projects/` —— 用户会话/项目数据
   - `~/.workbuddy/models/`（如 faster-whisper-* ）—— 本地STT模型，**用户刚修好的微信语音依赖它**，删了要重下
   - Documents / Desktop / Downloads —— 用户数据，只列给用户拣，不主动删
   - 一切程序本体（Program Files、Windows 目录）
3. **可安全清**：`$LOCALAPPDATA/Temp`、`C:\Windows\Temp`、`Google\Chrome...\Cache`、`Microsoft\Edge...\Cache`、`CrashDumps`、`npm-cache`、`pip\cache`、`uv\cache`（用官方命令）、`~/.workbuddy/traces/`、`~/.workbuddy/logs/`。

## 技术路径（本机实测，踩过的坑）

### 1. PowerShell 必须写 .ps1 文件跑，不要内联 —— 最关键的坑
在 git-bash / execute_code 里内联 PowerShell `"$env:LOCALAPPDATA\..."`，**`$` 变量会被 bash 转义清空**，导致 `Test-Path 参数为空`、`路径丢失` 等大量报错。

正确：
```bash
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Administrator\AppData\Local\Temp\scan.ps1"
```

写一个 `.ps1`，里面用 `$env:LOCALAPPDATA`。**别用 `-c/-Command` 内联带 `$` 的脚本**。

### 2. 扫描/清理脚本别放 $LOCALAPPDATA/Temp —— 会被自己清掉
本会话把 `scan_garbage.ps1` 放到 Temp 里，清理 Temp 时**把它自己删了**，后面再调就找不到。放别处：如 `E:\software\Hermes\scripts\` 或一个专门的临时目录。

### 3. du 扫大目录（Program Files / Windows / .workbuddy/binaries）会卡死超时
`du -sh /c/Program\ Files`、`du -sh ~/.workbuddy` 能跑到超时（60-180s）。用**后台 PowerShell Get-ChildItem** 统计代替：
```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scan.ps1   # background=true + notify
```
脚本内：`Get-ChildItem $p -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum`

### 4. uv 缓存用官方命令清，直接删目录删不掉
`uv cache` 里的文件常被占用/锁定，`Remove-Item` 会静默失败（`SilentlyContinue` 吞掉不报错）。必须用：
```bash
uv cache clean   # 输出: Removed N files (X GiB)
```
这是唯一可靠清 uv 缓存（本机曾 2.4GB）的方式。

### 5. 大目录拆分扫，别一口气
用户目录下 `.cache`(4G) `.workbuddy`(19G) `.codex`(1.6G) `Documents`(27G) 之类，逐个按子目录大小筛查（只看 >100MB 的），不要整棵 du。

## 标准流程

1. `df -h /c` 看当前空间（会用百分比）
2. 后台 PowerShell 扫描可清项大小（写 .ps1，放非 Temp 目录，background + notify）
3. 列清单给用户：可清项 + 每项说明 + 「删了影响吗」
4. 等用户确认（清/只清某几项/指定）
5. 执行清理（PowerShell Remove-Item 清可清项 + `uv cache clean` 清 uv）
6. `df -h /c` 复核效果 + 报告实际省多少

## 交付惯例
- 结论前置：先给「省了多少、降到多少%」
- 给影响说明：哪些不影响使用、哪些小影响（缓存清了下次重下/重载）
- 临时 .ps1 用完即删。
