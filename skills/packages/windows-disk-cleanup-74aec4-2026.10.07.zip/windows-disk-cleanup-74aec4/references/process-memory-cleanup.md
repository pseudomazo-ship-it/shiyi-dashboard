# Windows 内存/进程清理（关软件腾内存）

触发：十一说「电脑卡 / 内存占用高 / 关掉 Chrome、抖音、ChatGPT / 电脑有哪些软件在运行」。
本质和磁盘清理一样：**先枚举 → 报给用户 → 得到确认再动手**。

## 1. 先枚举，再动手

```powershell
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
# 有界面的（用户在用的）
Get-Process | Where-Object { $_.MainWindowTitle -ne "" } |
  Select-Object ProcessName, Id, MainWindowTitle,
    @{n='MB';e={[math]::Round($_.WorkingSet64/1MB,0)}} |
  Sort-Object MB -Descending | ConvertTo-Json -Depth 3

# 后台的（按名字聚合：个数 + 总内存）
Get-Process | Group-Object ProcessName |
  Select-Object Name, Count,
    @{n='MB';e={[math]::Round((($_.Group|Measure-Object WorkingSet64 -Sum).Sum)/1MB,0)}} |
  Sort-Object MB -Descending | Select-Object -First 30 | ConvertTo-Json -Depth 3
```

- ⚠ **必须写 `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8`** —— 否则中文窗口标题/进程名全变 `??` 乱码（实测踩过）。
- ⚠ `MainWindowTitle` 是**唯一能区分“哪个 Chrome 在跑什么”**的字段（例：`🐴 探域科技` / `拼多多 商家后台` / `评价管理`），报告时一定要带，否则用户没法判断能不能关。
- 内存统计用 `Get-CimInstance Win32_OperatingSystem`：`TotalVisibleMemorySize` / `FreePhysicalMemory`（单位 KB → /1MB 得 GB）。

## 2. 关进程：走 PID，别走中文名

`taskkill /IM 金山文档.exe` 这类**中文进程名在 bash→PowerShell 参数传递里会编码错**，杀不掉。可靠两步：

1. PowerShell 输出 `ProcessName + Id` 的 JSON（UTF-8）→ Python 解码后按名字筛出 PID
2. 只把**数字 PID** 传回去执行

```python
data = json.loads(ps('Get-Process | Select-Object ProcessName,Id | ConvertTo-Json -Depth 2'))
pids = [p["Id"] for p in data if p["ProcessName"] in {"chrome","ChatGPT","douyin","金山文档"}]
ps("Stop-Process -Id %s -Force" % ",".join(map(str, pids)))
```

## 3. ⚠ 关之前：能优雅就优雅，Force 会丢数据

- 先 `$p.CloseMainWindow()` —— 程序自己会弹「是否保存」（Excel/WPS/Word）
- `Stop-Process -Force` **不给保存机会** → **关带未保存内容的软件（Excel/WPS/记事本/编辑器）前必须先问用户一句**
- 实测：**WPS 对 `CloseMainWindow()` 不理会**（窗口不关、进程还在），最终还是得 Force —— 所以「先问」这一步更不能省
- 关完复查：`(Get-Process -Name xxx -ErrorAction SilentlyContinue).Count` = 0，别只看命令无报错

## 4. 报告格式（十一认的）

关前/关后**已用内存** + 每个程序的**进程数** + **释放了多少 GB** + 剩余清单 + ⚠ 后果提醒。

```
已用 19.8GB → 11.8GB（释放 8.0GB，总 31.9GB）
⚠ Chrome 关掉后，拼多多商家后台/探域/评价管理那些页面都没了 ——
  要跑采集/上架得重新打开并确认登录态
```

## 6. 文件夹改名/删除报「拒绝访问」= 被进程占着，**不是权限问题**（2026-09-25 实测）

触发：十一说「把 X 文件夹名改成 Y」/ 删某个目录，结果报 `[WinError 5] 拒绝访问`、"拒绝访问。" 或「另一个程序正在使用此文件」。

**先用三个探针定位，别一上来就去改 ACL/提权**（本次 ACL 完全正常，白折腾一轮）：

| 探针 | 代码 | 含义 |
|---|---|---|
| ① 目录内能不能建临时文件？ | `open(dir+"/_t.tmp","w")` | ✓ = 可写，**不是权限问题** |
| ② 它里面的**子文件夹**能不能改名？ | `os.rename(dir/sub, dir/sub+"_t")` | ✓ = 锁在**本层**，不在下层 |
| ③ **同级**其他文件夹能不能改名？ | `os.rename(sibling, sibling+"_t")` | ✓ = 排除全局/杀软/磁盘问题 |

**①✓ + ②✓ + ③✓ 而目标本身 ✗ ⇒ 有进程把这个目录当「当前工作目录 / 持有句柄」。**
Windows 不允许重命名正被当工作目录的文件夹。

- ⚠️ **`cmd /c move` 和 PowerShell `Rename-Item` 会以同样的方式失败**（本次两个都是「拒绝访问」）—— 不是换个命令就能过，**别再试第三种命令**，直接去查谁占着。
- **怎么找占者**：命令行里查不到时，去翻应用的**状态/配置文件**，它们常把工作目录写下来：
  - `~/.codex/process_manager/chat_processes.json` → `"cwd": "<目标>\\..."`
  - `~/.codex/config.toml` → `[projects.'...\\gpt\\日常（杂事）工作区']`
  - `~/.codex/ambient-suggestions/*/ambient-suggestions.json` → `projectRoot`
  - 通用做法：把应用配置目录整个 grep 一遍目标文件夹名。
- **杀子进程不一定有效**：守护进程会把子进程拉起来（本次杀 8 个后残留 5 个）。要杀就杀**整棵进程树**（按可执行路径筛，如 `$_.Path -like "*OpenAI\Codex*"`），杀完**再扫一遍计数**才算数。
- **可能应用自己能改**：本次 Codex 早就在目录里放了自己的改名脚本 + 状态日志（`rename-X-to-Y.ps1` / `rename-X-to-Y-status.txt`），它一直在写「等待释放占用」——
  **释放后它自己就改成了**。所以：查一下父目录有没有这类脚本/日志，也许不用你动手。
- ⚠️ **杀进程前先问**（尤其带未保存内容的软件）—— 十一说「不用了，我让 Codex 自己改」时**就停手**，不要自作主张继续杀。

## 5. 本机实测基线（2026-09-23）

| 程序 | 进程数 | 内存 |
|---|---|---|
| Chrome | 45 | 5.9GB（最大头，占已用内存 30%）|
| 金山文档 | 14 | 1.27GB |
| ChatGPT（桌面版）| 15 | 1.2GB |
| python | 14 | 1.1GB |
| 抖音 douyin | 9 | 566MB |
| 腾讯文档 | 14 | 534MB |
| Hermes | 5 | 725MB |
| 向日葵 AweSun | 3 | 51MB |

关掉 Chrome + 金山文档 + ChatGPT + 抖音 + 那个开着的 Excel → **19.8GB → 11.8GB**（总 31.9GB）。

⚠ **关 Chrome 前先确认有没有采集/上架任务在跑**：查端口 `9444`（上架外挂 Chrome）/`9555`（PDD 前台）/`9334`（工作台内嵌），
以及工作区 log 的 mtime —— 关错了正在跑的自动化会中断。
