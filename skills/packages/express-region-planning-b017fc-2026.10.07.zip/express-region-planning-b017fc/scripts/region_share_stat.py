# -*- coding: utf-8 -*-
"""偏远地区(东三/西四)占比统计 — 吉客云《销售单查询》导出。

用法:
    uv run --with openpyxl python region_share_stat.py <xlsx路径> [YYYY-MM]

不带月份 = 全段统计。分母口径: 全部订单 / 云仓订单。
阈值: 东三省<=6%, 西四省<=3% (2026-09 云仓新规)。
"""
import sys
import datetime
from collections import Counter
import openpyxl

EAST3 = {'黑龙江省', '吉林省', '辽宁省'}
WEST4 = {'甘肃省', '青海省', '宁夏回族自治区', '内蒙古自治区'}
PLAN17 = {'哈尔滨市', '齐齐哈尔市', '长春市', '吉林市', '沈阳市', '大连市',
          '兰州市', '陇南市', '临夏回族自治州', '天水市', '定西市',
          '银川市', '固原市', '西宁市', '赤峰市', '呼和浩特市', '通辽市'}


def ym(v):
    if v is None:
        return None
    if isinstance(v, (datetime.datetime, datetime.date)):
        return '%04d-%02d' % (v.year, v.month)
    s = str(v).strip()
    return s[:7] if len(s) >= 7 else None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    fp = sys.argv[1]
    mfilter = sys.argv[2] if len(sys.argv) > 2 else None
    ws = openpyxl.load_workbook(fp, data_only=True, read_only=True)['销售单']

    total = far_all = cloud = cloud_far = east = west = plan17 = 0
    outside = Counter()
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[0] is None:
            continue
        if mfilter and ym(r[7]) != mfilter:
            continue
        wh = (r[3] or '').strip()
        prov = (r[10] or '').strip()
        city = (r[11] or '').strip()
        total += 1
        is_far = prov in EAST3 or prov in WEST4
        if is_far:
            far_all += 1
        if '云仓' in wh:
            cloud += 1
            if is_far:
                cloud_far += 1
                if prov in EAST3:
                    east += 1
                elif prov in WEST4:
                    west += 1
                if city in PLAN17:
                    plan17 += 1
                else:
                    outside[city] += 1

    pct = lambda a, b: (a / b * 100 if b else 0.0)
    print('=== %s ===' % (mfilter or '全段'))
    print('全部订单: %d ｜ 东三西四 %d (%.4f%%)' % (total, far_all, pct(far_all, total)))
    print('云仓订单: %d ｜ 东三西四 %d (%.4f%%)' % (cloud, cloud_far, pct(cloud_far, cloud)))
    print('  东三省(上限6%%): %d  %.4f%%  %s' % (east, pct(east, cloud), '✅' if pct(east, cloud) <= 6 else '❌超标'))
    print('  西四省(上限3%%): %d  %.4f%%  %s' % (west, pct(west, cloud), '✅' if pct(west, cloud) <= 3 else '❌超标'))
    print('  17城清单: %d  %.4f%%' % (plan17, pct(plan17, cloud)))
    print('  清单外城市合计: %d' % sum(outside.values()))
    for c, v in outside.most_common(15):
        print('     %s: %d' % (c, v))


if __name__ == '__main__':
    main()
