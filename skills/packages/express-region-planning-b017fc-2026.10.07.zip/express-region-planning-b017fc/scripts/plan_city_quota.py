# -*- coding: utf-8 -*-
"""云仓偏远占比「贴满」城市清单规划（东三省 ≤ PE / 西四省 ≤ PW）

用法:
  uv run --with openpyxl python plan_city_quota.py <销售单导出.xlsx> 5.8 2.8
  uv run --with openpyxl python plan_city_quota.py <销售单导出.xlsx> 5.8 2.8 --keep 旧清单.txt

旧清单文件: 一行一个城市，支持简称（临夏 / 果洛 / 大兴安岭 都行），# 开头与空行忽略。

口径（务必与十一对齐）:
  云仓占比 = 云仓的东三省(西四省)订单数 ÷ 云仓订单总数
  候选池   = 该区域【全部订单】(不限仓库) —— 城市一旦配到云仓，其全部订单都走云仓

为什么必须联合求解: 两个上限的分母都是「云仓总单」，选城市会同时抬高分母。
  总 = c / (1 - PE - PW);  x = PE × 总;  y = PW × 总   (c = 非东三西四的云仓单量)
选完城市后分母再变，脚本已做迭代校正。
"""
import sys
import argparse
from collections import Counter

try:
    import openpyxl
except ImportError:
    sys.exit('缺 openpyxl: 用 uv run --with openpyxl python plan_city_quota.py ... 跑')

DONG3 = {'黑龙江省', '吉林省', '辽宁省'}
XI4 = {'甘肃省', '青海省', '宁夏', '宁夏回族自治区', '内蒙古', '内蒙古自治区'}
SHENGHUI = {'沈阳', '长春', '哈尔滨', '兰州', '西宁', '银川', '呼和浩特'}


def find_col(header, *keys):
    """先精确命中，再包含命中（不同导出批次列顺序会变，禁止硬编码下标）"""
    hs = [str(h or '').strip() for h in header]
    for k in keys:
        for i, h in enumerate(hs):
            if h == k:
                return i
    for k in keys:
        for i, h in enumerate(hs):
            if k in h:
                return i
    return None


def norm(s):
    return str(s or '').strip().replace('市', '')


def in_list(city, names):
    """前缀匹配: 数据里是自治州全名(临夏回族自治州)，十一的清单常写简称(临夏)"""
    c = norm(city)
    for n in names:
        n2 = norm(n)
        if c == n2 or c.startswith(n2):
            return True
    return False


def is_shenghui(city):
    return norm(city).replace('地区', '') in SHENGHUI


def load(xlsx):
    wb = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    it = ws.iter_rows(values_only=True)
    header = next(it)
    i_wh = find_col(header, '发货仓库')
    i_prov = find_col(header, '省')
    i_city = find_col(header, '市')
    if i_wh is None or i_prov is None or i_city is None:
        sys.exit('表头识别失败（需含 发货仓库 / 省 / 市）。首行=%s' % (header,))
    c_base = 0                      # 云仓里非东三西四的单量 = 联合求解的基数 c
    yc_all = 0
    yc_cur = {'D3': 0, 'X4': 0}
    all_city = {'D3': Counter(), 'X4': Counter()}
    for r in it:
        if r[1] is None:            # 运单/订单号为空 = 非数据行
            continue
        prov = str(r[i_prov] or '').strip()
        city = str(r[i_city] or '').strip()
        if not city:
            continue
        is_yc = '云仓' in str(r[i_wh] or '')
        grp = 'D3' if prov in DONG3 else ('X4' if prov in XI4 else None)
        if is_yc:
            yc_all += 1
            if grp is None:
                c_base += 1
            else:
                yc_cur[grp] += 1
        if grp:
            all_city[grp][(prov, city)] += 1
    return c_base, yc_all, yc_cur, all_city


def pick(counter, target):
    """省会必保 + 其余按单量降序贪心填满（填到再加就超为止）"""
    items = sorted(counter.items(), key=lambda x: -x[1])
    sel, used = [], 0
    for (p, c), v in items:
        if is_shenghui(c):
            sel.append(((p, c), v))
            used += v
    for (p, c), v in items:
        if is_shenghui(c):
            continue
        if used + v <= target:
            sel.append(((p, c), v))
            used += v
    return sel, used


def solve_greedy(c_base, all_city, PE, PW):
    t3 = PE * c_base / (1 - PE - PW)
    t4 = PW * c_base / (1 - PE - PW)
    s3, u3 = pick(all_city['D3'], t3)
    s4, u4 = pick(all_city['X4'], t4)
    for _ in range(8):              # 迭代校正：选中的城市会同时抬高分母
        tot = c_base + u3 + u4
        ns3, nu3 = pick(all_city['D3'], PE * tot)
        ns4, nu4 = pick(all_city['X4'], PW * tot)
        if (nu3, nu4) == (u3, u4):
            break
        s3, u3, s4, u4 = ns3, nu3, ns4, nu4
    return s3, u3, s4, u4


def group_by_prov(sel):
    d = {}
    for (p, c), v in sel:
        d.setdefault(p, []).append((c, v))
    return d


def show_sel(title, sel, used, total, limit):
    print('===== %s：%d城 / %s单 = %.4f%%（上限 %.1f%%）====='
          % (title, len(sel), format(used, ','), used / total * 100, limit * 100))
    g = group_by_prov(sel)
    for p in sorted(g):
        its = sorted(g[p], key=lambda x: -x[1])
        print('  【%s】%s单 / %d城' % (p, format(sum(v for _, v in its), ','), len(its)))
        print('     ' + '、'.join('%s%d' % (c, v) for c, v in its))


def show_cut(grp_name, counter, sel):
    kept = {k for k, _ in sel}          # ⚠️ 必须取键；写 set(sel) 会存元组，导致交集判断恒为真
    cut = sorted([(p, c, v) for (p, c), v in counter.items() if (p, c) not in kept],
                 key=lambda x: -x[2])
    assert not (kept & {(p, c) for p, c, _ in cut}), \
        '保留与不发出现交集 —— kept 集合构造有误'
    print('  ❌ 不发（%d城 / %s单）：' % (len(cut), format(sum(v for _, _, v in cut), ',')))
    d = {}
    for p, c, v in cut:
        d.setdefault(p, []).append((c, v))
    for p in sorted(d):
        print('     %s: %s' % (p, '、'.join('%s%d' % (c, v) for c, v in d[p])))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('xlsx')
    ap.add_argument('pe', type=float, help='东三省上限，如 5.8 或 0.058')
    ap.add_argument('pw', type=float, help='西四省上限，如 2.8 或 0.028')
    ap.add_argument('--keep', help='旧清单文件（一行一个城市）→ 输出最小改动增量方案')
    a = ap.parse_args()
    PE = a.pe / 100 if a.pe > 1 else a.pe
    PW = a.pw / 100 if a.pw > 1 else a.pw

    c_base, yc_all, yc_cur, all_city = load(a.xlsx)

    print('=== 现状（口径：全部订单，不限重量）===')
    print('云仓总单 %s ｜ 基数 c（非东三西四）= %s' % (format(yc_all, ','), format(c_base, ',')))
    print('东三省云仓 %s = %.4f%% ｜ 西四省云仓 %s = %.4f%%'
          % (format(yc_cur['D3'], ','), yc_cur['D3'] / yc_all * 100,
             format(yc_cur['X4'], ','), yc_cur['X4'] / yc_all * 100))
    print('候选池（该区域全仓订单）: 东三省 %s ｜ 西四省 %s'
          % (format(sum(all_city['D3'].values()), ','), format(sum(all_city['X4'].values()), ',')))
    print()

    if a.keep:
        with open(a.keep, encoding='utf-8') as f:
            names = [l.strip() for l in f if l.strip() and not l.startswith('#')]
        k3 = sum(v for (p, c), v in all_city['D3'].items() if in_list(c, names))
        k4 = sum(v for (p, c), v in all_city['X4'].items() if in_list(c, names))
        tot = c_base + k3 + k4
        print('=== 旧清单实测（%d 个城市名）===' % len(names))
        print('东三省 %s = %.4f%%（目标 %.1f%%，缺口 %.0f单）'
              % (format(k3, ','), k3 / tot * 100, PE * 100, PE * tot - k3))
        print('西四省 %s = %.4f%%（目标 %.1f%%，缺口 %.0f单）'
              % (format(k4, ','), k4 / tot * 100, PW * 100, PW * tot - k4))
        print('云仓总单 %s' % format(tot, ','))
        print()

        add3, t3 = [], k3
        print('=== 东三省 可加入（按单量降序，✅=能塞进上限）===')
        for (p, c), v in sorted(all_city['D3'].items(), key=lambda x: -x[1]):
            if in_list(c, names):
                continue
            nt = c_base + t3 + v + k4
            if (t3 + v) / nt <= PE:
                add3.append((p, c, v))
                t3 += v
                print('  ✅ %s %s %d单 → %.4f%%' % (p, c, v, t3 / (c_base + t3 + k4) * 100))
        print()
        add4, t4 = [], k4
        print('=== 西四省 可加入 ===')
        for (p, c), v in sorted(all_city['X4'].items(), key=lambda x: -x[1]):
            if in_list(c, names):
                continue
            nt = c_base + t3 + t4 + v
            if (t4 + v) / nt <= PW:
                add4.append((p, c, v))
                t4 += v
                print('  ✅ %s %s %d单 → %.4f%%' % (p, c, v, t4 / (c_base + t3 + t4) * 100))
        ft = c_base + t3 + t4
        print()
        print('=== 最小改动方案 ===')
        print('云仓总单 %s ｜ 东三省 %s = %.4f%% ｜ 西四省 %s = %.4f%%'
              % (format(ft, ','), format(t3, ','), t3 / ft * 100, format(t4, ','), t4 / ft * 100))
        print('东三省新增: %s' % ('、'.join('%s%d' % (c, v) for _, c, v in add3) or '无'))
        print('西四省新增: %s' % ('、'.join('%s%d' % (c, v) for _, c, v in add4) or '无'))
        print('（其余旧清单城市全部保留不动 —— 交付时必须写明这句）')
    else:
        s3, u3, s4, u4 = solve_greedy(c_base, all_city, PE, PW)
        ft = c_base + u3 + u4
        print('=== 全新贪心（省会必保 + 单量降序填满）===')
        print('新云仓总单 %s' % format(ft, ','))
        show_sel('东三省', s3, u3, ft, PE)
        show_cut('D3', all_city['D3'], s3)
        print()
        show_sel('西四省', s4, u4, ft, PW)
        show_cut('X4', all_city['X4'], s4)
        print()
        print('⚠️ 贪心会填进小城市、砍掉大城市（机械结果）。交付时主动给「换大城市」备选，')
        print('   并提醒十一：目标百分比是他当次指定的，照当次数字算。')


if __name__ == '__main__':
    main()
