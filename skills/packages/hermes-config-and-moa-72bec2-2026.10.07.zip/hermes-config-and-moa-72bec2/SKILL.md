---
name: hermes-config-and-moa
description: "Edit Hermes config.yaml and configure MoA model routing."
version: 1.0.0
author: Hermes Agent
platforms: [windows]
metadata:
  hermes:
    tags: [config, moa, model, provider, config.yaml, routing, deepseek]
---

# Hermes config editing & model routing (incl. MoA)

How to change Hermes runtime settings and switch the active model/provider,
and how to reason about MoA (Mixture of Agents). The user (十一) runs a
single-model deepseek setup by default and uses MoA only occasionally.

## Golden rule: config.yaml is write-PROTECTED from agents
`E:\软件\Hermes\config.yaml` is a security-sensitive file. The `patch` tool
refuses to touch it (
`Refusing to write to Hermes config file ... Agent cannot modify security-sensitive configuration`)
and so does a direct file write. **The only reliable edit path is the CLI:**
```bash
hermes config get <key>              # read one value
hermes config set <key> <value>      # write one value
hermes config show                   # read all
hermes config path                   # where the file lives
```
Do NOT try to patch/edit the .yaml by hand through a file tool — it will be
refused. `hermes config set` is the sanctioned writer.

## MoA is gated by provider, NOT by `moa.enabled`
`moa.enabled: true` only means "MoA is allowed". What actually triggers the
multi-model path is `model.provider == "moa"` — the source checks
`agent.provider == "moa"` to build the MoA virtual client. If `model.provider`
is still `deepseek`, MoA never runs regardless of `enabled`.

So "did I turn on MoA?" is answered by `hermes config get model.provider`:
- `deepseek` → single model, MoA NOT running (even if `moa.enabled: true`).
- `moa` → MoA path active.

Diagnose with `hermes config get model.provider` + `hermes config get model.default`, and
(if needed) the actual model-use distribution in `state.db`:
`SELECT model, COUNT(*) FROM session_model_usage GROUP BY model` — if only
`deepseek-*` appears and no aggregator/reference providers, MoA never fired.

## What MoA is, and when it's worth it
MoA = let several reference models each think, then an aggregator combines
into a final answer. Fits: complex analysis, major decisions, multi-angle
reasoning where a single model might miss something. Doesn't fit: routine
operations (reports, 对账, 上架, 笔记) — a single cheap model is faster and
cheaper and plenty accurate. For 十一 the rule the user settled on is
**occasional use**: default deepseek (cheap), temporarily switch to MoA only
for an important complex decision.

## The stock MoA preset references EXTERNAL models — fix before enabling
The default `moa.presets.default.reference_models` and `moa.aggregator` point
at `openai-codex gpt-5.5`, `openrouter deepseek/...`, and
`openrouter anthropic/claude-opus-4.8`. If those credentials aren't configured,
MoA fails immediately when you enable it. The reliable fix is to make it
pure-deepseek (no external payment needed):
```bash
hermes config set moa.aggregator.provider deepseek
hermes config set moa.aggregator.model deepseek-v4-pro
hermes config set moa.presets.default.reference_models \
  '[{"provider":"deepseek","model":"deepseek-v4-pro"},{"provider":"deepseek","model":"deepseek-v4-flash"}]'
```
Re-examine the result (`hermes config show` or parse config.yaml) and confirm
NO reference/aggregator still names `openrouter/openai/codex/claude/opus/gpt-5`
before turning MoA on. `config set` on a nested array key can return a "not a
recognized config key" warning — it still saves, but read the MoA block back
to confirm the structure is what you expect before trusting it runs.

## Actually switching the global model/provider
```bash
hermes config set model.provider moa
hermes config set model.default default      # default = the MoA preset name
# ... and back:
hermes config set model.provider deepseek
hermes config set model.default deepseek-v4-flash-vision-exp
```
Affects EVERY session, not just the current window. Changing the provider makes
an already-running session keep its old in-memory provider until restarted.

## CRITICAL warning: a global provider change breaks cron jobs
When you set `model.provider` to something new, `hermes config set` prints:
`1 enabled unpinned cron job has stored provider_snapshot values that differ
from the new global provider. They will fail closed on their next run instead of
silently using the changed model/provider.`
The sentinel cron (and any cron job) snapshots its provider at creation; a
global change makes the snapshot inconsistent and the job fails-closed. **Pin
the affected cron back** so it keeps using deepseek (it doesn't need MoA):
`hermes cron edit <job_id> --provider deepseek --model deepseek-v4-flash-vision-exp`.
Always inspect `hermes cron list` after a provider change if you want the
cron jobs to keep running on the old, cheap model.

## Model picker in the desktop UI
There is NO standalone MoA on/off button. The Model Picker (click the model
pill beside the composer) is where you switch models, but it EXCLUDES MoA from
the normal list (`MOA_PROVIDER_SLUG` handling in `src/lib/model-options.ts`).
The MoA CONFIG (preset / reference models / aggregator) is edited in
Settings → Model Settings (`/api/model/moa`), which is a config surface, not a
per-turn toggle.

## Session-artifact guard
Changes take effect only after a Hermes restart (gateway/serve reloads). Don't
promise "MoA is on now" unless you ran `hermes config get model.provider` after
a restart and it reads `moa`.
