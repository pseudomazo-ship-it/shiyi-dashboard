# -*- coding: utf-8 -*-
"""旬账单核对（基础价 / 加价 / 油价加收 / 包装费分布）—— 参数化模板。

用法：
  1. 先打表头确认列名（两区间 sheet 列数可能不同，勿硬编码）：
     uv run --with openpyxl python -c "import openpyxl;w=openpyxl.load_workbook(r'<xlsx>',read_only=True);print(w.sheetnames);[print(n,[c.value for c in next(w[n].iter_rows(max_row=1))]) for n in w.sheetnames]"
  2. 改 CFG 里的 sheet 名，跑：
     uv run --with openpyxl python scripts/check_shen_bill.py <xlsx> <区间sheet名>

设计要点（踩过的坑）：
  * 表头建 index dict，不硬编码列号（9.1-9.10 是17列、9.11-9.20 是18列，错位1列会读错金额）
  * 核对公式 = 金额 + 加价 + 9.19油价加收 == 金额合计
  * 报价单 sheet 不会同步涨价，勿只比报价单
  * 省份简称/全称都要兼容（黑龙/内蒙）
  * 禁止用 % 格式化中文（会 ValueError: unsupported format character）
"""
import sys
from collections import Counter

import openpyxl

CFG = {
    'sheet_rate': '报价单',      # 价格表所在 sheet
    'rate_header_row': 2,        # 价格表列名所在行
    'rate_first_row': 3,         # 价格数据起始行
    'col_province_in_rate': 1,   # 价格表: 目的地省列
    'rate_price_cols': (2, 3, 4, 5, 6, 7),   # 0.5/1/2/3/4/5kg 六档
}


def load_rates(wb):
    ws = wb[CFG['sheet_rate']]
    rate = {}
    for r in ws.iter_rows(min_row=CFG['rate_first_row'], values_only=True):
        if not r:
            continue
        prov = str(r[CFG['col_province_in_rate']] or '').strip()
        if not prov:
            continue
        try:
            rate[prov] = [float(r[c]) for c in CFG['rate_price_cols']]
        except (TypeError, ValueError):
            continue
    return rate


def base_price(rate, prov, cw):
    """按计费重量取标准基础价；计费重量字段值=价格表档位(0.5/1/2/3/4/5)。"""
    p = rate.get(prov)
    if not p or cw is None:
        return None
    for limit, price in zip((0.5, 1, 2, 3, 4, 5), p):
        if cw <= limit:
            return price
    return None


def check(xlsx, sheet):
    wb = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
    rate = load_rates(wb)
    ws = wb[sheet]
    rows = ws.iter_rows(min_row=1, values_only=True)
    hdr = next(rows)
    idx = {str(h).strip(): i for i, h in enumerate(hdr) if h}

    # 加价列名各期不同（含「上海/北京/深圳/广州/海南/」等），按前缀匹配
    c_add = next((v for k, v in idx.items() if k.startswith('上海')), None)
    c_oil = idx.get('9.19油价加收')          # 可能不存在（早于 9.19 的账单）
    keys = ['省份', '计费重量', '结算重量', '金额', '金额合计', '纸箱款', '打包费',
            '发货产品', '3盒装重量超1kg减免', '偏远加收']
    c = {k: idx.get(k) for k in keys}
    if c['省份'] is None or c['金额'] is None:
        print('⚠️ 表头未匹配，实际列名：', list(idx))
        return

    n = bad_base = bad_total = 0
    box, pack, remote = Counter(), Counter(), Counter()
    sum_amt = sum_box = sum_pack = sum_cut = sum_oil = 0.0

    for r in rows:
        if r[c['省份']] is None:
            continue
        n += 1
        prov = str(r[c['省份']]).strip()
        try:
            cw = float(r[c['计费重量']]) if r[c['计费重量']] is not None else None
        except (TypeError, ValueError):
            cw = None
        amt = float(r[c['金额']] or 0)
        tot = float(r[c['金额合计']] or 0)

        std = base_price(rate, prov, cw)
        if std is not None and abs(std - amt) > 0.005:
            bad_base += 1

        add = float(r[c_add] or 0) if c_add is not None else 0.0
        oil = float(r[c_oil] or 0) if c_oil is not None else 0.0
        sum_oil += oil
        if abs(amt + add + oil - tot) > 0.005:
            bad_total += 1

        sum_amt += tot
        if c['纸箱款'] is not None and r[c['纸箱款']] is not None:
            box[round(float(r[c['纸箱款']]), 2)] += 1
            sum_box += float(r[c['纸箱款']])
        if c['打包费'] is not None and r[c['打包费']] is not None:
            pack[round(float(r[c['打包费']]), 2)] += 1
            sum_pack += float(r[c['打包费']])
        if c['3盒装重量超1kg减免'] is not None and r[c['3盒装重量超1kg减免']] not in (None, ''):
            sum_cut += float(r[c['3盒装重量超1kg减免']])
        if c['偏远加收'] is not None and r[c['偏远加收']] not in (None, ''):
            remote[str(r[c['偏远加收']])] += 1

    print('=' * 62)
    print(sheet)
    print('=' * 62)
    print(f"单量            {n:,}")
    print(f"运费合计        {sum_amt:,.2f}")
    print(f"纸箱款合计      {sum_box:,.2f}")
    print(f"打包费合计      {sum_pack:,.2f}")
    print(f"3盒装减免       {sum_cut:,.2f}")
    print(f"油价加收        {sum_oil:,.2f}")
    print(f"总费用          {sum_amt + sum_box + sum_pack + sum_cut:,.2f}")
    print()
    print(f"⚠️ 基础价不符          {bad_base} 条")
    print(f"⚠️ 三项加总≠金额合计   {bad_total} 条")
    print()
    print('纸箱款分布:', dict(sorted(box.items())))
    print('打包费分布:', dict(sorted(pack.items())))
    print('偏远计数  :', dict(remote.most_common(8)))
    if c['发货产品'] is not None:
        sq = Counter()
        for r in rows:
            pass  # 品类细分见 deep 脚本（需二次遍历）
    print()
    print('👉 品类细分（方形袋等新包装规则）请用 deep 脚本按「发货产品」交叉纸箱款')


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    check(sys.argv[1], sys.argv[2])
