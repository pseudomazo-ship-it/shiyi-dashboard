# -*- coding: utf-8 -*-
"""蒙倩快递对账单核对（参数化）——①重量超标 ②收费合规 ③费用汇总 ④汇总表盲打

用法：
    uv run --with openpyxl python audit_bill.py <账单xlsx> <明细sheet名>

⚠️ 每个账单的列位置都不同，禁止跨文件复用下标！
   先跑：ws.iter_rows(max_row=1, values_only=True) 打印表头 → 再填 CFG。
   下面 CFG 已预置 2026年8月对账单（1-10/11-20/21-31）与 2026年9.1-9.10 旬账单的实测下标。

CFG 字段（0-based 列下标）：
    prov 省份简称 | settle 结算重量 | charge 计费重量 | plus 加价列
    amount 金额(基础价) | amount_all 金额合计 | remote 偏远加收标记
    box 纸箱款 | pack 打包费 | discount 3盒装超1kg减免 | product 发货产品 | pack_type 包装类型
"""
import sys
import openpyxl
from collections import Counter

# ---------------- 中通价格表（2026/04/03 执行；来源＝账单自带「报价单」sheet）----------------
COMMON = {0.5: 1.35, 1: 1.60, 2: 2.65, 3: 3.10, 4: 9.80, 5: 11.80}
P355 = {0.5: 1.35, 1: 1.60, 2: 2.65, 3: 3.55, 4: 9.80, 5: 11.80}   # 川渝贵云鲁冀津晋陕
LN = {0.5: 1.35, 1: 1.60, 2: 6.70, 3: 15.35, 4: 14.30, 5: 17.30}    # 辽宁
JL = {0.5: 1.35, 1: 1.60, 2: 6.70, 3: 15.35, 4: 17.30, 5: 21.30}    # 吉林
HLJ = {0.5: 1.35, 1: 1.60, 2: 6.70, 3: 15.35, 4: 19.30, 5: 23.80}   # 黑龙江
XIBEI = {0.5: 1.35, 1: 1.60, 2: 7.70, 3: 15.35, 4: 21.80, 5: 26.80}  # 甘青宁内


def base_price(prov, kg):
    """返回应收基础价；None=无对应档。prov 同时接受简称，否则大量假异常。"""
    if prov in ('辽宁', '辽'):
        t = LN
    elif prov in ('吉林', '吉'):
        t = JL
    elif prov in ('黑龙', '黑龙江'):
        t = HLJ
    elif prov in ('宁夏', '甘肃', '青海', '内蒙', '内蒙古'):
        t = XIBEI
    elif prov in ('四川', '重庆', '贵州', '云南', '山东', '河北', '天津', '山西', '陕西'):
        t = P355
    elif prov in ('新疆', '西藏'):
        # ⚠️ <1kg 也按首重 20.10，不能按公式折算（0.5kg 也算 20.10）
        return 20.10 if kg < 1 else round(20.10 + (kg - 1) * 18.10, 2)
    else:
        t = COMMON
    return t.get(kg)


CFG = {
    # 2026年9月旬账单（2026年9.1-9.10蒙倩对账单.xlsx）
    '9.1-9.10': dict(prov=5, settle=6, charge=7, plus=8, amount=9, amount_all=10,
                     remote=11, box=12, pack=13, discount=14, product=15, pack_type=16),
    # 2026年8月对账单（三区间列位各不相同！）
    '1-10': dict(prov=7, settle=8, charge=9, plus=10, amount=11, amount_all=12,
                 remote=13, box=14, pack=15, discount=16, product=17, pack_type=18),
    '11-20': dict(prov=6, settle=7, charge=8, plus=9, amount=10, amount_all=11,
                  remote=12, box=13, pack=14, discount=15, product=16, pack_type=17),
    '21-31': dict(prov=5, settle=6, charge=7, plus=8, amount=9, amount_all=10,
                  remote=11, box=12, pack=13, discount=14, product=15, pack_type=16),
}


def num(v):
    try:
        return round(float(v), 2)
    except Exception:
        return 0.0


def wt_band(w):
    for hi, name in ((1.05, '1.01-1.05'), (1.10, '1.06-1.10'), (1.20, '1.11-1.20'),
                     (1.50, '1.21-1.50'), (2.00, '1.51-2.00')):
        if w <= hi:
            return name
    return '>2.00'


def cause(prod, pack):
    if '1000ml' in prod:
        return 'A.1000ml彩盖白(单瓶即超1kg)'
    if '600ml' in prod:
        return 'B.600ml彩盖白'
    if '*4' in prod or '4盒' in pack:
        return 'C.紫盒/膏体 4支装'
    if '*3' in prod or '3盒' in pack:
        return 'D.紫盒/膏体 3支装'
    if '*2' in prod:
        return 'E.2支装'
    return 'F.其他'


def main():
    xlsx, sheet = sys.argv[1], sys.argv[2]
    c = CFG.get(sheet)
    if c is None:
        print('❌ CFG 里没有 sheet「%s」——先打印表头，再补一个下标字典' % sheet)
        return
    wb = openpyxl.load_workbook(xlsx, data_only=True, read_only=True)
    ws = wb[sheet]

    n = 0
    kg_c = Counter()
    band = Counter()
    cause_c = Counter()
    prod_over = Counter()
    pack_over = Counter()
    settle_gt1 = bill_gt1 = 0
    over_fee = 0.0
    base_ok = base_bad = plus_ok = plus_bad = 0
    bad_s, plus_s = [], []
    s_j = s_h = s_box = s_pack = s_disc = s_wt = 0.0
    remote_n = 0

    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[1] is None:            # 运单号非空才算数据行（首/尾常有杂行）
            continue
        n += 1
        prov = (r[c['prov']] or '').strip()
        sw, kgf = num(r[c['settle']]), num(r[c['charge']])
        jf, hf, pf = num(r[c['amount']]), num(r[c['amount_all']]), num(r[c['plus']])
        prod, pack = (r[c['product']] or '').strip(), (r[c['pack_type']] or '').strip()
        kg_c[kgf] += 1
        s_j += jf; s_h += hf; s_wt += sw
        s_box += num(r[c['box']]); s_pack += num(r[c['pack']]); s_disc += num(r[c['discount']])
        if str(r[c['remote']] or '').strip():
            remote_n += 1
        # 重量超标
        if sw > 1.0:
            settle_gt1 += 1
        if kgf > 1.0:
            bill_gt1 += 1
            over_fee += hf
            band[wt_band(sw)] += 1
            cause_c[cause(prod, pack)] += 1
            prod_over[prod[:34]] += 1
            pack_over[pack] += 1
        # 收费
        exp = base_price(prov, kgf)
        if exp is not None and abs(jf - exp) <= 0.01:
            base_ok += 1
        else:
            base_bad += 1
            if len(bad_s) < 8:
                bad_s.append((prov, kgf, jf, exp))
        if abs(round(hf - jf, 2) - pf) <= 0.01:
            plus_ok += 1
        else:
            plus_bad += 1
            if len(plus_s) < 8:
                plus_s.append((prov, kgf, jf, hf, pf))

    print('=' * 62)
    print('【一】重量超标（计费重量 > 1kg 即超标）')
    print('总单数: %s' % format(n, ','))
    for k in sorted(kg_c):
        v = kg_c[k]
        print('   %skg: %s 单 (%.2f%%)%s' % (k, format(v, ','), v / n * 100,
                                            '  ← 超标' if k > 1 else ''))
    print('结算重量>1kg: %s 单 | 计费重量>1kg: %s 单  → %s'
          % (format(settle_gt1, ','), format(bill_gt1, ','),
             '✅一致(无虚高计费)' if settle_gt1 == bill_gt1 else
             '⚠️不一致，计费>结算 = 多算档位，单独追'))
    print('超标单运费合计: %.2f 元' % over_fee)
    if bill_gt1:
        print('\n  超标单结算重量带:')
        for k in ('1.01-1.05', '1.06-1.10', '1.11-1.20', '1.21-1.50', '1.51-2.00', '>2.00'):
            v = band.get(k, 0)
            if v:
                print('    %s: %s 单 (%.2f%%)' % (k, format(v, ','), v / bill_gt1 * 100))
        print('\n  超标原因归类:')
        for k, v in sorted(cause_c.items()):
            print('    %s: %s 单 (%.2f%%)' % (k, format(v, ','), v / bill_gt1 * 100))
        print('\n  超标产品 TOP10:')
        for k, v in prod_over.most_common(10):
            print('    %-34s %s' % (k, format(v, ',')))
        print('\n  超标包装类型: %s' % dict(pack_over.most_common(8)))

    print('\n' + '=' * 62)
    print('【二】收费合规')
    print('基础价: 匹配 %s (%.4f%%) / 异常 %s'
          % (format(base_ok, ','), base_ok / n * 100, format(base_bad, ',')))
    print('加价:   匹配 %s (%.4f%%) / 异常 %s'
          % (format(plus_ok, ','), plus_ok / n * 100, format(plus_bad, ',')))
    if bad_s:
        print('  基础价异常样例 (省份, 计费kg, 账单值, 应收值):', bad_s)
    if plus_s:
        print('  加价异常样例 (省份, 计费kg, 金额, 金额合计, 加价列):', plus_s)

    print('\n' + '=' * 62)
    print('【三】费用汇总（明细实算）')
    print('运费(基础价) %.2f | 加价 %.2f | 运费合计 %.2f' % (s_j, s_h - s_j, s_h))
    print('纸箱款 %.2f | 打包费 %.2f | 3盒装减免 %.2f' % (s_box, s_pack, s_disc))
    print('结算重量合计 %.2f | 偏远标记 %s 单 (%.4f%%)'
          % (s_wt, format(remote_n, ','), remote_n / n * 100))
    print('合计费用(不含偏远加收/其他费用) = %.2f' % (s_h + s_box + s_pack + s_disc))
    print('\n⚠️ 与「汇总」sheet 逐项比：件量/重量/运费/纸箱/打包 应一致；')
    print('   减免列历来会对不上（汇总用另一套数）—— 把差额单独列成待确认项。')

    if '汇总' in wb.sheetnames:
        print('\n' + '=' * 62)
        print('【四】账单自带「汇总」sheet（原样打出，人工比对）')
        for r in wb['汇总'].iter_rows(values_only=True):
            vals = [('' if v is None else str(v))[:22] for v in r]
            if any(x.strip() for x in vals):
                print('   ' + ' | '.join(vals))


if __name__ == '__main__':
    main()
