# 往已有单文件看板注入一块新 UI（含采集 → 注入 → 验证 → 上线）

场景（2026-10-09 技能看板）：十一说「这个页面内每个板块内的前 3 页的技能采集到我的 Agent Skills 管理台
域名网页内」。也就是：**从外部站点采集一批数据 → 作为一块新 UI 注入到已有的单文件看板里**。

成品：`skills/index.html` 顶部多一条 `本机技能 ｜ 商店热门 · N` 切换，点进去是 CocoLoop 商店榜单。

---

## ① 采集：源站是纯前端 SPA 时（没有可复用的接口）

**特征**：`web_extract` 能抓到框架但列表为空（JS 渲染）；URL 不随筛选/翻页变化。

**探路（先跑一段再写循环，别盲猜）**：
```js
// 分类是不是 <button>？点一下标题有没有变？
document.querySelectorAll('button').length
document.querySelector('[class*=Card_card]').outerHTML.slice(0,800)
```
本次结论：10 个分类都是 `<button>`（不是 `<a href>`）→ **按钮点击，不是改 URL**。

**翻页**：找文字是 `›` 的按钮，点它；**别去构造 `?page=2`**（URL 不变）。
```js
(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.textContent.trim()==='›');
if(b){b.click();return 1} return 0})()
```
- **每页 15 条**，分类共 74 页；本次取前 10 页 = 每类 149~151 条（去重后一类 150 上下）。
- 切分类会重置到第 1 页 → **循环写成「点分类(等 4s) → 采 → 点›(等 3s)」**，不要假设页号连续。
- ⚠️ 每次 `goto_url` 会重置页面 → 每批开头都要重新点分类；脚本里必须做这件事。

**取字段：用模糊 class 名（CSS Modules 带 hash 后缀）**
```js
document.querySelectorAll('[class*=Card_card]')            // 卡片
c.querySelector('[class*=titleEn]')        // 英文名
c.querySelector('[class*=titleCn__]')      // 中文名（注意双下划线：titleCn 会误命中 titleCnRow）
c.querySelector('[class*=Card_desc]')
c.querySelector('[class*=BSSBadge_level]') // 等级徽章 S+/S/A/B/C/D
c.querySelector('[class*=Card_stat]')      // 两个数字
```

**🔴 数字类字段别用「枚举字母表」过滤**（本次踩）：等级有 S+/S/A/B/C/D，我写了 `/^[SAB]$/` 去过筛，
**D 级全被当成数值保留**，产出 `grade="D", installs="D", heat="D"`。
✅ 改成 **「只保留含数字的」**：`.filter(x=>/[0-9]/.test(x))` —— 等级永远不含数字，稳。
（反向也适用：要抽取等级时用 `/^[A-Z][+-]?$/`，别写死字母集合。）

**stat 里两个数字的读法**：`[等级, 等级, 安装量, 热度]`（等级被 span 套了两层，所以出现两遍）。
取数字序列的第 1、2 个即可；**不确定含义的那个就只展示、别硬起名字**（本次保留 `安装 / 热度` 两个标签）。

**分批落盘**：每 2 个分类一次 `browser_exec`（~1.5 分钟/批，共 5 批），每批 append 到同一个 JSON。
一次性跑 10 类 × 10 页会超时；分批 + 断点续传不丢进度。

---

## ② 注入：位置是最大的坑

**用标记注释包块，脚本幂等且自纠位**（完整函数见 SKILL.md 第 40 条）。

**落点选择（按优先级）**：
1. `<main>` 内、引导语/大标题之后，第一个内容锚点之前  ← 本次采用
2. 页面已有的 `.section-head` 之前
3. ❌ **不要放 `</header>` 之后**：header 常是 `position:fixed/sticky`，会盖住注入块

**判定可见性只看 `elementsFromPoint`**（写法见 SKILL.md 第 40 条）。
本次症状极具误导性：`rect.top=14`（看着在视口内）、`offsetParent=BODY`、`visibility:visible`，
**但最顶层元素是 header 里的 `DIV.brand`** → 被遮挡。

**切换逻辑别把原页面的板块搞丢**：本次要在商店模式隐藏「本机技能」的目录/筛选/详情面板，
写成了「遍历 `#skill-content .section-head, .workspace` 批量 `display:none`」，
切回时再全部恢复。比逐个 id 硬编码稳（新板块加进来也会被一起隐藏/恢复）。

---

## ③ 验证清单（缺一项都可能是「看着好了其实没好」）

```js
// 1. 结构
!!document.getElementById('src-tabs')                       // 容器在
document.querySelectorAll('#shop-cats button').length      // 分类数 = 10
document.querySelectorAll('#shop-grid .shop-card').length  // 卡片数 = 当前分类条数

// 2. 位置/可见（唯一可信的判据）
const r=el.getBoundingClientRect();
const top=document.elementsFromPoint(r.left+80, r.top+r.height/2)[0];
el.contains(top) || top.id==='src-tabs'                     // true 才算没被盖

// 3. 交互
// 切分类 → 首张卡名字必须变（本次「设计」首张仍是 PixPix 属正常：AI 生图本就在设计类）
// 搜索 → 卡片数下降 (搜 baoyu → 3 张)
// 切回「本机技能」→ 商店区 hidden、原卡片数不变

// 4. 性能实测值（1501 条数据）
// 加载 0.4s ／ 切到商店渲染 2.7s ／ scrollHeight 7045 ／ 文件 896 KB
```

⚠️ **测切换时别只等 0.9~1.5 秒就下结论** —— 本次因为等待太短，误判了「设计」分类没生效，
多跑了一轮。分类切换后给 **1.8~2.5 秒**再断言。

---

## ④ 上线与体积

- **单个 HTML 内嵌数据是「下载成本」不是「容量成本」**：896 KB 页面（含 1501 条 ≈ 275 KB JSON），
  电脑无感、手机用流量会慢一点。站点总量 42 MB / GitHub Pages 上限 1000 MB（占 4.2%）。
- 推送失败先查**代理是否还活着**：`curl -s -o /dev/null -w "%{http_code}" -x http://127.0.0.1:7897 https://github.com`
  → 本次返回 `000`（挂了），改直连（不带 `-c http.proxy`）一次成功。
- ⚠️ **推送前先 `git pull --rebase`**：本次远端被别的窗口推过两次（`6b2b08f` 技能简介改写），
  rebase 后无冲突；不 rebase 会 push 失败。
