# 批量改「同一个字段散在多份副本里」——技能看板卡片简介（2026-10-09）

背景：技能看板（`shiyi11.com.cn/skills/`）的每条卡片简介**同时存在 4 处**，
改一次要四处都落位，否则页面显示的是旧值而你以为改完了：

```
① 源 desc_*.py       卡片简介（卡片正面 + 详情页顶部）——「name": ("简介", "场景")」
② 源 detail_*.py     详情长文 full_description
③ skills_data.json  看板数据（description / full_description 两个键）
④ 两处 HTML          源 skills.html（开发版，无密码门） + 发布版 skills/index.html（有密码门）
```

## 做法：一个一次性脚本，单一数据源

**别用 patch 工具一个个改** —— 本次目标 26 个条目，手改必然漏。
写法：在一处定稿 `TARGETS`，脚本同时写三处。现成样例：

- `D:\Agent.GongZuoQu\Hermes.GZQ\数据--技能看板\apply_five_descs.py`（5 条，TARGETS 列表）
- 同目录 `update_26_descs.py`（26 条，带字数自检）

```python
TARGETS = {
  "技能名": ("卡片简介(≤80字)", "详情补充句"),
  ...
}

# ① 源 desc_*.py：「name": ("…", "…")」
pat = re.compile(r'("%s":\s*\()"[^"]*"(\s*,\s*")[^"]*(")' % re.escape(name))
src, n = pat.subn(lambda m: m.group(1) + json.dumps(card, ensure_ascii=False)
                             + m.group(2) + json.dumps(scene, ensure_ascii=False) + m.group(3),
                   src)

# ② 源 detail_*.py：「name":" 后面跟若干行字符串字面量
pat = re.compile(r'("%s":\s*\n)(?:\s*"[^"]*"\n)+' % re.escape(name))
src, n = pat.subn(lambda m: m.group(1) + "".join('    "%s",\n' % l for l in det_lines), src)

# ③ JSON：直接改 dict 的两个键
# ④ 两处 HTML：description 用相邻匹配；full_description 在 description 之后，
#    必须给一个窗口量 {0,1200} 的非贪婪匹配，否则匹配不到（本次实踩）
pat = re.compile(r'("name":\s*"%s".{0,1200}?"full_description":\s*")[^"]*(")'
                 % re.escape(name), re.S)
```

四步：**改源 → 跑脚本 → 只搬 `description`/`full_description` 两个字段（绝不整份覆盖 HTML）→ push**。

## 🔴 字数：在**写之前**算，不要写完再返工

本次为「≤80 字」连改 4 轮才全部达标。原因很具体：

- **中文按字符数算**（`len(s)`）—— 标点、空格、英文、数字**都算 1 个**，
  比目测的「字数」多得多。写完自认为 75 字，`len()` 出来 92。
- 一条 80 字的额度，**按 70 字写**，留余量。
- 脚本末尾**必须**自检，不合格直接报错而不是静默上线：
  ```python
  for name, (card, _) in TARGETS.items():
      if len(card) > 80:
          raise SystemExit("❌ %s 卡片简介 %d 字，超过 80" % (name, len(card)))
  ```
  本次就是这个自检一次抓出 4 条超长的。
- 写完后另跑一个 `verify_*.py` **从落盘文件里读回**再数一遍字 ——
  脚本自己算的数和文件里实际存的不一定是一回事。

## ⚠️ 「幽灵条目」：技能目录已删，看板条目还在

本次 26 个目标里 **3 个改不动**（`linghangyuan-overtime-judgment`、
`overtime-leader-judgment`、`pinduoduo-store-health-analysis`）：技能目录早已被合并/改名，
但 `skills_data.json` 和两个 HTML 里**仍留着条目** —— 卡片点得开、简介改不动（因为没有源可改）。

- 成因：**自动同步只管「新增」和「更新」，不管「删除」**；
  删除检测有阈值（约 30%），零散删几个不会触发。
- 判据（改不动时先跑这个，别怀疑正则）：
  ```bash
  ls E:/RuanJian/Hermes/skills/*/<技能名>/SKILL.md    # 空 → 目录已不存在，是幽灵条目
  ```
- 处理：按「下架技能」四步清（见 `skills-catalog-sync` 的「下架/删除技能时」一节），
  或在 `TARGETS` 里**显式跳过并报告**，不要假装改成功了。

## 交付前自检

- [ ] 每条 `len(卡片简介) <= 80`
- [ ] 每个目标在源 desc/detail、JSON、**两处** HTML 里都命中（`subn` 返回 n≥1）
- [ ] HTML 的密码门还在（只搬字段的写法天然安全，但抽查一下 `skill-gate` / `PASSWORD` 关键字）
- [ ] 线上字节数 == `git show HEAD:skills/index.html` 字节数（Pages CDN 要 1~2 分钟）
