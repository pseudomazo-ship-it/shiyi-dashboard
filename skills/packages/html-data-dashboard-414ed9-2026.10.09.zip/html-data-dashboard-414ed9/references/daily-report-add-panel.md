# 给数据日报加板块 / 加字段（`daily_dashboard_v2.py`）

> 来源：2026-10-09「在数值水位内加一个数值的趋势线走势（近3天/近7天/当月/近30天）」。
> 这份是那次的完整改动清单——照这个走，不会再出现「改完了页面没数据」。

## 产物链

```
E:\RuanJian\Hermes\scripts\daily_dashboard_v2.py              生成器
E:\RuanJian\Hermes\scripts\templates\daily_report_v2.html     模板
E:\RuanJian\Hermes\cache\shiyi-dashboard-git\daily\index.html 成品（推这里）
```

生成：`cd /e/RuanJian/Hermes/scripts && python daily_dashboard_v2.py`（约 30 秒，**它自己不 push** —— 见 SKILL.md 第 33 条）。

## 🔴 必须同改的四处（少一处 = 静默无数据）

| # | 位置 | 改什么 | 漏了的症状 |
|---|---|---|---|
| ① | 生成器 `build_period()` / `build_alerts()` | 算出数据、写进 `out["<key>"]` | — |
| ② | 生成器 `js_data()` | 把键加进那段 `%s` 列表 | **数据完全不在 HTML 里**，不报错 |
| ③ | 模板 HTML | 容器 `<div id="…">` | 渲染函数拿不到容器，直接空 |
| ④ | 模板 JS | 渲染函数 + 在 `render()` 里调用 | 容器永远空白 |

### ② 的具体改法（最常漏的一处）

`js_data()` 逐字段拼 JS 对象字面量，**不是 `json.dumps(out)`**：

```python
def js_data(data):
    for k in ("day", "d3", "d7", "month", "d30"):
        d = data[k]
        if k == "d30":
            parts.append('    %s:{range:%s,kpis:%s,score:%s,total:%s,totals:%s,scoreTrend:%s}' % (
                k, j(d["range"]), j(d["kpis"]), j(d["score"]), j(d["total"]), j(d["totals"]),
                j(d.get("scoreTrend"))))
            continue                              # ⚠️ 缩进别带歪
        parts.append('    %s:{…,rows:rows(%s),scoreTrend:%s}' % (
            k, …, j(d["rows"]), j(d.get("scoreTrend"))))
```

- 用 **`j(d.get("key"))`**（`.get` 而非 `[ ]`）—— 某些时段没这个数据时不会 KeyError。
- 改多行 `%` 参数时**特别容易把 `continue` 的缩进带错** → 立刻 `python -c "import ast;ast.parse(open(f).read())"` 或看 lint 报不报 `IndentationError`。
- ⚠️ **中文字符串里的字面 `%` 要写 `%%`**（同 SKILL.md 第 25 条）。

## ⚠️ 近30天是另一套视图（`monthlyView`）

`render()` 在 `is30` 时**直接 return**，标准视图的所有渲染函数都不会执行：

```js
const is30 = period==='d30';
$('#standardView').classList.toggle('hidden', is30);
$('#monthlyView').classList.toggle('hidden', !is30);
if(is30){ renderMonthly(); return }
renderCore(d); renderScoreTrend(d); renderBands(d); renderTrend(d); renderRanking(d); renderTable(d); renderSummary(d)
```

✅ **共用一套绘制代码，容器 id 参数化**（不要复制一份）：

```js
function renderScoreTrend(d, boxId){
  const box = $(boxId || "#scoreTrend"); if(!box) return;
  …
}
// 标准视图
renderCore(d); renderScoreTrend(d); renderBands(d); …
// 月视图（记得自己在 monthlyView 里加 <section>）
if(is30){ renderMonthly(); renderScoreTrend(d,"#scoreTrend30");
  const st30 = d.scoreTrend;                    // 标题右侧摘要，用 id 让 JS 填
  if(st30){ const kn = st30.values.filter(v=>v!=null); if(kn.length){
    const avg = kn.reduce((a,b)=>a+b,0)/kn.length, over = kn.filter(v=>v>46).length;
    const meta = $("#scoreTrend30Meta");
    if(meta) meta.innerHTML = `均 <b>${avg.toFixed(2)}%</b> · 超线 <b>${over}/${kn.length}</b> 天`; } }
  return }
```

### 插 `<section>` 的坑

月视图里每个板块是一个独立 `<section class="section">`，标题行是：

```html
<div class="section-head"><div><h2>标题</h2><div class="sub">副标题</div></div><div class="section-meta" id="…"></div></div>
```

🔴 **上一行的 `</div></div>`（section-head 的两个闭合）非常容易被 patch 吃掉**，本次就写出过一个未闭合的 section-head。改完立刻数：

```python
assert html.count('<section') == html.count('</section>'), '标签不配平'
```

## 生成后的三层自检

```bash
cd /e/RuanJian/Hermes/scripts && python daily_dashboard_v2.py
cd /e/RuanJian/Hermes/cache/shiyi-dashboard-git && python -c "
import io,re,json
t=io.open('daily/index.html',encoding='utf-8').read()
print('字段出现次数(应>=4):', t.count('scoreTrend'))
for k in ['day','d3','d7','month','d30']:
    m=re.search(r'\b'+k+r':\{.*?scoreTrend:(\{.*?\})\}', t, re.S)
    if m:
        d=json.loads(m.group(1)); print(k, len(d['labels']), d['values'][:4])
print('section 配平:', t.count('<section')==t.count('</section>'))
"
```

浏览器断言（`browser_exec`，比截图可靠）：

```python
goto_url('file:///E:/RuanJian/Hermes/cache/shiyi-dashboard-git/daily/index.html'); wait_for_load()
js('document.getElementById("pw").value="12511251"'); js('document.getElementById("pwb").click()')
# ① 节点数 / ② 基准线 / ③ 悬停气泡 / ④ 时段联动
print(js('document.querySelectorAll("#scoreTrend .tdot").length'))
print(js('!!document.querySelector("#scoreTrend .stdline")'))
js('''(()=>{const d=document.querySelector('#scoreTrend .tdot');const r=d.getBoundingClientRect();
  d.dispatchEvent(new MouseEvent('mouseover',{bubbles:true,clientX:r.left+2,clientY:r.top+2}))})()''')
print(js('document.getElementById("ttip").textContent'))      # → 「10/01 48.44%」
```

⚠️ **验证前先解锁密码门、展开目标板块** —— 收起状态下容器 `clientWidth===0`，量到 0 会误判（同 SKILL.md 第 19/31 条）。
⚠️ 切到 `d30` 时断言 `#monthlyView` 可见 + `#standardView` 隐藏，否则测的是另一套视图。

## 口径提醒（做这一块时必须知道）

数值 = `(退款金额 + 推广花费) / 业绩 × 100`，标准线 **46%**。
2026-10-09 实测近30天：**均 47.70%、26/30 天超线、区间 45.3~51.5%** ——
即**「超 46%」是常态而不是异常**。所以「仅看数值超线」筛选、四档里的「>50%」警示色、
以及结论里「优先处理数值高于 46% 的 22 家店」这类文案，**实际区分度很低**，做这块时不要默认它是异常信号。
（已把这一点报给十一并给了 A/B/C 三个改法，他未回；**不要自己改标准线**。）
