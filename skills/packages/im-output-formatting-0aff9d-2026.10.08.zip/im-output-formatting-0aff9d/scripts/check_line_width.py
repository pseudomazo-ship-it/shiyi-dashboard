# -*- coding: utf-8 -*-
"""IM 推送发出前的自检：行宽 + 行首空格 + 折行探针

为什么需要它：QQ 渲染换行，但聊天窗口约 **41 列就折行**（2026-09-21 实测）。
折行后内容被切成两段，用户看起来像“文字错位”；而行首空格/全角空格在手机上看着也像缩进错乱。
**这两件事靠眼睛看不出来，必须量。**

用法：
    # ① 检查某个脚本的 stdout（最常用）
    python check_line_width.py check "python E:\\RuanJian\\Hermes\\scripts\\yunying_daily.py"

    # ② 检查一个已有的文本文件
    python check_line_width.py file daily_out.txt

    # ③ 不知道对方窗口几列折行时，发一条探针让用户告诉你
    python check_line_width.py probe --to qqbot

退出码：0 = 全过；1 = 有行首空格 / 超宽行。

⚠️ 例外：**markdown 表格行不检查宽度**（去空白后以 `|` 开头的行）。
   QQ 会把 markdown 表格渲染成真表格（2026-09-21 实测验收），由渲染器分栏、不会折行，
   量字符宽毫无意义且会误报超宽。**只对这些行查行首空格。**

⚠️ 宽度口径：中日韩全角 + Ambiguous(`█` `━` `|` 等) 在中文环境下都算 **2 列**。
   按 1 列算会少算半行——这正是“看着没超但对方折了”的根因。
"""
import shlex
import subprocess
import sys
import unicodedata

MAXW = 40                                   # 超过就当作有折行风险（QQ 实测 ~41 列折）
BAD_HEAD = (" ", "\u3000", "\u00b7")       # 半角空格 / 全角空格 / 中点
PROBE_WIDTHS = (36, 38, 39, 40, 41, 42, 44, 46, 48, 50)


def width(s):
    """显示宽度：W/F/A 都算 2 列"""
    return sum(2 if unicodedata.east_asian_width(ch) in ("W", "F", "A") else 1 for ch in str(s))


def lint(text, maxw=MAXW, label=""):
    lines = [l for l in (text or "").splitlines() if l.strip()]
    if not lines:
        print(f"{label}⚠ 没有内容可检查")
        return 1
    head = [l for l in lines if l[:1] in BAD_HEAD]
    # markdown 表格行（`|` 开头）豁免宽度检查：QQ 会渲染成真表格，由渲染器分栏，不折行
    trow = [l for l in lines if l.lstrip().startswith("|")]
    over = [(width(l), l) for l in lines
            if not l.lstrip().startswith("|") and width(l) > maxw]
    print(f"===== {label or '输出'} =====")
    print(f"行数 {len(lines)}｜行首带空格 {len(head)}｜超 {maxw} 列 {len(over)}｜表格行豁免 {len(trow)}")
    for l in head:
        print(f"  [行首空格] {l[:60]!r}")
    for w, l in over:
        print(f"  [{w} 列折行] {l}")
    if not head and not over:
        print("  ✅ 通过")
    print()
    return 0 if (not head and not over) else 1


def cmd_check(command, maxw=MAXW):
    r = subprocess.run(shlex.split(command, posix=False), capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=300)
    return lint((r.stdout or "") + (r.stderr or ""), maxw, command[:60])


def file_check(path, maxw=MAXW):
    with open(path, encoding="utf-8", errors="replace") as f:
        return lint(f.read(), maxw, path)


def probe(to="qqbot", hermes_exe=r"E:\RuanJian\Hermes\hermes-agent\venv\Scripts\hermes.exe"):
    """发一条自带宽度的探针，让用户回报「从数字几开始断行」"""
    lines = ["【折行实测】下面每行开头标了它的宽度，请告诉我从哪一行开始被切成两行"]
    for w in PROBE_WIDTHS:
        head = str(w) + " "
        lines.append(head + "x" * (w - len(head)))
    body = "\n".join(lines)
    r = subprocess.run([hermes_exe, "send", "--to", to, body], capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=90)
    print((r.stdout or "").strip() or (r.stderr or "").strip() or f"已发送（rc={r.returncode}）")
    print("→ 让用户回一个数字，再把 MAXW 按「那个数字 - 1」收紧")
    return r.returncode


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    mode, rest = argv[1], argv[2:]
    if mode == "check":
        return cmd_check(rest[0])
    if mode == "file":
        return file_check(rest[0])
    if mode == "probe":
        to = "qqbot"
        if "--to" in rest:
            to = rest[rest.index("--to") + 1]
        return probe(to)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
