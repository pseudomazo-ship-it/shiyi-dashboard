# 代码块在各渠道的渲染能力（2026-09-29 定案）

## 一、结论表

| 渠道 | 换行 | markdown 表格 | ``` 代码块 | 发文件(MEDIA) |
|---|---|---|---|---|
| 微信 iLink | ✅ 保留（>120 字符才折行）| ✅ 保留 | ✅ **渲染成框（十一验收）** | ✅ |
| QQ · cron/网关投递 | ✅ | ✅ **渲染成真表格（十一发图验收）** | ❌ **不渲染，``` 会当正文显示** | ❌ |
| QQ · `hermes send` | ✅ | ❌ 只发纯文本 | ❌ | ❌ |
| 飞书 | ✅ | ✅ | ✅（官方文档明确支持围栏代码块）| ✅ |
| **桌面 Hermes 对话** | ✅ | ✅ | ⛔ **十一不要裹** | ✅ |

## 二、十一的逐条原话（唯一权威）

> 微信是代码块，　QQ不是（异常），桌面不需要裹代码块

三条同时给出，要**分开记**（① 微信要裹 ② QQ 不能裹 ③ 桌面不要裹）。

## 三、QQ 官方依据

QQ 机器人 `msg_type=2`（Markdown 消息）的「支持格式」页只列了：

- 文字样式（粗体 / 斜体…）
- 有序列表
- 块引用

文档：`https://bot.q.qq.com/wiki/develop/api-v2/server-inter/inter/message/type/markdown.html`
（真址：`bot.q.qq.com/wiki/develop/api-v2/server-inter/message/type/markdown.html`）

**⚠️ 两个不要踩的推论**：
1. 别因为这份列表没写表格，就推翻「QQ 能渲染表格」—— 那条是十一**发截图验收过**的，
   官方列表只是不完整，不是排除清单。
2. 别因为网关默认 `markdown_support: true` 就以为 QQ 一定能渲染一切 ——
   网关**确实按 `msg_type=2` 发了 markdown**（`gateway/platforms/qqbot/adapter.py`：
   `if self._markdown_support: body = {"markdown": {"content": ...}, "msg_type": MSG_TYPE_MARKDOWN}`），
   是**客户端不支持围栏**，不是我们没发。所以修法在**内容侧**（去掉围栏），不是在网关侧。

## 四、实现形状

```python
core    = "\n".join(L)
body_wx = "```\n" + core + "\n```"   # 微信
body_qq = core                        # QQ：纯文本 + `　` 全角空格缩进
```

- 正式跑（脚本自己发）→ `body_wx`
- **微信失败 print 出来走 cron 投 QC 兜底时 → 必须用 `body_qq`**
- 手动查看开关：`--show` / `--show --qq`

## 五、怎么验证（一次问清，别猜）

1. 同一条内容**分别发** QQ 和微信各一条，正文里标清「这条是 QQ / 这条是微信」。
2. 只问一件事：「**你看到的是代码块（灰底框），还是三个反引号露出来了？**」
3. 结论**以他看到的为准** —— 「我源码里是对的」不能推断渲染结果。
4. ⚠️ **改任何带代码块的输出后要重新各发一遍**：本次只发 QQ 才发现 ``` 裸露，
   微信那条一直是好的，差点被一并当成「代码块这条路走不通」。
5. ⚠️ 微信别连发多条（`iLink sendmessage rate limited`，且重试会重置 30s 冷却）；
   测格式时一次一条、分钟级间隔。
