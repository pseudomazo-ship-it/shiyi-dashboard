# 微信（iLink）为什么会把一条消息拆成多条

2026-10-08 十一问「**你怎么给我发消息是分段的**」—— 查源码定位，两条独立原因。

## 源码位置

`E:\RuanJian\Hermes\hermes-agent\gateway\platforms\weixin.py`

| 东西 | 行（2026-10-08 时点） | 说明 |
|---|---|---|
| `MAX_MESSAGE_LENGTH = 2000` | ~1178 | 单条上限。**不是 4000** |
| `_split_text_for_weixin_delivery(content, max_length, split_per_line)` | ~897 | 总入口，两个分支见下 |
| `_split_delivery_units_for_weixin(content)` | ~805 | 按顶层块切（围栏受保护） |
| `_should_split_short_chat_block_for_weixin(block)` | ~874 | ★ 「看起来像聊天」的判定 |
| `_looks_like_chatty_line_for_weixin(line)` | ~844 | 单行是否像聊天（≤48 字、非缩进、非 `>`/`-`/`*`/`【`/`#`/`|`、非表格线、非 `**粗体**`、非 `1.`）|
| `_looks_like_heading_line_for_weixin(line)` | ~864 | ≤24 字且以 `:`/`：` 结尾 → 算标题 |
| `_pack_markdown_blocks_for_weixin(content, max_length)` | ~884 | 超限时「按块贪心打包」 |
| 配置读取 | ~1240 | `extra.get("split_multiline_messages") or os.getenv("WEIXIN_SPLIT_MULTILINE_MESSAGES")`，**`default=False`** |

## 两个触发条件

```python
# compact 分支（默认，split_per_line=False）
if len(content) <= max_length:                                   # max_length = 2000
    return ([u for u in _split_delivery_units_for_weixin(content) if u]
            if _should_split_short_chat_block_for_weixin(content)  # ← 条件②
            else [content])
return _pack_markdown_blocks_for_weixin(content, max_length) or [content]   # ← 条件①
```

**① 超过 2000 字符** → 按块打包成多条（不可完全避免，只能压长度或改发文件）。

**② ≤2000，但整条内容满足 `_should_split_short_chat_block_for_weixin`：**
- 非空行数 `2 <= n <= 6`
- 首行**不是**标题（`_looks_like_heading_line_for_weixin` 为假）
- **每一行**都 `_looks_like_chatty_line_for_weixin` 为真

→ 就**故意拆成几个气泡**（源码注释：`for a more natural chat feel`）。
**这是设计，不是 bug。**

### 所以什么内容安全

带**代码块**（``` 围栏）、**markdown 表格**（`|` 开头）、**列表**（`-`/`*`/`1.`）、**标题**（≤24 字带冒号）
的消息，**行级判定就不通过** → 不会被 ② 拆。这正是「常用消息用代码块发」的额外好处。

## 配置开关（都可以不动）

| 开关 | 值 | 行为 |
|---|---|---|
| `platforms.weixin.extra.split_multiline_messages` | **默认 `false`（= compact，当前状态）** | ≤2000 时一条；只有撞上②才拆气泡 |
| 同上 | `true` | **legacy：每个顶层块一条**（远比现在碎，**别开**）|
| 环境变量 `WEIXIN_SPLIT_MULTILINE_MESSAGES` | 同上 | 同上 |

十一 2026-10-08 明确「**2000 上限先不动**」：那个数字大概是照 iLink 接收能力定的，
硬调高可能直接发失败 —— 比拆条更糟。真要动先小步试（3500），收不住就退回。

## 自查：我这条到底多少字

```python
msg = "..."            # 你打算发的内容
print(len(msg))        # > 2000 → 必被拆；<= 2000 还要看下面
lines = [l for l in msg.splitlines() if l.strip()]
print(len(lines))      # 2~6 且每行都很短 → 有触发②的风险
```

要**直接问网关函数**（同 `references/wechat-ilink-formatting-findings.md` 的做法）：
```python
import sys; sys.path.insert(0, r"E:\RuanJian\Hermes\hermes-agent")
from gateway.platforms.weixin import _split_text_for_weixin_delivery
print(len(_split_text_for_weixin_delivery(msg, 2000, False)))   # 期望 1
```

## 连带规则：链接放哪

- **代码块内**的 URL 在微信里是等宽纯文本，**不出蓝链、点不动**。
- **代码块外**、正文里单独一行的 URL → 可点蓝链。
- 十一 2026-10-08 连说两次：「链接就不要放在代码块内」「代码块内不是蓝链，我无法直接点击进入」。

## 本次实测记录（2026-10-08）

十一收到「为什么我的域名打不开」「技能包已发到你 QQ」那几条时，看到的是**被拆开的多条**。
两条被拆的原文分别约 2500 和 3000+ 字符 —— 撞的是**条件①**。
他确认改法有效：「**一条，没问题先不动**」（即：不改 2000，我压长度 + 用代码块 + 超长发文件）。
