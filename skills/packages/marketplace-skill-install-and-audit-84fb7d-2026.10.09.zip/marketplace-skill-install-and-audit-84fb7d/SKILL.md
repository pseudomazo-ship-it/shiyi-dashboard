---
name: marketplace-skill-install-and-audit
description: "Install/vet marketplace skills (SkillHub CocoLoop)."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [skillhub, cocoloop, clawhub, skill-install, security, audit, marketplace, zip]
---

# Installing & Auditing Marketplace Skills

Install third-party agent skills from marketplaces (SkillHub, CocoLoop, clawhub)
into Hermes and vet each one before trusting it. Covers the batch pattern the user
often uses ("依次执行以下步骤: 1. 检查 cocoloop 2. 从 URL 装 <skill>"), the
version-conflict case, and the security-audit decision.

## When to use
- User gives an install batch with numbered steps and a skill name/URL.
- User pastes a raw skill zip URL (`https://.../x-1.2.3.zip`) or a `.skill` file.
- **User attaches a skill `.zip` that is already on disk** (e.g. `E:\RuanJian\Hermes\attachments\<slug>_skill_<date>.zip`) and says "安装一下这个 skill" — same pipeline minus the download: unzip from the local path → read frontmatter → audit → copy to `skills/<category>/<slug>/`. The attachments path is usually OUTSIDE the workspace, so address it by absolute path and clean up the temp extract dir afterwards.
- User asks to vet/audit a third-party skill before or after install.
- You need to decide whether to trust a marketplace skill that contains code.

## Step 0 — pre-check: is it ALREADY installed (or already newer)? (NEW)
Before downloading/auditing, run `skills_list` (no category) and grep for the incoming skill's `name:` / slug. Several times the user's install batch points at a skill that is **already present on the machine** — either installed via clawhub/SkillHub (`@clawhub_*/<slug>`), or a newer version already live:
- **Already present, same/close version** → skip. Do NOT re-download or create a duplicate copy.
- **Already present and OLDER than the incoming zip** → still surface first; upgrading is the user's call.
- **Already present and NEWER** (incoming `_meta.json` version < installed version) → skip AND tell the user, because installing would be a **downgrade**. Hit for real: user ran the batch for `agent-browser` (already v0.27.0 CLI + `/skills/@clawhub_rez0/agent-browser`) and `self-improving-agent` (installed 3.0.24 > incoming 3.0.21) — both correctly skipped, no reinstall.
- **CLI dependency** may ALSO already be installed (`which agent-browser` / `agent-browser --version`) even when the skill dir is absent or duplicated — check both the skill AND its runtime binary before deciding.

## Marketplace install pipelines

### SkillHub (skillhub CLI)
- CLI is usually already installed (`command -v skillhub`). `skillhub --version`.
- Search: `skillhub search <term>` — prints candidates + exact install command.
- **Install into THIS agent's skills dir** — the default `./skills/` is NOT
  recognized. Always pass `--dir`:
  `skillhub install <slug> --namespace <ns> --dir "<$HERMES_HOME>/skills/"`
  — on this host that is `E:/RuanJian/Hermes/skills/`. ⚠️ **The Hermes install moved from `E:\软件\Hermes` to `E:\RuanJian\Hermes` (2026-09).** An older note quoting `E:/软件/Hermes/...` silently installs into a path that is no longer the live skills dir (the skill then never loads). If a `--dir` / absolute path in this skill or an older transcript says `E:\软件`, re-point it at `E:\RuanJian`.
- The same slug may exist under several namespaces (`@clawhub_pskoett/x`,
  `@zcwl/x`, `@user_*/x`...). Match the exact namespace the user named, then
  confirm the right one from the search output.

### CocoLoop (zip download)
- Given a raw `https://dl.cocoloop.cn/bss/skills/<slug>-<ver>.zip` URL:
  1. `curl -sL -o /tmp/x.zip "<url>"` then `unzip -o -q` to a temp dir.
  2. Read `SKILL.md` frontmatter (`name:`/`version:`) and `_meta.json` — this
     tells you the identity and whether it collides with an installed skill.
  3. Inspect payload: doc-only vs script-bearing (see audit below).
  4. Copy to `skills/<dir>/` (name dir by the slug or a disambiguating suffix).
  5. `hermes skills list` to confirm it shows `enabled`.
- **Hermes requires `name:` in the frontmatter to load.** Some marketplace
  zips ship a `SKILL.md` with only `description:` (no `name:`/`version:`). If
  you copy it verbatim, `skills_list` won't show it and `skill_view` returns
  blank identity. **Patch the frontmatter before install**: prepend
  `name: <slug>` and `version: <ver>` (version from `_meta.json`). Keep the
  original `description:`. Then re-list. (Hit for real on
  `matagul-desktop-control-1.0.0`.)
- **`skills_list(category=...)` only matches a set `category`. A bare skill
  (no `category` field) is found via the FULL list, not a category filter.**
  When grepping for a skill you just installed, call `skills_list` with no
  category arg and scan the `name`s, or use `skill_view(name)` directly.
- `cocoloop` itself is a manager SKILL (docs), not a binary — drive it by
  following its SKILL.md steps (search API → curl → extract → audit → install),
  you don't run a cocoloop executable.
- **"Is it already the latest?" when the zip carries NO version metadata**
  (`cocoloop-main.zip` is the case: SKILL.md has no `version:`, no `_meta.json`):
  you cannot compare versions, so compare **content**. Download the remote zip,
  `unzip` to temp, then md5 every shipped file against the installed copy:
  `for f in ...; do [ "$(md5sum new/$f|cut -d' ' -f1)" = "$(md5sum old/$f|cut -d' ' -f1)" ] && echo "SAME $f" || echo "DIFF $f"; done`
  All SAME ⇒ already latest ⇒ **skip the reinstall** and report "已是最新，无需重装"
  with the file count. All-DIFF-or-missing ⇒ the local copy is genuinely behind ⇒
  reinstall. (Verified 2026-09-30 on cocoloop: 7/7 files identical, step 1 of the
  batch correctly satisfied with zero writes.)
- **⚠️ Do NOT prune "duplicate-looking" payload dirs out of an installed zip.**
  Marketplace zips routinely ship the SAME CSV/data folder twice under two paths
  (e.g. `data/` **and** `assets/data/`, 24 CSVs each). Deleting the one that looks
  redundant is a landmine: the scripts often hardcode the path they read from.
  Hit for real 2026-09-30 — `anthropic-frontend-design` had
  `scripts/core.py: DATA_DIR = Path(__file__).parent.parent / "data"`, i.e. the
  ROOT `data/`, so pruning it silently breaks every script while the tree still
  looks complete. **Before deleting anything from a freshly-unzipped skill, grep
  the scripts for the path they resolve:**
  `grep -nE "__file__|Path\(|assets|'data'|\"data\"" scripts/*.py` — then keep
  whichever path the code actually uses (keeping both is fine and cheap).
  Fix if already pruned: just `cp -r` it back from the temp extract dir.
- **A skill zip with `name:` already present still benefits from adding `version:`**
  from `_meta.json` (the Anthropic Frontend Design zip shipped only `name:` +
  `description:`, no version). One-line frontmatter patch via `patch`, then
  `skill_view` to confirm it still loads.

### GitHub repo (`@url:https://github.com/<owner>/<repo>`)
User pastes a GitHub URL and says "安装这个技能". Pipeline:

1. **First confirm the repo actually IS a skill.** Fetch the root listing
   (`GET https://api.github.com/repos/<owner>/<repo>/contents/`) and look for
   `SKILL.md`. **The URL the user gives is often NOT the skill repo** — hit for
   real (2026-09): `AnxForever/stylekit` is the Next.js **website** for a style
   catalog; the actual skill lives in the sibling repo `AnxForever/stylekit-skill`.
   If there's no `SKILL.md`, read the README — it usually names the real install
   target (here: `npx skills add AnxForever/stylekit-skill`). Tell the user the
   URL they gave wasn't the skill, then proceed with the right repo.
2. **Download the whole tree.** List it first:
   `GET https://api.github.com/repos/<owner>/<repo>/git/trees/main?recursive=1`
   (fall back to `master`), then fetch each file with
   `GET .../contents/<path>` → the JSON has `content` as **base64** → `base64.b64decode`.
   **Why not `raw.githubusercontent.com` / `curl`:** raw often can't be reached from
   this host while `api.github.com` works. The contents API is the reliable route
   (stdlib `urllib` + `ssl` is enough; disable cert verification if the proxy
   intercepts). Keep the relative paths when writing locally so the skill's own
   `scripts/` + `references/` links stay intact.
3. **Audit** (see below), then copy the tree into `skills/<category>/<slug>/`.
4. **Write `_meta.json` yourself** — GitHub repos don't ship one, and other
   Hermes tooling uses it for version comparison:
   `{"name": <slug>, "version": <from SKILL.md or releases>, "source": "github:<owner>/<repo>", "installed": "<YYYY-MM-DD>", "license": <SPDX>}`.
5. Verify with `skill_view(<slug>)` → expect `"success": true` and
   `readiness_status: "available"`.

Worked example: [references/2026-09-stylekit-github-install.md](references/2026-09-stylekit-github-install.md).

## Gotcha: trailing full-width comma in user-supplied URLs
The user (and lots of pasted instructions) often appends an **`，`** to the URL
(`...zip，`). The download then fails with a craft-404 from the CDN (Aliyun OSS
`NoSuchKey`, or "the specified key does not exist") because the object key actually
contains the comma. The skill is NOT missing — strip the trailing `，`/`,` and
retry. Always try the comma-stripped URL before concluding "not found" / 404.
Also: the `@url` preview card may render as "page not found" while the real
markdown/zip is reachable (CDN vs page-render layer) — verify with `curl -sIL`,
not the rendered preview.

## Version-conflict handling (do NOT silently downgrade)
If the skill's `name:` (or slug) matches one already installed, compare versions:
`_meta.json` `version:` (installed) vs the incoming zip's. Same-skill,
different-version is a downgrade/upgrade decision that belongs to the user. Don't
overwrite an installed newer version with an older one, and don't install a second
copy under a near-identical name without asking. Ask once with a clear choice
(keep-newer / install-alongside / overwrite), then execute their pick. This user
runs the same install batch repeatedly with different versions (3.0.24 → 3.0.21 →
3.0.15) — always surface the version comparison rather than auto-covering.

## Auditing a skill: LOCAL vs CLOUD-SaaS (the key trust decision)
Two different classes of "security" skill — never treat them the same:
- **Local / offline** (e.g. zhongkui 钟馗): regex/pattern -only, reads files,
  does NOT upload anything, no daily network pull. Lower trust risk. Fine to
  install and run as-is. NOTE: it produces false positives on doc-only skills —
  it flags ordinary `https://` doc URLs as "外传" (C4), and text like
  "no credentials required" / "never store credentials" as "凭证访问" (C3),
  and markdown lists as "系统危险命令" (C5). A 🚫 verdict from such a tool is
  NOT authoritative — verify the specific red line actually holds (read the
  flagged line) before acting. Its own SKILL says "automated assessment, not a
  security guarantee".
- **Cloud SaaS client** (e.g. SkillScan / anything that hits
  `https://<vendor>.com/oapi/v1/...`): it COMPUTES a hash and **uploads your
  skill's code as a zip to a third-party server**, plus reports client
  fingerprint (`X-Client-Info`: MAC address, UUID, OS, Python version), and
  pulls a manifest update daily, and can even DELETE a flagged skill dir
  (`shutil.rmtree` on HIGH/CRITICAL). Installing one means your machine data
  leaves the box on every scan. **Do not auto-install.** Surface the
  upload/fingerprint behavior and get explicit consent. This user's standing
  preference: reject cloud-upload audit tools; keep audits local.
- **Cloud "shared-agent-memory" / bounty platform** (e.g. AgentOverflow /
  `agent-overflow.com`): the skill's RAISON D'ÊTRE is to register an external
  agent identity, then **POST the agent's problems, error traces, and code
  snippets to a public third-party server** for other agents to solve, driven
  by a platform-currency / bounty incentive (CrabCoin). This is a THIRD class:
  not a local tool, not a cloud AUDIT tool — it is a **data-EXFILTRATION-by-design**
  skill. Its own doc even has a "redact secrets" checklist because it KNOWS
  users will paste internal code/paths/errors. **Reject by default** — it
  conflicts with this user's standing rule ("第三方 skill 上传本机代码/信息到云端 =
  默认拒绝"). Hit for real on `agent-overflow` (2026-09): user chose 不装 after
  being shown the upload-to-cloud behavior. Tell the user what it DOEs before
  they decide — never install a data-exfiltration skill without explicit
  consent that acknowledges the upload.

Audit heuristic for a payload: `grep -rilE "fetch\(|https?://|exec\(|eval\(|subprocess|os\.system|curl |wget |require\("` over the payload. Doc-only
(no hits in script files, or hits only inside .md prose) ⇒ low risk. Real script
files with those calls, or cloud-API endpoints, ⇒ escalate to the user.

**Scan the actual network VERBS, not just URLs.** A URL match alone says nothing
about direction. The decisive evidence is `POST`/`PUT`/`PATCH`/upload calls, plus
any write/delete to the filesystem. A clean profile looks like:
```
POST/PUT/PATCH ..... 0 处        (不上传)
shutil.rmtree/rm -rf  0 处        (不删文件)
open(...,'w')/写入    0 处        (不污染本地)
网络请求              只有 GET <vendor>  (只拉规格)
```
Fetch-only + read-only + no-upload is the **low-risk** shape — safe to install.

**⚠️ Beware your OWN regex false positives — never report a heuristic count you
haven't read.** Hit for real (2026-09, stylekit audit): a loose pattern reported
「读取敏感目录 109 处」and「本机指纹 2 处」, which looked alarming. Both were
noise — the first matched the phrase **"design tokens"** (`token` ⊂ `tokens`),
the second matched **"machine-readable"** (`machine` ⊂ fingerprint heuristic).
Before putting any scary number in front of the user, **print the matched lines
with context and eyeball them**. Same discipline as the zhongkui false-positive
note above: a 🚫/high count from a pattern tool is a LEAD, not a verdict.

**Report "safe to install" and "actually applicable" as two SEPARATE verdicts.**
A clean audit only means it won't exfiltrate data — it says nothing about whether
it does what the user wants. stylekit was clean (no upload, no writes) **but** its
tokens/recipes target Tailwind/shadcn/React projects, while the user's actual
target was a hand-rolled HTML+CSS dashboard. Say both: "安全，可以装" **and**
"但它主要面向 Tailwind/shadcn，你的目标是纯 HTML，需要手工翻译 tokens — 适配性存疑".
Never let a clean security verdict be read as "this will solve your problem".

## Name collision → Hermes "Ambiguous skill name" (NEW)
If a freshly-downloaded zip ships the same `name:` (slug) as an already-installed copy, copying it
to top-level `skills/<slug>/` creates TWO dirs with one `name:`. Hermes then refuses to load it:
`Error: Ambiguous skill name 'x': 2 skills match ... Refusing to guess`.

Resolution principle: **compare Hermes-fitness, not just version number** — does the installed copy
carry `allowed-tools`, `hidden: true`, or discovery-stub/dynamic loading (which stays matched to the
installed CLI), vs the incoming zip being a verbose static manual? Keep the Hermes-integrated one, delete
the freshly-copied duplicate (`rm -rf skills/<slug>`, not the `@<ns>/<slug>` one), then re-confirm the
ambiguity is gone via `skill_view(name)`. Newer/"more complete" != better. Hit for real on
`agent-browser` (2026-09). See [references/2026-09-skill-name-collision.md](references/2026-09-skill-name-collision.md).

## 只“浏览/采集”商店榜单（不装任何东西）

十一 会发 `@url:hub.cocoloop.cn/popular` 说「这些板块的内容采到我的看板里」——
这是「摸市场」而不是安装，**不要走下载 zip / 审计 / 安装那套**。
站点是 SPA（切分类靠点 tab、URL 不变、分页是 `›` 按钮），选择器、抽取 JS、
四个坑（stats 文本粘成一串、字母表过滤漏 D 级、站内外两种 href、分批跑）
与实测量见 **`references/cocoloop-shop-harvest.md`**。
两条最容易踩的：
- **等级 / 数字要用「含数字」特征保留，不要写字母表排除** —— 漏一个等级值就是整批数据错。
- 汇报时把「等级分布 / 同质刷榜」一并说了，并重申**默认不装第三方技能**。

## Verification (always)
- `hermes skills list` → the new skill should show `enabled`. If a skill shows as
  a split two-line row (`Self-Improving +` / `Proactive Agent`), that's just a
  name-with-spaces rendering — functionally fine.
- For script-only skills: run `python <skill>/<main>.py --help` to confirm the
  code path works in THIS python (not just that it parsed).
- **A script-bearing skill usually needs a python dep — resolve it BEFORE calling the install done.**
  Probe with `python -c "import <pkg>"`. ⚠️ On this host plain `python -m pip install <pkg>` is
  REFUSED with `error: externally-managed-environment` (the interpreter is uv-managed, PEP 668) —
  that is a setup gate, not a broken install. Two working routes:
  **`python -m pip install <pkg> --break-system-packages`** (persists for the plain-`python`
  invocations the skill's own docs assume — verified: openpyxl 3.1.5) or run the script as
  `uv run --with <pkg> python <script>.py`. Prefer the persistent install when the skill's docs
  tell the user to run it with plain `python`.
- **Then actually EXECUTE the skill's main script once on throwaway input — `--help` is not enough.**
  A script that imports cleanly can still crash on real arguments. Verified on `pdd-merchant-harvest`:
  fed fake ids/attrs JSON to `scripts/gen_xlsx.py`, confirmed the xlsx was produced with the expected
  rows plus freeze `A2` / auto-filter / the anomaly-note logic, then deleted the temp files.
  Report the observed output (row count, file size), not "looks fine".
- **Skills with a usage-policy/consent gate** (e.g. `code-analysis`, a Git-history
  reflection tool requiring `--i-have-consent`): running it against a repo will
  print a usage notice and REFUSE ("Self-scope mode requires a local Git identity
  but none was found") until the CURRENT git identity matches the repo's commit
  author. A mismatch (commit author `Eleven <...>` vs configured `user.name`
  `TestUser`) is the gate working as designed, NOT a bug — it's protecting against
  analyzing someone else's data without consent. To genuinely test the full run,
  set a git identity matching the commit author (`git config user.name`/`email`
  in the repo), or use the `--multi-author-team-retro --consented-author` opt-in.
  Report "tool runs and enforces its consent gate" as the verification result for
  such skills — don't claim a report was generated when the gate refused.
- New skills load on the NEXT session, not the current one — tell the user.
  ⚠️ Nuance (observed 2026-09): a fresh copy-into-`skills/` install was already readable
  **immediately** via `skill_view(<slug>)` (`success: true`, `readiness_status: available`)
  in the same session that installed it. So the reliable check is `skill_view(<slug>)`,
  not a guess — and don't tell the user "wait for the next session" without trying it first.
  What does lag is the injected skill list at the top of an existing session's context.
- Clean up temp dirs (`/tmp/*`) after install; leave no orphaned dirs in `skills/`
  from failed installs.

## Reporting
Give a compact results table: skill | version | decision (装/拒收/跳过) | why.
Call out the reason for any rejection (esp. cloud-upload audit tools) and any
version conflicts. Never claim a skill "installed" when the tool returned an error.

## Session detail (worked examples)
- [references/cocoloop-shop-harvest.md](references/cocoloop-shop-harvest.md) — **CocoLoop 商店榜单采集**（hub.cocoloop.cn/popular）：
  SPA 特性 / 10 个分类与分页按钮、能跑的抽取 JS、等级与两个数字的取法、四个坑、452 条的对照基准。
  十一 说「把商店这些板块采下来 / 挂到看板」时读它。
- [references/2026-08-install-batches.md](references/2026-08-install-batches.md) — the concrete batch of installs this session (cocoloop, self-improvement 3.0.24/3.0.21/3.0.15, Self-Improving+Proactive 1.2.16, ontology 1.0.4, multi-search-engine 2.1.3, SkillScan rejection, agent-browser) and each decision.
- [references/2026-08-31-desktop-control-install.md](references/2026-08-31-desktop-control-install.md) — the Desktop Control (matagul-desktop-control-1.0.0) install: zip payload already-latest diff check, missing `name:` frontmatter fix, security grep (only `base64`), deps into hermes venv, empty-category gotcha.
- [references/2026-09-30-cocoloop-check-and-anthropic-frontend-design.md](references/2026-09-30-cocoloop-check-and-anthropic-frontend-design.md) — the two-step batch (check cocoloop latest → install Anthropic Frontend Design 1.1.0): md5 whole-file compare when the zip has no version, the `data/` vs `assets/data/` prune trap, stdlib-only script smoke test.
