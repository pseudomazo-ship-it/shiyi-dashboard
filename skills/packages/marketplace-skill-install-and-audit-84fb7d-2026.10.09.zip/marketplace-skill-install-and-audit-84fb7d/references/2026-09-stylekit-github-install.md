# 2026-09 — Installing `stylekit` from a GitHub repo

First real run of the **GitHub-repo** install pipeline (the URL user gives is not
necessarily the skill repo).

## What the user asked

> `@url:https://github.com/AnxForever/stylekit` 安装这个技能

…with a Context Warning already saying `no content extracted` (the `@url` preview
couldn't render the page). Do not read that as "the repo doesn't exist".

## Step 1 — the URL was the wrong repo

| | |
|---|---|
| `AnxForever/stylekit` | a **Next.js website project** (148-style catalog site). No `SKILL.md`. |
| `AnxForever/stylekit-skill` | **the actual agent skill** (MIT, v0.6.0). |

Found the right one by reading the first repo's README, which literally says:

> **Use as an Agent Skill** — `npx skills add AnxForever/stylekit-skill`

**Lesson:** always probe for `SKILL.md` at the repo root before downloading a tree.
If absent, read the README for the real skill target, tell the user their URL was
the website/docs and not the skill, then continue with the correct repo.

## Step 2 — getting the files (raw was unreachable)

- `git clone` from the terminal **timed out** (exit 124), and `curl` fetched nothing.
- `raw.githubusercontent.com` was blocked in this environment.
- **`api.github.com` worked.** So:

```python
import urllib.request, json, base64, ssl, os
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
API = "https://api.github.com/repos/AnxForever/stylekit-skill"

def get(path):
    req = urllib.request.Request(f"{API}/contents/{path}", headers={"User-Agent": "audit"})
    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
        return json.load(r)

# 1) enumerate the whole tree
tree = json.load(urllib.request.urlopen(
    urllib.request.Request(f"{API}/git/trees/main?recursive=1", headers={"User-Agent": "audit"}),
    timeout=30, context=ctx))
for node in tree["tree"]:
    if node["type"] == "blob":
        blob = get(node["path"])                      # {"content": "<base64>", ...}
        data = base64.b64decode(blob["content"])
        dest = os.path.join(tmp, node["path"].replace("/", os.sep))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        open(dest, "wb").write(data)
```

`GET .../git/trees/main?recursive=1` gives the full file list in one call; each
`contents/<path>` returns `content` as base64. Keep relative paths so the skill's
own `scripts/` and `references/` links resolve.

**This is the general fallback for any GitHub-hosted skill/repo when raw or git
is blocked — not a one-off.**

## Step 3 — audit (the decisive evidence)

Files: `SKILL.md` + `README.md` + `LICENSE` + 2 `references/*.md` + 5 `scripts/*.py`.

```
POST/PUT/PATCH ......... 0 处   → 不上传任何东西
shutil.rmtree / rm -rf .. 0 处   → 不删文件
写本地文件 .............. 0 处   → 不污染工作区
扫描全盘/敏感目录 ........ 无
网络请求 ................ GET https://www.stylekit.top/api/styles/<slug>  (只拉风格规格)
OpenAI API ............. 仅 benchmark.py --llm 可选，默认不调；默认 fixture 模式无需 key
```

Verdict: **low risk — fetch-only, read-only, no upload.** Installed.

### The false positives (worth remembering)

The first pass of a loose regex printed:

```
读取敏感目录   109 处     ← actually matched the phrase "design tokens"  (token ⊂ tokens)
本机指纹         2 处     ← actually matched "machine-readable"          (machine ⊂ fingerprint)
```

Both were noise. **Print matched lines with context and read them before quoting
any count to the user.** A pattern tool's hit count is a lead, not a verdict.

## Step 4 — install + meta

Copied the tree to `E:\RuanJian\Hermes\skills\creative\stylekit\`, then wrote the
`_meta.json` the repo doesn't ship:

```json
{"name": "stylekit", "version": "0.6.0", "source": "github:AnxForever/stylekit-skill",
 "installed": "2026-09-27", "license": "MIT"}
```

Verification:
- `skill_view("stylekit")` → `success: true`, `readiness_status: "available"`, `setup_needed: false`.
- Ran the main script for real (not just `--help`):
  `python scripts/fetch-style.py glassmorphism` → printed the full spec
  (colors / tokens / shadow / typography). Confirms the network path works from this host.

## Room for improvement for a future session

**Security verdict ≠ applicability verdict.** stylekit is safe to install, but its
design tokens and component recipes target **Tailwind v4 / shadcn / React**. The
user's actual target was a **hand-rolled HTML + inline-CSS + vanilla-JS dashboard**.
So the honest report had two halves:
1. 安全，可以装 (no exfiltration, no writes).
2. 但它主要面向 Tailwind/shadcn；纯 HTML 看板需要手工把 tokens 翻成 CSS 变量 — 适配性存疑。

Had this not been said, a clean audit could easily have been read as "this skill
will restyle your dashboard for you". It won't, unassisted.

## Related

- The dashboard the user wanted restyled is covered by `ecommerce/daily-report-dashboard`
  (user-owned) and `productivity/html-data-dashboard`.
- Key interaction: an externally-restyled dashboard HTML must be **ported back into the
  generator script**, or the next scheduled regeneration overwrites it. See
  `productivity/html-data-dashboard` items 12–13.
