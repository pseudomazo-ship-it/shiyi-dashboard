# CocoLoop 商店榜单采集（hub.cocoloop.cn/popular）

> 2026-10-09 实做：10 个分类 × 前 3 页 = **452 条**（去重后 393 个独立技能），注入到自建
> 技能管理台（`shiyi11.com.cn/skills/` 的「商店热门」页签）。
> 站点是公开页，**不需要登录**；不需要下载 zip，只采元数据作浏览参考。

## 何时用

- 十一发 `@url:hub.cocoloop.cn/popular` 并说「这些板块的内容采下来 / 挂到我的看板里」。
- 需要**摸市场**（哪些类别的 skill 多、热度分布、有没有值得装的）而不是装具体某一个——
  要装具体某个，走上级 SKILL.md 的安装/审计流程。

## 站点特性（先看这段，别去猜 URL）

- **SPA**：切分类靠点 tab，**URL 永远停在 `/popular`** → `goto_url('/popular?cat=office')`
  这类想法行不通，**只能点**。
- **分类 tab（10 个）**：总排行 ｜ 近期最热 ｜ 最新上传 ｜ AI 增强 ｜ 开发 ｜ 办公 ｜ 效率 ｜
  设计 ｜ 内容创作 ｜ 专业技能（`button[class*=tabItem]`，靠文字匹配）。
- **分页**：`›` 按钮（**没有 URL 参数**），底部有 `1 2 3 … 74` → **每个分类 74 页、每页 15 条**。
- 切分类**会重置到第 1 页** → 循环写成「点分类 → 采 3 次（每次采完点 `›`）」。

## 抽取 JS（真跑通过的）

```js
(()=>{
const out=[];
document.querySelectorAll('[class*=Card_card]').forEach(c=>{
  const en=(c.querySelector('[class*=titleEn]')||{}).textContent||'';
  if(!en) return;
  const cn=(c.querySelector('[class*=titleCn__]')||{}).textContent||'';
  const desc=(c.querySelector('[class*=Card_desc]')||{}).textContent||'';
  const lv=c.querySelector('[class*=BSSBadge_level]');            // 安全等级 S+/S/A/B/C/D
  const nums=Array.from(c.querySelectorAll('[class*=Card_stat]')).map(s=>{
    let txt='';
    s.childNodes.forEach(n=>{                                      // ⚠️ 必须走 childNodes
      if(n.nodeType===3) txt+=n.textContent;
      else if(n.nodeType===1 && n.tagName!=='SVG' && !n.querySelector('svg')) txt+=n.textContent; });
    return txt.trim();}).filter(x=>/[0-9]/.test(x));               // ⚠️ 用「含数字」判，别写字母表
  const a=c.tagName==='A'?c:c.querySelector('a[href]');
  out.push({en:en.trim(),cn:cn.trim(),desc:desc.trim(),grade:lv?lv.textContent.trim():'',
    installs:nums[0]||'',heat:nums[1]||'',url:a?a.getAttribute('href'):''});
});
return out})()
```

数据形状 `{en, cn, desc, grade, installs, heat, url}`，落盘时再补 `c`（分类名）。
两个数字是「安装量 / 热度」（站点自己没有标签，展示时写「安装 X ｜ 热度 Y」）。

## 四个坑（都踩过）

1. 🔴 **`stats` 的 `textContent` 会把等级字母和数字粘成一串** —— 直接 `.textContent` 得到
   `"S80k10k"`、`"A18.3k8.5k"`，**拆不开**。
   ✅ 必须**遍历 `childNodes`**：只累加文本节点 + **不含 `<svg>` 的元素**（图标路径里的数字
   不算），最后只留**含数字**的那些。
2. 🔴 **别用「字母表」过滤等级** —— 先写的是 `.filter(x=>!/^[SAB]$/.test(x))`，**漏了 D 级**
   → `grade`/`installs`/`heat` 三个字段**全部变成 `"D"`**，静默产出一整批废数据（445 条）。
   ✅ 用 `/[0-9]/.test(x)` 判「是不是数字」；等级单独从 `[class*=BSSBadge_level]` 取。
   教训：**枚举型过滤条件宁可写「保留特征」也不写「排除特征」**，漏一个值就是全表错。
3. **卡片 href 有两类**：站内 `/skills/15371` 与站外 `https://www.pixpix.art/...`。
   点击时站内要自己拼：`/^https?:/.test(u) ? u : 'https://hub.cocoloop.cn'+u`。
4. **同步等待不能省**：点分类后等 ~4s，点 `›` 后等 ~3.5s；采完按 `en` 去重（跨页会重复渲染）。
   采集循环**按分类分批跑**（一次 5 个分类 ≈ 2~3 分钟），别一口气跑 10 个，超时就得重来。

## 采到的量（下次的对照基准）

```
总排行 46 ｜ 近期最热 45 ｜ 最新上传 45 ｜ AI 增强 45 ｜ 办公 45
效率 45 ｜ 开发 45 ｜ 设计 46 ｜ 内容创作 45 ｜ 专业技能 45
合计 452 ｜ 去重 393 ｜ 等级分布 S+62 / S183 / A170 / B31 / C2 / D3 / 空1
```

（「设计」类首条是 PixPix 属正常——AI 生图本就归设计；不要以为分类没切成功。）

## 挂到自建管理台

数据块 `const shopSkills=[{c,en,cn,d,g,i,h,u}]`（字段名压短以省体积，452 条约 87 KB），
UI：来源切换 tab + 分类按钮 + 卡片网格；卡片点击 `window.open` 开原站；
搜索框在商店模式下过滤 `en+cn+d`。注入脚本 `E:\RuanJian\Hermes\cache\cocoloop_inject.py`（幂等）。

⚠️ 注入自建看板时有个关键约束：**必须用独立数据块，不能往看板自己的数据数组里塞**，
否则每轮自动同步会被覆盖。详见 `skills-catalog-sync` 技能（该技能当前需
`hermes curator adopt` 才能自动维护）。

## 给十一汇报时顺带说的两句

- **S+A 占了 90%**（183+170 / 452）→ 「等级」区分度有限，**只认 S+ 和 S 才有筛选价值**。
- 总排行前 5 里有 **3 个同质「AI 自我进化 / 记忆」类**（Self-Improving Agent、
  self-improving-agent、Self-Improving + Proactive Agent），安装量几十万到上百万
  → **安装量 ≠ 质量，同名刷榜常见**。
- ⚠️ 这批是**采集来的第三方信息，只作浏览参考**。按十一的规矩：**第三方技能默认不装**，
  要装先跑本地钟馗/源码审计（见上级 SKILL.md）。
