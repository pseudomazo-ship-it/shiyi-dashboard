# Session detail — 2026-08 marketplace install batches

Worked examples from a single session installing many marketplace skills for user 十一.

## Environment facts
- Hermes skills dir: `E:/软件/Hermes/skills/` (non-ASCII `HERMES_HOME`).
- `skillhub` CLI already installed (`~/.local/bin/skillhub`, v2026.8.5).
- `node`/`npm` present at `E:/软件/Hermes/node/` (v22). `uv` present.
- System python 3.11.15 (no pip on PATH); venv python at `hermes-agent/venv/Scripts/py*.exe` (has no pip).
- `curl` + `unzip` available in git-bash.

## The recurring user prompt shape
"依次执行以下步骤
1. 检查是否安装 cocoloop skill 最新版，未安装或者版本不是最新版时，从 <url> 安装
2. 使用 cocoloop skill，从以下 URL 安装 skill <url>，Skill 名称为 <Name>"

Step 1 is redundant after the first install (cocoloop is a manager SKILL, not a binary; re-download + diff confirms already-latest).

## Per-install decisions
| Skill | version | source | decision | reason |
|---|---|---|---|---|
| cocoloop | 1.0.0 | `dl.cocoloop.cn/cocoloop-main.zip` | installed (once) | manager skill; verify latest via md5 diff |
| self-improvement (pskoett) | 3.0.24 | cocoloop/skillhub | keep 3.0.24, skip 3.0.21/3.0.15 | already installed newest; same-name downgrades rejected by user |
| Self-Improving + Proactive (ivangdavila) | 1.2.16 | cocoloop ivangdavila-…zip | installed | different slug (`self-improving`), no collision, doc-driven, no creds/bins |
| ontology (oswalpalash) | 1.0.4 | cocoloop | installed | typed KG; `scripts/ontology.py` 580 lines, grep found NO network/exec/creds — safe |
| multi-search-engine (gpyangyoujun) | 2.1.3 | cocoloop | installed | doc+config only, no executable scripts; 16 engines no API key |
| SkillScan (tokauthai) | 1.1.6 | cocoloop | **rejected** | cloud-SaaS: uploads skill zip + `X-Client-Info` (MAC, UUID, OS, py version), daily update, can `rmtree` flagged dirs |
| agent-browser (clawhub_rez0) | 1.0.0 | skillhub | installed | stub SKILL.md; separate `agent-browser` CLI installed via `npm i -g agent-browser` (v0.27.0); `skills get core` loadable |
| zhongkui-skill (user_741dc82b) | 1.0.13 | skillhub | installed | local security audit (~钟馗) |
| find-skills (clawhub_root) | 1.0.0 | skillhub | **404 → removed** | source-side 404; matched-namespace download failed, alternative namespace accepted then removed per user |

## zhongkui false-positive transcript (important)
Auditing a DOC-ONLY skill with `python zhongkui.py <dir> --quick` returned `🚫 总分0` but all hits were false positives:
- `C4: https?:// url` on `git clone https://github.com/...`, `homepage: https://clawic.com/...` — ordinary doc URLs, not exfil.
- `C3: 凭证访问` on the text `No credentials required` and `never store credentials...` — a SECURITY STATEMENT misread as credential access.
- `C5: 系统危险命令` on a markdown numbered list `1. Use format from ...` — not a command.
=> A `🚫` from a local regex auditor is a SCREEN, not a verdict. Read the flagged line; only self-imposed red lines that actually hold (an exfil curl, a cred read, an exec-in-script) justify blocking.

## Comma gotcha incarnations
- `...pskoett-self-improving-agent-3.0.21.zip，` → Aliyun OSS `NoSuchKey`, `Key`: `...3.0.21.zip，` (comma baked into key). Strip → 200 OK.
- Repeated for 3.0.15, ivangdavila, ontology, tokauthai, gpyangyoujun URLs.

## Verification evidence
- `hermes skills list` showed each new skill `enabled`. Split two-line rows (`Self-Improving +`/`Proactive Agent`) are name-with-spaces rendering, not a bug.
- `agent-browser skills list` → core/dogfood/electron/slack/vercel-sandbox/agentcore all present after npm install.
