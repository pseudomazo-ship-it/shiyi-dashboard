# Agent-browser / self-improving batch (2026-09): the name-collision case

## Batch from the user ("依次执行以下步骤: 1. 检查 cocoloop 2. 从 URL 装 <skill>")
Full agenda across repeated runs this session: desktop-control (installed), agent-overflow (REJECTED),
agent-browser (SKIP — already installed), self-improving-agent 3.0.21 (SKIP — installed 3.0.24 is newer).

## NEW gotcha: Hermes "Ambiguous skill name" collision
Two skill dirs both shipping the same `name:` value make Hermes refuse to load either:

```
skill_view(name="agent-browser")
→ Error: Ambiguous skill name 'agent-browser': 2 skills match across your local skills
  dir and external_dirs. Refusing to guess — load one explicitly by its categorized path.
  matches: [".../skills/agent-browser/SKILL.md", ".../skills/@clawhub_rez0/agent-browser/SKILL.md"]
```

This happened because the cocoloop zip (`agent-browser-clawdbot`, slug `agent-browser`) was downloaded
and copied to a top-level `skills/agent-browser/`, while the user ALREADY had
`skills/@clawhub_rez0/agent-browser/`. Two dirs, same `name: agent-browser`. Hermes refuses to guess;
the skill is unusable until one copy is removed.

### How to resolve it — decide by Hermes-fitness, not just by "newest"
`skill_view(name)` ambiguity is the signal to STOP and compare before installing a second copy.
- `skill_view(name)` on each candidate (or read both SKILL.md frontmatter + body).
- Compare what each offers, not just its version number:
  - The @clawhub_rez0 variant had `allowed-tools: Bash(agent-browser:*), Bash(npx agent-browser:*)`
    (narrows the tool surface), `hidden: true`, and a **discovery stub** that dynamically loads
    `agent-browser skills get core` so instructions always match the installed CLI version.
  - The cocoloop variant was the full static command manual inlined into SKILL.md (no `allowed-tools`,
    no `hidden`), i.e. more prose, less Hermes-integrated.
- For THIS user the clawhub variant is the right one to keep: it is Hermes-fitted (toolsets + hidden)
  and version-driven. **Delete the freshly-copied duplicate** (`rm -rf skills/agent-browser`), keep the
  @clawhub_rez0 one, re-confirm with `skill_view(name)` that ambiguity is gone.

Newer != better. An incoming zip that is "more complete" (full manual) can still be the WRONG choice
when the installed copy is a Hermes-integrated stub with tool gating. State the comparison to the user
and delete the duplicate rather than leaving two copies that break loading.

## Skip cases (do not re-install)
- **agent-browser**: already installed (`agent-browser 0.27.0` CLI present, node v22, npm 10.9.8).
  CLI exists at `/e/软件/Hermes/node/agent-browser`. No install action needed.
- **self-improving-agent**: installed `@clawhub_pskoett/self-improving-agent` `_meta.json` version is
  **3.0.24**; the incoming cocoloop `pskoett-self-improving-agent-3.0.21.zip` is **3.0.21** = older.
  Kept 3.0.24. Same-skill cross-version = surface the comparison, don't downgrade.
  (Contrast with the earlier 3.0.24/3.0.21/3.0.15 sequence — always report installed-vs-incoming.)

## Reminder that held
Use `curl -sIL` (not the @url preview card / web_extract) to confirm the zip is actually downloadable,
and strip a trailing full-width `，` from pasted URLs before concluding 404.
