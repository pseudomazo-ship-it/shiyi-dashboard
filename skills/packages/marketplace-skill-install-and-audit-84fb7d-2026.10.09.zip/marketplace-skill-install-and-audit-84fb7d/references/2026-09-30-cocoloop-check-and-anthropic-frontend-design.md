# 2026-09-30 — cocoloop already-latest check + Anthropic Frontend Design 1.1.0

User's batch (the recurring shape):

> 1. 检查是否安装 cocoloop skill 最新版，未安装或不是最新时从 https://dl.cocoloop.cn/cocoloop-main.zip 安装
> 2. 使用 cocoloop skill，从 https://dl.cocoloop.cn/bss/skills/qrucio-anthropic-frontend-design-1.1.0.zip 安装 skill（名称 Anthropic Frontend Design）

Both `@url` cards rendered as "no content extracted" (CDN vs page-render layer) —
`curl -sSL` fetched both fine (HTTP 200 / 20519 B / 320502 B). Don't trust the card.

## Step 1 — cocoloop was already the latest

- Installed copy: `E:\RuanJian\Hermes\skills\cocoloop\` (SKILL.md 7293 B,
  README 3251 B, 5 × `references/*.md`).
- No version field anywhere (no `_meta.json`, SKILL.md frontmatter only has
  `name:` + `description:`) ⇒ **version comparison impossible; compare bytes.**
- Downloaded `cocoloop-main.zip`, unzipped to temp, md5'd all 7 files against the
  installed copy: **7/7 SAME** (identical sizes too) ⇒ already latest.
  `_meta.json` was absent — note the zip's only "version-ish" clue was the banner
  line `f5edaa1604fe123d0dc68df3038c8aaa1259cceb` unzip prints (an OSS object
  hash, NOT a semver — do not report it as a version).
- Action: **no install performed.** Report 「已是最新，无需重装」+ the comparison
  evidence. Rewriting identical files would have been a pointless write.

## Step 2 — Anthropic Frontend Design 1.1.0 installed

- `_meta.json`: `{ownerId: kn77ac0v1p7kd2dnez1431cyrh80dx71, slug: anthropic-frontend-design, version: 1.1.0, publishedAt: 1770341440625}`
- Installed to `skills/creative/anthropic-frontend-design/` (category `creative`
  already holds the sibling design skills: `claude-design`, `sketch`,
  `popular-web-designs`, `stylekit`).
- Verified **not** already present first: nothing matching *frontend*/*ui-ux*/
  *anthropic* anywhere under `skills/` or `profiles/`, and `hermes skills list`
  had no hit.
- Payload: `SKILL.md` (4539 B) + `scripts/{core,search,design_system,__init__}.py`
  + 2 × 24 CSVs (`assets/data/` **and** root `data/`) = 54 files, 1.1 MB total
  (549 KB after the accidental prune — see trap below).

### Trap: pruning the "duplicate" data dir broke every script

The zip ships the 24 CSVs twice — root `data/` and `assets/data/`, byte-identical.
I pruned root `data/` as redundant. Wrong: `scripts/core.py:14` reads

```python
DATA_DIR = Path(__file__).parent.parent / "data"   # → <skill root>/data
```

so search.py/design_system.py all work off the ROOT `data/`, and only
`assets/data/` existing would leave every query returning 0 results.
Fixed by `cp -r "$SRC/data" "$DST/data"` from the still-present temp extract dir.

**Rule:** grep the scripts for their data path before removing anything from a
freshly-unzipped skill. Keeping both copies is cheap (1.1 MB) — prefer keeping.

### Script smoke test (stdlib only, no deps needed)

Imports are `argparse/csv/json/os/re/c/datetime/pathlib/math/collections` ⇒ no
pip step, no `--break-system-packages` dance.

```bash
cd skills/creative/anthropic-frontend-design/scripts
python search.py "saas dashboard analytics" --domain color --max-results 2
python search.py "hair care dye ecommerce landing" --design-system -p "TestProj"
```
Both returned real content (palette rows `#1E40AF/#3B82F6/#F59E0B`; full design
system box with PATTERN/STYLE/COLORS). `--design-system --persist` writes
`design-system/<project>/MASTER.md` into CWD — that's the only write behavior.

### Audit result (local, nothing uploaded)

0 × `eval/exec/subprocess/os.system`, 0 × network calls, 0 × rmtree. Only reads
CSV + `open(...,'w')` for the optional persist. Source is T3 (individual
publisher `qrucio`) but the code is a pure local BM25 lookup + template writer
⇒ low risk, installed. Same shape as the earlier `matagul-desktop-control` call.

### Frontmatter touch

Zip shipped `name:` + `description:` but no `version:` (Hermes loads it either
way). Added `version: 1.1.0` from `_meta.json`; `skill_view` + `hermes skills
list` both then showed `enabled` (row rendered as `anthropic-frontend-…` —
column truncation, not a problem).

## Reporting shape the user got

Table: 版本 / 安装位置 / `hermes skills list` 状态 / 内容构成 / 脚本实测结果, then
安全自检 (✅ 无网络无上传 · ⚠️ 唯一写文件行为 · ⚠️ T3 来源但代码纯本地), then the
one gotcha fixed. Conclusion first, short. Source-of-truth label per line
(`_meta.json` vs my inference).
