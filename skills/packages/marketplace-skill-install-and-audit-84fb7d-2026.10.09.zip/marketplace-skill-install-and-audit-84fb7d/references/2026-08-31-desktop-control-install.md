# Session detail — 2026-08-31 Desktop Control install

Installed `desktop-control` (matagul-desktop-control-1.0.0) via cocoloop zip URL for user 十一.

## What happened
- Step 1 "check cocoloop latest" → already installed, re-downloaded zip, diffed `SKILL.md` name/description → identical, no version field → **already latest, skip reinstall**. (Confirms: cocoloop is a manager SKILL, re-download + diff is the version check; no binary to update.)
- Step 2 install `https://dl.cocoloop.cn/bss/skills/matagul-desktop-control-1.0.0.zip`.
  - Zip payload (7 files): `SKILL.md`, `_meta.json`, `__init__.py`, `ai_agent.py`, `demo.py`, `AI_AGENT_GUIDE.md`, `QUICK_REFERENCE.md`.
  - `_meta.json`: `{ownerId, slug: "desktop-control", version: "1.0.0", publishedAt}`.
  - **`SKILL.md` frontmatter had ONLY `description:` — no `name:`/`version:`.** Hermes won't load it without `name`. Patched frontmatter to add `name: desktop-control` + `version: 1.0.0` (and broadened the description trigger). Then `skills_list` showed it.
- Audit: grep over `__init__.py`/`ai_agent.py`/`demo.py` for `requests|urllib|httpx|socket|subprocess|eval(|exec(|os.system|http|upload|crypt|ssh|token|webhook` → **only `import base64`** (local image encoding). No network exfil, no remote exec, no creds. = clean local desktop-automation skill. Installed.
- Dependencies: `pip install pyautogui pillow opencv-python pygetwindow`. None on PATH python; installed into the **hermes venv** via `uv pip install --python E:/软件/Hermes/hermes-agent/venv/Scripts/python.exe pyautogui pillow opencv-python pygetwindow` (the venv python = the one Hermes uses).
- Verified: venv python imports `pyautogui 0.9.54 / cv2 5.0.0 / pygetwindow / PIL`; `skills_list` returned `desktop-control`; `skill_view` loaded it.

## Small gotchas worth carrying
- `skills_list(category="desktop-control")` returned **empty** because the skill has no `category` field. Must scan the full `skills_list` (no category) or `skill_view(name)`.
- The skill is "built for OpenClaw" but nothing prevents loading it in Hermes; doc-only API references to OpenClaw are harmless. It carries pyautogui failsafe (mouse-to-corner abort) + approval mode — respect user's rule: no captcha bypass; surface approval before its actions touch the desktop.
