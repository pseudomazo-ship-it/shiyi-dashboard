# 拼多多评价得分目标计算（会话验证过，纯 Python 无依赖）
# 用法: 修改 DIST 和 TARGET 后直接运行

DIST = {1: 5, 2: 1, 3: 20, 4: 40, 5: 189}   # 星级: 条数
TARGET = 4.75

stars = sorted(DIST)
total = sum(DIST.values())
weighted = sum(k * v for k, v in DIST.items())
avg = weighted / total
print(f"现状: {total} 条, 加权和={weighted}, 平均分={avg:.4f}, 目标={TARGET}")

# A) 纯新增 5 星
x = 0
while (weighted + 5 * x) / (total + x) < TARGET:
    x += 1
print(f"\n[A 纯新增] +{x} 条真实5星 -> {(weighted + 5 * x) / (total + x):.4f} (共{total + x}条)")
print(f"   评价率20% -> 约需 {x / 0.2:.0f} 单")

# B) 只改低分为5星（最少条数，贪心从低到高）
w, changed = weighted, []
for s in [k for k in stars if k < 5]:
    for _ in range(DIST[s]):
        w += (5 - s)
        changed.append(s)
        if w / total >= TARGET:
            break
    if w / total >= TARGET:
        break
from collections import Counter
cc = Counter(changed)
print(f"\n[B 只改低分] 改{len(changed)}条(明细{dict(cc)}) -> {w / total:.4f} (总条数不变)")

# C) 组合: 先改1星+2星再补新增
w2 = weighted + (5 - 1) * DIST.get(1, 0) + (5 - 2) * DIST.get(2, 0)
x2 = 0
while (w2 + 5 * x2) / (total + x2) < TARGET:
    x2 += 1
print(f"\n[C 组合] 先改{DIST.get(1, 0) + DIST.get(2, 0)}条(1星+2星)->{w2 / total:.4f} + {x2}条新增 -> {(w2 + 5 * x2) / (total + x2):.4f}")

# 提醒: 平台显示分(剔除不真实评价)可能 ≠ 算出的平均分, 黑盒时不要硬算, 用趋势监控
