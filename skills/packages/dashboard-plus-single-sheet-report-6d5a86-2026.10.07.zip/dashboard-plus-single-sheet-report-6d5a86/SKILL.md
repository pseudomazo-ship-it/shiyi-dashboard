---
name: dashboard-plus-single-sheet-report
description: Use when 要「看板+表格文件」双交付（HTML看板 + 单工作表Excel）。同源计算，两边数字不可能不一致。
metadata:
  hermes:
    tags: [dashboard, excel, report, single-sheet, 看板, 报表]
    category: productivity
---

# 看板 + 单页报表 双交付

十一常见需求：「用看板的形式展示…」＋「再生成一个表格文件，所有数据在一个页面内」。
本技能覆盖**从零构建**这对成品（与 `html-data-dashboard` 不同，后者是给已有看板换数据）。

## 铁律：计算一次，多处渲染

**绝不要让 HTML 和 Excel 各自算一遗。** 正确做法：

```
build_dashboard.py
  ├─ 读原始数据 → 算出全部指标
  ├─ 写 看板.html
  └─ json.dump(全部中间结果) → 脚本/_computed.json    ← 唯一真相

build_one_sheet_xlsx.py
  └─ 只读 _computed.json → 写 报表.xlsx              ← 不重算
```

好处：改口径只需改一处；十一问「两边怎么不一样」这种情况根本不会发生。
验证时也只需核一份数。

## HTML 看板约定（十一偏好）

- 深色 `#0f1117`；卡片区 `#161a22` + 边框 `#232a36`；区块间用 `border-top` 分隔
- 大 KPI 卡 + 横向条形图 + 堆叠条 + 彩色 pill 表；不用外部 JS/CSS（高线离线可用）
- **逐项分开**：说「1.2.3.4.5星作区分」就每个星级一张独立卡（条数·占·该维度率·人群构成·月度mini柱图·口径备注），不要揉成一张总表
- **不含金额字段**（评价/人群类看板）：只留单量·件数·人数·评价·占比·比率
- 估算/补录值单独标（灰/淡色 + “估算”字样），不写进实测叙述
- 每个板块开头用 `<div class="secnote">` 写清口径与分母

## 单页 Excel 约定

- **单工作表**（「所有数据在一个页面内」＝不切 tab，板块纵向排开）
- 帮助函数结构：`title() / section() / head() / row(vals, fmts, est) / blank()`
- **冻结首行、横向、fitToWidth=1、无网格线**（可打印在一页）
- **配色约定：蓝色字＝非计算来源（估算/补录/平台提供）；黑色＝计算所得**（延续「蓝=输入黑=公式」）
- 末段必写「口径说明与数据来源」多行（估算项、补录项、两套口径不可相减等）
- 常用数字格式：`N='#,##0'`、`P2='0.00%'`、`P1='0.0%'`、`D4='0.0000'`、
  `PD='+0.0000;-0.0000;0.0000'`（带符号差值）、`MUL='0.00"×"'`（倍差）
- 骨架见 `scripts/single_sheet_xlsx.py`

## 必踩的坑

### 1. 汇总必须「加权」，不能简单平均 ⭐
月度指标 → 整体指标时，若各月量差很多（本例月评价量 2,670~8,985，差 3.4 倍）
简单平均会错。实测：简单平均 **4.7416** vs 正确加权 **4.7273**。
```python
T = sum(EV[i] * X[i] for i in range(n)) / sum(EV)   # ✅
T = sum(X) / n                                       # ❌
```

### 2. 用自洽公式替代外部文件，并加断言
均分写成 `Σ(星级×条数) ÷ 评价数`，它就与页面上展示的星级表**严格自洽**；
再加一行断言与历史文件对比（口径不同的月份 pass）：
```python
assert abs(calc[i] - hist[i][4]) < 1e-3
```
—— 以后改任何一格星级，全表自动联动，不会出现“改了 A 忘了 B”。

### 3. Python 里的 `%%` 陷阱
用 `'...25%%...' % var` 正常（→`25%`），但**无 `%` 运算的字符串里 `%%` 会原样输出**。
最安全的写法：写 HTML 时统一 `'\n'.join(H).replace('%%', '%')`。
交付前 grep 一次：`%% / NaN / undefined / %s`。

### 4. Excel 被占用 → 先写临时文件
十一常一边看一边让你改。`~$xxx.xlsx` 锁文件存在时写入报
`PermissionError: [Errno 13]` 或 `Device or resource busy`。
解法：生成脚本支持 `sys.argv[1]` 覆盖输出路径 → 先写 `$LOCALAPPDATA/Temp/pending.xlsx`，
再 `cp -f` 覆盖；仍失败就请用户关 Excel，**不要另存新名字**（会产生两个版本）。

### 5. openpyxl 不在默认 Python 里
```bash
uv run --quiet --with openpyxl python build_one_sheet_xlsx.py
```
（`pip` 不存在；`execute_code` 沙箱也没 openpyxl，写 xlsx 一律走 terminal + uv）

### 6. 交付前自检（十一硬性要求）
读回成品校验，不只看脚本退出码：
- HTML：`grep -c` 关键值（总数、比率、各板块标题）、残留 `%%`/`NaN`/`undefined`
- Excel：`load_workbook` 数工作表数、行数、`number_format`、冻结/打印设置
- 列表里把「通过项」和「发现的问题」一起发出；发现的旧错误（如上面第1条）也要点名更正

## 常见报错

| 报错 | 原因 |
|---|---|
| `IndentationError: unexpected indent` | 往多行字符串拼接的 `A('...'` 行尾多写了 `)` |
| `IndexError: list index out of range` | 读 JSON 行时下标猜错（数一下 len） |
| 数字对但显示成 `1` | 纯显示层：断言按数值写，展示按 fraction |
