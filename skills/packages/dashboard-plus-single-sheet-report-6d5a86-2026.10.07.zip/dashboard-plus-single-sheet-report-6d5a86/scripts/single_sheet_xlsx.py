# -*- coding: utf-8 -*-
"""单工作表 Excel 报表骨架（所有板块纵向排在一个 sheet 内）

用法：
    uv run --quiet --with openpyxl python single_sheet_xlsx.py [输出路径.xlsx]

设计要次：
- 只读上游导出的 _computed.json，不重算（保证与 HTML 看板数字同源）
- 蓝字＝非计算来源（估算/补录/平台提供）；黑字＝计算所得
- 冻结首行 + 横向 + fitToWidth=1 → 可打印在一页
"""
import json, os, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ===== 配置 =====
BASE = r"<项目目录>"
DATA = os.path.join(BASE, '脚本', '_computed.json')
OUT = os.path.join(BASE, '<报表名>_<YYYY.MM.DD>.xlsx')
if len(sys.argv) > 1:            # 绕过 Excel 占用：先写临时文件再替换
    OUT = sys.argv[1]
NCOLS = 14

D = json.load(open(DATA, encoding='utf-8'))

# ===== 样式 =====
F_TITLE = Font(name='微软雅黑', size=14, bold=True, color='FFFFFF')
F_SEC = Font(name='微软雅黑', size=11, bold=True, color='FFFFFF')
F_HEAD = Font(name='微软雅黑', size=10, bold=True, color='1F2937')
F_TXT = Font(name='微软雅黑', size=10, color='000000')
F_EST = Font(name='微软雅黑', size=10, color='2F5597')          # 蓝＝非计算来源
F_SUM = Font(name='微软雅黑', size=10, bold=True, color='000000')
F_NOTE = Font(name='微软雅黑', size=9, color='7F7F7F')
FILL_TITLE = PatternFill('solid', fgColor='0F1117')
FILL_SEC = PatternFill('solid', fgColor='2F5597')
FILL_HEAD = PatternFill('solid', fgColor='DCE6F1')
FILL_SUM = PatternFill('solid', fgColor='FFF2CC')
FILL_EST = PatternFill('solid', fgColor='F2F7FF')
THIN = Side(style='thin', color='BFBFBF')
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ===== 数字格式 =====
N, P2, P1 = '#,##0', '0.00%', '0.0%'
D4 = '0.0000'
PD = '+0.0000;-0.0000;0.0000'   # 带符号差值
MUL = '0.00"×"'                 # 倍差

wb = Workbook()
ws = wb.active
ws.title = '全部数据'          # ← 单工作表
r = 1


def title(text, sub=''):
    global r
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, text); c.font = F_TITLE; c.fill = FILL_TITLE
    c.alignment = Alignment('center', 'center'); ws.row_dimensions[r].height = 26; r += 1
    if sub:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
        c = ws.cell(r, 1, sub); c.font = F_NOTE; c.alignment = Alignment('left', 'center'); r += 1


def section(text):
    global r
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, text); c.font = F_SEC; c.fill = FILL_SEC
    c.alignment = Alignment('left', 'center'); ws.row_dimensions[r].height = 20; r += 1


def head(cols):
    global r
    for i, h in enumerate(cols, 1):
        c = ws.cell(r, i, h); c.font = F_HEAD; c.fill = FILL_HEAD
        c.alignment = Alignment('center', 'center'); c.border = BOX
    r += 1


def row(vals, fmts=None, est=None, summary=False):
    """est: 需要标蓝的列号集合（估算/补录值）"""
    global r
    est = est or set(); fmts = fmts or []
    for i, v in enumerate(vals, 1):
        c = ws.cell(r, i, v); c.border = BOX
        c.alignment = Alignment('left' if i == 1 else 'center', 'center')
        if fmts and i <= len(fmts) and fmts[i - 1]:
            c.number_format = fmts[i - 1]
        if summary:
            c.font = F_SUM; c.fill = FILL_SUM
        elif i in est:
            c.font = F_EST; c.fill = FILL_EST
        else:
            c.font = F_TXT
    r += 1


def blank(h=6):
    global r
    ws.row_dimensions[r].height = h; r += 1


# ===== 正文（示例：按实际改成自己需要的板块） =====
title('<报表标题>', '数据来源：…    口径：…    生成：Hermes <日期>')

blank(); section('【一】总览')
head(['指标', '数值', '说明'])
row(['总条数', D['T'], '含义说明', N] if False else ['总条数', D['T'], '含义说明'], [None, N, None])

blank(); section('【七】口径说明与数据来源')
for t in ['1. 数据来源…', '2. 估算/补录口径…', '3. 蓝色字＝非计算来源；黑色字＝计算所得']:
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=NCOLS)
    c = ws.cell(r, 1, t); c.font = F_NOTE; c.alignment = Alignment('left', 'center'); r += 1

# ===== 列宽 / 冻结 / 打印 =====
for i, w in enumerate([22, 12, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 14, 14][:NCOLS], 1):
    ws.column_dimensions[get_column_letter(i)].width = w
ws.freeze_panes = 'A2'
ws.sheet_view.showGridLines = False
ws.page_setup.orientation = 'landscape'
ws.page_setup.fitToWidth = 1
ws.page_setup.fitToHeight = 0
ws.sheet_properties.pageSetUpPr.fitToPage = True
ws.print_options.horizontalCentered = True

wb.save(OUT)
print('已生成:', OUT, os.path.getsize(OUT), '字节 | 单工作表:', wb.sheetnames, '| 总行数:', r - 1)
