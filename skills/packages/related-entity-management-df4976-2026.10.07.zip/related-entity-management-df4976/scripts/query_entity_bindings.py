# -*- coding: utf-8 -*-
"""主体绑定店铺查询 —— 判断指定主体「现在」还绑着哪些店铺。

口径（十一 2026-09-15 确认）：
  「当前（新/旧）承接店铺」列 —— '旧主体' = 已解绑；'新主体' = 仍在绑定。
  同一店铺会同时出现在旧承接主体和新承接主体两行下，判断「还剩几个店」只能数「新主体」行。

用法：
  uv run --with openpyxl python query_entity_bindings.py                       # 全部主体
  uv run --with openpyxl python query_entity_bindings.py 徐州市戈丂商贸有限公司
  uv run --with openpyxl python query_entity_bindings.py --file 主体名单.txt
  uv run --with openpyxl python query_entity_bindings.py --xlsx <绑定表路径> ...
"""
import sys
import os
import io
from collections import defaultdict

import openpyxl

DEFAULT_XLSX = (
    r"D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\Hermes Agent"
    r"\公司🔴主体财务仓库快递\主体财务看板-boss\主体绑定店铺情况【模版】.xlsx.xlsx"
)


def load_rows(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    ws = wb[wb.sheetnames[0]]
    return [r for r in ws.iter_rows(min_row=2, values_only=True) if r[2]]


def main(argv):
    path = DEFAULT_XLSX
    names = []
    files = []
    i = 0
    while i < len(argv):
        if argv[i] == '--xlsx' and i + 1 < len(argv):
            i += 1
            path = argv[i]
        elif argv[i] == '--file' and i + 1 < len(argv):
            i += 1
            files.append(argv[i])
        else:
            names.append(argv[i])
        i += 1

    for f in files:
        with io.open(f, encoding='utf-8') as fh:
            names += [l.strip() for l in fh if l.strip()]

    if not os.path.exists(path):
        print('找不到绑定表：%s' % path)
        return 1

    rows = load_rows(path)
    all_zhu = []
    for r in rows:
        if r[2] not in all_zhu:
            all_zhu.append(r[2])

    uniq = []
    for n in names:
        if n and n not in uniq:
            uniq.append(n)
    targets = uniq if uniq else all_zhu

    bound = defaultdict(list)
    freed = defaultdict(int)
    for r in rows:
        z = r[2]
        if z not in targets:
            continue
        if '旧' in str(r[3]):
            freed[z] += 1
        else:
            bound[z].append((r[0], r[1]))

    still = [z for z in targets if bound.get(z)]
    clean = [z for z in targets if not bound.get(z)]

    print('表内主体总数: %d ; 本次核查 %d 家' % (len(all_zhu), len(targets)))
    if uniq and len(uniq) != len(names):
        print('（名单去重：原 %d 条 → %d 家）' % (len(names), len(uniq)))
    print()
    print('=== 仍绑定店铺 %d 家（动之前必须先迁店）===' % len(still))
    for z in still:
        print('【%s】%d 个:' % (z, len(bound[z])))
        for p, s in bound[z]:
            print('     %s | %s' % (p, s))
    print()
    print('=== 已完全解绑 %d 家（名下无店铺）===' % len(clean))
    for z in clean:
        print('   %s （已解绑记录 %d 条）' % (z, freed.get(z, 0)))
    print()
    print('⚠️ 内部记录表 ≠ 平台后台真实绑定状态；注销前须去各平台后台核对主体信息。')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
