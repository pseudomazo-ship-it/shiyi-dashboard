---
name: web-form-batch-submit
description: "Use when 要在网页表单上批量填表并逐条提交（WPS/金山表单、问卷、后台录入）。含控件填报术+逐条验证。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [web-form, batch, kdocs, wps, antd, browser-automation, verification, shiyi]
---

# 网页表单批量填写 + 逐条提交

十一常给一份**表格**（N 家公司 / N 条记录）+ 一个**网页表单地址**，要求「按这个顺序，每家填完提交，再填下一个」。
本技能覆盖这类任务的完整做法：**先核数据 → 摸控件 → 跑通第 1 条 → 批量 → 三重验证 → 完整回报**。

## When to use
- 十一说「填写两个数据 / 提交完之后再次填写下一个」+ 给一份清单或表格。
- 要把 Excel 里的 N 行搬进网页表单（涉税报送、问卷、后台录入、报名表）。
- **每提交一条表单就重置一次**的表单（WPS 金山表单的典型形态）。

不在本技能范围：从网页**取**数据出表 → 用 `web-console-data-harvest` / `console-api-harvest`。

## 🔴 先立三条边界（动手前想清楚，事后补救贵）

1. **「提交」是不可逆动作，但十一说「填完提交、再填下一个」就是明确授权。**
   不要拆成 22 轮反问「可以提交吗」——那是他没要的。**一次性跑完，一次性回报。**
   ⚠️ 但**不要顺手扩大范围**：他没让填的题就空着。
2. **敏感字段（身份证号 / 手机号 / 银行卡 / 验证码）默认不读、不填**，除非他单独点名。
   本次表单第 4 题要身份证号 → 全程一个字没碰，只在回报里声明。
3. **提交完要告诉他「能不能改」**。很多表单提交后不可修改（本次确认框原文「提交后不可修改，确定提交？」），
   补救入口是记录列表里的「**撤回答卷**」——主动说一句「要撤回哪家跟我说」，比事后被问强。

## 标准流程（照着走）

### 第 0 步：把数据在本地算完，不要边填边算
读源文件 → 在 Python 里把每条要填的值算成最终字符串 → 形成一个 `DATA = [(键, 值), ...]` 列表。
**顺序必须与十一给的清单一致**（他会核顺序）。
```python
import openpyxl
wb = openpyxl.load_workbook(SRC, data_only=False)
ws = wb.active
for r in range(first_data_row, ws.max_row+1):
    print(ws.cell(r,1).value, ws.cell(r,3).value, ws.cell(r,4).value)
```
⚠️ `.xlsx` 里**公式列用 `data_only=False` 读出来是 `=C5*0.955` 字符串**，不是值 → 派生值自己用 Python 算，别指望读出来。

### 第 1 步：摸控件（不要凭猜）
`browser_exec` 打开表单，先 dump 可交互元素：
```python
js("""(() => {
  var out = {url: location.href, title: document.title};
  out.inputs = Array.from(document.querySelectorAll('textarea, input')).map(function(e,i){
    return {i:i, tag:e.tagName, cls:e.className.slice(0,80), ph:e.placeholder||'', vis:e.offsetParent!==null};
  });
  out.buttons = Array.from(document.querySelectorAll('button')).map(function(b){
    return (b.innerText||'').replace(/\\s/g,'');
  });
  return JSON.stringify(out);
})()""")
```
要点：**题号与控件是位置对应的**（本次 4 道题 = 4 个 `textarea.ant-input`，index 0/1/2/3）。
⚠️ **按可见的 `textarea` 数对齐题号，不要按 DOM 里全部 input 数**（页头搜索框之类会混进来）。

### 第 2 步：跑通第 1 条（填 → 提交 → 看结果），成功才批量
**这一步不能省。** 表单千奇百怪（二次确认、滑块验证、提交后要扫码），跑通一条再跑 21 条。

### 第 3 步：批量循环
每条的完整动作链：
```
[若在成功页] 点「再填一份」 → 等一下
[若有弹窗]   关掉（「暂不」/「跳过」）
填入各题 → 读回确认 → 点「提交」 → 点「确认」→ 验证成功页
```

### 第 4 步：三重验证（缺一不可）
见下「验证」一节。

### 第 5 步：回报（见下「回报格式」）

## 控件填报术

### React / antd 受控输入：直接 `e.value = x` **无效**
框架的 value 追踪在 fiber 上，赋值后必须**用原生 setter + 派发事件**才会被框架登记：
```js
function setVal(el, val) {
  var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype
                                        : window.HTMLInputElement.prototype;
  var setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  setter.call(el, val);                                     // ← 关键：原生 setter
  el.dispatchEvent(new Event('input',  {bubbles:true}));
  el.dispatchEvent(new Event('change', {bubbles:true}));
  el.dispatchEvent(new Event('blur',   {bubbles:true}));
}
```
**填完立刻读回 `el.value` 确认**——读回对不上就别点提交。

### 点按钮：按 `innerText` 归一化匹配，别用 nth-child
```js
var b = Array.from(document.querySelectorAll('button'))
          .filter(x => (x.innerText||'').replace(/\s/g,'') === '提交')[0];
```
⚠️ 中文按钮的 innerText 常带空格（`提 交` / `确 认`）→ **必须先 `.replace(/\s/g,'')` 再比**。

### 二次确认弹窗：提交后必弹，要再点一次
`提 交` → 弹窗「**提交后不可修改，确定提交？**」→ `确 认` → 才真正落库。
**只点一次「提交」会以为成功了、实际什么都没提交。**

### 数值格式
**纯数字、不带千分位**（`2177846.54` 不是 `2,177,846.54`）。表单文案常写「数据请精确到小数点」= 2 位小数。

## 验证（三层，全都要做）

| 层 | 做法 | 能证明什么 |
|---|---|---|
| ① 逐条成功页 | 每次提交后断 URL 变 `write-success`、正文含「提交成功」 | 单条落库 |
| ② 计数精确递增 | 记录提交前后的「**已提交 N 份**」/「此表单你已填过 N 次」 | **提交次数 == 清单条数**，不多不少 |
| ③ 读回一条 | 用「**修改答卷**」打开最新一条，读 textarea 的值 | 值真的写进去了、字段没串位 |

**②是最硬的证据**：本次 28 → 50（**正好 +22**），中途每家的成功页计数逐一递增（29,30,…,50）。
把每次的 `{序号, 公司名, 计数, URL}` 打出来留痕，回报时能引用。

**③选最新一条**：调用链是 记录列表 → 点「修改答卷」→ 表单带值加载 → 读 `textarea.value`。
⚠️ **这是编辑态，读完值直接停手，别在它上面点提交**（会把那条改成一条新提交）。

### 🔴 别在「填写记录」列表页找字段值——找不到
本次在列表页翻了几轮：`50/50` 有了、列表项全渲染成「**提交中**」、**HTML 里搜不到任何一家公司名**（`22` 家只搜到 `1` 家，还是因为它在别处出现）。
列表是**懒加载 + 虚拟滚动**，且**卡片折叠态不渲染字段值**。
→ **这不是提交失败**，别据此怀疑、别重试、别重复提交。**换「修改答卷」读回**（第 ③ 层）。
这条坑值一次 5 分钟，写下来免得下次再翻。

## WPS / 金山表单（kdocs ksform）具体特征

现场细节（URL、题号映射、本次 22 家明细）见 **`references/wps-kdocs-form.md`**。要点：

- 地址形态：`https://f.kdocs.cn/ksform/w/write/<FORM_ID>`；**公开填写，无需登录**。
- 题目就是 `.ant-input` 的 textarea，**顺序 == 题号**。
- 成功页：`.../write-success`，带 `answerId`、可点「**再填一份**」。
- 记录列表：`.../write-list/<FORM_ID>`，顶部 `N/N`。
- **「复用上份记录快速填写」弹窗**会在开新一份时冒出来 → 点「**暂不**」，否则它可能套用上一条的答案。

## 回报格式（十一认可的形态）

1. **结论前置**：`✅ N 家全部提交完成`。
2. **验证证据**（三重，尤其「计数正好 +N」这句）。
3. **完整明细表**：`序号 | 键(公司名) | 填入值` —— **22 家就列 22 行，不许用「等」「其余同上」省略**。
4. **边界声明**：哪些题没碰（敏感字段）、提交是哪个浏览器实例做的。
5. **补救入口**：提交后不可修改 → 要改就用「撤回答卷」，说一句「要撤回哪家跟我说」。

⚠️ **如果他自己的浏览器还开着这个表单，提醒他刷新**（我提交的是另一个实例，他那个窗口是旧状态）——否则他会以为没生效。

## Pitfalls
- **只点一次「提交」= 没提交。** 二次确认框必须点「确认」。
- **`e.value = x` 对 antd/React 无效**，必须原生 setter + `input` 事件。
- **按钮文案里的空格**导致 `=== '提交'` 匹配不到（实际是 `提 交`）→ 先归一化。
- **在「填写记录」列表页找字段值**是死路（懒加载 + 折叠不渲染）→ 用「修改答卷」读回。
- **批量前必须跑通第 1 条**：滑块验证 / 二次确认 / 提交后需扫码，形态千奇百怪。
- **顺序别自作主张重排**：十一给的清单顺序就是填写顺序。
- **数值别带千分位**、别带 `¥`。
- 提交完成页/记录页**不要在回报里引用成"已确认无误"**——真正的值是第 ③ 层读回来的那个。

## 相关
- 源数据常来自看板筛选导出 → `shiyi-financial-dashboard`（「十一要『在<筛选条件>下统计出来生成表格』」一节）。
- 从网页**取数**（反向）→ `web-console-data-harvest`。
- 推送/回报的渠道与排版 → `chat-report-push`。
