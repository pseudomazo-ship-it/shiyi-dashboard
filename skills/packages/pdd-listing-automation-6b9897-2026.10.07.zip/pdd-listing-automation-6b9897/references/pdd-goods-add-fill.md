# goods_add 编辑页：填规格表 + 传图 + 提交上架（2026-09-29 实战）

适用：十一给一个 `https://mms.pinduoduo.com/goods/goods_add/index?type=add&...&goods_id=XXXX` 链接（他自己发布的**相似品草稿**），
要求「改价格/库存/规格编码 → 传标签图 → 直接提交并上架」。主图/SKU图/详情图他已传好。

---

## 一、先读状态（三个数）

```js
// 规格类型名、表格行数、图片区计数、错误徽标
const t = document.body.innerText || '';
const zones = ['商品轮播图','白底图','长图','包装标签图','商品详情'].map(z => {
  const i = t.indexOf(z); const seg = i<0 ? '' : t.slice(i, i+120);
  const m = seg.match(/已上传\s*(\d+)\s*\/\s*(\d+)/); return z + ':' + (m ? m[1]+'/'+m[2] : '?');
});
const 错误 = (t.match(/错误\s*[（(]\s*(\d+)\s*[)）]/) || [''])[0];   // 必须读到 错误（0）
```

## 二、SKU 表结构（有陷阱）

列：`净含量 ｜ 颜色 ｜ *库存 ｜ *拼单价(元) ｜ *单买价(元) ｜ *预览图 ｜ 规格编码 ｜ 状态`

- **净含量是 rowspan 合并格**：只有该组第 1 行有它，其余行少一个 td
- 8 格行：`[0]净 [1]色 [2]库存 [3]拼 [4]单 [5]图 [6]编码 [7]状态`
- 7 格行：`[0]色 [1]库存 [2]拼 [3]单 [4]图 [5]编码 [6]状态`
- 表表体行可能**不在 `table tbody tr`**（表头/表体分离）；行也可能被虚拟化，滚动后才进 DOM

### ⚠️ 别按 `tds[i]` 下标填（踩过）
2026-09-29 用 `tds[2]=库存 / tds[3]=拼单价 / tds[6]=编码` 逐行写 → 第 2 行起列号前移，
**库存 1000 被写进了拼单价**，页面立刻报「拼单价至少比单买价低1元」，且 28 行全错。

### ✅ 稳的定位法：按「行内第几个输入框」
```js
const ins = [...tr.querySelectorAll('input[type=text]')];
const codeIn = ins[ins.length - 1];   // 最后一个文本输入框 = 规格编码
const stockIn = ins[0], priceIn = ins[1], singleIn = ins[2];
// 颜色 = 第一个「不像净含量」的单元格
const tds = [...tr.querySelectorAll('td')];
const texts = tds.map(td => (td.innerText||'').replace(/\s+/g,' ').trim());
const netIdx = texts.findIndex(x => /^\d+\s*(g|ml|克)$/.test(x));
const color = (netIdx >= 0 ? texts[netIdx+1] : texts[0]).split('【')[0].trim();
```

### 写入方式
1. 先在页面里给目标 input 打标记（`inp.setAttribute('data-hcode', String(i))`）
2. 再用 Playwright 原生写入（**对 React 最稳**）：
```js
await p.locator(`input[data-hcode="${i}"]`).fill(code, { timeout: 12000 });
```
- ❌ 「原生 setter + 派发 input/change」在这页**失效**（`Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')` 取不到 setter）
- ❌ `page.evaluate(fn, A, B)` —— **evaluate 只收一个参数**，B 被丢掉 → 报 `Cannot read properties of undefined (reading '')`（看着像页面问题，实际是参数）。数据写进函数体或合并成一个对象

## 三、传「包装标签图」（可做，别推给十一）

```js
// 1) 打标记：从「包装标签图」文字往上爬 3 层，那层里有 1 个 file input
const hit = await p.evaluate(() => {
  const el = [...document.querySelectorAll('*')].find(e => (e.innerText||'').trim().startsWith('包装标签图'));
  let n = el;
  for (let k = 0; k < 8 && n; k++) { n = n.parentElement; const ins = [...n.querySelectorAll('input[type=file]')]; if (ins.length) { ins[0].setAttribute('data-hermes-label','1'); return true; } }
  return false;
});
// 2) 用 Playwright 原生 setInputFiles（✅ 实测生效）
await p.locator('input[data-hermes-label="1"]').setInputFiles([图1绝对路径, 图2绝对路径]);
// 3) 验证：区域文字 已上传 0/10 → 2/10，且没有尺寸/格式报错
```
- ❌ `CDP DOM.setFileInputFiles` 在这页**不生效**（投喂后计数不变）
- ✅ 两张实拍图（3:1 竖长条 + 4:3 横版）**都被平台接受** → 不要因为页面写的「1:1 或 3:4」就拒绝十一给的图
- 路径**用正斜杠**（`C:/Users/...`）：bash heredoc 里反斜杠会被 shell 吃掉 → `ENOENT ... C:UsersAdministrator...`

## 四、提交并上架

1. 必须「错误（0）」；有错先修。常见必填：**是否为特殊用途化妆品**（发布助手面板里点「**去处理**」跳到字段 → 下拉选「**是**」；染发剂按法规属特殊用途，且提示要求与【化妆品批准文号】一致）
2. 点「提交并上架」用**真人节奏**：`mouse.move` → `down` → 等 160ms → `up`
3. 按钮变「**提交中**」= 点击生效了（**别当成失败**）；等它变回来
4. ❗ **页面不一定给成功提示、URL 也不一定跳** → **必须去商品列表核对**：
   新开一个标签页进 `/goods/goods_list`，读页签（在售中/发布中/已驳回/草稿箱/已删除）＋ 用商品ID搜索，确认商品到底在哪
5. 报结果时只说核对到的事实（哪个页签、几条），**不说「应该提交成功了」**

## 五、其他坑

- **编辑页会自动保存**：误删规格值 / 误填都**存进草稿** ✗；`p.reload()` 只回到服务器草稿，**不回滚**已自动保存的改动（2026-09-29 误删了一个净含量档位，reload 也回不来）
- 改「商品规格」的值（颜色/净含量）会**重排整张 SKU 表**（14 行 ↔ 28 行 ↔ 42 行）→ 改完必须重新读行数再填
- 规格值不是随便填的：在规格值输入框里乱填会**改写/删掉规格值**，且自动保存 → 只改该改的
- 颜色值加前缀要**幂等**：写前先判 `/^B\d+#/` 已存在就跳过，否则会变成 `B165#B165#...`
- 十一自己可能正在页面上操作（他会先写一个示范给你看）→ 先读回来照抄格式，别抢着改
- 提交/填表这类活儿结束后，把关键数字（行数/编码/价格/图片计数）**列给十一看**，他不看截图

---

## 六、★ SKU 表是虚拟列表 → 用项目自带的 `fillSkus()`，别自己逐行填（2026-09-29）

**症状**：表里明明 28/42 行，`document.querySelectorAll('table tbody tr')` 只数到 **14~16 行**；
按「找最大的 table」+ 逐行 `fill()` 去填 → 只填到一屏，剩下的行永远填不上 ✗，
而且下一轮读到的「最大表」已经换成另一张 ✗ → 越填越乱（十一为此连喊两次「停止」）。

**根因**：拼多多 SKU 表是**虚拟列表**，只渲染当前一屏（源码注释里写着「实测 36 个 SKU 只渲染 15 行」）。

**正确做法**：别自己写 ✗ → **直接调用项目里 9/23 已跑通的执行层函数** ✓
（在 `_direct/` 里 `require` 只读调用，**不改 `src/`** ✓）：

```js
const pub = require('../src/worker/publisher');

// 1) 加规格类型（走「添加规格类型」按钮 + ul[class*="dropdownPanel"] 里选中）
await pub.ensureSpecType(page, '套餐', log);
// 2) 填规格值（内部会 Enter + 失焦，见下方警告）
await pub.fillSpecValues(page, ['自定义套餐'], ['一盒装', '两盒装', '三盒装']);
// 3) 一次填完整张表（自动边滚边填 + 按「颜色×第二规格」认行 + 补平台多出来的行）
const r = await pub.fillSkus(page, skus, { log: (...a) => console.log(...a) });
```

`skus` 每条的形状（`fillSkuRow` 认这些字段）：
```js
{ fixedColor: 'B165#自然黑【免漂发色】居家快染',   // = 页面上的颜色值（含 B 编号，原样照抄）
  secondSpecValue: '两盒装', spec2Key: '套餐',      // spec2Key 决定第二规格的类型名
  inventory: 1000, groupPrice: 59.99, normalPrice: 69.99,
  specCode: 'Y 220自然黑【紫盒】2盒', enabled: true }
// ⛔ 不要传 imageUrl：SKU 图十一已经传好了，传了会去覆盖
```

**其他可直接调的函数**（都由 `publisher` 导出）：
`fillSkus`｜`fillSkuRow`｜`tagVisibleSkuRows`｜`scrollSkuTableByScreen`｜`waitSkuRows`｜`scrollTableToTop`｜
`fillSpecValues`｜`ensureSpecType`｜`blankClick`｜`dumpSkuRows`｜`dumpSpecInputs`｜`downloadImage`

⚠️ **`fillSpecValues` 的致命细节**：填完**最后一个**规格值必须**点一下空白处让它失焦**，
否则最后一个值不提交 —— 实测 3 个套餐只进去 2 个，整张表少一整组（源码注释：十一 9/23 当场抓到）。
这个函数内部已经处理了（`Escape` + `blankClick`）→ **别自己写填规格值的循环** ✗

⚠️ **第二规格类型名取自 `spec2Key`**：取值不是「数字+单位」时**绝不能当净含量填** ✗
（平台会把净含量框里的值**失焦回滚**）→ 一律走【套餐】/【款式】维度

⚠️ **改规格值会重排整张表**（14 行 ↔ 28 行 ↔ 42 行）→ 改完必须重新读行数、再走 `fillSkus`
