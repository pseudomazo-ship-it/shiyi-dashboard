// Verify shiyi-dashboard index.html login + data (NEW SHA-256 login, crypto.subtle mocked)
// Usage: node verify-dashboard.js [path-to-index.html]
const {JSDOM} = require('jsdom');
const fs = require('fs');
const crypto = require('crypto');
const path = process.argv[2] || 'E:/软件/Hermes/cache/shiyi-dashboard-git/index.html';
const html = fs.readFileSync(path, 'utf8');
const dom = new JSDOM(html, {runScripts:'dangerously', url:'https://pseudomazo-ship-it.github.io/shiyi-dashboard/', pretendToBeVisual:true});
const {window} = dom;
const doc = window.document;

// jsdom has no crypto.subtle — mock SHA-256 to match PASSWORD_HASH check
window.crypto = window.crypto || {};
window.crypto.subtle = { digest: async (a, d) => { const h = crypto.createHash('sha256').update(Buffer.from(d)).digest('hex'); return new Uint8Array(Buffer.from(h,'hex')); } };

setTimeout(() => {
  const loginBtn = doc.getElementById('loginBtn');
  const passwordInput = doc.getElementById('passwordInput');
  console.log('loginBtn:', !!loginBtn, '| passwordInput:', !!passwordInput);
  console.log('dashboard visible before:', doc.getElementById('dashboard') ? doc.getElementById('dashboard').classList.contains('visible') : 'N/A');
  if (passwordInput && loginBtn) {
    passwordInput.value = 'mq520520';
    loginBtn.click();
    setTimeout(() => {
      const ov = doc.getElementById('loginOverlay');
      const db = doc.getElementById('dashboard');
      console.log('--- after login ---');
      console.log('overlay display:', ov ? ov.style.display : 'N/A', '(expect none)');
      console.log('dashboard visible:', db ? db.classList.contains('visible') : 'N/A', '(expect true)');
      const m = html.match(/const QDATA\s*=\s*(\{[\s\S]*?\});\s*\n?const PASSWORD_TOKEN/);
      if (m) { try { const q = JSON.parse(m[1]); console.log('QDATA full subjects:', q.full.length); } catch(e) { console.log('QDATA parse ERR', e.message); } }
      const ok = (ov && ov.style.display === 'none') && (db && db.classList.contains('visible'));
      console.log(ok ? 'LOGIN-OK' : 'LOGIN-FAIL');
      process.exit(ok ? 0 : 1);
    }, 500);
  } else { console.log('MISSING KEYS'); process.exit(1); }
}, 300);
