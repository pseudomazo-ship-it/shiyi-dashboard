#!/usr/bin/env node
/**
 * 按【看板自身的筛选逻辑】跑一遍并打印结果 —— 用于「按筛选条件导出数据/统计」的交叉验证。
 * 用 getFilteredData() 而不是自己重写谓词，保证与线上看板逐家一致。
 *
 * 用法:
 *   node query-dashboard-filtered.js <index.html路径> '<filters JSON>' [--json]
 * 例:
 *   node query-dashboard-filtered.js E:/RuanJian/Hermes/cache/shiyi-dashboard-git/index.html \
 *        '{"salesState":"has","region":"江苏省","quarter":["2026-Q3"]}'
 *   node query-dashboard-filtered.js <path> '{}' --json > filtered.json   # 结构化输出
 *
 * 依赖: 在本脚本所在目录执行 `npm install jsdom --no-save`
 * 输出: 筛选条件 / 命中家数 / 销售额合计 / 逐家清单(按 totalSales 降序)
 */
const fs = require('fs');
const crypto = require('crypto');
const { JSDOM } = require('jsdom');

const file = process.argv[2];
let spec = {};
try { spec = JSON.parse(process.argv[3] || '{}'); }
catch (e) { console.error('第二个参数必须是合法 JSON，收到:', process.argv[3]); process.exit(2); }
const asJson = process.argv.includes('--json');

if (!file || !fs.existsSync(file)) {
  console.error('用法: node query-dashboard-filtered.js <index.html> \'<filters JSON>\' [--json]');
  process.exit(2);
}

const dom = new JSDOM(fs.readFileSync(file, 'utf8'), {
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  url: 'https://pseudomazo-ship-it.github.io/shiyi-dashboard/'
});
const w = dom.window;

// jsdom 无 crypto.subtle，登录门(异步 sha256)会用到 —— 不 mock 就登录失败
w.crypto = w.crypto || {};
w.crypto.subtle = {
  digest: (alg, data) => Promise.resolve(new Uint8Array(
    Buffer.from(crypto.createHash('sha256').update(Buffer.from(data)).digest('hex'), 'hex')))
};

setTimeout(() => {
  let code = 0;
  try {
    // 先铺一遍看板默认值，再套用传入条件 —— 避免漏传某键时沿用脏状态
    w.eval([
      "filters.year=[];filters.quarter=[];filters.month=[];",
      "filters.status='all';filters.activeStatus='all';filters.sales='all';",
      "filters.region='all';filters.promo='all';filters.ware='all';",
      "filters.goods='all';filters.totalExp='all';",
      "filters.salesState='all';filters.flowState='has';filters.search='';"
    ].join(''));

    for (const [k, v] of Object.entries(spec)) {
      // filters 是 const，不挂 window —— 只能走 eval
      w.eval('filters[' + JSON.stringify(k) + ']=' + JSON.stringify(v) + ';');
    }

    const rows = JSON.parse(w.eval(
      "JSON.stringify(getFilteredData().map(function(d){return {" +
      "company:d.company,totalSales:d.totalSales,totalExp:d.totalExp," +
      "region:d.region,activeStatus:d.activeStatus,status:d.status,period:d.period};}))"));
    rows.sort((a, b) => (b.totalSales || 0) - (a.totalSales || 0));
    const sum = rows.reduce((a, x) => a + (x.totalSales || 0), 0);

    if (asJson) {
      console.log(JSON.stringify({
        filters: spec, count: rows.length,
        totalSales: Math.round(sum * 100) / 100, rows
      }, null, 1));
    } else {
      console.log('筛选条件:', JSON.stringify(spec));
      console.log('命中家数:', rows.length);
      console.log('销售额合计:', sum.toFixed(2));
      console.log('');
      rows.forEach((x, i) => console.log(
        String(i + 1).padStart(3) + '  ' +
        String(x.company).padEnd(30) +
        (x.totalSales || 0).toFixed(2).padStart(16) + '  ' +
        (x.region || '-')));
    }
  } catch (e) {
    console.error('失败:', e.message);
    code = 1;
  } finally {
    // 看板有 setInterval(updateLiveClock,1000) —— 不 close + exit 会卡满 300s 超时
    w.close();
    process.exit(code);
  }
}, 1300);
