#!/usr/bin/env node
/**
 * 主体财务看板 —— 筛选功能回归验证（jsdom 真实点击）
 *
 * 用法:
 *   cd <有 node_modules 的目录>  && npm install jsdom --no-save
 *   node scripts/verify-dashboard-filters.js "E:/RuanJian/Hermes/cache/shiyi-dashboard-git/index.html"
 *
 * 覆盖：年/季/月 三级多选 + 三级联动 + 执照地区(省份) + 销售状态/流水状态 + 区间翻转 + 重置
 *
 * 为什么必须用 .click() 而不是直接改 filters：
 *   updatePeriodVis() / updateSelHint() 是 setupFilters() 的闭包内函数 → w.updatePeriodVis 是 undefined，
 *   直接 w.eval('filters.year=[...]') 只改数据、不触发联动与口径提示，会把「联动没生效」误判成 bug。
 * 为什么必须 w.eval 访问 filters：
 *   filters 是 const，不挂 window。
 * 为什么必须 process.exit：
 *   看板有 setInterval(updateLiveClock,1000)，jsdom 定时器让 node 永不退出 → 命令卡满超时。
 */
const fs = require('fs');
const crypto = require('crypto');
const HTML = process.argv[2] || 'E:/RuanJian/Hermes/cache/shiyi-dashboard-git/index.html';
const html = fs.readFileSync(HTML, 'utf8');
let JSDOM;
try { JSDOM = require('jsdom').JSDOM; }
catch (e) { console.log('缺少 jsdom，先跑: npm install jsdom --no-save'); process.exit(1); }

const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
  url: 'https://pseudomazo-ship-it.github.io/shiyi-dashboard/' });
const w = dom.window, doc = w.document;
// 登录门用异步 sha256，jsdom 无 crypto.subtle → 必须 mock
w.crypto = w.crypto || {};
w.crypto.subtle = { digest: (a, d) => Promise.resolve(new Uint8Array(
  Buffer.from(crypto.createHash('sha256').update(Buffer.from(d)).digest('hex'), 'hex'))) };

const run   = c => w.eval(c);
const click = (g, f) => {
  const b = doc.querySelector('.filter-btn[data-group="' + g + '"][data-filter="' + f + '"]');
  if (b) b.click(); else console.log('  !! 缺按钮 ' + g + ' / ' + f);
};
const reset = () => doc.getElementById('resetFilters').click();
const n     = () => run('getFilteredData().length');
const visQ  = () => Array.from(doc.querySelectorAll('.filter-btn[data-group="quarter"]'))
                      .filter(b => b.style.display !== 'none').map(b => b.dataset.filter);
const hint  = () => { const e = doc.getElementById('selHint'); return e ? e.textContent : '(无)'; };

setTimeout(() => {
  run("document.getElementById('passwordInput').value='mq520520'; checkPassword && checkPassword();");
  setTimeout(() => {
    const P = s => console.log(s);
    let fail = 0;
    const chk = (label, got, want) => {
      const ok = (typeof want === 'number') ? (got === want) : String(got) === String(want);
      if (!ok) fail++;
      P('  ' + (ok ? '✅' : '❌') + ' ' + label + ': ' + got + (ok ? '' : '  (期望 ' + want + ')'));
    };
    try {
      P('=== 登录 ===');
      chk('dashboard.visible', run("document.getElementById('dashboard').classList.contains('visible')"), true);

      P('\n=== 结构 ===');
      P('  筛选组: ' + run('JSON.stringify(Array.from(new Set(Array.from(document.querySelectorAll(".filter-btn")).map(function(b){return b.dataset.group}))))'));
      const ths = run('document.querySelectorAll("thead th").length');
      P('  thead 列数: ' + ths);
      P('  末列表头: ' + run('document.querySelectorAll("thead th")[document.querySelectorAll("thead th").length-1].textContent'));

      P('\n=== 三级多选 + 联动 ===');
      reset();
      click('year', '2025');
      P('  点[2025年] → 口径: ' + hint());
      P('           可见季度: ' + JSON.stringify(visQ()));
      click('year', '2026');
      P('  再点[2026年] → 口径: ' + hint());
      reset();
      click('quarter', '2026-Q3');
      P('  点[26Q3] → 可见月份: ' + JSON.stringify(Array.from(
        doc.querySelectorAll('.filter-btn[data-group="month"]'))
          .filter(b => b.style.display !== 'none').map(b => b.dataset.filter)));
      click('quarter', '2026-Q2');
      P('  26Q3+26Q2 → 口径: ' + hint() + ' | 主体数: ' + n());
      click('month', '2026-08');
      P('  再叠加8月 → 主体数: ' + n());

      P('\n=== 执照地区（省份）===');
      reset();
      ['江苏省', '河南省', '湖北省'].forEach(r => { click('region', r); P('  ' + r + ' → ' + n() + ' 家'); });

      P('\n=== 销售状态 / 流水状态 ===');
      reset();
      P('  默认(有流水) = ' + n());
      click('flowState', 'all');  P('  全部        = ' + n());
      click('flowState', 'none'); P('  无流水额    = ' + n());
      click('flowState', 'has');  P('  有流水额    = ' + n());
      click('salesState', 'none');P('  无销售额    = ' + n());
      click('salesState', 'has'); P('  有销售额    = ' + n());

      P('\n=== 🔴 区间判断（数字必须随区间变化）===');
      [['2026-Q2'], ['2026-Q3'], ['2026-Q4']].forEach(p => {
        reset();
        click('flowState', 'none');
        click('quarter', p[0]);
        click('region', 'all');   // 触一次重渲染让 filters 生效
        const noF = n();
        click('flowState', 'all');
        const allF = n();
        P('  ' + p[0] + ' → 无流水 ' + noF + ' / 全部 ' + allF);
      });

      P('\n=== 🔴 单主体跨区间翻转（最能证明区间判断生效）===');
      const flips = JSON.parse(run(
        "(function(){var q3={},q4={};" +
        "(QDATA['2026-Q3']||[]).forEach(function(d){q3[d.company]=d});" +
        "(QDATA['2026-Q4']||[]).forEach(function(d){q4[d.company]=d});" +
        "var out=[];Object.keys(q4).forEach(function(c){var a=q3[c],b=q4[c];if(!a)return;" +
        "var fa=(Math.abs(+a.totalSales||0)>0)||(Math.abs(+a.totalExp||0)>0);" +
        "var fb=(Math.abs(+b.totalSales||0)>0)||(Math.abs(+b.totalExp||0)>0);" +
        "if(fa&&!fb)out.push(c)});return JSON.stringify(out.slice(0,3))})()"));
      P('  Q3有流水→Q4无流水 的主体: ' + JSON.stringify(flips));
      if (flips.length) {
        const c = flips[0];
        const inQ4 = (() => { reset(); click('flowState', 'none'); click('quarter', '2026-Q4');
                              click('region', 'all');
                              return run('getFilteredData().some(function(d){return d.company===' + JSON.stringify(c) + '})'); })();
        const inQ3 = (() => { reset(); click('flowState', 'none'); click('quarter', '2026-Q3');
                              click('region', 'all');
                              return run('getFilteredData().some(function(d){return d.company===' + JSON.stringify(c) + '})'); })();
        chk('「' + c + '」在 无流水额+26Q4 出现', inQ4, true);
        chk('「' + c + '」在 无流水额+26Q3 出现', inQ3, false);
      } else { P('  ⚠️ 找不到翻转样本，跳过'); }

      P('\n=== 重置 ===');
      reset();
      P('  主体数: ' + n() + ' | flowState: ' + run('filters.flowState') + ' | 口径: ' + hint());
      const rows = run('document.querySelectorAll("#tableBody tr").length');
      P('  表格行数: ' + rows);

      P('\n' + (fail === 0 ? '✅ 全部通过（0 处不符）' : '❌ 有 ' + fail + ' 处不符'));
    } catch (e) {
      console.log('❌ 异常: ' + e.message + '\n' + e.stack);
    } finally {
      w.close();          // ← 必做，否则 setInterval 让 node 卡满超时
      process.exit(0);
    }
  }, 900);
}, 1300);
