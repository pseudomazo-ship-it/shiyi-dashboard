#!/usr/bin/env node
/* 看板「列」完整性自检 —— 往主体财务明细表加/插列之后必跑
 *
 * 背景：这张表的列是**按索引硬编码**的（class="cN" + dsp(N) + colVis + getSortVal +
 * thead + col-toggle 六处），手动重编号极易出错。2026-10-06 插「均销售额」列时
 * 连踩两个坑（带后缀的 class 漏重编号、新单元格写了两个 style 属性），两次都是
 * 肉眼没看出来、靠专门自检才抓到。这个脚本就是把那些自检固化下来。
 *
 * 用法：
 *   cd <有 jsdom 的目录>            # npm install jsdom --no-save
 *   node verify-dashboard-columns.js <index.html 路径> [--expect N]
 *
 * 退出码：0 = 全过；1 = 有 FAIL
 */
const fs = require('fs');
const path = process.argv[2];
const expectIdx = process.argv.indexOf('--expect');
const EXPECT_COLS = expectIdx > 0 ? parseInt(process.argv[expectIdx + 1], 10) : null;

if (!path) { console.log('用法: node verify-dashboard-columns.js <index.html> [--expect 22]'); process.exit(1); }

let fails = 0, passes = 0;
function check(label, ok, detail) {
  if (ok) { passes++; console.log('  \u2705 ' + label); }
  else { fails++; console.log('  \u274c ' + label + (detail ? '  -> ' + detail : '')); }
}

const html = fs.readFileSync(path, 'utf8');

// ---------- 1) 静态：语法 + class 编号连续性 ----------
console.log('=== 静态检查 ===');
const scriptM = html.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptM) { console.log('  \u274c 找不到 <script>'); process.exit(1); }
fs.writeFileSync('_chk_cols.js', scriptM[1]);
try {
  require('child_process').execFileSync('node', ['--check', '_chk_cols.js'], { stdio: 'pipe' });
  check('node --check <script> 语法', true);
} catch (e) {
  check('node --check <script> 语法', false, (e.stderr || '').toString().split('\n').slice(0, 3).join(' | '));
  console.log('\n语法不过就不必往下测了。');
  process.exit(1);
}

const rowM = html.match(/('<tr class="'\+cls\+'">[\s\S]*?<\/td><\/tr>';)/);
if (!rowM) { console.log('  \u274c 找不到 renderTable 行模板'); process.exit(1); }
const row = rowM[1];
const clsNums = (row.match(/class="c(\d+)[^"]*"/g) || [])
  .map(function (s) { return parseInt(s.match(/c(\d+)/)[1], 10); });
const dspNums = (row.match(/dsp\((\d+)\)/g) || [])
  .map(function (s) { return parseInt(s.match(/\d+/)[0], 10); });

check('行模板 class 编号连续无重复（c1..cN）',
      JSON.stringify(clsNums) === JSON.stringify(clsNums.map(function(_, i){return i+1;})),
      JSON.stringify(clsNums));
check('dsp(N) 编号连续且在 class 范围内',
      JSON.stringify(dspNums) === JSON.stringify(dspNums.map(function(_, i){return i+5;}))
      || dspNums.length === clsNums.length,
      JSON.stringify(dspNums));
// 带后缀的 class 被漏改时，会出现同一编号两次
const dup = clsNums.filter(function (v, i) { return clsNums.indexOf(v) !== i; });
check('没有重复 class 编号（漏改后缀类的典型症状）', dup.length === 0, JSON.stringify(dup));
// 新列单元格不得出现两个 style 属性
const twoStyle = row.match(/style="[^"]*"\s*\+dsp\(/);
check('新列单元格没有「两个 style 属性」写法（会让列开关失效）', !twoStyle,
      twoStyle ? '发现 style="..." +dsp(N) —— 要合并成 style="..."+(colVis[N]?...)' : '');

let colVisM = html.match(/let colVis = \{([^}]*)\};/);
const colVisKeys = colVisM ? colVisM[1].split(',').map(function (p) { return parseInt(p.split(':')[0].trim(), 10); }) : [];
check('colVis 键覆盖 0..' + (clsNums.length),
      colVisKeys.length === clsNums.length + 1,
      'colVis 有 ' + colVisKeys.length + ' 个键，行有 ' + (clsNums.length + 1) + ' 列');
const syncM = html.match(/for \(var i = 0; i < (\d+); i\+\+\)/);
check('syncTh 循环上限 = 列数',
      syncM && parseInt(syncM[1], 10) === clsNums.length + 1,
      syncM ? 'syncTh 上限 ' + syncM[1] + '，应为 ' + (clsNums.length + 1) : '未找到 syncTh 循环');
const headTh = (html.match(/<thead>[\s\S]*?<\/thead>/) || [''])[0].match(/<th[\s>]/g) || [];
check('thead th 数 = 列数', headTh.length === clsNums.length + 1,
      'thead ' + headTh.length + ' 个 th，行模板 ' + (clsNums.length + 1) + ' 列');
if (EXPECT_COLS) check('列数 = 预期 ' + EXPECT_COLS, clsNums.length + 1 === EXPECT_COLS, '实际 ' + (clsNums.length + 1));

// ---------- 2) 运行时：jsdom ----------
console.log('\n=== 运行时检查（jsdom）===');
let JSDOM;
try { JSDOM = require('jsdom').JSDOM; }
catch (e) { console.log('  \u26a0\ufe0f  jsdom 未安装，跳过运行时检查（cd 到有 node_modules 的目录跑）'); process.exit(fails ? 1 : 0); }
const crypto = require('crypto');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
  url: 'https://pseudomazo-ship-it.github.io/shiyi-dashboard/' });
const w = dom.window;
w.crypto = w.crypto || {};
w.crypto.subtle = { digest: function (a, d) {
  const h = crypto.createHash('sha256').update(Buffer.from(d)).digest('hex');
  return Promise.resolve(new Uint8Array(Buffer.from(h, 'hex')));
} };
const doc = w.document;
const run = function (c) { return w.eval(c); };

setTimeout(function () {
  run("document.getElementById('passwordInput').value='mq520520'; checkPassword && checkPassword();");
  setTimeout(function () {
    try {
      check('登录后 dashboard visible', run("document.getElementById('dashboard').classList.contains('visible')"));
      run('renderTable();syncTh();');
      const cols = run('document.querySelectorAll("thead th").length');
      const cells = run('document.querySelector("#tableBody tr") ? document.querySelector("#tableBody tr").cells.length : -1');
      check('thead 列数 = 首行列数', cols === cells, 'thead ' + cols + ' / 行 ' + cells);
      check('colVis 未显示时列仍存在（cells 不因隐藏而减少）', cells === clsNums.length + 1, String(cells));

      // 每列都能「关掉」（display:none）再「打开」—— 专抓双 style 属性的坑
      let badToggle = [];
      for (let i = 0; i <= clsNums.length; i++) {
        run('colVis[' + i + ']=false;renderTable();syncTh();');
        const d = run('document.querySelector("#tableBody tr").cells[' + i + '].style.display');
        if (d !== 'none') badToggle.push(i + '(=' + JSON.stringify(d) + ')');
        run('colVis[' + i + ']=true;renderTable();syncTh();');
      }
      check('每一列都能被列开关关掉', badToggle.length === 0,
            badToggle.length ? '关不掉的列: ' + badToggle.join(', ') : '');

      // 每列都能排序（getSortVal 不漏列）
      let badSort = [];
      for (let i = 0; i <= clsNums.length; i++) {
        try {
          run('sortCol=' + i + ';sortAsc=false;renderTable();');
          if (!run('document.querySelector("#tableBody tr")')) badSort.push(i);
        } catch (e) { badSort.push(i); }
      }
      run('sortCol=null;renderTable();');
      check('每一列都能排序（getSortVal 无遗漏）', badSort.length === 0, badSort.join(','));

      console.log('\n--- 表头顺序 ---');
      JSON.parse(run('JSON.stringify(Array.from(document.querySelectorAll("thead th")).map(function(t){return t.textContent.trim()}))'))
        .forEach(function (t, i) { console.log('   ' + String(i).padStart(2) + '  ' + t); });
    } catch (e) {
      check('运行时检查', false, e.message);
    } finally {
      console.log('\n通过 ' + passes + ' / 失败 ' + fails);
      w.close(); process.exit(fails ? 1 : 0);
    }
  }, 900);
}, 1300);
