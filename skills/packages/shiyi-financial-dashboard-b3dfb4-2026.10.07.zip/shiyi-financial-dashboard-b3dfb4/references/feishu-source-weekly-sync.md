# 主体财务看板 · 飞书数据源 + 每周自动同步（2026-09-21 建立并跑通）

取代原来的「手工导出两份 Excel → 跑生成器」流程。用户要求：**每周一上午 9 点自动更新；周一电脑不开机则之后哪天开机及时补上。**

## 工作目录

`D:\Agent.GongZuoQu\Hermes.GZQ\项目：主体财务看板自动同步\`

| 文件 | 作用 |
|---|---|
| `weekly_sync.py` | 主流程：飞书拉数 → 写 Excel → 跑生成器 → 注入 QDATA → git push → 线上验证 → 写 state |
| `run_sync.py` | 同一目录内的便捷 wrapper（可删；cron 用的是 scripts 里那个） |
| `generate_dashboard.py` | 从 WorkBuddy 工作区**拷贝**来的生成器副本，已 patch 两处（见下） |
| `主体收支情况【模版】.xlsx` | 飞书收集结果导出的 14 列 Excel（生成器的输入） |
| `主体绑定店铺情况【模版】.xlsx.xlsx` | 绑定关系（暂为本地旧版，等飞书表2授权后改为直读） |
| `feishu_raw.json` | 飞书原始记录备份（重算/排查时不必再拉一次） |
| `sync_state.json` | `{last_success, last_date, rows}` —— 决定本周要不要跑 |
| `sync_log.txt` / `cron_runner.log` | 运行日志 |

cron 入口：`E:\RuanJian\Hermes\scripts\subject_dashboard_sync.py`（只用 stdlib，subprocess 调 `uv run`）。

## 生成器副本的两处 patch（必须保留）

1. `BASE` 硬编码在旧 WorkBuddy 路径 → 改成 `os.path.dirname(os.path.abspath(__file__))`（脚本所在目录）。
2. 开头的 `resp = input("✅ 是否继续生成看板？(y/n): ")` 会卡住非交互运行 → 改成
   `resp = (os.environ.get('AUTO_YES','').strip().lower() or input(...).strip().lower())`，跑时给 `AUTO_YES=y`，**不要再走 pty+process(submit) 那套**。

> ⚠️ **每次挪动/重命名看板文件后，都要重跑一遍 `grep -rn "index\.html\|github\.io"`**
> 把写死路径和旧域名一次改完 —— 只改看板不改脚本，下次自动更新会报错、
> 或者**更新到错的文件上**（更糟）。同类坑的通用教训见 `domain-hosting-access-control` 坑 11。

## 飞书 → Excel（关键转换）

- 拉取：`GET /bitable/v1/apps/{app}/tables/{table}/records?page_size=500` + `page_token` 分页，756 条 = 2 页。
- 14 列固定顺序：平台 / 店铺名 / 年份 / 季度 / 月份 / 业绩 / 转账推广费 / 技术服务费 / 主体公司 /【支出/收票】项目 / 仓储快递（支出）/ 货款转账（支出）/ 其他花费(支出）/【进项票】开票金额
  - ⚠️ Excel 模板里「其他花费」用的是**半角括号** `其他花费(支出）`，飞书字段是**全角** `其他花费（支出）` —— 两边名字不同，映射表要分开写。
- **数字列必须 `float()`**：飞书 type 2 字段经 API 返回**字符串**，直接写 Excel 会让 pandas 的 `.sum()` 把字符串首尾相连，报
  `ValueError: could not convert string to float: '1094090.92938846.92...'`。受影响列：业绩/转账推广费/技术服务费/仓储快递/货款转账/其他花费/进项票开票金额。
- 空值保留 `None`，不要写 0。

## 生成 → 注入 → 推送

1. `AUTO_YES=y uv run --with pandas --with openpyxl python generate_dashboard.py`
   → 输出 `主体财务看板<YYYY-MM-DD>.html`，日志尾部有 `总销售额: ¥...` 和 `安全/需发票/超标/使用中` 计数。
2. **生成器输出一定带旧登录门**（`loginBtn=0`、`authGate=2`、`auth-locked=3`、`unlockDashboard=3`、`checkPassword=0`）→ **绝不能直接发布**。走干净骨架 + QDATA 注入：
   - 正则 `const QDATA\s*=\s*(\{.*?\});\s*\n?const PASSWORD_TOKEN` 从生成的文件里取新 QDATA，替换到仓库 `finance/index.html` 的旧 QDATA。
     ⚠️ **2026-10-07 起看板从仓库根 `index.html` 挪到了 `finance/index.html`**
     （根域 `/` 改成了「个人工作台」导航页，财务看板占了 `/finance/`）。
     `weekly_sync.py` 里的读/写路径已同步改好；新写脚本时别再指回根目录。
   - 同时替换**所有**旧日期标注：`截止<old>`、`更新日期：<old>`、`看板版本：<old>`、`<title>...截止<old></title>`。完工后 `old` 应剩 **0 处**。
   - 自检：`loginBtn`=2、`authGate`/`auth-locked`/`unlockDashboard`=0、`checkPassword`=3、`PASSWORD_TOKEN` 数量不变。任一不过就抛错，不要往下走。
   - 独立脚本写法见技能正文「Alternative path」和 `direct-rebuild.md`；本条只是补充“QDATA 无变化也要继续同步日期标注”这一点。
3. `git add finance/index.html && git commit -m "sync subject finance dashboard to <date> ..."`
4. **`git -c http.proxy=http://127.0.0.1:7897 -c https.proxy=... pull --rebase origin main`（必做，仓库被评价星级 cron 共用）** → 然后 `push`。
5. 线上验证：等 ~80 秒，fetch `https://shiyi11.com.cn/finance/?v=<ts>`（直连，不带代理），断言 `更新日期：<date>` 且 `loginBtn`=2 / `authGate`=0。**失败要能报出来**，不要静默算成功。
   ⚠️ **旧地址 `pseudomazo-ship-it.github.io/shiyi-dashboard/` 绑了自定义域后会 301**，
   不能再当验证 URL 用 —— 否则验证逻辑失效或误报失败。

## 周更判定逻辑（脚本内，别靠 cron 猜）

```python
m9 = 本周一 09:00
if now < m9: skip            # 周一还没到 9 点
if last_success >= m9: skip  # 本周已成功跑过
否则 run
```

- 效果：周一 9 点前不跑；周一 9 点后首次触发即跑；周一没开机 → 周二起任意一次触发补跑；跑过之后再触发就静默。
- `--force` 无视判断（手动重试用），`--dry-run` 只拉数不发布，`--quiet` 抑制日志（cron 用）。

## 验证清单

- [ ] `sync_state.json` 的 `last_success` 是本次时间
- [ ] 生成器日志 `Total rows` = 飞书实际条数（本次 756；`Sales rows` 419 / `Expense-only rows` 337）
- [ ] 注入后干净性断言全过
- [ ] `git status -sb` = `## main...origin/main`（无 `[ahead N]`）
- [ ] 线上 `?v=` 版本页的 `更新日期` = 本次日期，旧日期 0 处
- [ ] 主体数变化要主动报告（41 → 43 这种是源数据变化，不是 bug）

## 本次实测数据（2026-09-21）

756 条（比上次 754 多 2 条）、43 主体、39 店铺；总销售额 ¥96,155,354；安全 9 / 需发票 26 / 超标 8 / 使用中 27。最新有业绩月份 = 2026-08（9 月尚未登记，`2026-09` 全为 0 属正常）。
