## Exact per-step commands (from a verified run, 2026-08-31)

Project dir: `D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\Work Buddy\数据、财务工作区\项目：主体 x 财务=Boss`
Git repo: `E:\软件\Hermes\cache\shiyi-dashboard-git`

### 0. Fix BASE in generator (if not already patched)
grep line 10 of `generate_dashboard.py` — it points at a missing dir. Patch to:
```
BASE = r'D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\Work Buddy\数据、财务工作区\项目：主体 x 财务=Boss'
```

### 1. Regenerate (needs pandas+openpyxl; send 'y')
```bash
cd "<project dir>"
uv run --with pandas --with openpyxl python generate_dashboard.py
```
It prompts `✅ 是否继续生成看板？(y/n):` and blocks on stdin. In the desktop terminal, run with `background=true, pty=true` then `process(action=submit, data='y')`. Expect log of rows, companies, and `✅ HTML看板已保存: ...主体财务看板<YYYY-MM-DD>.html`.

### 2. Deploy (adds password gate + live clock)
```bash
cd "<project dir>"
mkdir -p deploy            # deploy/ often does NOT exist
python _rebuild_deploy.py  # pure python, no pandas needed
```
Expect `Deploy rebuilt: <n> bytes`. Output: `deploy/index.html`.

### 3. Copy to git repo
```bash
cd "E:\软件\Hermes\cache\shiyi-dashboard-git"
cp "<project dir>/deploy/index.html" index.html
```

### 4. Commit + push
```bash
git add index.html
# git config user.name/user.email already set (Eleven / pseudomazo@gmail.com)
git commit -m "同步主体财务看板至<YYYY-MM-DD>: 数据源更新, 更新日期<YYYY-MM-DD>"
git push origin main
```

### 5. Verify live (GitHub Pages rebuild ~30-120s)
Fetch `https://shiyi11.com.cn/`. First fetch may be stale/old size; poll a few times. New build ≈450KB vs old ≈180KB. Assert the `更新日期：<run-date>` header.

## Data sources
- `主体收支情况【模版】.xlsx` — income/expense per subject (headers: 平台/店铺名/年份/季度/月份/业绩/转账推广费/技术服务费/主体公司/仓储快递/货款转账/其他花费/开票金额).
- `主体绑定店铺情况【模版】.xlsx.xlsx` — bindings (headers: 平台/店铺名/承接主体/当前（新/旧）承接店铺).

## Generator internals worth knowing
- `DEFAULT` thresholds: SALES_OVER_LIMIT=4_000_000, SALES_SAFE_LIMIT=250_000, EXPENSE_SAFE_RATIO=0.64, RATIO_GREEN_MAX=0.45, RATIO_ORANGE_MAX=0.55.
- EXCLUDED_COMPANIES={'徐州鲁刘种植有限公司'} (kept out of the dashboard, not deleted from Excel).
- Output filename `主体财务看板<today_short>.html`, today_short = `YYYY-MM-DD` from `datetime.now()`.
- Dashboard password `mq520520`; the deploy script injects a SHA-256 gate and live clock.
