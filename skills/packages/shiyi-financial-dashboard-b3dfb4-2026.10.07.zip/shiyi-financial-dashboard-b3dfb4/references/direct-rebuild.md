# Direct rebuild: QDATA injection into clean skeleton (validated 2026-09-05)

Use when `generate_dashboard.py` output is polluted by old-gate residue (authGate>0) — which is the CURRENT normal state of the generator as of 2026-09-05. This path leaves the login system, live clock, JS/CSS untouched and publishes only new data.

## Why (hard evidence)
- `主体财务看板<date>.html` from `generate_dashboard.py`: loginBtn=2, **authGate=2, auth-locked=3, unlockDashboard=3** (poisoned).
- `_rebuild_deploy.py` → `deploy/index.html`: same poisoning (455,215 bytes, authGate=2).
- Git repo `cache/shiyi-dashboard-git/index.html` (the online-fixed skeleton): loginBtn=2, **authGate=0** — this is the only clean base; stay with it.

## Recipe (run via `uv run --with openpyxl python` — no pandas needed)

### 1. Copy updated source Excel into the generator dir first
`cp` both new templates from user workspace into `D:\其他文件\...\项目：主体 x 财务=Boss\` (overwrites old). Then run `generate_dashboard.py` (background pty + `process(action=submit, data='y')` for the input() prompt) to produce the fresh `主体财务看板<YYYY-MM-DD>.html`.

### 2. Extract new QDATA from generator output
```python
import re, json
gen = open(r'...\主体财务看板<date>.html', encoding='utf-8').read()
git = open(r'E:\软件\Hermes\cache\shiyi-dashboard-git\index.html', encoding='utf-8').read()
m1 = re.search(r'const QDATA\s*=\s*(\{.*?\});\s*\n?const PASSWORD_TOKEN', gen, re.S)
m2 = re.search(r'const QDATA\s*=\s*(\{.*?\});\s*\n?const PASSWORD_TOKEN', git, re.S)
assert m1 and m2
new_q, old_q = m1.group(1), m2.group(1)
json.loads(new_q)  # validate it parses
new_index = git.replace(old_q, new_q)
assert new_index != git
```

### 3. ALSO sync static headers (QDATA swap alone leaves stale date!)
```python
for pat in [r'<title>[^<]*</title>', r'更新日期：[^<"}]*', r'数据截至[^<"}]*']:
    old = re.findall(pat, new_index)[0]
    new = re.findall(pat, gen)[0]
    assert old in new_index
    new_index = new_index.replace(old, new)
open(r'E:\软件\Hermes\cache\shiyi-dashboard-git\index.html', 'w', encoding='utf-8').write(new_index)
```
Verify afterwards: `loginBtn` count==2, `authGate`==0, `auth-locked`==0, `unlockDashboard`==0, title contains new date, `更新日期：<today>`.

### 4. Verify login still works (jsdom + crypto.subtle mock)
The page uses the NEW SHA-256 `checkPassword()`; jsdom lacks `crypto.subtle`, so mock it, then click `#loginBtn` with `mq520520` and assert `#loginOverlay.style.display==='none'` and `#dashboard` `.visible===true`. Also parse QDATA from the final file and assert `full.length`==expected subject count (43) and key company names present (e.g. 开封莉梭商贸有限公司). Working script saved as `scripts/verify-dashboard.js`.

### 5. Commit, push, verify live (same as main pipeline)
`git add index.html && git commit -m "同步主体财务看板至<YYYY-MM-DD>"` then `git push origin main`. Push errors are NOT conclusive (see SKILL.md) — check `git status -sb` (no `[ahead N]`) then fetch the live URL with urllib+UA and assert title/更新日期/loginBtn/authGate. GitHub Pages takes ~30-120s; if the fetch returns old content, wait and retry.

## Gotchas
- `curl -o` to a path that already exists can silently keep an old file (exit 23 / wrong size) — delete the target first, or use urllib and write fresh bytes; then check size + `更新日期` text, never just byte size.
- Regex for QDATA must be non-greedy `(\{.*?\});\nconst PASSWORD_TOKEN` with DOTALL — the JSON is ~400KB, one giant line context; greedy `.*` over-matches.
- Never hand-edit `更新日期`; it comes from the run's dynamic date. If wrong after regen, the generator wasn't re-run on the new Excel.
