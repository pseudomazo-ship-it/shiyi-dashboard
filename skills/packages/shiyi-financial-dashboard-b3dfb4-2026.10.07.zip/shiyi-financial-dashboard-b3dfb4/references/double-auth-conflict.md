# Double-auth conflict — "login does nothing" (root cause 2026-08-31)

## Symptom
Page loads, the password box appears, but typing the correct password and submitting does **nothing** (`loginOverlay`/`authGate` stays, or the page is blank). User reports "还是看不到 / 输密码没反应" even after network is confirmed reachable and the password is confirmed correct.

This is **NOT** a network, CDN-cache, or wrong-password problem. It is a **dirty merge**: the deployed `index.html` carries BOTH an old password gate AND a new login system.

## Detect
```bash
grep -c loginBtn   index.html   # should be 2  (new system: button + JS ref)
grep -c authGate   index.html   # should be 0
grep -c 'auth-locked' index.html  # should be 0
grep -c unlockDashboard index.html # should be 0
grep -c '<script>'   index.html  # should be 1
```
If `authGate` > 0 or `auth-locked` > 0 or `unlockDashboard` > 0 while `loginBtn` is present → old gate remnants survived the merge. The two systems both bind `#passwordInput`, both toggle `document.body`/`#dashboard` visibility, and both register their own submit/enter handlers, so they cancel each other.

## The two systems
| System | Signals | Login flow |
|---|---|---|
| OLD (password gate) | `authGate`, `authForm`, `auth-locked`, `unlockDashboard`, `readAuthToken`, `PASSWORD_TOKEN`, `btoa(input.value.trim())` | `authForm` submit → `btoa(???)===PASSWORD_TOKEN` → `unlockDashboard()` |
| NEW (login overlay) | `loginOverlay`, `loginCard`, `loginBtn`, `checkPassword`, `PASSWORD_HASH` (SHA-256), `logout`, `showDashboard`, `kickDashboard` | `loginBtn`/Enter → `checkPassword()` → `sha256(p)===PASSWORD_HASH` → `showDashboard()` → `kickDashboard()` (renders) |

Both passwords are the same (`mq520520`): old token `bXE1MjA1MjA=` = base64("mq520520"); new hash `030399ee247e9f25189d627e54eaee29b38ff79467597d0ea082c3d940e3199d` = sha256("mq520520").

## Fix — keep NEW system, strip OLD gate
1. In `<body>`, remove the whole `<div class="auth-gate" id="authGate">…</form></div>` block; change `<body class="auth-locked">` → `<body>`.
2. Drop old CSS rules: `body.auth-locked{overflow:hidden}` and `body:not(.unlocked) .dashboard{visibility:hidden}` (also ensure `.dashboard{visibility:hidden}` → visible; the NEW system gates visibility via `#dashboard` `.visible` class).
3. In `<script>`, delete ONLY the login remnants: `function unlockDashboard`, `function readAuthToken`, `function saveAuthToken`, the `if(readAuthToken()===PASSWORD_TOKEN){unlockDashboard()}else{…focus…}` block, and `document.getElementById('authForm').addEventListener('submit', …)` (the `btoa(input.value.trim())===PASSWORD_TOKEN` handler).
4. **KEEP** `const PASSWORD_TOKEN`, `SALES_SAFE_LIMIT`, `SALES_OVER_LIMIT`, `RATIO_GREEN_MAX`, `RATIO_ORANGE_MAX`, the `liveClockFormatter`/`updateLiveClock` block — those are dashboard logic, not login. `PASSWORD_TOKEN` is harmless once the old gate is gone.
5. Confirm no dangling refs: `grep -c authError index.html` = 0 (the `authError` div lives inside the removed `authForm`).

Verified result: `loginBtn`=2, `authGate`=0, `auth-locked`=0, `unlockDashboard`=0, `authForm`=0, `authError`=0, one `<script>`.

## Verify with jsdom (the NEW system needs a crypto.subtle mock)
jsdom does not ship `crypto.subtle`, so `checkPassword()` (async sha256) throws `Cannot read properties of undefined (reading 'digest')` and reports 密码错误 even with the right password. Inject a mock before calling it.

```bash
cd cache && npm install jsdom --no-save
cat > verify.js <<'EOF'
const {JSDOM}=require('jsdom');
const crypto=require('crypto');
const fs=require('fs');
const html=fs.readFileSync('index.html','utf8');
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://pseudomazo-ship-it.github.io/shiyi-dashboard/',pretendToBeVisual:true});
const {window}=dom;
// mock crypto.subtle so sha256() works under jsdom
window.crypto=window.crypto||{};window.crypto.subtle={
  digest:(alg,data)=>{const h=crypto.createHash('sha256').update(Buffer.from(data)).digest('hex');return Promise.resolve(new Uint8Array(Buffer.from(h,'hex')));}
};
setTimeout(()=>{
  const d=window.document;
  d.getElementById('passwordInput').value='mq520520';
  window.checkPassword().then(()=>setTimeout(()=>{
    console.log('loginOverlay display :', JSON.stringify(d.getElementById('loginOverlay').style.display)); // expect none
    console.log('dashboard visible   :', d.getElementById('dashboard').classList.contains('visible'));        // expect true
    console.log('table rows          :', d.getElementById('tableBody').querySelectorAll('tr').length);          // expect 41
    console.log('errorMsg show       :', d.getElementById('errorMsg').classList.contains('show'));             // expect false
    window.logout();
    console.log('after logout overlay:', JSON.stringify(d.getElementById('loginOverlay').style.display));       // expect flex
  },400)).catch(e=>console.log('checkPassword threw:',e.message));
},300);
EOF
node verify.js
```
Pass criteria: `loginOverlay display: "none"`, `dashboard visible: true`, `table rows: 41`, `errorMsg show: false`, and after `logout()` the overlay returns to `"flex"`. Any single failure = the merge still isn't clean.

Note: the earlier `authForm`/`unlockDashboard` jsdom snippet in SKILL.md only exercises the OLD system. Use this file for the NEW system.

## Push + confirm (trust the content, not the push exit code)
`git push` may print `Recv failure: Connection was reset` / `Empty reply from server` and STILL land. Confirm with `git status -sb` (no `ahead N`) and fetch the live URL, asserting `loginBtn`=2 and `authGate`=0 — both must hold before telling the user it's fixed. After a clean merge push the live build was 523,829 bytes.
