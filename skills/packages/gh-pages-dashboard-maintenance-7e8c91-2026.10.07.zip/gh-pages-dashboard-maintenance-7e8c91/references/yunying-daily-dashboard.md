# 看板③ 运营数据日报看板 — 可复用模板与算法

生成器：`E:\RuanJian\Hermes\scripts\daily_dashboard.py`
输出：`cache\shiyi-dashboard-git\daily\index.html` + 工作区副本 `数据--数据日报\日报看板.html`
线上：`https://pseudomazo-ship-it.github.io/shiyi-dashboard/daily/`

结构（**2026-09-27 定版**）：`时间切换(5档) → 6 个 KPI 卡(不吸顶) → 核心指标(仪表盘+环形图) → 总业绩趋势折线图(近7天/近30天/当月) → 各店铺业绩走势(仅近30天) → 店铺趋势小结(仅近30天) → 各店铺业绩 → 各店铺明细 → 数据提示 → 数据小结`
其中**七个板块全部可折叠**（核心指标 / 趋势图 / 走势 / 趋势小结 / 各店铺业绩 / 各店铺明细 / 数据提示 / 数据小结），
长板块（趋势图 / 走势 / 各店铺业绩 / 各店铺明细）**默认收起**，短板块（核心指标 / 数据提示 / 数据小结 / 趋势小结）**默认展开**。

---

## 1. 取数（踩过坑的那一段）

```python
BASE  = "Q6PZbQRH3aZum0skE3Pc8WCVnPh"
TABLE = "tbl9bX2VE4PXRRiM"

def fetch_all(token):
    """⚠️ 必须用 GET /records。records/search 的 page_token 会一直返回同一个值
       （pageToken:500），while has_more 会无限拉第一页且不报错 → 脚本假死。
       实测 GET /records：6,083 条 / 13 页 / 45 秒。"""
    rows, page_token, seen = [], None, set()
    while True:
        url = f"/bitable/v1/apps/{BASE}/tables/{TABLE}/records?page_size=500"
        if page_token:
            url += f"&page_token={page_token}"
        d = req_get(url, token).get("data", {})
        for it in d.get("items", []):
            fs = it.get("fields", {})
            ts = fs.get("日期")
            if not isinstance(ts, (int, float)):
                continue
            day = datetime.datetime.fromtimestamp(ts/1000, tz=CN).strftime("%Y-%m-%d")  # CN=UTC+8
            nm  = str(fs.get("店铺名称（拼多多旗舰店）") or fs.get("店铺名称（拼多多个人店）") or "?")
            rows.append({"d": day, "shop": nm,
                         "p": num(fs.get("当日总业绩")), "r": num(fs.get("退款金额")),
                         "a": num(fs.get("推广花费")),   "o": num(fs.get("成团单量")),
                         "ro": num(fs.get("退款单量"))})
        if not d.get("has_more"):
            break
        pt = d.get("page_token")
        if not pt or pt in seen:          # ← 防死循环的保险，必加
            break
        seen.add(pt); page_token = pt
    return rows
```

- **数字字段（type 2）读出来是字符串** → 用 `num()` 转 float，别直接算。
- `日期` 是 **epoch 毫秒 + UTC+8**，用 `fromtimestamp(..., tz=CN)`；`utcfromtimestamp` 会整体错一天。

## 2. 归集与去重

```python
days = sorted({r["d"] for r in rows})
by_day = {d: {"p":0.0,"r":0.0,"a":0.0,"o":0.0,"ro":0.0,"shops":{}} for d in days}
seen = set()
for r in rows:
    k = (r["d"], r["shop"])
    if k in seen:            # 同一天同店重复登记：只取第一条，不相加
        continue
    seen.add(k)
    v = by_day[r["d"]]
    v["p"] += r["p"]; v["r"] += r["r"]; v["a"] += r["a"]
    v["o"] += r["o"]; v["ro"] += r["ro"]
    v["shops"][r["shop"]] = {"p": r["p"], "r": r["r"], "a": r["a"], "o": r["o"], "ro": r["ro"]}

payload = {"days": days, "byDay": by_day, "byShop": by_shop,
           "meta": {"gen": datetime.datetime.now(CN).strftime("%Y-%m-%d %H:%M"),
                    "today": today_str}}
html = HTML_TPL.replace("__DATA__", json.dumps(payload, ensure_ascii=False))
```

⚠️ **发送当天（today）也要传进 payload**。前端 `resolveBaseDay()` 需要「从哪天起往前找」，
只给 `days`（数据里最后的日期）会退化成「最新有数据的那天」= 就是那个没登齐的日子。

## 3. 基准日 + 时间段切换 + 对比口径（前端 JS）

### 3.1 `resolveBaseDay()` —— 全看板的锚点

```js
function resolveBaseDay(){
  /* ⭐ 2026-09-27 十一定版（照字面实现，别再自作聪明）：
       当天 23:00 之前  →  报「前天」
       当天 23:00 之后  →  报「昨天」（23:45 同步、23:55 推链接都落在 23:00 之后）
     ❗ 必须按「打开页面的当前时间」实时算，不能写死 meta.base_day ——
       否则 HTML 生成后跨了自然天就不对（看板放两天，第二天打开还是旧基准日）。
     ❗ 不按登记完整度回退、不因“这天填得少”而跳天。那天一条没登也要能显示。 */
  const now = new Date();
  // 转北京时间（东八区）
  const cn = new Date(now.getTime() + (now.getTimezoneOffset() + 480) * 60000);
  const back = cn.getHours() >= 23 ? 1 : 2;      // 23点后→昨天；23点前→前天
  cn.setDate(cn.getDate() - back);
  const b = cn.getFullYear() + '-' +
            String(cn.getMonth() + 1).padStart(2, '0') + '-' +
            String(cn.getDate()).padStart(2, '0');
  if(!byDay[b]) byDay[b] = {p:0, r:0, a:0, o:0, ro:0, shops:{}};   // 补空天，不崩不跳天
  if(days.indexOf(b) < 0){ days.push(b); days.sort(); }
  return b;
}
```

**❌ 两个已废弃的旧写法（别再退回去）：**
- 用**当天** → 数据在填，天天误报「漏登 13 家」。
- **「从昨天起往前找最近一个登记完整的日子、最多回看 10 天」**（完整度回退）—— 曾是正解，
  但 2026-09-27 十一**明确否定**：「不按登记完整度回退，定哪天就报哪天」。
  那天只登了 1 家也照报，漏登交给「数据提示」统计。

**自检手法（必跑）**：用 `browser_exec` + 覆盖 `window.Date` 模拟不同时刻，逐行列「时刻 → 基准日」对表：
```js
window.Date = (function(O){ class F extends O{ constructor(...a){ a.length?super(...a):super(T); }
  static now(){ return T; } } return F; })(Date);   // T = 目标时刻的 ms
resolveBaseDay();                                   // 对一下十一给的自检表
```
实测应得：`9/27 14:35→9/25`、`9/27 23:45→9/26`、`9/27 23:55→9/26`、`9/28 08:34→9/26`、`9/30 10:00→9/28`。

### 3.2 `pickDays(w)` / `pickPrev(w, sel)`

```js
<!-- w ∈ 1 | 3 | 7 | 'm' | 30（tab 的 data-w） -->
function pickDays(w){
  const B = resolveBaseDay();
  const iB = days.indexOf(B);
  if(w === 'm'){
    const ym = B.slice(0,7);
    return days.filter(d => d.startsWith(ym) && d <= B);   // 当月1号 ~ 基准日
  }
  return days.slice(Math.max(0, iB - (w-1)), iB + 1);      // 基准日往前 w 天
}

function pickPrev(w, sel){
  if(!sel.length) return [];
  const s = sel[0], e = sel[sel.length-1];
  const d1 = new Date(s+'T00:00:00'), d2 = new Date(e+'T00:00:00');
  if(w === 'm'){                    // 当月 → 上月同期（同起止日，整体 offset −1 month）
    const clamp = (d,y,mo)=>{ const x=new Date(d); x.setFullYear(y); x.setMonth(mo);
                              return x.getDate() !== d.getDate() ? new Date(y,mo+1,0) : x; };
    const f = d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    const a = clamp(d1, d1.getFullYear(), d1.getMonth()-1);
    const b = clamp(d2, d2.getFullYear(), d2.getMonth()-1);
    return days.filter(d => d >= f(a) && d <= f(b));
  }
  const len = sel.length;
  const iS = days.indexOf(s);
  const prev = days.slice(Math.max(0, iS-len), iS);   // 上一个等长区间
  return prev.filter(d => byDay[d]);
}
```

| 档位 | 统计 | 对比 |
|---|---|---|
| 当日 | `B`（1 天） | `B−1` |
| 近3天 | `B−2 ~ B` | `B−5 ~ B−3` |
| 近7天 | `B−6 ~ B` | `B−13 ~ B−7` |
| 当月 | 当月1号 ~ `B` | **上月同期**（上月1号 ~ 上月同日序号） |
| **近30天** | `B−29 ~ B` | 再往前 30 天 |

**5 个时段**（2026-09-27 从 4 个扩到 5 个）。⚠️ 新增一个时段要同步改的地方（漏一个就不一致）：
`pickDays`/`pickPrev`（已通用）、`sumTips` 标签、`cmpLabel`、`periodName`、`cmpName`、
总业绩趋势折线图的显示条件 `(w===7 || w===30 || w==='m')`、tabs 横向可滑（5 个按钮手机不挤：
`.tabs{overflow-x:auto;scrollbar-width:none}` + `.tab{flex:0 0 auto}`）。

- **当月对比是「上月同期」**（9/1~9/23 vs **8/1~8/23**），**不是**「上一个等长区间」（8/24~9/15）。
- **措辞跟着档位变**：`前一日` / `前 3 天` / `前 7 天` / `上月同期`。统一写「较上一周期」= 没改。
- 顶部显式写出两个区间：`统计 9/21 ~ 9/23（3天） vs 对比 9/18 ~ 9/20（3天）`。
- tab 点击处理：`const w = t.dataset.w; render(w === 'm' ? 'm' : +w);` —— 别忘了 `'m'` 不能 `+`。
- 比率类（数值%）→ 差用 **pt**（`cur - prev`）；金额类 → 用 **%**（`(cur-prev)/prev*100`）。

## 4. 总业绩趋势图（仅「近7天」「当月」；**2026-09-25 起是纯 SVG 折线图**）

> ⚠️ **下面的竖柱实现已废** —— 十一在第三次改版里要求「数据方面以表格、仪表盘、柱状图、
> **折线图**、饼图、指标卡…展现」，已换成 `renderLine(sel)`（面积渐变折线图）。
> **代码见 `references/pure-svg-charts.md` 第 3 节。别照着下面写回竖柱。**
> 本节保留的只有「什么时候显示」和「判趋势算法」这两条不变规则。

以**下为历史竖柱实现，仅存档参考**：

```js
const sec = document.getElementById('trendSec');
if((w === 7 || w === 'm') && sel.length >= 2){
  sec.style.display = '';
  const mxD = Math.max(1, ...sel.map(d=>byDay[d].p));
  const peak = sel.reduce((a,d)=>byDay[d].p>byDay[a].p?d:a, sel[0]);
  let dh = '<div class="dchart">';
  sel.forEach(d=>{
    const p = byDay[d].p, h = Math.max(4, p/mxD*150);
    dh += `<div class="dcol${d===peak?' peak':''}">
      <span class="dv">${(p/10000).toFixed(1)}</span>
      <div class="db" style="height:${h}px"></div>
      <span class="dl">${shortD(d)}</span></div>`;
  });
  dh += '</div>';
  document.getElementById('dailybars').innerHTML = dh;
} else {
  sec.style.display = 'none';        // 当日 / 近3天：整块隐藏
}
```

```css
.dchart{display:flex;align-items:flex-end;gap:7px;height:190px;padding-top:14px;overflow-x:auto}
.dcol{flex:1 1 0;min-width:34px;display:flex;flex-direction:column;align-items:center;gap:6px}
.dcol .db{width:100%;border-radius:6px 6px 0 0;background:linear-gradient(180deg,#60a5fa,#2563eb);min-height:3px}
.dcol .dv{font-size:13px;font-weight:800;color:#0f1c2e;font-variant-numeric:tabular-nums}
.dcol .dl{font-size:13px;color:#6b7d95}
```

⚠️ **判趋势必须前后段等长**：
```js
let trend = null;
if(n >= 6){                                  // < 6 天不显示走势
  const h = Math.floor(n/2);
  const f1 = dailyP.slice(0,h).reduce((a,b)=>a+b,0)/h;
  const f2 = dailyP.slice(n-h).reduce((a,b)=>a+b,0)/h;   // ← slice(n-h)，不是 slice(h)
  if(f1 > 0) trend = (f2-f1)/f1*100;
}
```
写 `slice(0,h)` vs `slice(h)` → 7 天变成 **3 天比 4 天**，本次实测近7天被误算成 **−21.3%**，
改成 3v3 后是 **+4.9%** —— 方向都反了。

## 5. 数据小结（跟随时间段）

```js
function renderSummary(w, sel, prevSel, P, R, A, O, pP, pR, pA){
  const n = sel.length;
  const rate = P>0 ? (R+A)/P*100 : 0, pRate = pP>0 ? (pR+pA)/pP*100 : 0;
  const dPct = pP>0 ? (P-pP)/pP*100 : 0;
  const cmpName = (w==='m') ? '上月同期' : (w===1?'前一日':(w===3?'前 3 天':'前 7 天'));
  // 【概况】P / dPct / rate / cmpName
  // 【走势】n>=6 才出：mx/mn 及 trend（见上）
  // 【问题】跑 window.__notice 里的 down / anom / miss
  // 【建议】按档位分支，点名具体店 + 具体数字
}
```

- 结构固定四段：`【概况】→【走势】→【问题】→【建议】`。
- **建议要由数据生成**（点名具体店 + 具体数字），不能是套话。
- ⚠️ **调用顺序**：`renderNotice()`（公告区，固定口径）**必须先跑**，把下滑/漏登挂到 `window.__notice`；
  `render(w)` 再跑并调用 `renderSummary(w, ...)` 取用。反了小结会读不到数据。
- 切档位时同步更新标题右侧口径：`当日口径 / 近3天口径 / 近7天口径 / 本月口径`。

## 6. 店名独占一行 + 折叠 + KPI **不**冻结

```css
/* 店名单独一行，数值/百分比下一行 */
.srow{padding:13px 0;border-bottom:1px solid #eef2f8}
.srow .sname{font-size:16.5px;font-weight:800;color:#0f1c2e;margin-bottom:8px}
.srow .sline{display:flex;align-items:center;gap:10px}
.srow .sbar{flex:1;min-width:0;height:24px;background:#f1f5fa;border-radius:7px;overflow:hidden}
.srow .sbar i{display:block;height:100%;border-radius:7px;background:linear-gradient(90deg,#60a5fa,#2563eb)}
.srow .sval{font-size:16px;font-weight:800;font-variant-numeric:tabular-nums;flex:none}
.srow .srate{font-size:15px;font-weight:800;flex:none;min-width:52px;text-align:right}

/* 折叠标题（箭头用 28×28 圆角徽章，别用小三角——十一嫌小） */
h2.foldable{cursor:pointer;-webkit-user-select:none;user-select:none}
h2.foldable:active{opacity:.55}
.foldArrow{font-size:13px;color:#475467;transition:transform .24s ease;flex:none;margin-left:auto;
  width:28px;height:28px;line-height:28px;text-align:center;border-radius:9px;
  background:#f2f4f7;border:1px solid #ececf1}
h2.foldable.closed .foldArrow{transform:rotate(-90deg)}

/* ⚠️ KPI 卡【不要】吸顶 —— 十一 2026-09-25 明确否掉：
   「这些顶部数据不需要做冻结，正常可滑动即可。不然会影响观感」
   （吸顶会把卡片顶部裁切：圆角没了、左侧色条被削断、文字贴住屏幕顶，他发截图来过）
   用默认 static 即可。唯一保留吸顶的是表格表头：thead th{position:sticky;top:0} */
.kpis{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:13px;margin-top:22px}
/* 卡片统一高度，否则没环比的卡会比别的卡矮 */
.kpi{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px 15px;
  box-shadow:var(--sh1);min-height:104px;display:flex;flex-direction:column;justify-content:space-between}
```

```js
/* 五个板块通用折叠：[标题id, 内容id, 是否默认收起] */
[
  ['trendHead','trendBody',   true ],      // 总业绩趋势
  ['shopHead','shopBody',     true ],      // 各店铺业绩
  ['shopTblHead','shopTblBody', true ],    // 各店铺明细
  ['noticeHead','noticeBody', false],      // 数据提示（短，默认展开）
  ['sumHead','sumBody',       false]       // 数据小结（短，默认展开）
].forEach(function(p){
  const head = document.getElementById(p[0]), body = document.getElementById(p[1]);
  if(!head || !body) return;
  if(p[2]){ head.classList.add('closed'); body.style.display = 'none'; }
  head.addEventListener('click', ()=>{
    const closed = head.classList.toggle('closed');
    body.style.display = closed ? 'none' : '';
  });
});
```

- HTML 里每个折叠块：`<h2 class="foldable" id="shopHead">标题 <span class="cnt"></span><span class="foldArrow">▼</span></h2>` +
  `<div class="card" id="shopBody">…</div>`。
- 切换时间段**要保留折叠状态**（`render()` 只改内容，不重置 `style.display`）。
- ⚠️ **历史教训（方法通用，吸顶本身已废）**：本次曾被 `@media(min-width:1180px){position:static}` 坑过 ——
  桌面验证时 `getComputedStyle().position` 返回 `static`，看着像功能没生效。
  **验证任何 `position` 效果，一律读 `getComputedStyle(el).position` 的计算值，
  不要相信「我写了这条 CSS」。**
- **验证 KPI 不吸顶**（现在的期望值）：`getComputedStyle(kpis).position === 'static'`，
  且 `window.scrollTo(0,900)` 后 `getBoundingClientRect().top` 应从正数变为**明显负值**（证明它随页面滚走了）。

## 7. 明细表字段（十一 2026-09-25 指定）

`店铺名 | 业绩 | 环比 | 数值 | 推广费占比 | 退款占比 | 客单价`，按业绩降序 + 末尾合计行。

⭐ **「环比」= 本周期 vs 同周期**（十一追加：「各版块各店铺业绩数据内新增一个
对比同周期的上涨下滑比例数据」）—— **条形图和明细表都要加**：
```js
// ① 先把对比区间 prevSel 的各店业绩汇总
const prevAgg = {};
prevSel.forEach(d => Object.keys(byDay[d].shops||{}).forEach(nm => {
  prevAgg[nm] = prevAgg[nm] || {p:0};
  prevAgg[nm].p += byDay[d].shops[nm].p;
}));
// ② 每家店
const pv   = prevAgg[nm] ? prevAgg[nm].p : 0;
const cchg = pv > 0 ? (p.p - pv) / pv * 100 : null;   // null → 显示「无对比」，不要显示 0
const cls  = cchg === null ? 'flat' : (cchg >= 0.5 ? 'up' : (cchg <= -0.5 ? 'down' : 'flat'));
const txt  = cchg === null ? '无对比' :
  `${cchg>0?'▲':(cchg<0?'▼':'—')} ${Math.abs(cchg).toFixed(1)}%`;
```
- 条形图：标签放**店名同一行右侧**（`.sname .schg{margin-left:auto}`），涨绿底 / 跌红底 /
  持平（±0.5% 内）灰底；`title` 属性写清基准（「较前 7 天」）。
- 表格：「环比」列**紧跟在业绩后面**，颜色 `var(--good)` / `var(--bad)`。
- ⚠️ **合计行必须同步加这一格** —— 漏了会整行列错位（少一格后面全右移）。
- ⚠️ **自检（一行验算）**：明细表**合计行的环比必须 == KPI 卡「业绩」的环比**
  （本次两边都是 `▲13.4%` ✓）。不等就是 `prevSel` 聚合或用错区间了。

```js
const rA = v.p>0 ? v.a/v.p*100 : 0;      // 推广费占比
const rR = v.p>0 ? v.r/v.p*100 : 0;      // 退款占比
const rt = rA + rR;                      // 数值（= 两列相加，可自检）
const aov = v.o>0 ? v.p/v.o : 0;         // 客单价 = 业绩 ÷ 成团单量
```

- **数值 = 推广费占比 + 退款占比**（自检：两列相加应等于数值列）。
- 数值列 pill **统一 46% 基准**：绿 `<42%` / 黄 `42~46%` / 红 `≥46%`（= 仪表盘标准线）。
  ⚠️ 曾残留 30/20 旧分档，与标准线 46% 矛盾 —— 包括小结文字里误写成「偏高（红线 30%）」。
  2026-09-25 已把**明细表 pill、合计行 pill、条形图右侧百分号、小结 `lvl` 文案**全部改成 46/42。
  （**例外**：异常检测里的 `±50%` 业绩波动、`±20pt` 数值突变是**异常阈值**，不是分档，别动。）
- 早先版本带「退款/推广/单量」原始列 —— 已按十一要求换掉，别退回去。

## 8. 视觉规范（十一拍板，手机优先；**2026-09-25 第三次改版后的定版**）

⚠️ **配色到 2026-09-25 一共改了三轮**（浅灰蓝 → 靖蓝 → 这套）。**看板里的真实色以生成器为准**：
`grep -n ':root' E:\RuanJian\Hermes\scripts\daily_dashboard.py`。下面的令牌是第三次（现行）的。

整体颜色写成 CSS 变量，改一套即可全页生效：
```css
:root{
  --bg:#f4f6f9; --surface:#fff; --surface2:#fafbfc;
  --line:#e7eaf0; --line2:#d5dae3;
  --ink:#12151b; --ink2:#5a6474; --ink3:#98a1b0;
  --brand:#2563eb; --brand2:#3b82f6; --brand-l:#eef4ff; --brand-d:#1d4ed8;
  --good:#0ea472; --good-l:#e9f8f3;
  --warn:#e08600; --warn-l:#fff7e8;
  --bad:#e5484d;  --bad-l:#fdeeee;
  --violet:#7c5cf0; --violet-l:#f2effe;   /* 成团单量 / 数值卡 */
  --cyan:#0891b2;   --cyan-l:#e6f7fb;     /* 退款单量卡 */
  --sh1:0 1px 2px rgba(18,21,27,.04);
  --sh2:0 2px 4px rgba(18,21,27,.05), 0 12px 28px -18px rgba(18,21,27,.16);
  --sh3:0 4px 10px rgba(18,21,27,.06), 0 20px 40px -24px rgba(18,21,27,.22);
  --r:16px;
}
```

| 元素 | 值 |
|---|---|
| 页面背景 | `#f4f6f9`（比第二代的 `#fafafb` 多一点灰，卡片更跳） |
| 卡片 | `#fff` + `1px solid #e7eaf0` + `border-radius:16px` + `box-shadow:var(--sh1)` + **`min-height:126px`** |
| **主色** | **`#2563eb`**（二代用过靖蓝 `#4f46e5`，三代调回蓝——**色值不能当版本凭据**） |
| 正文 / 次级 / 三级 | `#12151b` / `#5a6474` / `#98a1b0` |
| 成功 / 警告 / 危险 | `#0ea472` / `#e08600` / `#e5484d`（三代都换了：`#0f9d58`→`#047857`→**`#0ea472`**）|
| **卡左侧标识条** | `.kpi::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px}` + 每类卡一个色——「专业化」观感主要就来自这个 3px |
| 基础字号 | `17px`（`@media(max-width:480px)` 时 `16px`） |
| KPI 数字 | `32px / 800 / letter-spacing:-1.5px`（手机 `25px`） |
| **KPI 网格** | **`repeat(6,minmax(0,1fr))`**；`max-width:1240px` 时 `repeat(3,…)`、手机 `repeat(2,…)`。**别用 `auto-fit`**——6 张卡会掉成 5+1 |
| 标题前缀条 | `h2::before{width:3px;height:17px;background:var(--brand);border-radius:2px}` |
| 状态 pill | **统一 46% 基准**：绿 `<42%` / 黄 `42~46%` / 红 `≥46%`（= 标准线） |
| 时间切换 | **分段控件**：白底容器 `padding:5px` 包住四个 tab，选中项 `background:var(--brand)` + 白字 + 柔和投影 |
| 图表渐变 | 折线/条 `#2563eb`，环图 `#e5484d`/`#e08600`/`#7c5cf0`/`#0ea472` |

> 用户原话（第三次改版）：「**再换一个美化风格**，看板色调我要**浅色系**的，数据方面以表格、仪表盘、
> 柱状图、折线图、饼图、指标卡、表格、进度图等形式展现，要看起来**高端**，配色配字都要好看。
> **电商数据观感一定要专业化**」
> 二代：「再做一个UI美化，各方面按钮和配色更加高级一些」；
> 一代：「看板内容做好美化，色调偏浅色调；看板内字体大一点，因为更多是手机看的」

### ⚠️ 环比颜色：按「业务好坏」，不是按「涨跌方向」

这是被视觉复审抓出来的真 bug：业绩涨显示绿（对），但**退款涨也显示绿、数值降反而显示红**——全反了。
```js
// goodDown=true 表示「降才是好事」
function delta(cur, prev, ptMode, goodDown){
  if(!prev) return '<div class="d flat">—</div>';
  const diff = ptMode ? (cur-prev) : (cur-prev)/prev*100;                 // pt=比率类，%=金额类
  const s = ptMode ? Math.abs(diff).toFixed(1)+'pt' : Math.abs(diff).toFixed(1)+'%';
  const good = goodDown ? diff <= 0 : diff >= 0;
  const cls  = Math.abs(diff) < 0.05 ? 'flat' : (good ? 'up' : 'down');
  const arrow = diff > 0 ? '▲' : (diff < 0 ? '▼' : '—');
  return `<div class="d ${cls}">${arrow} ${s} <span style="color:#98a2b3;font-weight:500">环比上期</span></div>`;
}
```
调用：
```js
delta(P,     pP,     false, false)   // 业绩      → 涨=绿
delta(R,     pR,     false, true )   // 退款金额  → 降=绿
delta(A,     pA,     false, true )   // 推广花费  → 降=绿
delta(rate,  prevRate, true, true )   // 数值%     → 降=绿
delta(RO,    pRO,    false, true )   // 退款单量  → 降=绿（如果加这个卡）
```
**自检**：`[...document.querySelectorAll('.kpi')].map(k=>k.querySelector('.d')?.className + ' ' + getComputedStyle(k.querySelector('.d')).color)`
—— 断言「退款/推广/数值」三项环比颜色是红（`rgb(190,18,38)`）而业绩是绿（`rgb(4,120,87)`）。

## 8.5 两个「近30天专属」板块 + 板块显隐（2026-09-27 新增）

### 显隐规则（十一定，实测通过）

| 时段 | 显示的板块 |
|---|---|
| 当日 / 近３天 / 近７天 / 当月 | 常规七块（核心指标、趋势图(7/m)、各店铺业绩、各店铺明细、数据提示、数据小结） |
| **近30天** | **只显示「各店铺业绩走势」+「店铺趋势小结」，其余全部隐藏**（顶部时段切换 + KPI 卡保留）|

实现：`render()` **最末尾**（必须在各板块自己设完 display 之后）统一切 `#app > section`：
```js
const ONLY_TREND = (w === 30);
const isTrend = id => (id === 'stSec' || id === 'stSumSec');   // 走势 + 趋势小结 = 近30天专属
document.querySelectorAll('#app > section').forEach(sec=>{
  if(ONLY_TREND){
    sec.style.display = isTrend(sec.id) ? '' : 'none';
  } else {
    if(isTrend(sec.id)) sec.style.display = 'none';
    else if(sec.id !== 'trendSec') sec.style.display = '';     // trendSec 由自己的逻辑管
  }
});
```
⚠️ **必须放 render 末尾** —— 放前面会被各板块自己的 `style.display` 覆盖。
⚠️ **新增一个「某时段专属」板块**时，要同时（a）加进 `isTrend` 列表，（b）加进折叠数组。

### 各店铺业绩走势（`stSec` / `sttrend`）
一行一个店：`店铺名(全名) | 该时段每日业绩折线(铺满整行) | 区间合计 | 相对等长上一段涨跌%`，按区间业绩降序。

```js
/* 折线带悬停：为每一天生成一个透明热区（铺满整列，好命中），不是只在点上放 circle */
function shopSpark(seq, dates, color, uid){
  const n = seq.length; if(n < 2) return '<div class="stempty">数据不足</div>';
  const W=600, H=52, padTop=7, padBot=7;
  const mx = Math.max(...seq), top = mx > 0 ? mx*1.08 : 1;
  const step = W/(n-1), y = v => H-padBot - (v/top)*(H-padTop-padBot);
  const pts = seq.map((v,i)=>[i*step, y(v)]);
  const line = pts.map((q,i)=>(i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1)).join(' ');
  const area = line + ` L ${W} ${H} L 0 ${H} Z`;
  let hotspots = '';
  for(let i=0;i<n;i++){                       // ← 热区：日期/数值写 data-*
    const x0 = Math.max(0, i*step-step/2), x1 = Math.min(W, i*step+step/2);
    hotspots += `<rect class="sthit" x="${x0.toFixed(1)}" y="0" width="${(x1-x0).toFixed(1)}"`
              + ` height="${H}" fill="transparent" data-d="${dates[i]||''}"`
              + ` data-v="${(seq[i]/10000).toFixed(2)}"></rect>`;
  }
  // 渐变面积 + 折线(stroke-width 2) + 首/末端点 + 最高点圆点 + ${hotspots}
}
```
- tooltip 容器 `#sttip`（`position:fixed`），事件委托在 document：
  `mouseover` 显 / `mouseout` 隐 / `touchstart` 显 / `touchend` 隐 / `scroll` 隐（防错位）。
- ⚠️ **验证时若把 `mouseout` 派发到 `document` 上不会隐藏**（`e.target.closest('.sthit')` 为空，看着像 bug）。
  **要派发到热区元素本身**才算数。
- svg 用 `preserveAspectRatio="none"` + CSS `width:100%;height:52px` → 自动拉满成横条。

### 店铺趋势小结（`stSumSec` / `trendSum`）
结构：`【整体】→【上升的店（全部 N 家）】→【下滑的店（全部 N 家）】→【店铺结构】→【建议】`
- 实现 `renderTrendSummary(rows, cur, prv)`，在 `renderStoreTrend()` **末尾**调用（`rows` 在作用域内）。
- 排序：上升降序、下滑升序；持平（±0.5% 内）与「上一周期无数据」的店也**分别列全**。
- 集中度 = 前 3 名业绩 / 总业绩，`≥55%` 算偏高（提醒头部依赖）。

### ⛔ 总结文案纪律（十一 2026-09-27 要求，所有总结通用）

**所有总结/问题列表必须完整列出，不能用「等」「另有 X 家」「…」省略。**
- ❌ 反面（真实抓包）：`⚠️ 15 家业绩下滑（A、B、C 等）`、`【下滑最多】1~3 … 另有 10 家下滑`
- ✅ 正确：`【下滑的店（全部 13 家）】` + 1~13 逐行列完（`店名　前值→现值　▼-x.x%`）
- 涉及位置：数据小结的「业绩下滑」、近30天的「店铺趋势小结」。
- 交付前：`grep -c "另有\|等）\|..."` 应为 0。
- 23 家全列确实长（实测小结 39 行）—— 这是他要的，**别自作聪明截断**。

## 9. 发布

```bash
cd E:/RuanJian/Hermes/cache/shiyi-dashboard-git
git add -A && git commit -m "看板：xxx"
git pull --rebase origin main      # ⚠️ 必须：cron 也会向同一仓库推，直推会被 reject
git push origin HEAD
```

**验证：** 推完等 1~2 分钟 Pages 部署，用 `urllib` 回读 `url + '?v=' + str(int(time.time()))` 断言新片段存在。
⚠️ 本机可能连不上 `github.io`（当次连原有页面也报 `URLError`）→ 那是本机网络问题，**不是看板没发布**；
以 `git push` 的成功输出（`old..new HEAD -> main`）作为发布凭据，并让用户自己打开确认。

⚠️ **git 连不上 GitHub：先试简单循环重试，再上代理。**
2026-09-25 两次遇到：（a）`Failed to connect to github.com port 443 after 21090 ms`（b）`Recv failure: Connection was reset`。
第 4 次重试就成功了 —— 所以**先跑下面这段，不要一上来就改代理配置**：
```bash
for i in 1 2 3 4 5; do
  git push origin HEAD 2>&1 | grep -q -E "main ->|up-to-date" && { echo ok; break; }
  sleep 6
done
```
连试 5 次都不过 → 再按上面「脚本化每日发布 ②」的 `http://127.0.0.1:7897` 代理兜底。
**上线凭据看 `git status -sb` 的 `## main...origin/main`（无 ahead）**，或 `git ls-remote origin main` 的 sha；
用户那边随时可先看本地副本 `数据--数据日报\日报看板.html`，不必等推送。
