#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读 Hermes 会话库的尾部 —— 用于接管另一个窗口的上下文。

用法:
  python tail_session.py --list                  # 看各入口最近的会话
  python tail_session.py --source qqbot          # QQ 那条会话的对话尾部
  python tail_session.py --source weixin --limit 40
  python tail_session.py --session 20260830_224937_35fb9e17 --limit 40

只读打开 state.db（mode=ro），不会影响正在跑的门关/桌面端。
库路径可用环境变量 HERMES_STATE_DB 覆盖。
"""
import argparse
import datetime
import os
import sqlite3
import sys

CN = datetime.timezone(datetime.timedelta(hours=8))
DB = os.environ.get("HERMES_STATE_DB", r"E:\RuanJian\Hermes\state.db")


def connect():
    if not os.path.exists(DB):
        sys.exit("找不到会话库: %s（可用环境变量 HERMES_STATE_DB 覆盖）" % DB)
    uri = "file:%s?mode=ro" % DB.replace("\\", "/")
    return sqlite3.connect(uri, uri=True)


def fmt_ts(ts):
    if not ts:
        return "?"
    try:
        return datetime.datetime.fromtimestamp(ts, CN).strftime("%m-%d %H:%M")
    except (ValueError, OSError, TypeError):
        return "?"


def cmd_list(con, limit):
    rows = con.execute(
        "SELECT id, source, title, last_activity_at, message_count "
        "FROM sessions ORDER BY last_activity_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    if not rows:
        print("（没有任何会话）")
        return
    print("%-24s %-10s %-13s %-6s %s" % ("session_id", "source", "最后活动", "条数", "标题"))
    for r in rows:
        print("%-24s %-10s %-13s %-6s %s" % (
            r[0] or "", (r[1] or "?")[:10], fmt_ts(r[3]),
            (r[4] if r[4] is not None else 0), (r[2] or "")[:36]))


def pick_session(con, source, session_id):
    if session_id:
        return session_id
    row = con.execute(
        "SELECT id FROM sessions WHERE lower(coalesce(source,'')) LIKE ? "
        "ORDER BY last_activity_at DESC LIMIT 1",
        ("%" + source.lower() + "%",),
    ).fetchone()
    if not row:
        sys.exit("没找到 source 含 %r 的会话；先跑 --list 看看有哪些入口" % source)
    return row[0]


def cmd_tail(con, sid, limit):
    rows = con.execute(
        "SELECT id, role, content, timestamp FROM messages "
        "WHERE session_id = ? AND role IN ('user','assistant') "
        "  AND content IS NOT NULL AND length(content) > 0 "
        "ORDER BY id DESC LIMIT ?",
        (sid, limit),
    ).fetchall()
    if not rows:
        sys.exit("会话 %s 没有可读的 user/assistant 消息" % sid)
    n_user = sum(1 for r in rows if r[1] == "user")
    print("会话 %s · 最近 %d 条（时间正序，其中十一发言 %d 条）\n" % (sid, len(rows), n_user))
    for r in reversed(rows):
        who = "十一" if r[1] == "user" else "我  "
        body = " ".join(str(r[2]).split())
        print("[%s] %s  #%s" % (fmt_ts(r[3]), who, r[0]))
        print("   " + body[:400] + ("…" if len(body) > 400 else ""))
        print()


def main():
    ap = argparse.ArgumentParser(description="读 Hermes 会话库尾部（只读）")
    ap.add_argument("--list", action="store_true", help="列出最近会话（按入口看）")
    ap.add_argument("--source", help="按入口过滤: desktop / qqbot / weixin / feishu")
    ap.add_argument("--session", help="指定 session_id（优先于 --source）")
    ap.add_argument("--limit", type=int, default=24, help="条数，默认 24")
    a = ap.parse_args()
    con = connect()
    try:
        if a.list:
            cmd_list(con, a.limit)
        else:
            cmd_tail(con, pick_session(con, a.source or "desktop", a.session), a.limit)
    finally:
        con.close()


if __name__ == "__main__":
    main()
