---
name: cross-window-context-recovery
description: Use when 要接上另一个窗口/平台的聊天记录再继续。
---

# 跨窗口上下文接管

十一同时在多个入口跟我说话：**桌面窗口 / QQ / 微信 / 飞书**。
常见请求：

- 「你看一下 QQ 记录」「看下微信那边」
- 「我们在这里沟通」← 把话题从另一个入口搬到当前入口
- 「刚才那个事接着弄」← 事在另一个窗口做过，当前窗口没有上下文

**目标**：先把那个窗口发生了什么摸清楚（哪些做完了、哪些没做完），再接着干。
**不要**一上来就问「你说的什么事」——那等于让他再说一遍。

## 🔴 反向义务：**在一个窗口谈定的事，要当场写进永久记忆**（2026-09-30 十一定为长久规则）

上面讲的是「**去读**别的窗口」；这一条是反方向 —— 「**让别的窗口能读到**」。

十一原话：「**所有窗口沟通的记忆，在所有窗口都要同步。**
（比如：我在 QQ 跟你沟通好的内容，在微信/桌面沟通时就没有印象，不要出现这种信息不同步的情况）」

**机制（必须先分清，别理解偏）**：

| | 是否跨窗口共享 |
|---|---|
| 记忆 `MEMORY.md` / `USER.md` | ✅ **共享**（所有窗口读同一份）|
| 技能 `skills/*/SKILL.md` | ✅ **共享** |
| **对话历史** | ❌ **不共享**（QQ 里聊的，桌面窗口读不到）|

⇒ **所以「同步」这件事不会自动发生。** 在窗口 A 谈定的结论、口径、规则、新习惯，
**光「当场执行」是不够的** —— 必须**同时把它写进永久记忆**（涉及流程的再更新对应技能），
否则窗口 B 完全无感知，下次他就会说「你怎么没印象」。

**执行动作（每个窗口都要做）**：
1. 他**改口径 / 定新规则 / 纠正做法** → 说完就 `memory` 落一条（**同一个来回里完成，不要拖**）。
2. 改的是**某类任务的做法** → 同时 `skill_manage` 补进对应技能（他自己在其他窗口只会看到技能，看不到这段对话）。
3. 记忆满时**同一批**里淘汰旧的（`operations` 批量原子提交），别因为「装不下」而放弃写入。
4. 要回溯**另一窗口聊过的内容**时用 `session_search`（或下面的会话库直读），**别装作没听过**。

⚠️ **反面案例（本会话）**：另一个窗口把「加班通知」改成「排除阮国熙/博怡」写进了记忆，
而脚本里的 `EXCLUDED` 早已被我清空 —— 我差点照着错记忆去办事。
**纪律：记忆与代码冲突时，`grep` 一遍代码再定谁对，然后把记忆改对**（不是反过来改代码）。

## 为什么不能只靠 session_search

`session_search` 是 FTS，适合「找某个话题的历史」，但：

- 长会话的旧轮次会被压缩成摘要，**最新的几条未必原样返回**
- 十一点名了具体入口（QQ / 微信）时，你要的是**那个会话的原始尾部**，不是跨库匹配

**想看某个入口最近发生了什么 → 直接读会话库**（下面）。
**想按话题找历史 → session_search**（`profile=` 参数还能读另一个 profile 的库，只读）。

## 数据在哪（已核实）

| 项 | 值 |
|---|---|
| 库 | `E:\RuanJian\Hermes\state.db` |
| 会话表 | `sessions` —— 主键是 **`id`**（不是 `session_id`）|
| 消息表 | `messages` —— 外键列叫 **`session_id`** |
| 入口标识 | `sessions.source` ∈ `desktop` / `qqbot` / `weixin` / `feishu` / `cron` / `unknown` |
| 时间 | `timestamp` 是 **Unix 秒**，显示要 +8 转北京时间 |

`sessions` 常用列：`id, source, title, chat_id, message_count, last_activity_at`
`messages` 常用列：`id, session_id, role, content, tool_name, timestamp`

⚠️ **cron 会生成上百个会话**（本机 ~961 个）—— 一定按 `source` 过滤，别全表扫。

## 现成脚本（优先用它）

```bash
# 看有哪些入口、各自最近的会话
python E:/RuanJian/Hermes/skills/productivity/cross-window-context-recovery/scripts/tail_session.py --list

# 看 QQ 那条会话最近 30 条对话
python .../tail_session.py --source qqbot --limit 30

# 指定会话
python .../tail_session.py --session 20260830_224937_35fb9e17 --limit 40
```

## 手工查（脚本不够用时）

```python
import sqlite3, datetime
CN = datetime.timezone(datetime.timedelta(hours=8))
con = sqlite3.connect("file:E:/RuanJian/Hermes/state.db?mode=ro", uri=True)  # ⚠️ 只读
cur = con.cursor()

# ① 按入口列会话（先拿 session_id 和最后活动时间）
cur.execute("""SELECT id, source, title, last_activity_at, message_count
                FROM sessions WHERE lower(source) LIKE '%qq%'
                ORDER BY last_activity_at DESC LIMIT 10""")

# ② 读那个会话的对话尾部
cur.execute("""SELECT id, role, content, timestamp FROM messages
                WHERE session_id = ? AND role IN ('user','assistant')
                  AND content IS NOT NULL AND length(content) > 0
                ORDER BY id DESC LIMIT 24""", (SID,))
```

## 流程

① **定位会话**：先 `--list` 看哪个入口、哪条会话最后活跃（十一说「QQ」就找 `qqbot`）。

② **读尾部**：一般 24~40 条够还原上下文；只读 `user`/`assistant`，别把 `tool` 输出拉进来。

③ **归纳成三栏**（这是给十一看的部分）：
   - ✅ 已完成（带结果：文件路径 / 上线状态 / 数字）
   - ⏳ 进行中（卡在哪、等谁）
   - ❓ 悬而未决（我当时问了他、他没答的）

④ **⚠️ 不要相信另一个窗口的「已完成」**——那是**别的会话的自述**，不是事实。
   动手前花一步**验证真实状态**：文件 mtime、cron job 是否存在、线上内容对不对。
   本会话实踩：QQ 那边说看板已推上线，实际查 `git status` 发现那次 push 没生效。

⑤ **别重做已完成的事**。已定版的产出不要重生成；直接把⏳/❓接着推进。

⑥ **报告要短**，然后立刻执行他这次的新指令。他在当前窗口开口，是要「往下推进」，不是要听你复述纪要。

## 坑

1. **`sessions` 主键是 `id`**；写 `WHERE session_id = ...` 查 sessions 会报 `no such column`。
2. **连接必带 `?mode=ro`** —— 网关/桌面端正在写这个库，别拿写锁。
3. **`timestamp` 是 Unix 秒**，直接 `datetime.fromtimestamp(ts)` 出来是 UTC 的错觉源；统一 `timezone(timedelta(hours=8))`。
4. **按 `id` 排序取尾部**比按 `timestamp` 稳（同一秒内多条时 timestamp 会并列）。
5. **cron 会话淹没结果** —— 不带 `source` 过滤，列表里全是定时任务。
6. **另一个窗口可能正在改同一个文件**。接管后要动文件，**先重新读一遍当前内容**再改；
   （本机出现过：另一个窗口的 agent 把生成好的 HTML 覆盖、多塞了 9 条 CSS 规则。）
7. **另一个窗口的记忆/技能变更可能已生效**，也可能没有 —— 别把「那边说改了」当成「已经改了」。
8. 🔴 **会话注入的那份记忆是「会话开始时的快照」、会过期；磁盘上的文件才是权威** ——
   `E:\RuanJian\Hermes\memories\MEMORY.md`（+ `USER.md`）才是现行版，而且**多窗口在并行维护它**。
   长会话里我脑子里那条规则，很可能已经在别处被改过了。
   **凡要据此下结论或动手改东西之前，先 `read_file` 一遍 MEMORY.md**；
   十一说「**你先同步一下你的记忆**」就是让我干这个（干完要把「哪几条跟我的旧认知不一样」列给他）。
   本会话实踩（2026-09-29，同一轮对话里连错三次，都是他先发现）：
   - 按旧快照说「**微信不渲染换行、只能发图片/txt**」→ 早已修好，换行和 markdown 都正常
   - 按旧快照认定「**加班通知要手写文案**」→ 早就有自动化任务（`ae50fbb9a3ce`，每天 16:00）
   - 按旧快照以为「**加班脚本只是 print、不会自己发**」→ 它默认就自己 `hermes send` 发微信
   同类可查的权威处：`cron/jobs.json`（当前到底有哪些定时任务，`cronjob(action='list')` 更直接）、
   技能目录下各 SKILL.md 的最新修订段、以及工作区里产出过的定稿 md。
9. **同一件事可能被两个窗口各改一遍** —— 技能 / 脚本 / 记忆都是共享文件：
   动共享脚本（`scripts/daily_dashboard.py`、`项目：领航员加班判定\overtime_daily.py` 等）前
   **先 `grep` / `tail` 看当前状态**，别拿上文记忆里的版本直接 patch；
   patch 工具提示 `modified by sibling subagent` 是**信号不是噪音** —— 停下来看对方改了什么，
   再把「我的改动 + 对方的改动」合并，别互相覆盖。

## 验证

- 读出来的最后几条 `user` 消息，能对上十一这次说的那句话（他说「日报日期不对」，那边最后一条就该是这事）
- 归纳里的每个「已完成」，都有**你亲自验证过的**凭据（路径/URL/cron job_id），不是转述
