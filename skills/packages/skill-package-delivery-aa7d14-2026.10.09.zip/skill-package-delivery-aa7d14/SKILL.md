---
name: skill-package-delivery
description: Use when 十一要「把技能打包发我」。打 zip 交付并处理占用锁。
metadata:
  hermes:
    tags: [skills, delivery, zip, packaging, 技能包]
    category: productivity
---

# 技能包交付（把技能打包发给十一）

十一会把一轮工作沉淀成技能，过一阵回来说「**把最新的这个技能打包发我**」。
他要的不是源码归档，是**解压即用、换台机器 / 换个人接手也能跑**的一个 zip。
本技能只管「更新 → 打包 → 交付 → 收尾」这一段；技能内容本身怎么维护，看被包的那个技能。

## 触发

| 十一说 | 我做什么 |
|---|---|
| 「把技能打包发我」「把最新的技能 skill 打包发我」 | 打包 → `MEDIA:` 发他 |
| 「**更新 skill 技能**并打包发我」 | ⚠️ 这半句是**先更新再打包**，别跳过更新 |
| 「打包一份技能包」 | 同上 |
| 「把**所有** skill 的名称和简介、安装包和安装指令汇总**放在一个网页**」 | **打总览页**，见下节（不是打 zip） |
| 「更新一下技能清单网页」 | 重跑生成器 —— **先分辨是哪一版（见下）** |
| 「按这份规则自查全部技能、整理安装包、同步到**现有**网页看板」 | **多 Agent 共用看板**，路径与规格都不同 → 见 `references/agent-kanban-multisync.md` |

### ⚠️ 有两种页面形态，别拿错生成器（2026-10-07）

| 形态 | 生成器 | 产物 |
|---|---|---|
| **简化版（chips 页）** | `scripts/build_skills_page.py --root <skills> --out <html>` | `Hermes技能清单.html` + `skills_index.json` |
| **管理台版（他给了完整规格的）** ← 现行 | `gen_skills_data.py` → `gen_skills_html.py`（**两个要依次跑**） | `skill_manager/skills.html` + `skills_data.json` |

管理台版的脚本本机位置（**暂寄在 `脚本--PDD采集\` 下，属误放**；已问过十一要不要挪，未定）：
```
D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\gen_skills_data.py
D:\Agent.GongZuoQu\Hermes.GZQ\脚本--PDD采集\gen_skills_html.py
产物：D:\Agent.GongZuoQu\Hermes.GZQ\文档--Hermes工作规则\skill_manager\
```
**他再说「更新技能清单网页」时，默认按管理台版更新**（重跑那两个脚本），
不要退回简化版 —— 他看过简化版之后才给出的完整规格，两者不是同一件东西。

## 铁律

1. **先更新 SKILL.md，再打包。** 本次会话学到的东西要**当场写进技能**，
   否则包出去的是旧知识。打包脚本不负责更新 —— 更新是 `skill_manage(action='patch')` 的活。
2. **文件锁不是失败。** 十一常把上一版 zip 开着（预览中 / 解压中），`os.remove` 抛
   `PermissionError`（Windows 上表现为「另一个程序正在使用此文件」）。
   **不要重试到死，也不要干脆跳过清理** —— 改名叫 `_v2` 继续打，
   并在交付里写一句「旧包被占用删不掉，你关掉后我清」。
3. **只发一份。** 不要同时把 `_v1` 和 `_v2` 都发出去（违反「同信息只留最新版」）。
4. **交付前必跑校验**：`zipfile.testzip()` + 列出包内文件与各自字节数。
   「打包完成」这句话要有 `testzip()` 和文件清单撑着。
5. **实事求是：只放能真正跑起来的命令 / 链接 / 地址。**
   十一原话（2026-10-07，看板上本地包却挂着一条用不了的安装口令时）：
   「**既然是本地技能包，没有口令，就不需要口令内容。做实事求是。**」
   → 判断标准很简单：**把这句命令原样粘到「另一台电脑 / 另一个 Agent」上，它跑得起来吗？**
   跑不起来就**整段删掉**，改成一句实话（「本机本地包，没有公网下载地址，给别的机器安装时把 ZIP 一并发过去」）。
   ⚠️ **连带清干净**：按钮 / 段落 / 事件绑定 / 已无人调用的生成函数，四处一起删；
   还要**连累生成脚本一起改**（见下节），否则下次重生成又长回来。
   ⚠️ **不要用「占位」「待补充」凑数**（`disabled` 的按钮、「安装包待补充」这类）——
   那和假口令是同一个毛病。没有就不显示，不要留个空壳。
6. **写完必须复核「我的版本还在不在」。** 十一经常**同时在多个窗口下同一批指令**，
   同一个文件会被反复覆盖（本类任务实测一轮被覆盖 2 次，其中一次 175 条改写 0 条存活）。
   → 写完立刻逐条比对（`sum(1 for e in disk if e['description']==D.get(e['name']))`），
   发现被覆盖就再写一次（**字典文件留着**就是恢复手段）；
   并**主动跟十一说「这个文件建议只让一个窗口改」**，别自己硬扛 ping-pong。

## 🔴🔴 打包/上线之前：**扫技能文件里的明文凭据**（2026-10-08 真发现一处泄露）

**这条是最容易漏的一类泄露**：技能会被**打包成 zip 放在公开页面上**
（`shiyi11.com.cn/skills/` 的 `packages/<slug>.zip`，能直接下载），
所以 **`SKILL.md` 正文里的任何明文密码 / token / 密钥 = 已经发出去了**。

本次实例：`skills-catalog-sync/SKILL.md` 里有一行
「线上：`<https://…/skills/>`　进入密码 **11**」——
是我自己早先为了“好记”写进去的，之后它一路被同步、打包、发布。
已改成「进入密码见 `domain-hosting-access-control` 技能，**不要写进任何会同步到看板的文件**」。

**规矩**：
- **技能正文里绝不写密码 / 密钥 / token**，要指就指「见某某技能」——
  两份技能都没明文，才不会被某一个包带出去。
- **打包前**跑一遍 `scripts/scan_skill_secrets.py`（本技能自带，无依赖）；
  同步到看板之前再跑一遍（`--root <skills>` 扫全库）。
- ⚠️ **发现时要说清“已经发出去的那几版还在”** —— 改源码只挡住下一次打包，
  **历史 zip 已经挂在公开页上了**；要真止血只能换密码，**这条必须主动告诉他，别只报“已改成不带密码”**。
- ✅ 判断标准同铁律 5：**这个字一旦出现在公网可下载的文件里，就等于已经泄了。**

## 包内结构（十一验收过的形状）

```
<label>-技能包_<YYYY.MM.DD>_v<N>.zip
├─ <skill-name>/
│   └─ SKILL.md                  ← 技能主文件（已含本次更新）
├─ scripts/
│   ├─ <主流程脚本>.py            ← 平时只跑这个的那个
│   ├─ <生成器>.py
│   └─ <辅助>.py
├─ 参考-<文档名>_<YYYY.MM.DD>.md  ← 本次改动的说明/核查报告，可选但很有用
└─ README.txt                    ← 上手说明，见下节
```

- 保留技能自己的相对路径（`scripts/`、`references/` 相对技能目录），换机器解压后链接不断。
- **`scripts/` 放的是 Hermes 侧的运行脚本**（`E:\RuanJian\Hermes\scripts\`），
  跟技能目录里的 `scripts/` 不是一回事 —— 都要收进去，放同一层 `scripts/`。

## README.txt 骨架（9 节，照抄结构换内容）

固定顺序，标题用全角【】：**是什么 → 结构 → 怎么用 → 纪律 → 口径 → 现状 → 数据源/产物 → 坑 → 验证清单**。
完整骨架见 `templates/pack_readme_skeleton.txt`，直接复制改内容。

要点：
- 「怎么用」必须给出**一条能直接粘贴运行的完整命令**（含解释器绝对路径），别写成「运行 xx 脚本」。
- 「纪律」把该技能最容易犯的 2 条放最前面（如一「照字面实现别自作聪明」、二「总结必须全量列出」）。
- 「坑」段直接用 SKILL.md 里的编号清单，不要另写一套。
- 有密码 / 凭证的：写「访问密码 12511251」这类**用户已知的**，**不要把 token、secret、哈希写进 README**。

## 另一种交付形式：技能清单网页（全库总览）

十一 2026-10-07 要的：「**把你所有的 skill 的名称和简介，对应的安装包和安装指令都汇总放在一个网页，创建一个网页**」。
他要的不是某一个技能包，是 **整个技能库的一页目录** —— 看自己有什么能力、并知道怎么搬到别的机器。

```bash
"E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" \
  "E:/RuanJian/Hermes/skills/productivity/skill-package-delivery/scripts/build_skills_page.py" \
  --root "E:/RuanJian/Hermes/skills" \
  --out  "D:/Agent.GongZuoQu/Hermes.GZQ/文档--Hermes工作规则/Hermes技能清单.html"
```

页面形态（他验收过）：顶部 5 个统计卡 → 搜索框 + 分类 chips（全部 / 专属定制 / 各分类）→
每技能一张卡（名称 + 类型/分类/体积标签 + 简介 + 磁盘路径 + **两条可一键复制的命令**）。
两条命令就是他要的「安装包 / 安装指令」：
```
安装/迁移  cp -r "<skill 路径>" "<目标机>/skills/<分类>/"
打包发送  cd "<skill 目录>/.." && zip -r "<skill>.zip" "<skill>"
```
**技能本身就是文件夹 —— 所以「安装包」= 那个文件夹，「安装指令」= 复制它。** 页面底部再补一段
「整包迁移：把 skills 根目录整个拷过去」，并提醒**脚本里的绝对路径换机器要改**。

交付：`desktop_preview(action='open', url=<html 路径>)` 当场给他看 + `MEDIA:` 给一份文件。

### ⚠️ 两个分不清的分类维度（本次踩了，别再宣称精确）

页面上「自建 vs 内置」这类标签，**做不到准**，两种判法都试过：

| 判法 | 结果 |
|---|---|
| 按名字关键词白名单（`pdd-`/`feishu-`/`xlsx`…） | ❌ 误判 5 个：`docx`/`xlsx`/`hermes-agent-skill-authoring`/`windows-desktop-maintenance`/`windows-electron-app-verify` 都是自带的 |
| 按「简介含中文」判**专属定制** | 🟡 好用但约 10% 偏：`baoyu-infographic`/`cocoloop`/`zhongkui-skill`/`feishu`/`feishu-api` 是市场/自带的 |

**做法**：用第二种，但①标签文字写成「专属定制 / 通用工具」（描述性，不是断言）；
②**主动告诉十一这个标签是近似的**，并说「要精确区分得我逐个手工核，你要的话我去核」——
本次直接这么坦白，他没追问。**别把猜出来的分类当成事实汇报。**

另外两个小坑：
- `skills_list` 报的条数（166）与扫盘 `SKILL.md` 数（180）**不等**，因为有 `.bak`/未启用副本。
  重名要去重（优先留非 `bak` 的那份），否则页面上出现重名卡。
- 扫盘要把 **plugins / `.bak_*` / `@clawhub_*` / `@user_*`** 目录一并列上（能看出哪些是外部装进来的），
  但这些是**只读展示**，不要写回。

### 升级版形态：Agent Skills 管理台（十一 2026-10-07 给的完整规格）

看过第一版 chips 页面后，他**直接给了一份完整产品规格**，要的形态重得多。
遇到他贴规格，就按这个做，**别再用简化版**。

**布局**
```
顶部导航（fixed, 64px）：图标 + 站名 | 技能总数 | 更新时间（可加 专属定制/分类）
筛选栏（sticky top:64px）：搜索框 + 分类▾ + 适用Agent▾ + 安装方式▾ + 重置 + 计数
主体：卡片网格（3列） + 右侧 sticky 详情面板
页脚：维护说明 / 技能怎么用 / 安装到别的机器 / 反馈 + 更新时间
```

**响应式**：桌面 3 列 / <1400px 2 列 / <1100px 单列。窄屏时点卡片改为**全屏详情页**（带返回键 + ESC）。
**用 `window.matchMedia('(max-width:1100px)')` 在 JS 里判断**，不要只靠 CSS 隐藏 —— 桌面版和移动版的详情渲染路径不同。

**设计规范（他逐字给的，照做）**
```
主色 #2B6CB0 ｜ 背景 #F7F9FC ｜ 卡片 #FFFFFF + 阴影
字体 system-ui + 微软雅黑
卡片间距 24px ｜ 内边距 24px ｜ 圆角 12px
顶部导航固定，筛选栏 sticky top:64px
```

**详情面板 7 个板块**：简介 / 基本信息（版本·适用Agent·体积·安装方式）/ 安装指令（可复制）/
安装包位置（可复制路径）/ 来源 / 注意事项 / 更新时间。

**数据字段（11 个，他要的）**
```
name / description / version / category / agent / install_method /
install_command / package_url / source_url / notes / updated_at
```

**⚠️ 数据必须内联进 HTML**
`file://` 协议下 `fetch` 读本地 JSON 会被浏览器拦（CORS），**双击打不开**。
做法：数据同时写 `skills_data.json`（供别的程序用）+ 内联成 `skills.html` 里的 `const DATA = [...]`。
**JSON 是副产品，HTML 才是交付物** —— 他说「双击即可打开」就是指这个。

**`notes` 字段怎么来**：从 SKILL.md 正文抽「坑 / 注意 / ⚠️」章节的头两条，
去 Markdown 标记、截 160 字。抽不到就写「无特殊注意事项」。

**⚠️ 两个下拉实际只有 1 个值 —— 要主动说明，别装作是筛选**

| 下拉 | 实际值 | 原因 |
|---|---|---|
| 适用Agent | 全是 `Hermes（通用）` | 技能都是 Hermes 的，没有 Codex/Claude/GPT |
| 安装方式 | 全是 `手动（文件夹复制）` | 技能 = 文件夹，不存在 npm/pip/git 安装 |

他规格里写了多值，但实际没有 → **直接告诉他「这俩现在是摆设」**，
并建议把「安装方式」换成**「来源筛选」**（专属定制 / Hermes 内置 / 市场安装 / 外部技能），
那个真有区分度。**猜一个假的分类维度比说"没有"更糟。**

**来源判定（比名字关键词准）**：`@clawhub_*` / `@user_*` 前缀 → 市场安装；
`ima-skill*` → 外部技能；`ecommerce` 分类 → 自建；其余 → Hermes 内置。

本次实测数据：**176 个技能 / 20 个分类 / 自建 39 / 内置 132 / 市场 3 / 外部 2**。

## 打包

```bash
# 通用打包器（自动找技能目录、收脚本、清理旧包、处理占用锁）
"E:/RuanJian/Hermes/hermes-agent/venv/Scripts/python.exe" \
  "E:/RuanJian/Hermes/skills/productivity/skill-package-delivery/scripts/pack_skill.py" \
  --skill daily-report-dashboard \
  --label 数据日报看板 \
  --out "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报" \
  --scripts run_daily_report.py daily_dashboard.py daily_report_push.py \
  --ref-md "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报/数据日报看板改版说明_2026.09.27.md" \
  --readme "D:/Agent.GongZuoQu/Hermes.GZQ/数据--数据日报/_pack_readme.txt"
```

输出：zip 绝对路径 + 逐文件字节数 + `testzip()` 结果。

## 交付

```
MEDIA:<zip 绝对路径>
```

报告里给全四样：**包内结构树（带字节数）/ README 写了哪几节 / 本次 skill 改了哪几处 / 校验结果**。
⚠️ 如果这一轮同时有旧包被占用删不掉，**单独点出来**并说「关掉后我清」。

### ⭐ 默认就再放一份到桌面（2026-10-08 实求）

十一先说「**把技能包发我**」，拿到 `MEDIA:` 之后又跟一句「**单独把这个技能包放在电脑桌面**」——
说明「发我」+「放桌面」是他的实际使用习惯（聊天里的文件过阵就不好找了，桌面双击就能解压）。

```bash
cp "/e/RuanJian/Hermes/skills/productivity/<skill>.zip" \
   "/c/Users/Administrator/Desktop/" && \
  ls -lh "/c/Users/Administrator/Desktop/<skill>.zip"
```

- **桌面上直接放 zip 文件**，不要建文件夹、不要解压（他要的是双击就能用）。
- 顺带用 `ls -d "/c/Users/<user>/Desktop" "/c/Users/<user>/OneDrive/Desktop"` 确认桌面真实位置
  （本机是 `C:\Users\Administrator\Desktop`；若重定向到 OneDrive 则放 OneDrive 那份）。
- **验证后把绝对路径报给他**（一行）：`C:\Users\Administrator\Desktop\<skill>.zip   (N KB)`，
  别只说「已放桌面」。
- 他**没明说放桌面时**，仍以「发他 MEDIA + 写在工作区」为主；
  但同一轮里他**先要 zip、过一会又说桌面**的情况很常见，主动补上这一步比等他再说一遍好。

### 交付到**别的渠道**（他在微信说「把技能打包发我 QQ」）

跨渠道点单很常见：人在这边聊，东西要发那边。`MEDIA:` 写在回复里只会落到**当前渠道**，
要发去别处得走 CLI：
```bash
"E:/RuanJian/Hermes/hermes-agent/venv/Scripts/hermes.exe" send \
  --to "qqbot:B442F9FE60F6270750FBB0E59D838EFF" \
  "得物规则中心采集 · 技能包（2026.10.04 v1）｜6 个文件 / 15.6 KB / 校验 OK

MEDIA:D:/Agent.GongZuoQu/Hermes.GZQ/数据--得物规则中心/得物规则中心采集-技能包_2026.10.04.zip"
```
- **附件只能靠正文里的 `MEDIA:<绝对路径>`**；`-f/--file` 读的是**纯文本正文**，不是附件。
- `hermes.exe` 要写绝对路径（`<Hermes>\hermes-agent\venv\Scripts\hermes.exe`）—— 新 shell / cron 的 PATH 里没有它。
- 回执只有 `sent` 一行（`hermes send` 没有读回接口）。⚠️ **它只证明“网关收下了”，不等于他真收到**：
  2026-10-08 往 QQ 发技能包 zip 回就是 `sent`，但十一既没确认收到也没抱怨。
  → **发文件到 QQ 时，交付话术里带一句「收到了说一声」**；
  真没收到就改走微信（`hermes send --to weixin:<chat_id> "MEDIA:<路径>"`，微信是确定支持 MEDIA 的）。
  （`im-output-formatting` 里对 QQ-MEDIA 也标着「结论待重验」，两边口径一致，别再各自宣布一次。）
- **回复渠道铁律照样成立**：文件发他点名的那边，**文字说明仍只在他找我的那个渠道回一次**，别两边都贴。

## 收尾

- 打包用的临时 README（`_pack_readme.txt`）留在产出目录即可，下次覆盖写，不算交付物。
- **旧包清理**：正常情况同目录只留最新一个；被占用就先留着，**下次碰这个目录时先扫一遍再删**，
  `glob("<label>-技能包_*.zip")` 排序后除最新全删。

## 第三种形态：多 Agent 共用看板（Codex 工作区，2026-10-07）

十一给的 8 节规格：适用范围是 **WorkBuddy / Claude / Codex / Hermes 及以后新增的桌面 Agent**，
要求把各 Agent 的技能汇总进**同一个**看板。

```
D:\Agent.GongZuoQu\Codex.GZQ\项目：Skill资源库\skill_manager\
  skills.html ／ skills_data.json ／ packages\
```

**与上面两个形态的关键差别**：这是**别人的工作区、别人的数据和包**，
铁律从「只留最新」变成「**合并，绝不覆盖别人新增的**」。

⚠️ **完整操作手册在 `references/agent-kanban-multisync.md`** —— 开工前必读。
最要命的三个坑（都真的踩了）：
1. **同名包会覆盖别人的** → 自己加 `-h` 后缀，并从源目录把别人的包**重新打包还回去**；
2. **`re.sub` 的替换串会把 `\n` 还原成真换行** → 内联 JSON 写坏、页面白屏（改用 `lambda m:`）；
3. **ID 撞号** → 点 A 卡详情显示 B（合并后必须全局重编号 + 断言唯一）。

另一条：**别人的生成脚本（`build_catalog.py`）一跑会整体替换内联数据**，把其他人的条目冲光 →
按规格要求「同步修改生成逻辑」，改成只覆盖自己 Agent 的条目。

**删字段也要改生成脚本（2026-10-07 实修）。** 十一说「清」之后，光删 `skills_data.json`
里的 `install_command` 没用 —— `build_catalog.py` 下次生成会重建它。要清就得三处一起：
① 数据里的字段；② 别人的生成脚本（`command = f"…"` / `install_command=command,` /
`entry['install_command'] = f"…"` 三处）；③ 自己这次用的合并脚本。
**清完在全仓复扫一遍**（`.py/.cjs/.js/.html` 里 `grep install_command`），确认 0 残留再收工。

口径变化与页面改动的完整记录在 `references/agent-kanban-multisync.md` **第 8、9、10 节**
（本地包去口令 / 清字段 / 模板 `${{}}` bug / 多窗口覆盖事故 / **恢复口令的三个托管方案与风险**），
改这个看板、或十一问「能不能用口令下载」之前，先看那三节。

### ⛔ 往线上发之前：Codex 那份是**开发版，没有密码门**（2026-10-07 真踩）

这个看板有两份文件，**形态不同**，别当成同一份：

| 文件 | 性质 | 密码门 |
|---|---|---|
| `Codex.GZQ\…\skill_manager\skills.html` | **开发版**（本地预览） | ❌ 无 |
| `cache/shiyi-dashboard-git/skills/index.html` → 线上 `shiyi11.com.cn/skills/` | **发布版** | ✅ 有 |

⛔ 直接把开发版 `cp` 过去 = **线上密码门当场消失**。
✅ 正确做法：**只搬字段**（`description` / `full_description`），其余一字不动。
**覆盖前先比门禁关键字**（`password` / `gate` / `login` 在线数）：线上 >0、本地 =0 → 本地是开发版。

另：`merge_kanban.py` 的 `"full_description": d` 原本与短简介同值，`detail_*.py` 那份长简介
从未被读 → 已改为 `DETAIL.get(name, d)`（改完清 `__pycache__`，`load_mod` 走 importlib 会读旧的）。
它最后一段 `assert 分类按钮锚点` 会在 HTML 被别的窗口改过时失败 —— 那时 **JSON 已写、HTML 没写**，属正常，
继续走「只搬字段」即可。

> 完整流程与去重脚本：**`gh-pages-dashboard-maintenance` 技能的
> § 看板⑤ 与 `references/skills-catalog-page.md`**。
> （本节只管“怎么把东西发出去”，页面本身的坑归那边 —— 两边都标一条，免得以哪边先加载为准。）

## 技能目录卫生：重名 / 备份残留 / 子模块误收（2026-10-07 实修）

十一说「**名称有歧的修改一下**」时的标准做法。三类毛病一次扫出来：
先跑 `scripts/find_skill_name_collisions.py`（只读，实测当场抓出 2 处真问题）。

| 毛病 | 症状 | 根因 | 修法 |
|---|---|---|---|
| **重名** | `skill_view('x')` 报 `Ambiguous skill name: N skills match`，必须手打全路径才能加载 | **技能名取自 `SKILL.md` 的 `name:` 字段，不是目录名** —— 备份目录里的 SKILL.md 仍写着原名 | **把旧版目录移出技能加载目录**（改文件夹名没用！） |
| **备份/存档残留** | `.bak_1.1.8/`、`.archive/` 被当成技能扫进来、重复计数 | 放在 `skills/` 下就会被扫 | 同上，整体移出 |
| **子模块误收** | 某技能的子章节（如 `ima-skill/knowledge-base`、`notes`）在看板上变成独立技能 | 子模块也有 `SKILL.md`，但**没有 `name:` 字段** | 扫盘/入库时**排除「无 `name:` 字段的 SKILL.md」**（规格第五节第 4 条：不把子章节误当独立技能） |

### 移出（不是删除）的标准动作

十一的规矩是「不删原始数据/模板/脚本/不确定文件」+「动文件前先问」→ **一律移出 + 留说明**：

```bash
SRC="<skills>/旧版目录"; DST="<工作区>/软件--技能旧版备份/<同名>"
mkdir -p "$(dirname "$DST")" && cp -r "$SRC" "$DST"
# 复制完先逐文件校验（文件名+大小），一致才删源
diff <(cd "$SRC" && find . -type f -printf "%p %s\n" | sort) \
     <(cd "$DST" && find . -type f -printf "%p %s\n" | sort) && rm -rf "$SRC"
```

- **别用 `mv` 跨盘**（D:/E: 之间 = 复制+删，中途失败源就没了）→ **`cp` → 校验 → `rm`**。
- 在目标目录写一份 `_为什么在这里.md`：原路径 / 移出时间 / 版本对比 / 恢复命令。
- **动手前先查引用**：`grep -rl "<旧目录名>" <Hermes 根>` 看有没有配置/脚本指过去
  （本次只命中一份说明文档，可安全移走）。
- 判断「哪个是正统版」看 `meta.json` 的 `version` + 文件数，**别信文件夹名** ——
  本次 `ima-skill.bak_1.1.8` 的实际版本是 **1.1.9**，名字本身就是错的。

### 判别原则

- **技能名 ≠ 目录名**：只重命名目录，`skill_view` 依然歧义。
- **有 `SKILL.md` ≠ 是可独立调用的技能**：没有 `name:` 字段的都是别人的子章节。
- 移出后**立刻复扫验证**：重名 0、备份残留 0；再 `skill_view('<原歧义名>')` 确认能加载。

### 下架前的覆盖核对（2026-10-07 新增，**移出旧技能前必做**）

十一说「重复的、旧版的删掉」时，**不能按文件名/日期直接判重复**。
先逐对比较：**章节清单 + 附件（`references/` 里有什么）**，确认新版完全覆盖才移出。

本次三对的实际结论（三种典型结局）：

| 情形 | 例 | 处理 |
|---|---|---|
| 新版逐节覆盖 | `linghangyuan-overtime` 盖掉 `linghangyuan-overtime-judgment`、`overtime-leader-judgment` | 直接移出 |
| 旧版**有新版本没有的附件+内容** | `pinduoduo-store-health-analysis` → 新版 `pdd-store-diagnosis` | **先把附件 `references/….md` 复制到新版目录**、正文补一行引用，**再**移出旧版 |
| 名字像但其实是不同东西 | `claude-code`/`codex`/`opencode`（三个不同 CLI）、两个 Windows 修复技能 | **不重复，保留** |

做法：把两个 `SKILL.md` 的小节标题各列一遍 + `ls references/`，人眼过差异；
判「像重复」时**先看 `references/` 有没有独有附件** —— 正文常常因为引用了附件才显得「短」。
**移出 ≠ 删除**（见上节「移出（不是删除）的标准动作」），误判可恢复，但别拿这个当借口省掉核对。

### 下架后：**看板/清单侧也要跟着清**（2026-10-07 起已自动化）

技能从目录移出后，域名看板（`shiyi11.com.cn/skills/`）上那条旧条目和旧包**不会自己消失**
（当时实测：移走 3 个旧技能后看板仍挂着 354 条）。
这条链路的代码在 `skills-catalog-sync` 技能里（**十一自有技能，curator 只读不改**）——
下面只记口径，免得下次重复推演：

- 自动同步守护（cron `75c6684105eb`，`skills_sync_watch.py`）2026-10-07 起**补齐了删除检测**：
  state 里记一份 `present`（上轮扫到的全部 `(name, agent)`）；本轮算 `present - scanned`
  = 消失的技能，**只对「上轮确实扫到过」的判定** —— 否则嵌套子技能、同名跳过那些
  本来就被过滤掉的会被天天误判成「已删除」。
- **护栏：一次消失超过总数的 30%（且 >3 个）就只告警、不下架** ——
  防某个盘/目录临时不可达时把看板清空。
- 下架动作 = `scripts/drop_skill.py --names a,b,c`（在 `skills-catalog-sync` 目录下）：
  从 `skills_data.json` + **两个 HTML** 的 `const skills=[…]` 移除条目并**重编号 id**
  → 删两处 `packages/<slug>-<date>.zip` → 提交推送 → 验证线上条数。
- **下架是可逆的**（目录回来 → 下轮扫描当新技能重新同步上去），所以不必要求人工确认。
- 脚本动不了时的兜底：手动清一条龙的旧脚本参考 `cache/drop_old_entries.py`（本次清 3 个旧技能用的）。

⚠️ **实测复核（2026-10-09）：“已自动化”目前没落到那几个技能上。**
上面「下架前覆盖核对」表里移出的 3 个技能（`linghangyuan-overtime-judgment` /
`overtime-leader-judgment` / `pinduoduo-store-health-analysis`）**在看板里仍然各留着 1 条记录**
（JSON 和两处 HTML 里都能 grep 到）。可能是 30% 护栏拦下了、也可能是迁移后被重扫回来。
→ 所以「移出后看板会自己清」只能当**预期**、不能当**事实**：
交付/汇报前 **grep 一下看板 JSON 里还有没有这条名字**，有就告诉十一「要清说一声」，
**不要自己删**（`drop_skill.py` 是 `skills-catalog-sync` 的活）。
副作用：批量改简介时撞到这些条目会表现为「HTML 里按标准格式找不到这个 name」——
**别当成自己的替换脚本写错了**（详见 `gh-pages-dashboard-maintenance` 的
`references/bulk-card-copy-update.md` 第 3 节）。

### ⚠️ 批量变化时不要「一个技能推一次」

十一让改一批技能（本次 16 个文件、20 处链接）时，守护脚本会把每个变化的技能**各推一次**
→ 12 个技能 = 12 次 commit+push，每次还要轮询线上验证 ≈ 40 秒 → **一次跑十几分钟、直接超时**。

✅ 正解：待处理 > 1 个时，逐个用 `--no-push` 只改本地，最后
`git add skills/` → 一次 `commit`（`自动批量同步 N 个技能`）→ `pull --rebase` → `push`。

🔴 **同一轮里踩到的 bug（值得记住）**：批量推送那段写成了
```python
st = _S.git(['status','--short'], ...).stdout.strip()   # ← 把 state 字典 st 覆盖成了字符串
```
`st` 原本是 `load_state()` 拿到的 dict，被覆盖后函数末尾 `st['last_scan'] = now` 抛
`TypeError: 'str' object does not support item assignment` ——
**技能其实全部同步成功了，只是最后保存状态时崩了**（现象是「日志看着全成功、退出码 1」）。
→ **长函数里给临时变量起名要避让已有的 state/dict**（`git status` 的结果就叫 `gst`/`dirty`）。
这类「同名覆盖」不会被任何静态检查报出来，只在运行时以毫不相干的 TypeError 出现在无害的那一行。

## 卡片文案与布局（十一 2026-10-07 明确要求，同步数据时别改回去）

**简介是给人「一眼想起这技能能干什么」用的，不是给机器看的摘要。**

1. **两段式**：`功能是什么。……什么时候用。` —— 第二句统一用「**时用**」结尾，全站一致。
2. **要写详细**（他原话「**把技能简介写稍微详细一些，方便我能理解及时想到用处**」）：
   把关键口径 / 范围 / 产出写进去，**中位 ~50 字、上限 78 字**。
   泛泛的「需要按现有口径维护时用」= 不合格；要写成
   「综合分行业排名比前一天低、或比近 7 天均值低就记下，**两条都低才算加班**；加班运营过半则总监陪同；个人店不参与」。
   ⚠️ **同类技能最怕简介长得一样**（三个加班技能原本几乎同文）—— 必须写出**差异点**：
   哪个是出通知的、哪个是定名单的、哪个是改规则的。
3. **长度预算（硬约束）**：卡片简介 `-webkit-line-clamp:4` + `max-height:72px` + `line-height:18px`
   = **4 行 ≈ 78 字**。超了就被截断（只剩 `title` 悬停可看）→ **落盘前先算长度，超了就删字**，
   不要指望卡片自适应。
   ⚠️ **按 ≤72 字写，别贴着上限**（2026-10-08 为此返工三轮：92 → 84 → 80 才过）。
   量的是 `len(字符串)`，**全角标点、`/`、`（）` 都算 1 字**，肉眼估必然偏小。
   写的时候留 8 字余量，比写完再数、再压、再测快得多。
4. **版本号不上卡片**：卡片渲染里去掉 `<span class="version">`（版本仍留在详情页「技能版本」），
   腾出的空间给简介。也可用 CSS `.card .version{display:none}` 兜底，但
   **别在下次同步数据时把它加回来**。
5. **加详细的正确姿势**：**先读一遍当前简介**再改写（别的窗口可能刚重排过格式），
   按 `{技能名: 新简介}` 写成**分批字典文件**，最后按名合并写入 JSON ——
   **不要逐条 patch HTML**，也不要一次写完 175 条。

完整做法（分批规模、合并脚本要点、以及「**哪些动作该做成新技能**」的缺口分析法）
见 `references/skill-card-copywriting.md`。

⚠️ **「详细一些」是加到详情，不是加到卡片**：卡片 `description` 受 4 行 / ~78 字 clamp 限制，
长文本只会被截断；`full_description`（右侧详情面板）才是放开写的地方。
两者分工：**卡片 = 是什么 + 什么时候用；详情 = 口径 / 范围 / 产出 / 坑。**
（2026-10-07 我一度把 130~170 字塞进卡片字段，属超预算；见 `references/agent-kanban-multisync.md` 第 12 节。）

⚠️ **他说「卡片简介，中文简介内容详细一些」时怎么办（2026-10-07 同日第二次发生）**：
他要的“详细”与卡片的 4 行硬限制**是矛盾的**，不要默默二选一：
1. 卡片 `description`：在预算内**尽量把它写满**（写具体口径/范围/结束语「……时用」），**不超 ~78 字**；
2. 长内容全部放 `full_description`（详情面板，无限制）；
3. 交付时**直接说明**：「卡片只有 4 行，我把它写满了；更细的都在详情页」——
   并问他「要不要把卡片也写长（会被截断）」。
❌ 不要因为他说了“详细”就把长文本塞进卡片：他打开看的是**被截掉的半句话**，只会再让你改一遍。

## 相关文件

- `references/skill-card-copywriting.md` — **卡片简介写法与长度预算**（两段式模板、78 字硬上限、
  分批改写流程）+ **技能库缺口分析法**（哪些手工活值得固化成技能）
- `references/agent-kanban-multisync.md` — **多 Agent 共用看板**的完整操作手册（路径、包命名规则、
  五个坑、验收配方、报告口径；含 11. 独创标签与 Agent 专用标签的落地方式）
- `scripts/pack_skill.py` — 通用打包器（打单个技能包 → zip）
- `scripts/scan_skill_secrets.py` — **打包前 / 同步看板前必跑**（只读，无依赖）：扫已知口令 + 
  `Bearer` / PEM 私钥 / `token=…` / 长 base64。**技能会打包成 zip 挂在公开页面上可下载**，
  正文里的明文口令 = 已经发出去了。退出码 0=干净 1=有命中。
  用法：`python scan_skill_secrets.py`（默认扫技能库）／`--root <目录>`（扫工作区或待打包的技能）／
  `-v`（连 LOW 也报）。命中后**先人眼分类**：代码里 `password: str` 这类变量名会误报。
- `scripts/find_skill_name_collisions.py` — **技能目录体检**（只读）：扫出重名 frontmatter、
  备份/存档残留、无 `name:` 字段的子模块。十一说「名称有歧」或入库前先跑它
- `scripts/dedupe_kanban_json.py` — **看板 JSON 去重**（默认 dry-run）：只在同一 `agent` 内按
  `name` 收敛，**不动别人的条目**。跑完合并脚本发现条数暴涨时用它
- `scripts/fix_kanban_entry_text.py` — **看板 HTML 聚焦替换**（默认 dry-run）：合并脚本末尾
  `assert 锚点` 挂掉、JSON 已更新而 HTML 没动时，用它把自己的简介灌进 HTML
- `scripts/build_skills_page.py` — **简化版（chips）清单页生成器**（`--root` / `--out`，无第三方依赖；
  输出 HTML + `skills_index.json`）。只在没给规格时用
- `gen_skills_data.py` / `gen_skills_html.py` — **管理台版生成器（现行）**：前者扫盘出
  `skills_data.json`（含 `meta` + `skills`），后者把数据内联进单文件 `skills.html`。
  ⚠️ 两者分两步跑，改完扫描逻辑要先跑 data 再跑 html，否则页面还是旧数据
- 重生成时的两个细节：① `category` 要把目录名（`ecommerce`/`productivity`…）映射成中文，
  并特判 `@clawhub_*` / `@user_*` → 「市场安装」（否则页面上挂着裸目录名）；
  ② 去重时优先留非 `.bak` 目录的那份，否则页面上出现重名卡

## 坑

1. **`os.remove` 抛 `PermissionError` ≠ 打包失败。** 那是十一开着旧包。换名（`_v2`）继续，
   别为了删旧包卡住整个交付。实测一轮里撞过两次。
2. **别用 `write_file` 直接写 zip 同名文件**：同上锁。命名带 `_v<N>` 是唯一的解。
3. **f-string 里不能带反斜杠**（`f"{re.findall(r'<div[\s>]', t)}"` → `SyntaxError`，
   整个 cell 一行都不执行，表现为「文件没生成」）。正则结果先算成变量。
4. **不要给通用打包器写死某个技能的路径** —— 参数化 `--skill/--scripts/--out`，
   否则第二个技能要复制一份脚本。

## 验证

- [ ] `zipfile.testzip()` 返回 `None`
- [ ] 包内文件数与预期一致，逐项列出字节数
- [ ] `SKILL.md` 是**更新后**的版本（含本轮新加的条目）
- [ ] README 里的运行命令**粘出来能跑**（解释器绝对路径正确）
- [ ] **跑过 `scripts/scan_skill_secrets.py --root <技能库或待打包目录>`**，退出码 0（不是靠眼睛看一遍）
      —— 命令和 token / 明文口令写进包内任何文件都算失败；命中后要判断真凭据还是变量名
- [ ] 若上一步发现的是**真凭据**，已告知十一「**历史 zip 已挂在公开页面上，只能换口令止血**」
- [ ] 交付用 `MEDIA:` 绝对路径
- [ ] 旧包清理状态已说明（已删 / 被占用待删）
- [ ] **交付物里没有跑不通的命令 / 链接**（粘到别的机器上试一遍）；没有「待补充」「占位」这类空壳
- [ ] **移除过字段/功能时，生成脚本已同步修改**，且全仓复扫确认无残留（否则下次生成又长回来）
- [ ] **内容类改动已逐条复核存活**（多窗口并发下最容易被覆盖；字典文件留着以便恢复）
