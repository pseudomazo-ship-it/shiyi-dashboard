# -*- coding: utf-8 -*-
"""通用：把「行」渲染成 PNG 图片（聊天平台不渲染换行时，只有图片能保住排版）

用法：
    from report_image import render
    render([{"text": "标题", "kind": "title"},
            {"kind": "sep"},
            {"text": "【板块】", "kind": "head"},
            {"text": "内容", "kind": "body", "color": "#d93025"}],
           r"E:\\...\\out.png")
"""
from PIL import Image, ImageDraw, ImageFont

FONT = r"C:\Windows\Fonts\msyh.ttc"
FONTB = r"C:\Windows\Fonts\msyhbd.ttc"

DARK = "#1a1a1a"


def render(rows, out_path, pad=36, lh=46):
    """
    rows: list of dicts
        {"text": str, "kind": "title|head|body|sep", "color": "#rrggbb"}
        kind="sep" 时画一条浅灰横线（text 忽略）
    返回生成的图片路径
    """
    f_title = ImageFont.truetype(FONTB, 40)
    f_head = ImageFont.truetype(FONTB, 30)
    f_body = ImageFont.truetype(FONT, 28)

    def font_of(k):
        return f_title if k == "title" else (f_head if k == "head" else f_body)

    widths = []
    for r in rows:
        if r.get("kind") == "sep":
            widths.append(0)
        else:
            widths.append(font_of(r.get("kind", "body")).getlength(r.get("text", "")))
    W = int(max(widths) if widths else 400) + pad * 2
    W = max(W, 520)
    H = pad * 2 + lh * len(rows)

    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    y = pad
    for r in rows:
        k = r.get("kind", "body")
        if k == "sep":
            d.line([(pad, y + lh // 2), (W - pad, y + lh // 2)], fill="#d0d0d0", width=2)
        else:
            d.text((pad, y), r.get("text", ""), font=font_of(k), fill=r.get("color", DARK))
        y += lh
    img.save(out_path)
    return out_path
