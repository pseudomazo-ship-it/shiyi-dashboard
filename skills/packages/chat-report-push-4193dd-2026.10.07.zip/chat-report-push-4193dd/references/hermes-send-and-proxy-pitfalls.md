# `hermes send` / 脚本发消息：三个踩过的坑（2026-09-29）

这一份只讲**脚本或命令行发消息**时的坑；排版方案看 SKILL.md §0 矩阵。

---

## 1. `hermes` 不在 PATH 里 → 一律写绝对路径

在 agent 的 terminal / execute_code 里直接调：

```python
subprocess.run(["hermes", "send", "--to", TARGET, text], ...)
# ❌ 返回码 1：'hermes' 不是内部或外部命令
```

这台机器上可用的路径（随便挑一个）：

```
E:\RuanJian\Hermes\bin\hermes.exe
E:\RuanJian\Hermes\hermes-agent\venv\Scripts\hermes.exe
```

**稳的写法（列表参数 + 绝对路径 + 不带 shell）**：

```python
HERMES = r"E:\RuanJian\Hermes\bin\hermes.exe"
r = subprocess.run([HERMES, "send", "--to", TARGET, text],
                   capture_output=True, text=True,
                   encoding="utf-8", errors="replace", timeout=240)
ok = (r.stdout or "").strip().lower().startswith("sent")
```

- ✅ 成功标志：返回码 0 且 stdout 以 `sent` 开头。
- ⚠️ **别用 `shell=True` 带多行文本** —— Windows cmd 会只留第一行，
  在他那边表现为一条**空白消息**（完整复现见 `blank-message-shell-truncation.md`）。
- ⚠️ `hermes send` **只发纯文本**（表格会变裸 `|`）；只能用于短通知或**就是要纯文本给他复制**的场景。
- ⚠️ 一次发多段（比如把长文档分段给他复制）时，段间 `time.sleep(4~5)`，别连着轰。

**实例**（2026-09-29）：十一说手机不方便收文档，要我把几千字的档案**直接贴成消息**给他复制。
做法：按章节在 `═══` 处切成 2 段（≈2200 / ≈2050 字符），每段前面标「（第 1/2 段）」
→ 两段 `hermes send` 都返回 `sent`，他回「谢谢」。
（切段阈值参考：单段控制在 **3000 字符以内**。）

---

## 2. 本地代理软件会挡掉国内接口（飞书、QQ 投递）

**现象**（2026-09-29 实踩）：
- 16:05 加班通知任务输出：`⚠️ 加班判定：飞书取 token 失败，今天没算出来`
- 同一时段 cron 投递报错：`Cannot connect to host 127.0.0.1:7897 ssl:default [远程计算机拒绝网络连接]`

**根因**：这台机器装了代理软件（进程 `com.vortex.helper.exe`，监听 **127.0.0.1:7897**）。
Python 的 `urllib` **会读 Windows 系统代理** → 飞书（国内接口）的请求被拉去走代理，
代理一抽风就全挂；而 GitHub Pages 这类走 CDN 的又恰好正常，所以很容易误判成“飞书挂了”。

**修法（在国内接口的脚本开头加，2026-09-29 已加）**：

```python
import urllib.request
# 飞书/国内接口不该走代理；python 默认读系统代理，这里显式绕开
urllib.request.install_opener(
    urllib.request.build_opener(urllib.request.ProxyHandler({})))
```

已加过的地方：
- `D:\Agent.GongZuoQu\Hermes.GZQ\项目：领航员加班判定\overtime_daily.py`
- `E:\RuanJian\Hermes\scripts\daily_dashboard.py`

**排查口诀**：报错里看到 `127.0.0.1:7897` → 直接想到代理，不要往飞书权限/凭证上查。

---

## 3. 转发脚本不能把「空 stdout」当成错误

**背景**：自推型脚本（自己 `hermes send` 的那种）**成功时故意保持 stdout 为空**，
这样 cron 就不会再投递一遍（这是正确设计，见 SKILL.md §4.2）。

**实踩（2026-09-29）**：转发脚本 `scripts/overtime_leader.py` 原本写的是：

```python
print(out or '⚠️ 加班判定：无输出（返回码 %d）' % p.returncode)   # ❌
```

→ 内层脚本成功发微信后本来就是空输出 → 转发脚本把这个当成异常 →
**每天 16:00 都多推一条 `⚠️ 加班判定：无输出（返回码 0）` 的假警报**，十一直接问「什么意思」。

**改法**：

```python
out = ((p.stdout or '') + (p.stderr or '')).strip()
if out:          # 空 = 内层已自推送成功，静默
    print(out)
raise SystemExit(0)
```

**通用规则**：凡是“A 脚本包 B 脚本、把 stdout 交给 cron 投递”的转发层，
**空输出 = 正常（已发过了）**，只有非空才透传。写转发层时先把这条写进去。
