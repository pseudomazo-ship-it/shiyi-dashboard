# QQ 各推送通道的 markdown 渲染能力 —— 实测证据链（2026-09-22）

> 本文件是 `SKILL.md` 第 0 节的证据附录。当下次怀疑「通道行为是不是变了」，先看这里，再重跑第 0.3 节的对照实验。

## 1. 结论（已验证）

| 发送方式 | 底层 | markdown 表格 | 证据 |
|---|---|---|---|
| **cron 任务**（`deliver=qqbot`，no_agent 脚本 stdout） | 网关投递 | ✅ **渲染成真表格**（带边框、表头底色） | 用户回复「✅ 渲染」 |
| **`hermes send`**（CLI 直发） | 直连平台接口 | ❌ **纯文本**，表格显示成裸 `\|` `---` | 用户回复「AB 都没有」+ 截图确认 |
| **agent 对话回复** | 网关，作为 assistant 消息 | ✅ 渲染 | 用户截图里有分栏/边框 |

**无关变量（已排除）**：消息长度、表格数量、`━` 分隔线、`\|` 列数。
测试过「1 张表 / 200 字」的短消息走 `hermes send` → **同样不渲染**；而 79 行 7 张表的报告走 cron → **渲染**。
所以差异**只在于通道**，不是内容。

## 2. QQ 不能发文件（原文报错）

```
send_message MEDIA delivery is currently only supported for
 telegram, discord, matrix, weixin, signal, yuanbao, feishu, whatsapp and slack;
 target qqbot had only media attachments
```
→ qqbot 不在支持列表。十一 2026-09-22 明确「**只发qq不走微信**」，所以不要自作主张改走微信发 xlsx。
需要文件时：① 让他从电脑取 ② 走飞书。

## 3. 手动推送通道（走能渲染的那条路）

因为 `hermes send` 不能用于报表，又经常需要「临时推一份带表格的报告」，所以做了一条常驻通道：

| 项 | 值 |
|---|---|
| 任务名 | **手动推送(markdown通道)** |
| job id | **`fab94fd32361`** |
| 脚本 | `E:\RuanJian\Hermes\scripts\push_qq.py` |
| 内容文件 | `E:\RuanJian\Hermes\cache\qq_push.txt` |
| 归档目录 | `E:\RuanJian\Hermes\cache\push_archive\push_<时间戳>.txt` |
| cron 计划 | `0 4 * * 1`（每周一 4:00，此时无文件=静默，不会误发） |
| deliver | `qqbot` |

**用法（agent 侧）**：
```
1) 把内容写进 cache/qq_push.txt
2) cronjob(action='run', job_id='fab94fd32361')
```
脚本先把文件 `os.replace` 到归档目录再 print，所以：投递重试/重复触发**不会重发**；文件不存在或为空则**静默退出**（no_agent 模式 stdout 为空 = 不投递）。

## 4. 投递自检（不要只看「已发送」）

读 `E:\RuanJian\Hermes\cron\jobs.json`，按 `id` 找到任务后检查：
- `last_status` = `ok`
- `last_delivery_error` = `None`
- `last_run_at` 是刚才那次

`hermes send` 成功只返回 `sent`，**不代表渲染**（渲染与否要看用户那端）。

## 5. 已知遗留（不影响）

`scripts/waiting_sentinel_*.py` 与 `_sentinel_deliver.py` 仍用 `hermes send` —— 它们推的是**微信**短提醒，微信本来就不渲染 markdown，不需改。

## 6. 相关「只发一份」规则

同一份报告**不要既推又贴**（用户会收到两条，一条裸一条渲染）。十一原话口径：**要报告只发一份**。
- 他临时要（「日报发我」）→ 首选**直接在对话回复里给出**（渲染，且只有一条）；
- 需要以「机器人推送」形式出现 → 用手动推送通道（第 3 节）。
