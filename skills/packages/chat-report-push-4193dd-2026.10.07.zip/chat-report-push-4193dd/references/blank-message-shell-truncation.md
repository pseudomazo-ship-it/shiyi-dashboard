# 「空白消息」根因：`shell=True` 截断多行参数（2026-09-29 复现并修好）

## 症状

十一收到一条**空白**（不是「一坨」、也不是缺几行）。典型场景：加班通知这类
「脚本自己 `hermes send` 发微信、成功则 stdout 留空给 cron 兜底」的脚本。
迷惑点：**发送侧一切正常** —— `hermes send` 返回 `sent`、脚本 `exit 0`、cron 留档写着
「无输出（返回码 0）」，只有用户那边是空的。

## 根因

```python
subprocess.run(["hermes", "send", "--to", WX, body],   # body 是多行（含 ``` 围栏）
               capture_output=True, text=True, timeout=120,
               cwd=r"E:\RuanJian\Hermes", shell=True)    # ❌ 元凶
```

Windows 下 `shell=True` 会把 list 拼成一条 cmd 命令行 → **cmd 在第一个换行处截断** →
只把第一行 ` ``` ` 传给了 `hermes send`。他收到的就是一个空代码块。

## 10 秒复现（不打扰用户，先证明再改）

```bash
python -c "
import subprocess
body = '\`\`\`\n第一行\n第二行\n\`\`\`'
p = subprocess.run(['echo', body], shell=True,  capture_output=True, text=True)
print('shell=True  →', repr((p.stdout or '')+(p.stderr or '')))
p = subprocess.run(['echo', body], shell=False, capture_output=True, text=True)
print('shell=False →', repr((p.stdout or '')+(p.stderr or '')))
"
```

实测输出：

```
shell=True  → '```\n'                              ← 只有第一行，后面没了
shell=False → '``` 第一行 第二行 ```\n'            ← 完整
```

## 修法（照抄这个形状）

```python
r = subprocess.run(
    [r"E:\RuanJian\Hermes\hermes-agent\venv\Scripts\hermes.exe",
     "send", "--to", WX, body],
    capture_output=True, text=True, encoding="utf-8", errors="replace",
    timeout=120, cwd=r"E:\RuanJian\Hermes")      # ✅ 去掉 shell=True
```

两个要点，别只改一半：
1. **去掉 `shell=True`**（多行内容绝对不能过 shell）。
2. **顺手把 `hermes` 换成绝对路径** —— cron 环境的 PATH 里常常没有它
   （同源坑：cron 的 PATH 也没有 git，见 `hermes-cron-script-jobs`）。

改完**必须真发一条验证**（发一条 4 行的短测试，问他「看到几行」），别只看 patch 回执。

## 同一个坑的第二处：cron 的 prompt 让 agent 自己拼命令行

哨兵任务（`waiting_sentinel`）的 prompt 原来写的是：

```
hermes send --to "weixin:…" "$(python -c "<读出 header+meta+content 拼接>")"
```

→ **命令替换同样过 shell → 同样在第一个换行处截断** → 十一看到的是
「**转达只有标题、没有正文**」（他为此专程问过一次「什么意思」）。

修法（两层一起改，缺一不可）：
- **prompt 层**：把「自己拼命令行发送」删掉，改成**调用现成的 dispatch 脚本**
  （`scripts/waiting_sentinel_dispatch.py`：它读 emit.json → 逐条 `hermes send`，
  **列表参数、不经 shell、hermes 走绝对路径**），并在 prompt 里写明
  「⚠️ 绝对不要用 `hermes send "$(…)"` 拼命令行发，会截断只发标题」。
- **脚本层**：逐条之间加 `time.sleep(4)` 防微信限流（原来没有间隔，连发易被 `rate limited`）。

**通用规则**：任何「多行内容 → 发聊天」的路径，**都不许经过 shell**。
无论是脚本里的 `subprocess`，还是 agent 在 terminal 里手敲的命令。

## 排查顺序（收到「空白 / 只有标题」时）

1. `grep -n "shell=True" <发送脚本>` —— 命中就直接是这个坑。
2. 没命中 → 跑它的**不推送模式**（`--show` 之类）看内容是否完整。
3. 还正常 → 看是不是**命令替换**在拼内容（`"$(…)"`）。
4. 全都干净 → 再去看通道（限流 / 互动窗口过期 `ret=-2`）。

## 附：为什么不能给聊天里的代码块加按钮

十一要过「代码块加个全屏按钮，方便复制其中一段」。**聊天消息里的代码块加不了按钮** ——
那是客户端渲染的，我方无法注入控件。替代方案（已做过一版）：把内容生成一个**HTML 页面**，
里面给【全屏】【复制全部】【每段单独复制】按钮；先本地出文件给他看，他认可再同步线上。
