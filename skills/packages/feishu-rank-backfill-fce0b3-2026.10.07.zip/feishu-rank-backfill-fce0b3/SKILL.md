---
name: feishu-rank-backfill
description: "Use when 要把 Excel 的「近90天用户评价得分排名」回填到飞书领航员登记表。"
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [飞书, 领航员, 评分排名, 数据回填, Excel]
    related_skills: [feishu-api, linghangyuan-overtime]
---

# 近90天用户评价得分排名 · 回填飞书

## 触发场景

十一说：「飞书里近90天用户评价得分排名是空的，把 Excel 里的填进去」——
或类似「用 Excel 的评分排名补飞书表」。

## 两个数据源

### 目的表（飞书）
```
app : S3r3bHOeXaEJzXsNTfUcpC2Mncd
表  : tbl4h3Q7tsHljiwS   （「领航员·每日登记-4.8⭐」）
字段: 日期 / 运营 / 店铺 / **近90天用户评价得分排名**(type 2 数字) / 领航员综合分行业排名 / 1星~5星 / 花费金额 / DSR(公式) / 评价总数(公式)
规模: 约 7,500 条（22 店 × 395 天）
```

### 源表（Excel，十一提供）
文件：`店铺数据（每日登记）-N.xlsx`（最新版号）
**只有一个工作表**：`【DsR数据】每日登记`

**取数难点：openpyxl 读不了它**（WPS 生成，报 `TypeError: Fill() takes no arguments`）
→ **直接解 xlsx 的 zip + XML**：
```python
import zipfile, re
from xml.etree import ElementTree as ET
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
z = zipfile.ZipFile(P)
sst = ["".join(t.text or "" for t in si.iter(NS+"t")) for si in ET.fromstring(z.read("xl/sharedStrings.xml")).iter(NS+"si")]
sheet = ET.fromstring(z.read("xl/worksheets/sheet1.xml"))
```

**内部结构**（关键，搞错就全错）：
```
行 1  ：日期行。E 列起每列一天，值是 Excel 序列号（45909 = 2025-09-09）
        → 换算 datetime.date(1899,12,30) + timedelta(days=n)
        实际有数据的列：IF(2026-05-01) ~ NU(2026-09-23)

每 9 行一个店铺块，顺序：
  A 列=店名（换行 + 运营名，如「蒙倩彩妆官方旗舰店\n齐钰」）  ← 店名在这
  D 列=短名（如「蒙倩彩妆官方」）
  然后 1星/2星/3星/4星/5星/评价总数/dsr
  最后一行 D 列 = 「近90天用户评价得分排名⏎从【星级体验】查数据」
       ★ **这一行同一列（IF~NU）的值才是排名数据**
```

**读法**：扫 A 列找店名行 → 往下 12 行内找 D 列含「近90天」的行 → 取那行的 IF~NU 值

**22 家店 + 运营对照**（Excel 里就有，不用另找）：
```
朝玲  : 蒙倩官方旗舰店 / 蒙倩药妆官方旗舰店 / 蒙倩个人护理官方旗舰店
袁盼盼: 蒙倩美妆旗舰店 / 蒙倩美发护发官方旗舰店 / 蒙倩美发护发旗舰店
小魏  : 蒙倩护发旗舰店 / 蒙倩染发旗舰店 / 蒙倩护发官方旗舰店
玉珍  : 蒙倩造型官方旗舰店 / 蒙倩旗舰店 / 蒙倩染发官方旗舰店
丽丽  : 蒙倩洗护官方旗舰店 / 蒙倩美发官方旗舰店 / 蒙倩美妆洗护官方旗舰店
轩轩  : 蒙倩精油官方旗舰店 / 蒙倩化妆品官方旗舰店
齐钰  : 蒙倩彩妆官方旗舰店
国熙  : 蒙倩个护官方旗舰店
修炜  : 蒙倩美容护肤官方旗舰店 / 蒙倩美发旗舰店
博怡  : 蒙倩美容美发官方旗舰店
```

## 🔴 转换规则（最容易搞错，实踩）

**十一要的是「百分比数值，两位小数」**，即 `0.2694 → 26.94`。
**但 Excel 里混着两种口径**（同一列！），不能一律 ×100：

```python
v = float(excel_value)
if v < 1:      # 小数口径（0.2847）→ 转百分比
    v = round(v * 100, 2)     # → 28.47
else:          # 已经是百分数（26.54）→ 不动
    v = round(v, 2)
```

**实测分布**：3,113 条是小数（×100），66 条本来就是百分数（不动）。
**那 66 条全在 2026-05，是历史遗留的整数近似**（旧值 26 → Excel 精确值 26.54）。

## 飞书写入

### ⚠️ 必须先关代理（否则拿不到 token）
```python
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))
```
本机有代理软件（127.0.0.1:7897），**飞书是国内接口，走代理会被挡**。

### 凭证与接口
```python
ENV = r"E:\RuanJian\Hermes\.env"        # FEISHU_APP_ID / FEISHU_APP_SECRET
BASE = "https://open.feishu.cn/open-apis/bitable/v1/apps/" + APP

# token
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
     {"app_id":..., "app_secret":...}   → tenant_access_token

# 全量取记录（用 GET，不要用 records/search——page_token 会重复死循环）
GET {BASE}/tables/{TABLE}/records?page_size=500[&page_token=...]
    ⚠ 必带 seen 集合防重复；has_more=false 才停

# 批量写（一次最多 500 条）
POST {BASE}/tables/{TABLE}/records/batch_update
     {"records":[{"record_id":..., "fields":{"近90天用户评价得分排名": 26.94}}, ...]}
```

### 匹配键：(日期, 店铺)
飞书的店铺字段是 array（`[{"text":"蒙倩官方旗舰店"}]`），取值要拆；
日期是毫秒时间戳 → UTC+8 转 `YYYY-MM-DD`。

## 完整流程

1. **读 Excel** → 得 `{店铺: {日期: 值}}`
2. **拉飞书全量** → 建 `(日期, 店铺) → {record_id, 现值}` 索引
3. **比对分类**：
   ```
   现值 = None 或 0  → 要补
   现值非 0 且 ≠ 新值 → 需十一决定（本次是整数近似，直接覆盖）
   现值 = 新值       → 跳过
   ```
4. **转换值**（见上方规则）
5. **⚠️ 小批试写 10 条回读验证**（确认格式被接受，避开全量翻车）
6. **分批 batch_update**（500/批，每批 3 次重试）
7. **回读验证**：按月统计覆盖率 + 抽查具体日期

## 已知边界（2026-09-30 实测）

```
2025-09 ~ 2026-04   飞书空、Excel 也没数据 → 留空（十一确认过）
2026-04-30 ~ 09-23  本次补了 3,179 条
2026-05-14 ~ 05-31 蒙倩染发官方旗舰店 / 蒙倩造型官方旗舰店 —— **源里也空**，补不了
                    （2026-10-07 复核：两家 5/1~5/13 源里有值 13/13，5/14 起源断档；
                    飞书那 36 条记录本身存在、5星/花费都有值，只是排名列空 → 不要删记录）
2026-09-24 之后    飞书已经是对的 → 不动
```

- **未写入 2025-09~2026-03**：两边都没源，补不了。以后若拿到「星级体验」的历史导出再说。
- 备份文件：`E:\RuanJian\Hermes\cache\rank_final.json`（含全部旧值，可回滚）

## 坑

1. **openpyxl 读不了 WPS 的 xlsx** → 解 zip+xml
2. **Excel 日期是序列号**（45909）→ `1899-12-30 + days`
3. **店名在 A 列（带运营，单元格内有换行），不在 D 列**；D 列是短名
4. **排名值在「近90天用户评价得分排名」那一行**，不在星级那几行
5. **两种数值口径混用**（0.2694 vs 26.54）→ 按「<1 就 ×100」判断
6. **飞书 API 必须关代理**
7. **判「已填」不能只看 is not None** —— 0 也算没填（曾因此误判「全有值」）
8. **records/search 的 page_token 会重复** → 用 GET /records
9. **飞书接口偶发 RemoteDisconnected** → 请求函数要带重试（本次加了 4 次）
10. **写线上表不可逆** → 动手前把旧值导成 JSON 备份

## 验证清单

1. 试写 10 条 → `code: 0` 且回读值正确
2. 全量写完 → 抽查 2 个日期各 5 家，值和 Excel×100 对得上
3. 按月覆盖率：2026-06 ~ 09 应为 100%
4. 失败条数应为 0（把失败 record_id 存下来可重试）
