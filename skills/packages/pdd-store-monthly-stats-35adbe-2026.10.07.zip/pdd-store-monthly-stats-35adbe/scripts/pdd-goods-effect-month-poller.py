#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""拼多多「商品数据」页 (/sycm/goods_effect) —— 按月轮询监听器

为什么需要它：该页的月份/日期筛选**对程序化点击无响应**（标签会变、表格数据逐字节不变），
只有真人点击才会真正刷新数据；而数字又是 `spider-font` 加密的（PUA 码点）。
所以正确分工是：**十一点月份，本脚本自动记录**。

用法：
    cd /e/RuanJian/Hermes
    "E:/RuanJian/Hermes/bin/browser-use.EXE" < scripts/pdd-goods-effect-month-poller.py

前置（关键）：
    1. 页面上先把「商品ID」筛选框粘好要查的多个ID，**别动它**（否则只出全店前 10 名）。
    2. 让十一按「点月 → 选月份 → 点输入框右边「查询」→ 停 3~5 秒」逐月走一遍。
    3. 点完读 OUT json；每月一快照，按顺序对应十一点的月份顺序。

解码机制（已验证：字形跨轮换稳定，只换码点不换字形）：
    - 首次运行（无 glyph_ref.json）进入 bootstrap：把当前页 10 个码点的字形渲染成
      glyphs_bootstrap.png，并把码点清单打出来。用 vision 读那张图 → 写出
      glyph_ref_seed.json {"0xE5ED":"5", ...}（10 项）→ 再跑一次即进入自动模式。
    - 自动模式每次 tick 重建映射，页面刷新也不怕。
"""
import base64, json, os, time

WS = os.environ.get("BH_AGENT_WORKSPACE", ".")
OUT = os.path.join(WS, "month_poll.json")
REF_FILE = os.path.join(WS, "glyph_ref.json")          # 自动模式用：digit -> 3136位字形串
SEED_FILE = os.path.join(WS, "glyph_ref_seed.json")    # bootstrap 产物："0xE5ED":"5"
BOOT_PNG = os.path.join(WS, "glyphs_bootstrap.png")
INTERVAL = 4          # 秒
DURATION = 1500       # 总时长（25 分钟）

RENDER_JS = r"""
const __mk = () => {
  const c1=document.createElement('canvas'); c1.width=120; c1.height=170;
  const k1=c1.getContext('2d');
  const c2=document.createElement('canvas'); c2.width=56; c2.height=56;
  const k2=c2.getContext('2d',{willReadFrequently:true});
  return {c1,k1,c2,k2}; };
const __sig = (m,cp)=>{ m.k1.clearRect(0,0,120,170); m.k1.fillStyle='#000';
  m.k1.font='110px spider-font'; m.k1.textBaseline='top';
  m.k1.fillText(String.fromCodePoint(cp),8,6);
  m.k2.clearRect(0,0,56,56); m.k2.drawImage(m.c1,6,2,112,120,0,0,56,56);
  const d=m.k2.getImageData(0,0,56,56).data; let s='';
  for(let i=3;i<d.length;i+=4) s+= d[i]>90?'1':'0';
  return s; };
const __cps = ()=>{ const s=new Set();
  document.querySelectorAll('span.__spider_font').forEach(el=>{
    for(const c of (el.textContent||'')){const cp=c.codePointAt(0);
      if(cp>=0xE000&&cp<=0xF8FF) s.add(cp);} });
  return [...s].sort((a,b)=>a-b); };
"""

SNAP_JS = RENDER_JS + r"""
(() => {
  const m=__mk(), list=__cps(), sigs={};
  list.forEach(cp=>{ sigs['0x'+cp.toString(16).toUpperCase()]=__sig(m,cp); });
  const stat=(document.body.innerText.match(/统计时间[:：][^\n]{0,30}/)||[''])[0];
  const tbs=[...document.querySelectorAll('tbody')].filter(t=>t.querySelectorAll('tr').length>2);
  const tb=tbs[tbs.length-1];
  const rows = tb? [...tb.querySelectorAll('tr')].map(tr=>{
    const tds=[...tr.querySelectorAll('td')];
    const info=(tds[0]&&tds[0].innerText||'');
    const cell=i=> tds[i]? (tds[i].textContent||'').split(/较前|昨日/)[0] : '';
    return {id:(info.match(/ID[:：]\s*(\d{6,})/)||[])[1]||'',
            c:[cell(1),cell(3),cell(4),cell(5),cell(6)]};}).filter(x=>x.id):[];
  return JSON.stringify({stat,sigs,n:rows.length,rows});
})()
"""

BOOT_JS = RENDER_JS + r"""
(async () => {
  if (document.fonts && document.fonts.ready) { try { await document.fonts.ready; } catch(e){} }
  const m=__mk(), list=__cps();
  const c=document.createElement('canvas'); c.width=120*list.length; c.height=170;
  const k=c.getContext('2d'); k.fillStyle='#fff'; k.fillRect(0,0,c.width,c.height); k.textBaseline='top';
  list.forEach((cp,i)=>{ k.fillStyle='#000'; k.font='110px spider-font';
    k.fillText(String.fromCodePoint(cp), i*120+8, 6);
    k.fillStyle='#c00'; k.font='24px monospace';
    k.fillText('U+'+cp.toString(16).toUpperCase(), i*120+4, 128); });
  const sigs={}; list.forEach(cp=>{ sigs['0x'+cp.toString(16).toUpperCase()]=__sig(m,cp); });
  return JSON.stringify({sigs, png:c.toDataURL('image/png')});
})()
"""


def _target():
    for x in cdp('Target.getTargets')['targetInfos']:
        if x.get('type') == 'page' and 'goods_effect' in (x.get('url') or ''):
            return x['targetId']
    return None


def evaluate(expr):
    tid = _target()
    if not tid:
        return None
    sid = cdp('Target.attachToTarget', targetId=tid, flatten=True)['sessionId']
    v = cdp('Runtime.evaluate', expression=expr, returnByValue=True,
            awaitPromise=True, session_id=sid)['result'].get('value')
    return json.loads(v) if v else None


def hamming(a, b):
    return sum(1 for x, y in zip(a, b) if x != y)


def bootstrap():
    d = evaluate(BOOT_JS)
    if not d:
        print('未找到 goods_effect 页面，请先打开并登录')
        return
    open(BOOT_PNG, 'wb').write(base64.b64decode(d['png'].split(',', 1)[1]))
    print('码点清单:', list(d['sigs'].keys()))
    print('字形图已存:', BOOT_PNG)
    print('→ 用 vision 读这张图，写出 %s 形如 {"0xE5ED":"5", ...}（10 项）' % SEED_FILE)


def build_ref():
    """bootstrap 后：用 seed 把 digit->字形串 固定下来"""
    seed = json.load(open(SEED_FILE, encoding='utf-8'))
    d = evaluate(BOOT_JS)
    ref = {seed[k]: s for k, s in d['sigs'].items() if k in seed}
    if len(ref) != 10:
        print('⚠️ seed 与当前页码点对不上（页面刷新过？），请重跑 bootstrap。已匹配:', sorted(ref))
        return None
    json.dump(ref, open(REF_FILE, 'w', encoding='utf-8'))
    print('参考字形已建:', REF_FILE)
    return ref


def decode(raw, M):
    o = ''
    for ch in raw or '':
        cp = ord(ch)
        if 0xE000 <= cp <= 0xF8FF:
            o += M.get(cp, '?')
        elif ch.isdigit() or ch == '.':
            o += ch
    return o


def main():
    ref = None
    if os.path.exists(REF_FILE):
        ref = json.load(open(REF_FILE, encoding='utf-8'))
    elif os.path.exists(SEED_FILE):
        ref = build_ref()
    else:
        bootstrap()
        return

    hist, last = [], None
    end = time.time() + DURATION
    while time.time() < end:
        d = evaluate(SNAP_JS)
        if d and d.get('rows') is not None:
            M = {}
            for key, s in d['sigs'].items():
                best, bd = None, 10 ** 9
                for dg, rs in ref.items():
                    k = hamming(s, rs)
                    if k < bd:
                        bd, best = k, dg
                if bd < 120:
                    M[int(key, 16)] = best
            rows = [{'id': r['id'], 'uv': decode(r['c'][0], M), 'amt': decode(r['c'][1], M),
                     'qty': decode(r['c'][2], M), 'ord': decode(r['c'][3], M),
                     'buyers': decode(r['c'][4], M)} for r in d['rows']]
            tot = sum(int(r['buyers']) for r in rows if r['buyers'].isdigit())
            key = (d['stat'], d['n'], tot)
            if key != last:
                last = key
                snap = {'ts': time.strftime('%H:%M:%S'), 'stat': d['stat'], 'n': d['n'],
                        'mapSize': len(M), 'rows': rows}
                hist.append(snap)
                json.dump(hist, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
                print(snap['ts'], '|', d['stat'], '| n=', d['n'], '| 买家合计=', tot,
                      '| 映射=', len(M), flush=True)
        time.sleep(INTERVAL)
    print('DONE', len(hist), '快照 →', OUT)


main()
