---
name: tanyu-points-consume-collect
description: Use when 十一要采集探域积分消耗页。分页取全量→按店铺汇总出表。
---

# 探域 · 积分消耗采集

## 触发
- 十一发 `https://agent.tanyuai.com/v2/groupAndStore/financial-center/consume`
- 或说「采集探域积分消耗」「登记消耗积分」「每个店铺的积分消耗」

## 一句话流程
读页面当前筛选 → 用页面自己的接口 `POST /api/gc/points-bill/paginate` 逐页取回 → 按店铺/按小时/明细三表出 xlsx → **放桌面**

---

## 一、先读页面状态（必须做，不能猜日期）

十一经常自己改筛选（一天一天采过 9/01-09/07、9/22、9/17、5/15）→ **必须读当前值**：

```python
# 1) 切到探域标签（页面在主浏览器里，不是专用浏览器）
tabs = list_tabs()
ty = [t for t in tabs if 'tanyuai' in (t.get('url') or '')]
switch_tab(ty[0])

# 2) 读筛选 + 总条数
r = js(r"""(() => {
  const ins = [...document.querySelectorAll('input')].map(e => ({ph: e.placeholder, val: e.value}));
  const pg = ([...document.querySelectorAll('[class*=pagination]')]
              .map(e => e.innerText.replace(/\s+/g,' ')).filter(x => x.includes('共'))[0]) || '';
  return { startTime: ins[0].val, endTime: ins[1].val, pager: pg,
           rows: document.querySelectorAll('.ant-table-tbody .ant-table-row').length };
})()""")
# → inputs[0]=开始时间, inputs[1]=结束时间；从 pager 取「共 N 条数据」→ 页数 = ceil(N/100)
```

⚠️ **别用 @url 附件判断登录态**：附件是抓取工具**未登录**的视图，会显示「扫码登录/处于登出状态」，而浏览器实际登着。
**以浏览器里的真实页面为准**（`.ant-table-tbody .ant-table-row` 数量 > 0 = 已登录）。

## 二、取数（关键：接口 + 后台跑 + 轮询）

**接口**：`POST https://agent.tanyuai.com/api/gc/points-bill/paginate`
```json
{"startTime":"2026-09-17","endTime":"2026-09-17","pageSize":100,"pageIndex":1}
```
返回 `{code:1(成功), data:{total, pageIndex, pageSize, results:[...]}}`

行字段 → 页面列：
| 接口字段 | 页面列 |
|---|---|
| `billDate` | 时间 |
| `shopName` | 店铺 |
| `desc` | 消耗类型 |
| `receptionCount` | 应扣积分 |
| `entryReceptionCount` | 实扣积分 |

（另有页面不显示的 `platform` / `thirdShopId` / `type` / `groupId`）

**在页面里发 (带 cookie 鉴权)**，不要在外面用 requests 打：
```python
js(r"""(() => {
  window.__all = []; window.__prog = {done:0, of:N, n:0, bad:[], finished:false};
  (async () => {
    for (let p = 1; p <= N; p++) {
      try {
        const resp = await fetch('/api/gc/points-bill/paginate', {method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({startTime:'YYYY-MM-DD', endTime:'YYYY-MM-DD', pageSize:100, pageIndex:p})});
        const j = await resp.json(); const d = j.data || {};
        if (j.code !== 1) window.__prog.bad.push(p);
        else { window.__prog.total = d.total; (d.results||[]).forEach(r => window.__all.push(r)); }
      } catch(e) { window.__prog.bad.push('p'+p); }
      window.__prog.done = p; window.__prog.n = window.__all.length;
    }
    window.__prog.finished = true;
  })();
  return 'started';
})()""")
# 然后每 3 秒轮询 js('JSON.stringify(window.__prog)') 直到 finished
```

⚠️ **harness 的 js() 有 5 秒响应上限** → 绝不 `await` 一整圈（会 `Runtime.evaluate timed out after 5s`）。**必须页面后台跑 + 轮询进度**。

⚠️ **一次 js() 约能回 ~25KB 字符串** → 超了就按 26KB 分片 `js('window.__csv.slice(a,b)')` 拼回来。

## 三、校验（必做）
- 取回条数 == 接口 `total` == 页面「共 N 条数据」
- `bad` 为空（0 页失败）
- 应扣合计 vs 实扣合计（目前 4 次全相等；不等要单独报告）

## 四、出表 → 桌面

**路径**：`C:\Users\Administrator\Desktop\探域积分消耗_按店铺_<日期>.xlsx`
（十一明确要放桌面；已确认不是 OneDrive 重定向；单日就写 `_2026.09.17.xlsx`）

三个工作表：
1. **按店铺汇总** —— 店铺 / 消耗积分 / 占比 / 记录数 + 按消耗类型拆分列，末尾合计行，冻结首行 + 筛选
2. **按小时汇总** —— 24 个小时桶（时间倒序）
3. **消耗明细** —— 时间/店铺/消耗类型/应扣/实扣，冻结首行 + 筛选

格式：表头深蓝底白字、边框、千分位、打印一页宽。

---

## 五、坑（都踩过）

| 坑 | 真相 |
|---|---|
| **时间列是小时桶的「结束时刻」** | 单日查询会多出**下一天 00:00** 的 22~24 行 —— 那是当天 23:00-24:00 那一小时，**不是多出来的数据**，别剔别慌 |
| 筛选换了不知道 | 十一会自己改日期 → **每次先读 inputs 的值** |
| @url 附件显示要扫码登录 | 那是抓取工具自己的未登录视图 ✗ 浏览器实际登着 ✓ 先查页面再说话 |
| 同名店出现两条 | 同一店名在**不同平台**（`platform` 1/5/7、`thirdShopId` 不同）→ 不是重复登记 |
| 一次 await 全部页 | 撞 harness 5s 上限 → 后台跑 + 轮询 |
| 分页点「2」 | 会让十一的页面停在第 2 页 ✗ → 采完**复位到第 1 页** |
| 日期段跨天 | 接口支持 startTime≠endTime（一次拉整段），此时时间列就是真实日期 |

## 六、交付话术

- 报：页数 / 条数 / 店铺数 / **合计积分** / 应扣=实扣
- 给**全店铺表**（十一要「每个店铺占一行」，markdown 表桌面端能渲染）
- 给文件 `MEDIA:` 路径 + 自检（✅通过项 + ℹ️说明）
- 十一一天一天采时 → 主动提「要不要按日期段批量采、出按天×店交叉表」
