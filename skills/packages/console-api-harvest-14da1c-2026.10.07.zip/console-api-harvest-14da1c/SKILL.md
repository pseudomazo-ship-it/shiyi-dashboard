---
name: console-api-harvest
description: Use when 要从已登录后台网页批量翻页取数出表(探域/商家后台)。
---

# 后台网页批量取数出表（console API harvest）

> 触发：十一给一个**已登录的后台页面 URL** + 「把这个页面所有页数采下来 / 每个 X 的统计，生成表格」。
> 核心一句话：**别点分页按钮 —— 重放页面自己发的那次请求**（筛选条件就在请求体里，改页码循环即可）。
> 实测对象：探域积分消耗明细（配方见 `references/tanyu-points-consume.md`）。

## 一、什么时候用 / 什么时候别用

| 情况 | 做法 |
|---|---|
| 页面有「导出」按钮 | **先试导出**（一次拿全最省事，文件通常在下载目录） |
| 没导出 / 导出不带当前筛选 | 走本文流程（重放接口） |
| 接口是**加密 payload**（如 PDD `xg/pfb/a2`） | 重放不了 → 走 UI 驱动（配方见技能 `pdd-stars-daily-collect`） |
| 数据是服务端渲染 / 接口返回 HTML | 直接解析 DOM 或 HTML |

## 二、标准流程（六步，实测跑通）

### ① 先挂到正确的标签
harness 的 `js()` 只作用于**它当前挂着的**标签。**不要**手搓 `Target.attachToTarget` + `Runtime.evaluate(sessionId=...)` —— 实测会评估到别的标签（读到的是另一个页面的 DOM）。
```python
tabs = list_tabs()                          # 每项 targetId / title / url
ty = [t for t in tabs if 'tanyuai' in t['url']]
switch_tab(ty[0])                           # 之后 js()/page_info() 都作用在它身上
current_tab()                               # 核对：title 带 🐴 标记 = 当前挂载
```

### ② 把页面真实状态抄下来（⚠️ 最容易出错的一步）
```js
[...document.querySelectorAll('input')].map(e => ({ph: e.placeholder, val: e.value}))  // 筛选框真实值
[...document.querySelectorAll('[class*=pagination]')].map(e => e.innerText)           // 「共 N 条数据」「100 条/页」
(document.querySelector('.ant-pagination-item-active')||{}).innerText                 // 当前第几页
```
- **用户口述的筛选 ≠ 页面实际筛选**。实测：十一说「近七天」，页面实际是 `2026-09-01 ~ 2026-09-07`。
  → **按页面实际值采**，采完**明确报出实际范围**并问要不要换。不要自己替换成「我以为的时间段」，也不要默默改他的筛选。
- 记下「共 N 条」= 后面校验的**硬基准**。

### ③ 抓页面自己发的那次请求（拿 method + body）
```js
performance.getEntriesByType('resource').map(e => e.name)
  .filter(u => /consume|list|page|api/i.test(u) && !/\\.(js|css|png|jpg|svg|woff|ttf)/i.test(u))
```
找到候选后**挂钩子**再触发一次翻页（点第 2 页），把真实请求体录下来（`fetch` 和 `XMLHttpRequest` 都钩，不知页面用哪个）：
```js
const of = window.fetch;
window.fetch = function(...a){ /* 记 a[0] / a[1].body */ return of.apply(this, a); };
const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
```
实测录到：
```json
POST /api/gc/points-bill/paginate
{"startTime":"2026-09-01","endTime":"2026-09-07","pageSize":100,"pageIndex":2}
```
→ **body 里带着筛选条件** = 证明这条接口就是当前这份数据，可以放心重放 ✓（录到的条件要和第②步抄的值对上）。

### ④ 页面内跑翻页循环（⚠️ 必须后台跑 + 轮询）
`js()` 的 CDP 响应上限是 **5 秒** —— 37 页循环会 `Runtime.evaluate timed out`。
**解法：在页面里起一个不 await 的异步任务，进度写 `window.__prog`，外面轮询。**
```js
// 第一次调用：启动，立即返回
(() => {
  window.__all = []; window.__prog = {done:0, of:37, n:0, bad:[], finished:false};
  (async () => {
    for (let p = 1; p <= 37; p++) {
      try {
        const resp = await fetch('/api/...', {method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({...条件, pageSize:100, pageIndex:p})});
        const j = await resp.json(); const d = j.data || {};
        if (j.code !== 1) window.__prog.bad.push(p);
        else (d.results||[]).forEach(r => window.__all.push(r));
      } catch(e) { window.__prog.bad.push('p'+p); }
      window.__prog.done = p; window.__prog.n = window.__all.length;
    }
    window.__prog.finished = true;
  })();
  return 'started';
})()
```
```python
while True:
    time.sleep(3); st = json.loads(js('JSON.stringify(window.__prog)'))
    if st['finished']: break
```
- **用页面自己的 `fetch`** → cookie/鉴权自动带上，不用找 token ✓
- 成功码不一定是 0：探域是 **`code: 1` = 成功**（`msg:'操作成功!'`）→ 先看一页的返回再写判断

### ⑤ 校验（做全，别只看条数）
- **累计条数 == 页面「共 N 条」**（实测 3637/3637、543/543、524/524 ✓）
- `bad` 为空（逐页 0 失败）
- 日期范围覆盖对不对（min/max），有没有边界溢出（见坑表）
- 列间关系（探域：应扣 == 实扣；有不等要单独报）
- **别只看「脚本跑完了」就报成功**：数据没落文件、看板没重建、线上没同步、推送没发出——都算没完成

### ⑥ 取出来出表
- 大 payload **分段取回**更稳（`js('window.__csv.slice(a,b)')`，每段 ~28k 字符）；实测 25KB 一次也能拿回，但别赌
- 落文件用 `encoding='utf-8-sig'`（Excel 打开中文不乱码）
- Excel（openpyxl）：**冻结首行 + `auto_filter` + `fitToWidth=1` + 数值 `#,##0` + 占比列 `0.00%`**；文件名带数据日期段（`..._2026.09.17.xlsx`）
- 汇总表**每个实体占一行**（店铺类清单：店铺 | 积分 | 占比 | 条数）；发群用 markdown 表格（QQ 渲染成真表格）

## 三、踩过的坑

| 坑 | 真相 / 做法 |
|---|---|
| `js()` 里 await 长循环 | 5 秒 CDP 响应上限 → 后台跑 + 轮询 `window.__prog` |
| `Target.attachToTarget` + `sessionId` 做评估 | 会落到别的标签（实测读到另一个页面）→ 用 `list_tabs()` + `switch_tab()` |
| CDP `Input.dispatchMouseEvent` 打在非活动标签 | 会超时 → 用**页面内 `dispatchEvent`** 触发已验证的事件，或先 `activate_tab()` |
| 分页按钮点了没反应 | antd 这类组件 **JS `.click()` 就生效**（React 监听冒泡）；PDD 那种风控页才必须 `mousedown+mouseup+click` 三连 |
| **时间列是「小时桶的结束时刻」** | 最后一批会标成**次日 00:00**（9/01–9/07 有 22 行标 9/08；9/22 最后 23 行标 9/23）→ **不是多出来的数据**，别当异常报 ✗ |
| 同名实体出现重复行 | 同一店名在**不同平台**（接口 `platform` = 1/5/7、`shopId` 不同）→ 不是重复登记，在说明里讲清 |
| 拿常识替换用户的筛选 | 先读页面真实值（见②），把**实际范围**报出来 |
| **照抄别的技能里写的定时时间** | 用户会改 cron，技能正文常跟不上（实例：评价星级采集 14:00 → **14:20**、看门狗「每小时」→ **每天 14:50**）。一律 **`cronjob list` 查实际 `schedule`/`last_status`/`next_run_at` + `run_log` 尾部 + 产物 mtime**，再判“坏了没” |

## 四、交付习惯（十一）
- 采集/分析**只读**：不动筛选、不点保存、不翻页导出平台数据
- **采完复位**：把页码点回他原来的那一页（测试点过第 2 页 → 采完点回第 1 页）
- 交付位置**按当次说的**：说「放桌面」就放桌面 → 先确认真实桌面路径（`reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders" /v Desktop`，防 OneDrive 重定向；本机 = `C:\\Users\\Administrator\\Desktop`）
- 报告结构：**结论前置**（总计/条数）→ 明细表（每实体一行）→ 文件路径 → **自检**（通过项 + 问题/口径提醒）

## 五、批量模式（多日期段）
用户按天一天天来采时，别陪着一天一个文件 —— 给一个日期段就**循环每天调一次接口**，出「**按天 × 按实体**」交叉表（+逐日小计）：一遍拿全、能看趋势。
（2026-09-23 已向十一提议，等他给日期段；实现要点同②④，只是外层多一层日期循环。）

## 参考
- `references/tanyu-points-consume.md`：探域积分消耗的接口/字段/实测数字（可直接照着重放）
