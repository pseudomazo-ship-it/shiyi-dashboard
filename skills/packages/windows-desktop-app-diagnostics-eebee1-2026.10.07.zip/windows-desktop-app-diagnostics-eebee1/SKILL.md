---
name: windows-desktop-app-diagnostics
description: "Use when a Windows desktop app hangs or can't connect."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, diagnostics, ports, winnat, hyper-v, proxy, dns, netsh, desktop-app]
---

# Windows Desktop-App Diagnostics (OS layer)

A desktop app that **hangs, spins forever, or never connects** is usually NOT fixed by reinstalling. Work outward from the app's own log to the OS layer before touching the app.

## Triggers
- "软件打开后一直转圈 / 卡在请等待 / 登录不上去"
- An app whose UI sits in a waiting state while its process(es) are clearly running.
- **Reinstalling had no effect** (strong signal it is not the app's files).
- A local helper/IPC port the app should be listening on is not listening.

## Rule 0 — reinstalling is the LAST resort, not the first
Before re-downloading or reinstalling: **read the app's own log.** Most Electron/native apps write the real error there (login/API failures, bind errors, crashes). Reinstalling the same version cannot fix a system-level cause, and it destroys your evidence. (Real case below: a full reinstall changed nothing because the cause was at the OS layer.)

## Diagnostic sequence

### 1. Confirm the app is actually running
```powershell
Get-Process <app> -ErrorAction SilentlyContinue | Select-Object Id,ProcessName,Path
```
A multi-process Electron app spawns several (main + renderers + a helper). Processes present + UI stuck = the failure is inside, not a launch failure.

### 2. Find the app's OWN log and read the tail
Common locations, in order:
- `%USERPROFILE%\.config\<app>\log\<app>-<YYYY-MM-DD>.log`  ← Electron helpers often land here
- `%APPDATA%\<app>\` and `%LOCALAPPDATA%\<app>\`
- alongside the exe
Look for `error`, `bind`, `listen`, `timeout`, `ECONNREFUSED`.

### 3. Read the app's connection state, not just the UI
Where the app stores its config/state (often `%APPDATA%\<app>\<app>.json`), fields like `connected: false` tell you whether it ever got through.

### 4. Look for the stuck local connection (fastest tell)
```powershell
Get-NetTCPConnection -ErrorAction SilentlyContinue | Where-Object {$_.State -eq "SynSent"} |
  Select-Object LocalPort,RemoteAddress,RemotePort,OwningProcess
```
A `SynSent` to a **loopback** port (e.g. `127.0.0.1:<port>`) while `netstat -ano | Select-String "<port>"` shows **no `LISTENING` row** means: *the app's UI is waiting on its own helper port, and nothing is listening on it.* That is the signature of a **failed bind**.

---

## Case: the port is inside a Windows RESERVED range (verified 2026-09-16)

**Symptom:** a proxy/VPN client opened fine but its login spun on "请等待" forever. Processes were up; the helper port was not listening; **reinstalling the same version changed nothing.**

**The log said it outright** (`<app>/.config/<app>/log/core-<date>.log`):
```
level=error msg="External controller listen error: listen tcp 127.0.0.1:39797: bind:
An attempt was made to access a socket in a way forbidden by its access permissions."
```

**"access permissions" here is NOT a permissions problem — it is a RESERVED PORT.** Windows (Hyper-V / WSL / Docker's `winnat`) reserves blocks of TCP ports; **any** process, admin or not, gets denied binding inside them.

**Confirm in one command:**
```powershell
netsh int ipv4 show excludedportrange protocol=tcp
```
Real output (the app needed 39797):
```
开始端口    结束端口
  5357        5357
 39749       39848     ← 39797 falls in here
 39849       39948
 39949       40048
 50000       50059     *
```
(`*` = managed by the system; the others are winnat/Hyper-V reservations.)

### Root cause found: the machine's dynamic-port range had been changed
```powershell
netsh int ipv4 show dynamicport tcp
# startup port : 10000     ← NON-default (Windows client default is 49152)
# number of ports : 55000
```
A range starting at 10000 pushes winnat's reservations down into the 39xxx block, where the app's fixed port lives. **A wide/low dynamic range is what makes an app's hard-coded port collide with the reservation.**

### The fix (needs Administrator)
```powershell
net stop winnat
netsh int ipv4 set dynamicport tcp start=49152 num=16384    # back to the Windows default
net start winnat
```
- ⚠️ **`net stop winnat` alone usually clears the reservations** — after stopping, `netsh int ipv4 delete excludedportrange ...` returns **"找不到元素"** because the block is already gone. Don't treat that error as a failure; re-check the range table.
- Stopping `winnat` briefly interrupts networking (a few seconds). Warn the user; it is expected.
- Both the kill-retry and the netsh steps need elevation: run them from one elevated PowerShell (`Start-Process powershell -Verb RunAs -ArgumentList ...`) — and have the script **write its output to a file** you then read, because a Chinese-language elevated console mangles stdout on capture.

### Verify the fix — three independent checks
1. **Can it bind now?** (do not just re-read netsh)
   ```powershell
   $l = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, 39797)
   $l.Start(); $l.Stop(); "BIND OK"
   ```
2. **Is the app now listening?** `netstat -ano | Select-String "39797"` → a `LISTENING` row, and the UI↔helper pair should flip from `SynSent` to `ESTABLISHED`.
3. **Is the app's log clean?** tail it again — the bind error must be gone.
A port that was `SynSent` and becomes `LISTENING` + `ESTABLISHED` is the proof; "netsh shows a different table" is not.

### Why the reinstall was useless
It replaced app files while the OS kept reserving the port. **Classify first, then act** — this is why step 0 exists.

---

## Case: window opens but sits on a splash/blank forever — a required HOST is unreachable (verified 2026-09-16)

**Symptom:** the app starts fine (several processes up, window renders, it even has a title), but the content area shows only the product logo on white — indefinitely. Looks like a broken install; is not.

**Method — probe the app's own required hosts from the OS, with a known-good control:**
```python
import socket, time
for h in ["<app-domain>", "www.baidu.com"]:        # app host + control
    s = socket.socket(); s.settimeout(5); t = time.time()
    try: s.connect((h, 443)); print(h, "OK", int((time.time()-t)*1000), "ms")
    except Exception as e: print(h, "FAIL", e)
    finally: s.close()
```
Real output: `chatgpt.com` → **timed out**, while `openai.com`, `api.openai.com`, `www.baidu.com` and `mms.pinduoduo.com` all connected in <250ms. **One host dead + everything else healthy = the app is fine and the route to *its* host is the problem.**

**Then check whether a proxy exists and whether Windows is actually using it:**
```powershell
Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" | Select ProxyEnable,ProxyServer
Test-NetConnection 127.0.0.1 -Port 7897      # is the proxy client actually listening?
```
Real state: `ProxyEnable=0`, `ProxyServer=127.0.0.1:7897`, port **listening** → the proxy client was running but Windows was not routing through it, so the app went direct and hit the wall.

**Verify the proxy will actually carry the app's host** (do this BEFORE telling the user to switch it on):
```python
import urllib.request
op = urllib.request.build_opener(urllib.request.ProxyHandler({"https": "http://127.0.0.1:7897"}))
try: print(op.open("https://<app-host>", timeout=8).status)
except Exception as e: print("via proxy:", e)
```
⚠️ **A `403` here is SUCCESS, not failure.** A bare `urllib` request to a Cloudflare-fronted host returns 403 with no browser headers — that proves the tunnel reached the host. Only a timeout / connection refusal means the proxy isn't carrying it. Do not report the 403 as an error.

**Fix:** turn on the system proxy (the proxy client's 「系统代理」 toggle is the normal way, or set `ProxyEnable=1` + `ProxyServer=127.0.0.1:<port>`), then **restart the app** — it reads the proxy setting at launch, so a running instance won't pick it up.

**Pitfalls specific to this case:**
- **Don't try to focus/poke a splash-stuck window into life.** Rendering is not the blocker; reachability is. Diagnose the route instead of retrying UI actions.
- Windows' foreground lock means an app you launched programmatically may refuse to come to the front (`foreground activation failed`) — that is normal, **ask the user to click its taskbar button** rather than looping on focus.
- A **Store/MSIX** app lives under `C:\Program Files\WindowsApps\...`; launching that exe directly is ACL-blocked and pointless. If it isn't running, resolve its AppID and start it properly:
  ```powershell
  Get-StartApps | Where-Object {$_.Name -like "*<App>*"} | Select Name,AppID
  ```
  then `explorer.exe "shell:AppsFolder\<AppID>"` (e.g. `OpenAI.Codex_2p2nqsd0c76g0!App`). Expect a few seconds of splash before the window fills in — pair this with the reachability probe above when it never does.
- Your capture may show a blank window while the **user's** screen already shows content; ask them what they see before declaring it stuck.

---

## Other OS-layer causes on this same checklist
Work these only after the port check, and only if the app's log points that way:

| Layer | Check |
|---|---|
| **Proxy: on, off, or mismatched** | `Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings" \| Select ProxyEnable,ProxyServer,AutoConfigURL`. **Both directions bite, so never read the flag alone:** `ProxyEnable=1` pointing at a **dead** local port breaks apps that honour the system proxy; and **`ProxyEnable=0` while a proxy client IS running** (its port listens, but Windows isn't routing through it) breaks any app whose host is only reachable *through* that proxy. Read `ProxyEnable` and `ProxyServer` **together**, and see the splash-screen case below. |
| **Another VPN/proxy stole routing/DNS** | `Get-NetAdapter` (a virtual adapter `Up` + a `0.0.0.0/0` route through it), `Get-DnsClientServerAddress -AddressFamily IPv4`. A virtual adapter present but `Disconnected` is usually **not** the culprit — verify before blaming it. |
| **hosts file** | `C:\Windows\System32\drivers\etc\hosts` — non-comment lines. |
| **Time skew** | A wrong system clock breaks TLS and can look like "login fails". `Get-Date`. |
| **DNS for the app's own API host** | Resolve the domain against a public resolver to separate a DNS problem from an app problem: `nslookup <host> 223.5.5.5`. |

## Pitfalls
- ⚠️ **Do not conclude "the app is broken" from a stuck UI.** The UI can be waiting on a helper/port that a system policy is blocking.
- ⚠️ **Two VPN/proxy products can coexist and conflict** — check what is actually driving routes/DNS before assuming the product under test is at fault.
- ⚠️ **Cancelling a process that runs elevated fails with `拒绝访问`** from a normal shell; use one elevated script rather than a retry loop.
- ⚠️ **Elevated PowerShell + Chinese output**: capturing stdout often raises a UnicodeDecodeError. Write results to a UTF-8 file and read that.
- ⚠️ **A "reserved port" fix does not survive every reboot for free** — with the dynamic range back at the default the reservation normally stays high (e.g. 50000-50059), but keep the one-line diagnosis above handy; if it recurs, the dynamic range was changed again (some VPN/accelerator tools do this).

## Reporting
State the layer in one line ("this is a Windows reserved-port block, not the app"), then the two commands that prove it (`netsh` range + the app log line), then the fix and the three verification results. Lead with the conclusion — this user reads the verdict first.
