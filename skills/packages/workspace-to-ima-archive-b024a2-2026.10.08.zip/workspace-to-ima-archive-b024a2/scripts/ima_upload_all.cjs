// 把三个 Agent 工作区的 md 全量传入 IMA（按 Agent 文件夹分类，断点续传）
// 用法: node ima_upload_all.cjs [--limit N] [--only Agent名]
const fs = require('fs'), os = require('os'), path = require('path');
fs.writeFileSync(path.join(os.homedir(), '.config/ima/last_update_check'), new Date().toISOString().slice(0, 10));
const { imaApi } = require('C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs');
const P = s => { try { return typeof s === 'string' ? JSON.parse(s) : s; } catch (e) { return { code: -1, msg: 'parse fail' }; } };

const KB = '0wy6KjHzzkor-e9oBf1c4OCQT8KE9bJ0zcuQwWb9bk4=';
const FOLDERS = JSON.parse(fs.readFileSync('E:/RuanJian/Hermes/cache/ima_folders2.json', 'utf8'));
const DONE_FILE = 'E:/RuanJian/Hermes/cache/ima_upload_done.json';
const LIST_FILE = 'E:/RuanJian/Hermes/cache/ima_upload_list.json';

const limitArg = process.argv.indexOf('--limit');
const LIMIT = limitArg > 0 ? parseInt(process.argv[limitArg + 1], 10) : 0;
const onlyArg = process.argv.indexOf('--only');
const ONLY = onlyArg > 0 ? process.argv[onlyArg + 1] : null;

const done = fs.existsSync(DONE_FILE) ? JSON.parse(fs.readFileSync(DONE_FILE, 'utf8')) : {};
console.log('已完成 ' + Object.keys(done).length + ' 条（断点续传）');

const all = JSON.parse(fs.readFileSync(LIST_FILE, 'utf8'));
let todo = all.filter(x => !ONLY || x.agent === ONLY).map(x => ({ p: x.path, label: x.agent, rel: x.rel, type: x.type }));
console.log('清单 ' + all.length + ' 条 → 本轮候选 ' + todo.length + ' 条' + (LIMIT ? '（限 ' + LIMIT + ' 条）' : ''));
if (LIMIT) todo = todo.slice(0, LIMIT);
console.log();

(async () => {
  let ok = 0, skip = 0, fail = 0;
  const t0 = Date.now();
  for (let i = 0; i < todo.length; i++) {
    const it = todo[i];
    const key = it.label + '/' + it.type + '/' + it.rel;
    if (done[key]) { skip++; continue; }
    const folderId = (FOLDERS[it.label] && FOLDERS[it.label].types && FOLDERS[it.label].types[it.type]) || FOLDERS[it.label].id;
    const raw = fs.readFileSync(it.p, 'utf8');
    const title = '【' + it.label + '】' + path.basename(it.p, '.md') + '_' + new Date(fs.statSync(it.p).mtime).toISOString().slice(0, 10).replace(/-/g, '.');
    // 首行写成标题（IMA 以内容首行为标题）
    const body = raw.replace(/^\s*#+\s*/, '');
    const content = '# ' + title + '\n\n> 来源：' + it.label + ' ／ ' + it.type + ' ／ ' + it.rel + '\n\n' + body;
    try {
      const r1 = P(await imaApi('openapi/note/v1/import_doc', { content_format: 1, content }, {}));
      if (r1.code !== 0 || !(r1.data && r1.data.note_id)) { throw new Error('import_doc: ' + JSON.stringify(r1).slice(0, 120)); }
      const noteId = r1.data.note_id;
      const r2 = P(await imaApi('openapi/wiki/v1/add_knowledge',
        { media_type: 11, note_info: { content_id: noteId }, title, knowledge_base_id: KB, folder_id: folderId }, {}));
      if (r2.code !== 0) { throw new Error('add_knowledge: ' + JSON.stringify(r2).slice(0, 120)); }
      done[key] = { note_id: noteId, title, folder: it.label + '/' + it.type, at: new Date().toISOString() };
      ok++;
      console.log('[' + (i + 1) + '/' + todo.length + '] ✅ ' + title.slice(0, 56));
    } catch (e) {
      fail++;
      console.log('[' + (i + 1) + '/' + todo.length + '] ❌ ' + title.slice(0, 44) + ' :: ' + String(e.message).slice(0, 110));
    }
    if ((i + 1) % 10 === 0) fs.writeFileSync(DONE_FILE, JSON.stringify(done, null, 1), 'utf8');
    await new Promise(s => setTimeout(s, 1200));
  }
  fs.writeFileSync(DONE_FILE, JSON.stringify(done, null, 1), 'utf8');
  console.log();
  console.log('完成: 成功 ' + ok + ' ｜ 跳过 ' + skip + ' ｜ 失败 ' + fail + ' ｜ 用时 ' + ((Date.now() - t0) / 1000).toFixed(0) + 's');
  console.log('累计已传 ' + Object.keys(done).length + ' 条');
})();
