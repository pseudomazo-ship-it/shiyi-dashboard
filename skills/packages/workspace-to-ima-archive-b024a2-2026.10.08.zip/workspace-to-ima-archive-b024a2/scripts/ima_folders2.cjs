// 建两级文件夹：Agent-办公室 / 类型
const fs = require('fs'), os = require('os'), path = require('path');
fs.writeFileSync(path.join(os.homedir(), '.config/ima/last_update_check'), new Date().toISOString().slice(0, 10));
const { imaApi } = require('C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs');
const P = s => { try { return typeof s === 'string' ? JSON.parse(s) : s; } catch (e) { return { code: -1, msg: 'parse fail' }; } };

const KB = '0wy6KjHzzkor-e9oBf1c4OCQT8KE9bJ0zcuQwWb9bk4=';
const AGENTS = ['Hermes-办公室', 'Codex-办公室', 'WorkBuddy-办公室'];
const LIST = JSON.parse(fs.readFileSync('E:/RuanJian/Hermes/cache/ima_upload_list.json', 'utf8'));
const TYPES = {};
for (const x of LIST) (TYPES[x.agent] = TYPES[x.agent] || new Set()).add(x.type);

async function listFolders(parentId) {
  const out = {};
  let cursor = '', guard = 0;
  while (guard++ < 20) {
    const body = { knowledge_base_id: KB, cursor, limit: 50 };
    if (parentId !== KB) body.folder_id = parentId;
    const r = P(await imaApi('openapi/wiki/v1/get_knowledge_list', body, {}));
    const l = (r.data && r.data.knowledge_list) || [];
    for (const x of l) if (x.media_type === 99) out[x.title] = x.media_id;
    if (!r.data || r.data.is_end || !r.data.next_cursor) break;
    cursor = r.data.next_cursor;
  }
  return out;
}

(async () => {
  const map = {};
  const rootFolders = await listFolders(KB);
  for (const ag of AGENTS) {
    let fid = rootFolders[ag];
    if (!fid) {
      const r = P(await imaApi('openapi/wiki/v1/create_folder', { knowledge_base_id: KB, parent_media_id: KB, name: ag }, {}));
      if (r.code !== 0) { console.log('❌ 一级 ' + ag + ': ' + JSON.stringify(r).slice(0, 120)); continue; }
      fid = r.data.media_id;
      console.log('新建一级  ' + ag + ' → ' + fid);
      await new Promise(s => setTimeout(s, 900));
    } else {
      console.log('复用一级  ' + ag + ' → ' + fid);
    }
    map[ag] = { id: fid, types: {} };
    const sub = await listFolders(fid);
    const want = Array.from(TYPES[ag] || []).sort();
    for (const t of want) {
      if (sub[t]) { map[ag].types[t] = sub[t]; console.log('   复用 ' + t + ' → ' + sub[t]); continue; }
      const r = P(await imaApi('openapi/wiki/v1/create_folder', { knowledge_base_id: KB, parent_media_id: fid, name: t }, {}));
      if (r.code === 0 && r.data && r.data.media_id) {
        map[ag].types[t] = r.data.media_id;
        console.log('   新建 ' + t + ' → ' + r.data.media_id);
      } else {
        console.log('   ❌ ' + t + ': ' + JSON.stringify(r).slice(0, 120));
      }
      await new Promise(s => setTimeout(s, 900));
    }
    console.log();
  }
  fs.writeFileSync('E:/RuanJian/Hermes/cache/ima_folders2.json', JSON.stringify(map, null, 1), 'utf8');
  const n = Object.values(map).reduce((a, x) => a + Object.keys(x.types).length, 0);
  console.log('✅ 一级 ' + Object.keys(map).length + ' 个 ｜ 二级 ' + n + ' 个 ｜ 表已存 cache/ima_folders2.json');
})();
