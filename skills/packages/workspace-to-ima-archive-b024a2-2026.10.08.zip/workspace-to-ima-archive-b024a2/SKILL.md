---
name: workspace-to-ima-archive
description: "Use when 要把工作区/多Agent 的 md 批量存档进 IMA 知识库（分类+断点续传）。"
---

# 工作区 md → IMA 知识库 全量存档

> 2026-10-08 十一定（永久规则）：**工作区（Hermes/Codex/WorkBuddy 三个 Agent 工作区）的 md 全量上传 IMA 知识库**，要求**分类清楚、全面不遗漏**。
> ⚠️ 域名网页 `/docs/` 方案**已废弃删除**——只走 IMA，不再做网页看板。

## 目标库

**「Agent知识库（记忆留痕记录）」**
`knowledge_base_id = 0wy6KjHzzkor-e9oBf1c4OCQT8KE9bJ0zcuQwWb9bk4=`

## 文件夹结构（两级，2026-10-08 定）

```
Agent知识库（记忆留痕记录）
├ Hermes-办公室
│   ├ 技术文档 ｜ 规则与方法论 ｜ 操作说明
│   ├ 业务资料 ｜ 对话留痕 ｜ 工作记录 ｜ 个人作品
├ Codex-办公室
│   ├ 工具与软件 ｜ 规则与方案 ｜ 工作记录
└ WorkBuddy-办公室
    ├ 产品与运营资料 ｜ 结论与方案 ｜ 工作记录
```

## 必备脚本（在 `E:\RuanJian\Hermes\cache\`）

| 脚本 | 作用 |
|---|---|
| `ima_folders2.cjs` | 建/复用两级文件夹，产出 `ima_folders2.json` |
| `ima_upload_all.cjs` | 读清单批量上传（断点续传、失败不中断） |
| `ima_upload_list.json` | 待传清单（含 `agent` / `type` / `path` / `rel`） |
| `ima_upload_done.json` | 进度（每 10 条落盘，重跑自动跳过已完成） |

**跑法**（node 用绝对路径）：
```bash
cd /e/RuanJian/Hermes/cache
"E:/RuanJian/Hermes/node/node.EXE" ima_folders2.cjs              # ① 建文件夹
"E:/RuanJian/Hermes/node/node.EXE" ima_upload_all.cjs --limit 3   # ② 试传 3 条验证
"E:/RuanJian/Hermes/node/node.EXE" ima_upload_all.cjs            # ③ 全量（后台跑，约 2h）
# 可选：--only Hermes-办公室 只跑某个 Agent
```

## 生成清单（Python，每次同步前重跑）

扫描三个工作区，排除依赖/第三方/采集数据，并给每条打上 `type`（二级分类）：

```python
import os, json, re
BASE = r'D:\Agent.GongZuoQu'
WS = [('Hermes.GZQ','Hermes-办公室'), ('Codex.GZQ','Codex-办公室'), ('WorkBuddy.GZQ','WorkBuddy-办公室')]
SKIP = ['node_modules','.git','.venv','site-packages','__pycache__','dist-info',
        '.portable-staging','_第三方项目','技能旧版备份','.archive',
        'PDD帮助中心','得物规则中心','.agents','dist','build']
SKIPN = re.compile(r'(^LICENSE\.md$|^license\.md$|^CHANGELOG\.md$|^ThirdParty|^测试_|^测试-)', re.I)
out = []
for w, lab in WS:
    root = os.path.join(BASE, w)
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP]
        if any(s in dp for s in SKIP): continue
        for f in fn:
            if f.endswith('.md') and not SKIPN.search(f):
                p = os.path.join(dp, f)
                out.append({'path': p, 'agent': lab, 'rel': os.path.relpath(p, root)})
json.dump(out, open('E:/RuanJian/Hermes/cache/ima_upload_list.json','w',encoding='utf-8'),
          ensure_ascii=False, indent=1)
```

**二级分类 `type` 规则**（按 `agent` + `rel` 判定）：

| Agent | 类型 | 路径特征 |
|---|---|---|
| Hermes | 对话留痕 | `数据--对话留痕` |
| Hermes | 技术文档 | `文档--多功能登录器复刻` / `文档--上架软件` / `脚本--` / `软件--待办` / `文档--紫盒` / `软件--评价星级` / `软件：自动处理退款工作台` / `项目--上架控制台` / `项目：多店铺` |
| Hermes | 规则与方法论 | `文档--Hermes工作规则` / `文档--IMA上传规则` / `数据--技能看板` / `数据--快递决策` / `文档--主体变更` / `项目：领航员` |
| Hermes | 业务资料 | `数据--主体财务仓库快递` / `数据--云仓费用规则` / `数据--发货出库统计` / `数据--探域积分` / `数据--店铺产品采集` |
| Hermes | 操作说明 | `申诉复议` / `售后补发` / `数据--数据日报` / `评价` |
| Hermes | 个人作品 | `个人作品` / `练手记` |
| Hermes | 工作记录 | 其余 |
| Codex | 工具与软件 | `软件：` / `工具` / `仓库` / `看板` |
| Codex | 工作记录 | `PLAN` / `memory` / `LOG` / `验收` / `流程` |
| Codex | 规则与方案 | 其余 |
| WorkBuddy | 工作记录 | `memory` / `索引` |
| WorkBuddy | 产品与运营资料 | `产品知识库` / `1过往文件` |
| WorkBuddy | 结论与方案 | 其余 |

## 上传流程（每条两个调用，必须都 `code===0`）

```js
const fs=require('fs'), os=require('os'), path=require('path');
// 绕 -200 更新拦截（按 UTC 当天写）
fs.writeFileSync(path.join(os.homedir(),'.config/ima/last_update_check'), new Date().toISOString().slice(0,10));
const { imaApi } = require('C:/Users/Administrator/.workbuddy/skills/ima-skill/ima_api.cjs');
const P = s => { try { return typeof s==='string' ? JSON.parse(s) : s; } catch(e){ return {code:-1,msg:'parse fail'}; } };
const KB = '0wy6KjHzzkor-e9oBf1c4OCQT8KE9bJ0zcuQwWb9bk4=';

const raw = fs.readFileSync(filePath,'utf8');
const title = '【'+label+'】'+nameBase+'_'+date;              // 标题
const body  = raw.replace(/^\s*#+\s*/, '');                  // 去掉原首行标题
const content = '# '+title+'\n\n> 来源：'+label+' ／ '+type+' ／ '+rel+'\n\n'+body;

const r1 = P(await imaApi('openapi/note/v1/import_doc', { content_format:1, content }, {}));
if (r1.code!==0 || !(r1.data&&r1.data.note_id)) throw new Error('import_doc failed');
const r2 = P(await imaApi('openapi/wiki/v1/add_knowledge',
  { media_type:11, note_info:{content_id:r1.data.note_id}, title,
    knowledge_base_id:KB, folder_id:目标二级文件夹ID }, {}));
if (r2.code!==0) throw new Error('add_knowledge failed');
```

- 每条之间 `sleep 1200ms` 节流；**大文档（对话留痕有 2MB 分片）会慢到 ~20s/条**，397 条约 2 小时，正常。
- **每 10 条**把进度写 `ima_upload_done.json`；重跑自动跳过（key = `agent/type/rel`）。

## 建文件夹（含坑）

```js
await imaApi('openapi/wiki/v1/create_folder',
  { knowledge_base_id: KB, parent_media_id: 父文件夹ID, name: '文件夹名' }, {});
// → { code:0, data:{ media_id:'folder_xxx' } }
```

- **根目录**：`parent_media_id` 传 **知识库 ID**（不是空串）。
- 参数名是 **`parent_media_id`**（`media_id` 也行）；`folder_id`/`folder_name` 会报错。
- ✅ **实测能建**；定位现有文件夹用 `get_knowledge_list`（带 `folder_id`），筛 `media_type===99`。

## ⚠️ 坑（都踩过）

1. **IMA 无删除接口** —— `delete_folder` / `delete_knowledge` / `remove_knowledge` / `delete_media` **全部不存在**（返回空字符串）。
   → 传错/建错**只能让十一到 IMA 客户端手删**。所以**传前必须 try 小批量（`--limit 3`）验证**。
2. **同名检查是全库级** —— 建文件夹报 `220001 已存在同名知识` 时，别处（任意层级）已有同名条目。换个名字即可（本次：「工作记录」被占 → Codex 用「日常记录」、WorkBuddy 用「工作日志」）。
3. **`imaApi()` 返回 JSON 字符串**，必须 `JSON.parse`；否则 `r.code===undefined`，会把**成功误判为失败**并重传（=造垃圾）。
4. **`-200` 更新拦截**：脚本开头写 `~/.config/ima/last_update_check` = **UTC 当天日期**（本地日期会不匹配）。
5. **标题 = 内容首行** —— `import_doc` 的 `title` 参数**无效**，必须把标题写进 `content` 第一行。
6. **返回空字符串 = apiPath 写错**，不是「没数据」。`note/` 与 `wiki/` 两个命名空间别搞混：`import_doc`/`append_doc` 在 **note**，`add_knowledge`/`search_knowledge`/`search_knowledge_base` 在 **wiki**。
7. **大文件用 `require` 方式**调 `imaApi`，别拼命令行（>30KB 报 `ENAMETOOLONG`）。
8. **目录遍历差异**：Node 的 `fs.readdirSync` 递归与 Python 的 `os.walk` 对 `node_modules` 等跳过判断可能不一致 → **统一用 Python 生成清单，Node 只读清单**，别在 Node 里重新遍历（本次因此多算成 1201 条）。
9. **⚠️ 单条内容上限约 50 万字符** —— 超过后 `import_doc` 报 **`fetch failed`**（错误信息完全看不出是超长，容易误判为网络抖动而反复重试）。
   - 实测：50.8 万字符 → 必失败；48.4 万 → 成功。
   - 症状：同一文件反复重试都报 `fetch failed`，而其他文件正常。
   - 解法：**按字符数均分拆片**（不要按段落数切 —— 段落长度不均，本次按段落切 3 片结果片 1 仍有 48 万字，等于没拆开）。正确做法是按**字符偏移量**切（每片 ≤ 40 万字）。
   - 对话留痕的导出脚本已按 200 条消息分片，但单条消息很长时仍可能超限。

## 完成后必做

1. 逐二级文件夹 `get_knowledge_list` 数条数，对照清单报「目标 N / 实际 M」。
2. **点名列出失败的**（脚本输出里的 ❌ 行），不静默。
3. 列出需十一手删的（测试文件夹、误传笔记、散落在上级目录的）。

## 完成记录

**2026-10-08 首次全量：397/397 全部到位**（Hermes 205、Codex 14、WorkBuddy 178）。
耗时约 90 分钟；中途 16 条 `fetch failed` 重跑补回 15 条，最后 1 条因超长（50.8 万字符）拆片后成功。

## 相关

- IMA 通用坑与笔记规则：见技能 `ima-notes-and-kb-workflow`、`ima-skill/references/ima-notes-rules.md`
- 会话导出（对话留痕的来源）：`E:\RuanJian\Hermes\cache\export_dialogs.py`（从 `E:\RuanJian\Hermes\state.db` 的 sessions/messages 表导出十一真人参与的会话，筛 user≥2 条发言，排除 cron 自动任务）
