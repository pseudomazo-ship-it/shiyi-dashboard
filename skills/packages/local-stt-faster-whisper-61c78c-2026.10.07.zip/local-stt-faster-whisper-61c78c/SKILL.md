---
name: local-stt-faster-whisper
description: "Fix & verify local STT (faster-whisper) voice transcription."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [stt, whisper, speech-to-text, faster-whisper, hf-mirror, voice]
---

# Local STT (Speech-to-Text) via faster-whisper

Hermes auto-transcribes inbound voice messages from messaging platforms (WeChat/QQ/Feishu) into text using local `faster-whisper` (default provider `local`, model `base`). The whole voice→text path is: platform adapter downloads the audio → `gateway/run.py` dispatches it as `MessageType.VOICE` → `tools/transcription_tools.transcribe_audio` → faster-whisper.

## When to use
- Voice messages from a platform come back empty / error / `[Voice transcription...]` with nothing.
- User asks “语音识别不了 / 微信语音听不懂 / STT 不工作”.
- You suspect a corrupt/partial whisper model download.
- A platform delivered a raw `.silk` (WeChat voice) that wasn't auto-transcribed, and you must decode it first.

## Decode a WeChat `.silk` into a wav (before ASR)
WeChat voice arrives as `.silk` (SILK_V3; the file's first bytes are `#"SILK_V3`). If Hermes didn't auto-transcribe it (the audio was saved as `.../audio_<id>.silk` with a "could not be transcribed" note), decode it to a wav with the Python `pilk` library, then feed the wav to faster-whisper:

```python
import pilk, os
pilk.silk_to_wav(r"...\audio_xxx.silk", r"...\audio_xxx.wav", rate=24000)
print(os.path.getsize(wav))  # >0 means it decoded
```

Pitfalls (all verified this session):
- The call signature is **`pilk.silk_to_wav(input, output, rate=24000)`**. The parameter is `rate` — `pilk.silk_to_wav(..., pcm_rate=...)` and `pilk.decode(audio, wav, sample_rate=...)` both FAIL with a wrong-keyword TypeError.
- Check `pilk`'s available helpers with `[x for x in dir(pilk) if not x.startswith('_')]` / `inspect.signature(pilk.silk_to_wav)` before guessing the kwarg.
- Confirm it's really silk first: read the first bytes (`b'#' + b'"' + b'SILK_V3'`).
- The wav comes out at the `rate` you set (24000 here); for a model expecting 16k, resample with `scipy.signal.resample_poly(x, 2, 3)`.
- Run in a python that has `pilk` installed (local env), not a bare `python3` with no packages.

## Diagnostics — verify quickly
```bash
python -c "import faster_whisper; print(faster_whisper.__version__)"   # installed?
```
Cache lives at `~/.cache/huggingface/hub/models--Systran--faster-whisper-{tiny,base,small}`. Check the snapshot files:
```bash
ls -la ~/.cache/huggingface/hub/models--Systran--faster-whisper-base/snapshots/*/
```
A healthy base snapshot has 4 files: `config.json`, `model.bin` (~145MB), `tokenizer.json` (~2.2MB), `vocabulary.txt` (~460KB).

To test transcribe end-to-end with a synthetic tone (verifies pipeline, not real speech):
```python
from faster_whisper import WhisperModel
model = WhisperModel('base', device='cpu', compute_type='int8')
segs, info = model.transcribe('/path/audio.wav', language='zh', beam_size=1)
print(''.join(s.text for s in segs))
```
If it raises `IncompleteSnapshotError` or `File model.bin is incomplete`, the cache is corrupt/partial — repair below.

## Running it when `faster_whisper` is NOT installed (ad-hoc, no persistent install)
A failed `import faster_whisper` in the `execute_code` kernel or in a bare `python` does **not** mean STT is unavailable — the package may simply not be in that interpreter. Run it one-off without installing anything:
```bash
uv run --with faster-whisper python <script>.py
```
Verified working (faster-whisper 1.2.1, model `base` loaded and transcribed). Put the code in a `.py` file, not `-c` with complex quoting. `uv run --with openpyxl python ...` / `--with websocket-client python ...` follow the same pattern for other one-off tools.

- **No separate `ffmpeg` binary is needed.** faster-whisper pulls in `av` (PyAV), which decodes media itself — a missing `ffmpeg`/`ffprobe` on PATH is not a blocker for feeding it an audio/video file.
- **Model availability is per-CACHE, not per-interpreter**: `~/.cache/huggingface/hub/models--Systran--faster-whisper-<size>` is shared, so a good `base` cache serves any interpreter. Check file sizes before blaming the env (on this host `base` = healthy, `tiny`/`small` = 0-byte placeholders).

## Transcribing a video the user hands you (口播文案)
- **Get the media FILE, then transcribe locally** — that path is verified end-to-end once you have the file. Ask the user to save/download the clip rather than trying to fetch it yourself.
- Distinguish the two asks first: **spoken narration** (whisper handles it) vs **text burned into the picture** (needs OCR — a different pipeline entirely). Confirm which one before starting.
- Platform short-links (抖音/Douyin etc.) are anti-bot protected: a freshly-spawned browser profile carries no login/`msToken`, so the page won't render the video at all. Don't burn the session on that — get the file, then transcribe.

## Common root causes (seen for real)
- **`model.bin` is 0 bytes** (tiny/small) → download was interrupted.
- **`model.bin` present but `config.json`/`tokenizer.json`/`vocabulary.txt` missing** (base) → the JSON/config small files never landed.
- **HuggingFace.co unreachable** (WST timeout) but **`hf-mirror.com` reachable** → download through the mirror.

## Repair through the mirror (hf-mirror.com) — the reliable recipe

### Fix a missing-tiny-files case (base): download the 3 small files
```python
import os, glob, urllib.request
snap = glob.glob(os.path.expanduser('~/.cache/huggingface/hub/models--Systran--faster-whisper-base/snapshots/*'))[0]
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
for f in ['config.json', 'tokenizer.json', 'vocabulary.txt']:
    url = f'https://hf-mirror.com/Systran/faster-whisper-base/resolve/main/{f}'
    open(os.path.join(snap, f), 'wb').write(urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=120).read())
```

### Fix an empty/corrupt `model.bin`: re-download the whole model via mirror
```bash
HF_ENDPOINT=https://hf-mirror.com python -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-whisper-base', local_dir=r'<abs dir>')"
```
Then point faster-whisper at that dir via `WhisperModel('<abs dir>', ...)`, or drop the files into the snapshot so the cache resolves normally.

## Key gotchas
- **The mirror serves 0 bytes without a `User-Agent`.** `curl` / `urllib` MUST send a normal UA header or you get an empty file and think the download “worked”. Always set UA and verify the returned byte count > 0.
- **`snapshot_download` can fail to self-heal** a corrupt cache (HEAD call on a bad entry errors out). Plain per-file `urllib`/`curl` download into the snapshot dir is more robust than trusting `snapshot_download` to fix it.
- **Hermes default model is `base`** (`DEFAULT_LOCAL_MODEL = "base"` in `transcription_tools.py`) — fix base first, it is what actually loads. `stt.enabled` defaults to `True`; no config change needed to turn voice on.
- **First use is slow** (model load ~2-3s on CPU) — expected, not a bug.
- **Do NOT conclude “STT doesn't work”** — the pipeline wiring is fine; a corrupt model download is the usual culprit. Repair the model, not the plumbing.

## Config reference
`config.yaml`:
```yaml
stt:
  enabled: true
  provider: local   # local | groq | openai | mistral | elevenlabs | deepinfra
  local:
    model: base     # tiny | base | small | medium | large-v3
    language: zh
```
Auto-detect order: local faster-whisper → Groq (`GROQ_API_KEY`) → OpenAI (`VOICE_TOOLS_OPENAI_KEY`) → Mistral Voxtral (`MISTRAL_API_KEY`).
