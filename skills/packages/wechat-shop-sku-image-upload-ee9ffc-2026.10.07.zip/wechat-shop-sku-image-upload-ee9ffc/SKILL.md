---
name: wechat-shop-sku-image-upload
description: Use when 微信小店/视频号小店商品编辑页要批量上传规格(SKU)配图。
---

# 微信小店 规格配图 批量上传

在 store.weixin.qq.com 商品编辑页（`/shop/goods/entry`）给每个颜色/规格值批量传配图。
已验证 2026-09-16（蒙倩攀七花美发店，30 颜色值）。

## 页面结构（关键：内容在 shadow DOM 里）
- 商品表单整体挂在 `<micro-app>` 自定义元素的 **shadowRoot** 内（约 1.6M 字符）。
  普通 `document.querySelector` / `document.body.innerText` **读不到**（innerText 返回 0），必须
  `document.querySelector('micro-app').shadowRoot.querySelectorAll(...)`。
- 规格区：每组规格是 `div.goods-attr-item`；**每个规格值一格**，格子 = `div.attr-value`，内含
  ① `input[type=file].input_upload`（配图，accept=图片，multiple=true，隐藏、宽高 0）
  ② 颜色名文本框 `input`（读 `.value` 拿颜色名）③ 删除图标 img。
- 判断某格**是否已有配图**：在 `.attr-value` 内找 `img`，**过滤掉 `res.wx.qq.com/t/components/icons`（图标）**；
  有其它 src = 有图。进一步核实用 `naturalWidth>0`（真加载）+ URL 去重（每张图 URL 不同）。
  ⚠️ 只数 img 个数会被垃圾桶图标污染；往上爬祖先会把邻居的图算进来。**必须限定在 `.attr-value` 内。**
- SKU 明细表格里也有「配图」列（x≈1887，每行一个 input），那是**颜色配图自动带出来的**，不用单独传；
  微信小店只允许一组规格配图（提示语「仅支持一组规格批量配图」）。

## 配图有**两套独立**的槽位，别只填一套
同一页面上存在两组互不同步的上传框（实测 2026-09-17，官方3 链接）：
1. **规格值配图**：颜色组每个 `.attr-value` 里的 `input[type=file]`（数量 = 颜色数，如 24）。开关「配图」打开才出现。
2. **SKU 表行内配图**：SKU 明细表每行一个 `input[type=file]`（数量 = 行数 = 颜色×规格，如 72），实测它们的 `getBoundingClientRect().x` 明显靠右（如 1516）可用来区分。

**填了第 2 套不会自动填第 1 套**（实测：72 行全有图后，颜色组 24 个槽仍然 23 个是空的）。传完一边后必须**分别查两边**：
```js
// 颜色组
[...g0.querySelectorAll('.attr-value')] → 每个里面找 img（过滤 /components/icons）
// SKU 表行
[...sr.querySelectorAll('.leaf-line')] → 每行找 img（/wxt\.wxapp|mmbiz/）
```
⚠️ 用户截图看着“只第一行有图”时，先分清楚他拍的是颜色组还是 SKU 表，再定位。

## 配图颜色对位怎么“真的核对”（不要只看有没有图）
数量/URL 唯一都证明不了“颜色没串”。已验证的硬核做法（2026-09-17，30 张全部正确）：
1. 页面里把每个 `.attr-value` 的颜色名 + 缩略图 `img.src`（完整带 token 的 URL）导成 JSON。
2. 本地按文件名解出 颜色→文件，两边都压成 24×24（`thumbnail` + 白底居中补正方）取像素。
3. 对每个槽位算 `diff(页面图, 它自己那个文件)` 与 `diff(页面图, 其他每个文件)`。
   验收条件：**自己=0（或明显最小）且 最像的别人 ≫ 0**。同时先算一遍本地图两两差异作基准（实测 94~209）。
   跑：`uv run --with pillow python verify.py`（PIL 不在环境里）。
   ⚠️ 平台缩略图的像素与本地原图**完全一致**（同比例缩放后 diff=0），所以这个办法能直接判对错。

## 上传方法（唯一可靠路径）
`DOM.setFileInputFiles` 走 **objectId**，不需要 `DOM.enable`、不需要 dump 整棵 DOM：

```python
# 1) 定位槽位并取 objectId（returnByValue=False）
expr = """(() => {
  const sr = document.querySelector('micro-app').shadowRoot;
  const els=[...sr.querySelectorAll('input[type=file]')].filter(el=>{
    const r=el.getBoundingClientRect(); return Math.round(r.x)<1700 && r.y>0; });
  for (const el of els){ const s=el.closest('.attr-value'); if(!s) continue;
    const ci=s.querySelector('input:not([type=file])');
    if (ci && ci.value.startsWith(COLOR)) return el; } return null; })()"""
obj = cdp('Runtime.evaluate', expression=expr, returnByValue=False)['result']['objectId']
# 2) 传文件（绝对路径，中文/【】文件名没问题）
cdp('DOM.setFileInputFiles', files=[abs_path], objectId=obj)
```
- ⚠️ 走 `objectId` 而不是 `nodeId`，绕开了「DOM.enable 必须同一条 WS 连接」和 shadow DOM 的 `querySelector` 穿透问题。
- **每次重新取 objectId**：上传后列表会重渲染，旧 objectId 失效。
- 上传后 `input.files.length` 会变回 0（控件自己清了），**不能拿它判断成功**——用上面的缩略图检查。
- 节奏：每张间隔 2.5~3.5s（随机），别 0 延迟连发。

## 图名 → 颜色 的匹配（这步最容易出错，必须人工确认）
图片文件名形如 `SKU07_两套装【蜜茶棕】温柔少女_彩染系列【全程指导】…jpg`，取 `【】` 里的颜色名匹配页面颜色值。
- 页面颜色值格式 `颜色名【文案】+工艺`，**取「【」之前那一段**做 key（如 `蜜茶棕【甜美浪漫】+无需漂色+碗刷披肩` → `蜜茶棕`）。
- 归一化：`粽→棕`（文件名里真的有「亚麻灰粽」这种错别字）、去掉「色」再比。
- **数量经常对不上**（实测页面 30 个颜色 vs 文件夹 33 张图）。必须把结果分三档交给人：
  ✅唯一匹配 / 🟠同色多图或近似（给候选让人挑）/ ❌无图。**不要自己猜。**
- 同名不同工艺的图（如「黑茶色_可盖白发」vs「黑茶色_自身黑发适用」）靠页面颜色值里的工艺词（可盖白发/无需漂色）定。

## 规格(SKU)编码 批量填写（紫盒规则）
- **编码 = 色号表里的 `code` + `<盒数>盒`**。例：`W 011亚麻棕【紫盒】` + `2盒` = `W 011亚麻棕【紫盒】2盒`。
- 色号表：`D:\其他文件\00000000000000即用即删\【龙虾】三哥工作区\GPT\软件：自动上架工具\data\purple-box-colors.json`
  （`rows[] = {row, color, code}`，312 条，code 已含 `【紫盒】`，以 W/Y 开头）。
- 同一个颜色的两个规格：买一套送一套 = 基础码；「两套加【打蜡228ml】」= 基础码 + `+【打蜡】1个`（十一 2026-09-17 定）。
- 写入表单（React 受控输入）：native setter + `input`/`change` 事件 + React `onChange`，写完 sleep 2s 读回校验。
- ⚠️ **色号表里同名颜色有多条编码（实测 38 个颜色），必须以 W/Y 前缀和 数字（C645 vs 645、5.3、366、C631 vs 775）人工确认，不能猜。**
  色号表没有列说明 W/Y 的含义，源表（WPS 备份 `紫盒【色号表】_2026.09.11.xlsx.*.et`）只有序号/颜色名称/内部色号三列，推不出规律。
- ⚠️ **交付后必查“串行”**：实测出现过 栗棕色 被填成 `Y C645酒红色【紫盒】2盒`（复制粘贴串了）。逐行核 颜色↔编码，别只看填充率。

## 规格值（颜色/组合）批量填写——用 `Input.insertText`
规格值输入框（`.goods-attr-item` 里 placeholder 以「请输入」开头）**写 value + 派发事件不生效**，也**不需要逐字敲**。已验证最快路径（2026-09-17，30 个颜色 12 秒填完）：

```python
# 1) 找到该规格组最后一个空输入框并 focus
FOCUS = '''(() => {
  const it=[...sr.querySelectorAll('.goods-attr-item')][GROUP];   // 0=颜色 1=组合
  const inp=[...it.querySelectorAll('input')]
     .filter(x=>x.type!=='file'&&x.placeholder&&x.placeholder.indexOf('请输入')===0 && x.value==='');
  if(!inp.length) return 'no empty input';
  inp[inp.length-1].focus(); return 'ok'; })()'''
# 2) 插一条，它会自动在末尾生成下一个空输入框
cdp('Input.insertText', text=value, session_id=sid); time.sleep(0.35)
```
也可以先 `inp.focus()` 再 `cdp('Input.insertText', text=...)`——**插完就已经提交了，不需要再回车**（回车也不会出错，值已经落上）。

- ⚠️ **别在批量前“先试一条”再接批量列表从第 1 条开始——会把第 1 条插两遍。** 试完要么从第 2 条接，要么先删掉试的那条。本次真的重复了一个「亚麻棕」，已删。
- 删重复行：该行 `.attr-value` 里 `img[src*=trash]` 的 click 父元素派发全套鼠标事件即可，无确认弹窗。
- ⚠️ **最后一条规格值必须“提交”一下，否则 SKU 表少一组。** 实测填完 33 个颜色后表格只有 64 行（33×2 应为 66），缺的正是最后那个颜色。做 `focus()` + 回车，再在空白处点一下触发 blur，表格就补到 66 行了。规律：**前 N-1 条 insertText 即生效，第 N 条要 blur/Enter 才算定稿**。
- ⚠️ **SKU 表格重建是异步的**：刚填完规格值时 `querySelectorAll('.leaf-line')` 可能只返回一半（实测 30 而应是 60），甚至几行文本全是第一行的内容。**sleep 2s + 滚一下再看**，否则会把“还没渲染完”误判成填写失败。验收就看 `行数 == 颜色数 × 组合数`。
- 规格组容器：`.goods-attr-item`（顺序 = 页面上规格组顺序，第一个一般是颜色，第二个是组合）。

## 上架流程（视频号店铺/微信小店，/shop/goods/entry）
新建商品是**分步表单**，不是一页到底：
1. **基础信息**（第一屏）：`1:1 主图 0/9`（可多选，一次传完）+ **商品标题** + 商品类目 + 店铺首页展示分类 → 「下一步」
   - 商品标题输入框的 **placeholder 是「请输入商品名称与关键字」**，不是「标题」——用 `/标题/` 找不到，要按 placeholder 定位。计数器显示 `32/60`。
   - 主图源文件：工作区 `D:\店铺图片\01蒙倩各店铺热卖链接\<店铺>_商品ID_<id>\主图01..08.jpg`（命名即顺序）。
   - ⚠️ 类目未选时会提示「未申请当前类目，无法创建商品。去申请」——类目要另选（个人护理 > 美发造型 > 染发产品 等）。
2. 详情图 / 规格和库存价格（颜色配图、规格编码）/ 商品参数 / 运费模板等。

### 同店多标签页时，怎么确认用户指的是哪一个
后台会同时开 5–7 个 `goods/entry` 标签且 URL 完全一样（尤其多个空白新建页），无法按 URL 区分。**可靠做法**：给每个候选标签注入焦点探针，让用户点一下目标页，再比时间戳：
```js
window.__focusAt=0; window.__badge=0;
addEventListener('focus', ()=>{window.__focusAt=Date.now();}, true);
document.addEventListener('click', ()=>{window.__badge=Date.now();}, true);
```
然后逐个 `Target.attachToTarget{flatten:true}` + `Runtime.evaluate` 读 `__badge/__focusAt`，**最大且最近的那个就是目标页**。
⚠️ 用户可能在确认后又关掉那个标签——拿不到 targetId 时先重新枚举 `Target.getTargets`，别反复重试旧 id。

## 商品参数（属性）批量填写
参数是**自定义下拉组件**，不是原生 select——写 `value` **不会**选中。已验证有效套路（每步之间 sleep 1.0–1.3s）：

**① 下拉字段**（品牌/是否为特殊用途化妆品/类别/功效/国产进口/商品产地/颜色/色系/特殊用途化妆品）：
```js
// 开
const it=[...sr.querySelectorAll('.param_item,.param_item--double')].find(x=>{const l=x.querySelector('.goods-input-label span')||x.querySelector('.goods-input-label'); return (l&&l.textContent||'').trim()===LABEL;});
const inp=it.querySelectorAll('input')[INDEX];   // INDEX=0 普通；保质期/净含量 的单位框是 index 1
['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>inp.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,buttons:1})));
// 选（只找当前可见的那个 menu，防止拿到隐藏副本）
const menu=[...it.querySelectorAll('.weui-desktop-dropdown-menu')].filter(m=>{const r=m.getBoundingClientRect(); return r.width>0&&r.height>0;})[0];
const hit=[...menu.querySelectorAll('.weui-desktop-dropdown__list-ele__text')].find(t=>t.textContent.trim()===VALUE);
const ele=hit.closest('.weui-desktop-dropdown__list-ele')||hit;
['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>ele.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,button:0,buttons:1})));
```
**选项是先开才渲染的**：不开下拉，`.weui-desktop-dropdown__list` 里只有「暂无数据」。

**② 文本字段**（产品名称/备案编号/生产企业名称/香型/保质期数字/净含量数字）：按 `placeholder` 定位，`native setter` + `input`/`change` 事件（页面是 Vue，v-model 吃 `input`），写完 sleep 0.8s 读回。

**③ 多选字段（适用人群）**：点开 → 点 `.weui-desktop-form__check-label` 文本 === 选项 的 label（不是点 checkbox 本身）。选项值含：成人/成人（除孕妇及哺乳期人群）/普通人群/青少年/男性/女性/老年人/孕妇/通用。

**⚠️ 其他重要参数默认只显示 5 项，剩下 4 项藏在「展开全部 N」链接后面。**
必须先把 `textContent === '展开全部 4'` 那个元素点开，生产企业名称/特殊用途化妆品/净含量（g/ml）/香型 才会渲染出来。不展开时 `querySelector` 完全找不到这 4 个 label（不是虚拟列表，是条件渲染）。
验收看页头计数：`必填参数 7/7` + `其他重要参数 9/9`（但计数会滞后，以逐字段读回为准）。

- ⚠️ **不要把“第二个规格值的文案”写死。** 我按上一次的写法判断 `/两套加/`，但页面上实际是 `两套装加【打蜡228ml】顺滑固色蜡`——**子串 `两套加` 不在其中**，结果 66 行全部只填了基础码、后缀没挂上，看上去“填完了”实际错一半。
  可靠做法：**用语义关键词判断**（如 `/打蜡/`），而不是复制上一次的具体文案。
  同理：**填进去的规格值可能被平台改写成它自己的标准文案**（实测插入 `买一套送一套【植萃香氛彩染】赠送工具`，页面上显示成 `两套装【植萃香氛彩染】赠送工具`）。**读回校验时要以页面当前文案为准，不要拿自己输入的串去比。**

## 交付口径（十一）
- 只传配图，**绝不点保存/提交**；传完报「已传 N/失败 M + 仍为空清单」，让人核完自己保存。
- ⚠️ **不要覆盖已有图的槽位**——先跑一遍「哪些格已有图」的清单，默认跳过；要覆盖先问。
- 留一张截图 + 逐槽缩略图核验结果一起给，识别类核对以 DOM 数据为准（视觉读数会出错）。
